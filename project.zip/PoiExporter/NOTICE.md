# Third-party components
- **Proj4J 1.4.3** (Apache License 2.0) — sources under `app/src/main/java/org/locationtech/proj4j`, parameter files under `app/src/main/resources/proj4`. See `LICENSE-proj4j.txt`. EPSG parameter data come from the PROJ/Proj4J distribution (EPSG registry, IOGP terms).
- **JTS Topology Suite 1.20.0** (Eclipse Distribution License 1.0 / EPL 2.0) — Maven dependency `org.locationtech.jts:jts-core`.
- **osmdroid 6.1.18** (Apache License 2.0).
- Map data © OpenStreetMap contributors (ODbL). Tiles of third parties are subject to their own terms of service.
- **iraqi-geography-data** (MIT) — Iraqi governorates, districts and cities, `app/src/main/resources/geo/iraq_geography.json`. Source: https://github.com/hoshmandent/iraqi-geography-data (commit 6c4f8477ff957ecdfb3e6e4a558aeec8be5454a4). English names, coordinates and populations are as published there; the Arabic names and notes were added for this app. Licence text:

```
MIT License

Copyright (c) 2024 Hoshmand M. Qadir

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
