# Third-party components
- **Proj4J 1.4.3** (Apache License 2.0) — sources under `app/src/main/java/org/locationtech/proj4j`, parameter files under `app/src/main/resources/proj4`. See `LICENSE-proj4j.txt`. EPSG parameter data come from the PROJ/Proj4J distribution (EPSG registry, IOGP terms).
- **JTS Topology Suite 1.20.0** (Eclipse Distribution License 1.0 / EPL 2.0) — Maven dependency `org.locationtech.jts:jts-core`.
- **osmdroid 6.1.18** (Apache License 2.0).
- Map data © OpenStreetMap contributors (ODbL). Tiles of third parties are subject to their own terms of service.
