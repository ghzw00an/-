package iq.gis.poiexporter;

import android.app.Dialog;
import android.content.Intent;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.PlusCode;

/** Plus Codes: paste a list to import as a layer, or export a layer's landmarks as codes. */
final class PlusTools {
    private PlusTools() {
    }

    private static android.view.View scroll(MainActivity a, LinearLayout box) {
        ScrollView sv = new ScrollView(a);
        sv.addView(box);
        LinearLayout o = new LinearLayout(a);
        o.setOrientation(LinearLayout.VERTICAL);
        o.addView(sv, new LinearLayout.LayoutParams(-1, Ui.dp(a, 480)));
        return o;
    }


    // ------------------------------------------------------------------ import from pasted text

    static void importDialog(final MainActivity a) {
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, "📍 " + S.t("استيراد Plus Codes", "Import Plus Codes")));
        box.addView(UiKit.note(a, S.t("الصق الأكواد، كل سطر كود (واختيارياً اسم المعلم بعده)، مثل:\n8FVC2222+22  مدرسة النور\n9QCJ+2VX  مستشفى\n\n"
                        + "الأكواد القصيرة (بلا الأحرف الأولى) تُفهم بالنسبة لمركز الخريطة الحالي، فحرّك الخريطة إلى المدينة أولاً. "
                        + "اسم المدينة بعد الكود يُحفظ مع الاسم ولا يُستخدم لتحديد الموقع (لا بحث عن أسماء بلا إنترنت).",
                "Paste codes, one per line, optionally followed by the landmark name:\n8FVC2222+22  Nour school\n9QCJ+2VX  Hospital\n\n"
                        + "Short codes (without the leading letters) are read relative to the current map centre, so move the map to the city first. "
                        + "A town name after the code is kept in the name and is not used to find the place (no offline place lookup).")));
        final EditText txt = Ui.field(a, S.t("الأكواد", "Codes"), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        txt.setMinLines(6);
        txt.setGravity(Gravity.TOP | Gravity.START);
        txt.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_LTR);
        box.addView(txt, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        final EditText layer = Ui.field(a, S.t("اسم الطبقة", "Layer name"), InputType.TYPE_CLASS_TEXT);
        layer.setText(S.t("أكواد Plus", "Plus Codes"));
        box.addView(layer, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        final boolean[] fill = {true};
        box.addView(UiKit.check(a, S.t("ملء القضاء والمحافظة من الحدود المرجعية", "Fill district and governorate from the boundaries"), true, v -> fill[0] = v));
        final TextView info = UiKit.note(a, "");
        box.addView(info);
        final Dialog d = a.card(scroll(a, box));
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, d::dismiss), Ui.lp(0, -2, 1f, a, 0, 10, 4, 0));
        r.addView(Ui.button(a, S.t("استيراد", "Import"), true, () -> {
            if (a.map != null) {
                org.osmdroid.api.IGeoPoint c = a.map.getMapCenter();
                PlusCode.setReference(c.getLatitude(), c.getLongitude());
            }
            Result res = parse(txt.getText().toString(), fill[0]);
            if (res.features.isEmpty()) {
                info.setTextColor(Theme.danger);
                info.setText(S.t("لا توجد أكواد صالحة. ", "No valid codes. ") + res.badSummary());
                return;
            }
            LayerData l = new LayerData(Library.newId(), layer.getText().toString().trim().isEmpty() ? "Plus Codes" : layer.getText().toString().trim(), Feature.POINT);
            l.features.addAll(res.features);
            LayerData added = MainActivity.WS.addLayerWithFeatures(l);
            d.dismiss();
            a.rebuild();
            a.showMap();
            a.zoomToLayer(added);
            a.toast(S.t("تم استيراد " + res.features.size() + " معلم", res.features.size() + " landmarks imported")
                    + (res.bad.isEmpty() ? "" : S.t(" • تعذّر " + res.bad.size(), " • failed " + res.bad.size())));
            if (!res.bad.isEmpty()) a.message(S.t("أسطر لم تُستورد", "Lines not imported"), res.badSummary(), null, null);
        }), Ui.lp(0, -2, 1f, a, 4, 10, 0, 0));
        box.addView(r);
        d.show();
    }

    static final class Result {
        final List<Feature> features = new ArrayList<>();
        final List<String> bad = new ArrayList<>();

        String badSummary() {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < Math.min(bad.size(), 12); i++) b.append(bad.get(i)).append('\n');
            if (bad.size() > 12) b.append("…");
            return b.toString();
        }
    }

    /** One landmark per line: a Plus Code anywhere in the line, the rest of the line is the name. Needs the reference set for short codes. */
    static Result parse(String text, boolean fillAdmin) {
        Result r = new Result();
        iq.gis.poiexporter.core.admin.AdminRef ar = null;
        if (fillAdmin) {
            try {
                ar = iq.gis.poiexporter.core.admin.AdminRef.get();
            } catch (RuntimeException ignored) {
                // no boundaries offline
            }
        }
        String day = java.time.LocalDate.now().toString();
        int n = 0;
        for (String line : text.split("\\r?\\n")) {
            String s = line.trim();
            if (s.isEmpty()) continue;
            n++;
            String code = PlusCode.find(s);
            if (code == null) {
                r.bad.add(n + ": " + s + "  — " + S.t("لا يوجد كود صالح", "no valid code"));
                continue;
            }
            double[] ll;
            try {
                ll = PlusCode.toLatLon(code);
            } catch (IllegalArgumentException e) {
                r.bad.add(n + ": " + s + "  — " + S.t("كود قصير بلا مرجع", "short code without a reference"));
                continue;
            }
            String name = s.replace(s.substring(s.toUpperCase(Locale.ROOT).indexOf(code), s.toUpperCase(Locale.ROOT).indexOf(code) + code.length()), " ")
                    .replaceAll("^[\\s,،;:|\\-–\\t]+|[\\s,،;:|\\-–\\t]+$", "").replaceAll("\\s{2,}", " ");
            Feature f = Feature.point(ll[0], ll[1]);
            f.name = name;
            f.updated = day;
            if (ar != null) {
                try {
                    iq.gis.poiexporter.core.admin.AdminRef.Hit hit = ar.locate(f.lat, f.lon);
                    if (hit != null && hit.found()) {
                        f.qadaa = hit.qadaa(true);
                        f.governorate = hit.governorate(true);
                    }
                } catch (RuntimeException ignored) {
                    // leave empty
                }
            }
            r.features.add(f);
        }
        return r;
    }

    // ------------------------------------------------------------------ export as text

    static void exportDialog(final MainActivity a) {
        final List<LayerData> ls = new ArrayList<>(MainActivity.LIB);
        ls.addAll(MainActivity.DL);
        if (ls.isEmpty()) {
            a.toast(S.t("لا توجد طبقات", "No layers"));
            return;
        }
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, "📍 " + S.t("تصدير Plus Codes", "Export Plus Codes")));
        box.addView(UiKit.note(a, S.t("اختر طبقة، فتُنشأ قائمة: الكود الكامل ثم اسم المعلم. تُنسخ أو تُشارك كنص.",
                "Pick a layer: a list of full code and landmark name is made, to copy or share as text.")));
        final Dialog d = a.card(scroll(a, box));
        for (final LayerData l : ls) {
            if (l.features.isEmpty()) continue;
            LinearLayout c = Ui.card(a);
            c.addView(UiKit.headerRow(a, l.color, l.label, String.valueOf(l.features.size()), LayerData.geomName(l.geom), false));
            c.setClickable(true);
            Ui.pressable(c);
            c.setOnClickListener(v -> {
                d.dismiss();
                show(a, l);
            });
            box.addView(c);
        }
        d.show();
    }

    static String listing(LayerData l, boolean withShort, double refLat, double refLon) {
        StringBuilder b = new StringBuilder();
        for (Feature f : l.features) {
            double lat = f.lat, lon = f.lon;
            if (Double.isNaN(lat) || Double.isNaN(lon)) continue;
            String code = PlusCode.encode(lat, lon, 10);
            if (withShort) code = PlusCode.shorten(code, refLat, refLon);
            b.append(code);
            if (!f.name.isEmpty()) b.append("  ").append(f.name);
            b.append('\n');
        }
        return b.toString();
    }

    private static void show(final MainActivity a, final LayerData l) {
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, l.label));
        double[] c = a.map == null ? new double[]{33.3, 44.4} : new double[]{a.map.getMapCenter().getLatitude(), a.map.getMapCenter().getLongitude()};
        final String full = listing(l, false, c[0], c[1]);
        final String sh = listing(l, true, c[0], c[1]);
        TextView t = Ui.text(a, full, 13, Theme.text, false);
        t.setTypeface(android.graphics.Typeface.MONOSPACE);
        t.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_LTR);
        t.setTextIsSelectable(true);
        box.addView(t);
        final Dialog d = a.card(scroll(a, box));
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("نسخ", "Copy"), false, () -> a.copy(full)), Ui.lp(0, -2, 1f, a, 0, 10, 3, 0));
        r.addView(Ui.button(a, S.t("نسخ مختصر", "Copy short"), false, () -> a.copy(sh)), Ui.lp(0, -2, 1f, a, 3, 10, 3, 0));
        r.addView(Ui.button(a, S.t("مشاركة", "Share"), true, () -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, full);
            a.startActivity(Intent.createChooser(i, S.t("مشاركة", "Share")));
        }), Ui.lp(0, -2, 1f, a, 3, 10, 0, 0));
        box.addView(r);
        box.addView(UiKit.note(a, S.t("المختصر يحذف الأحرف الأولى ويصح قرب مركز الخريطة الحالي فقط.", "The short form drops the leading letters and is valid only near the current map centre.")));
        d.show();
    }
}
