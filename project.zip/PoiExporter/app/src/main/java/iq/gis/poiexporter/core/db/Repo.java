package iq.gis.poiexporter.core.db;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;

import java.util.List;

/** Storage behind a Workspace: SQLite on Android ({@code iq.gis.poiexporter.SqliteRepo}), memory in tests. */
public interface Repo {
    List<ProjectInfo> projects();

    ProjectInfo createProject(String name);

    void renameProject(String id, String name);

    /** Deletes the project with all layers, features and history. */
    void deleteProject(String id);

    /** Layers of the project (not deleted) including their features. */
    List<LayerData> loadLayers(String projectId);

    /** One layer with its (not deleted) features, or null. */
    LayerData loadLayer(String layerId);

    /** Insert or update the layer record (not its features). */
    void saveLayerMeta(String projectId, LayerData l);

    void setLayerDeleted(String layerId, boolean deleted);

    /** Insert or replace the features (and mark them not deleted). */
    void saveFeatures(String layerId, List<Feature> fs);

    void setFeaturesDeleted(List<String> ids, boolean deleted);

    void purgeFeatures(List<String> ids);

    void purgeLayer(String layerId);

    Feature getFeature(String id);

    /** Like getFeature but also returns soft-deleted features (needed by undo). */
    Feature getFeatureAny(String id);

    /** Features of the project whose text fields match (local offline search). */
    List<Feature> search(String projectId, String text, int limit);

    long addHistory(String projectId, HistoryEntry e);

    /** Oldest first. */
    List<HistoryEntry> history(String projectId);

    void setHistoryUndone(long seq, boolean undone);

    void deleteHistory(List<Long> seqs);

    String getMeta(String key, String def);

    void setMeta(String key, String value);
}
