package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.core.crs.Crs;

/** Options for ExportHub. */
public final class ExportOptions {
    /** Target CRS; null means WGS84. */
    public Crs target;
    /** Write attributes (landmark fields and imported attributes), not only geometry. */
    public boolean attributes = true;
    public String docName = "PoiExporter";

    public Crs target() {
        return target == null ? Crs.wgs84() : target;
    }

    public static ExportOptions wgs84() {
        return new ExportOptions();
    }
}
