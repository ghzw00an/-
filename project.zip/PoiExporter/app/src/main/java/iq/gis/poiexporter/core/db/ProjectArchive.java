package iq.gis.poiexporter.core.db;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.MiniJson;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Backup / restore of one project as a ZIP: manifest.json plus one JSON-lines file per layer. Lossless (all fields, holes, history not included). */
public final class ProjectArchive {
    private ProjectArchive() {
    }

    public static final String FORMAT = "poiexporter-project";

    public static void write(String projectName, List<LayerData> layers, OutputStream os) throws IOException {
        ZipOutputStream z = new ZipOutputStream(os);
        z.setLevel(6);
        StringBuilder man = new StringBuilder("{\"format\":\"" + FORMAT + "\",\"version\":1,\"name\":");
        MiniJson.quote(projectName, man);
        man.append(",\"created\":");
        MiniJson.quote(java.time.Instant.now().toString(), man);
        man.append(",\"layers\":[");
        for (int i = 0; i < layers.size(); i++) {
            if (i > 0) man.append(',');
            man.append(FeatureJson.layerJson(layers.get(i)));
        }
        man.append("]}");
        put(z, "manifest.json", man.toString().getBytes(StandardCharsets.UTF_8));
        for (LayerData l : layers) {
            z.putNextEntry(new ZipEntry("layers/" + l.id + ".jsonl"));
            for (Feature f : l.features) z.write((FeatureJson.toJson(f) + "\n").getBytes(StandardCharsets.UTF_8));
            z.closeEntry();
        }
        z.finish();
    }

    private static void put(ZipOutputStream z, String name, byte[] data) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(data);
        z.closeEntry();
    }

    public static final class Restored {
        public String name;
        public final List<LayerData> layers = new ArrayList<>();
    }

    @SuppressWarnings("unchecked")
    public static Restored read(InputStream in) throws IOException {
        ZipInputStream z = new ZipInputStream(in);
        Restored r = new Restored();
        Map<String, LayerData> byId = new java.util.LinkedHashMap<>();
        Map<String, List<Feature>> feats = new java.util.HashMap<>();
        boolean manifest = false;
        ZipEntry e;
        while ((e = z.getNextEntry()) != null) {
            String n = e.getName();
            if (n.contains("..")) continue;
            if (n.equals("manifest.json")) {
                String s = new String(readAll(z), StandardCharsets.UTF_8);
                Map<String, Object> m = MiniJson.obj(s);
                if (!FORMAT.equals(MiniJson.str(m, "format", ""))) throw new IOException("not a project archive");
                r.name = MiniJson.str(m, "name", "project");
                for (Object o : (List<Object>) m.get("layers")) {
                    LayerData l = FeatureJson.layerFrom((Map<String, Object>) o);
                    byId.put(l.id, l);
                }
                manifest = true;
            } else if (n.startsWith("layers/") && n.endsWith(".jsonl")) {
                String id = n.substring(7, n.length() - 6);
                List<Feature> fs = new ArrayList<>();
                BufferedReader br = new BufferedReader(new InputStreamReader(new NoClose(z), StandardCharsets.UTF_8));
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.isEmpty()) continue;
                    fs.add(FeatureJson.fromJson(line));
                }
                feats.put(id, fs);
            }
        }
        if (!manifest) throw new IOException("not a project archive");
        for (LayerData l : byId.values()) {
            List<Feature> fs = feats.get(l.id);
            if (fs != null) l.features.addAll(fs);
            r.layers.add(l);
        }
        return r;
    }

    private static final class NoClose extends java.io.FilterInputStream {
        NoClose(InputStream in) {
            super(in);
        }

        @Override
        public void close() {
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        return b.toByteArray();
    }
}
