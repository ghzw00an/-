package iq.gis.poiexporter.core.report;

import iq.gis.poiexporter.core.crs.Crs;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Pure map-layout maths for printed maps. */
public final class MapMath {
    private MapMath() {
    }

    public static final double[] NICE_SCALES = {1000, 2000, 2500, 5000, 10000, 20000, 25000, 50000, 100000, 200000,
            250000, 500000, 1000000, 2000000, 5000000};

    /** Ground distance in metres of one degree of longitude at the latitude (spherical R=6371008.8 m). */
    public static double metresPerDegLon(double lat) {
        return Math.PI / 180 * 6371008.8 * Math.cos(Math.toRadians(lat));
    }

    public static double metresPerDegLat() {
        return Math.PI / 180 * 6371008.8;
    }

    /** Result of fitting a bbox into a page rectangle. */
    public static final class Fit {
        /** Exact scale denominator needed to make the bbox fill the frame (not rounded). */
        public final double exactScale;
        /** Nice scale denominator (first nice value >= exact, so everything fits). */
        public final double niceScale;
        /** Metres per millimetre of paper at the nice scale (= niceScale / 1000). */
        public final double mPerMm;
        /** bbox {west, south, east, north} actually shown at the nice scale, centred on the original bbox. */
        public final double[] shown;
        public final double widthM, heightM;

        Fit(double e, double n, double[] shown, double w, double h) {
            exactScale = e;
            niceScale = n;
            mPerMm = n / 1000.0;
            this.shown = shown;
            widthM = w;
            heightM = h;
        }
    }

    /**
     * Fits the lon/lat bbox {west,south,east,north} into a frame of frameWmm x frameHmm millimetres. The scale is the
     * smallest nice scale (1:1000..1:5,000,000) at which the whole bbox fits; if none fits the exact scale is used.
     */
    public static Fit fit(double[] bbox, double frameWmm, double frameHmm) {
        double lat0 = (bbox[1] + bbox[3]) / 2;
        double wM = Math.max(1e-6, (bbox[2] - bbox[0]) * metresPerDegLon(lat0));
        double hM = Math.max(1e-6, (bbox[3] - bbox[1]) * metresPerDegLat());
        double exact = Math.max(wM / (frameWmm / 1000.0), hM / (frameHmm / 1000.0));
        double nice = exact;
        for (double s : NICE_SCALES) {
            if (s >= exact) {
                nice = s;
                break;
            }
        }
        double shownW = frameWmm / 1000.0 * nice, shownH = frameHmm / 1000.0 * nice;
        double cx = (bbox[0] + bbox[2]) / 2, cy = lat0;
        double dLon = shownW / 2 / metresPerDegLon(lat0), dLat = shownH / 2 / metresPerDegLat();
        return new Fit(exact, nice, new double[]{cx - dLon, cy - dLat, cx + dLon, cy + dLat}, shownW, shownH);
    }

    /** Scale denominator from ground resolution (metres per pixel) and print resolution (dots per inch). */
    public static double scaleFor(double metresPerPixel, double dpi) {
        return metresPerPixel * dpi / 0.0254;
    }

    /** Metres per pixel for a scale denominator at a dpi. */
    public static double metresPerPixel(double scale, double dpi) {
        return scale * 0.0254 / dpi;
    }

    /** Largest 1-2-5 x 10^n length not exceeding maxMetres (>= 1 m). */
    public static double niceScaleBarLength(double maxMetres) {
        if (!(maxMetres >= 1)) return 1;
        double p = Math.pow(10, Math.floor(Math.log10(maxMetres)));
        double[] m = {5, 2, 1};
        for (double k : m) if (k * p <= maxMetres * (1 + 1e-12)) return k * p;
        return p;
    }

    public static String scaleBarLabel(double metres, boolean arabic) {
        if (metres >= 1000) {
            double km = metres / 1000;
            String s = km == Math.rint(km) ? String.valueOf((long) km) : String.format(Locale.US, "%.1f", km);
            return s + (arabic ? " كم" : " km");
        }
        return (long) metres + (arabic ? " م" : " m");
    }

    // ------------------------------------------------------------------ grids

    /** A labelled grid line as a lon/lat polyline (interleaved lon,lat). */
    public static final class GridLine {
        public final double[] lonlat;
        public final String label;
        public final boolean vertical; // meridian / easting line
        public final double value;

        GridLine(double[] p, String label, boolean vertical, double value) {
            this.lonlat = p;
            this.label = label;
            this.vertical = vertical;
            this.value = value;
        }
    }

    /** Nice step (degrees) giving about target lines over the span: 1,2,5 x 10^n degrees, or 1/2/5/10/15/30 arc-minutes. */
    public static double niceDegreeStep(double spanDeg, int targetLines) {
        double raw = spanDeg / Math.max(1, targetLines);
        double[] steps = {1.0 / 3600, 2.0 / 3600, 5.0 / 3600, 10.0 / 3600, 15.0 / 3600, 30.0 / 3600, 1.0 / 60, 2.0 / 60, 5.0 / 60,
                10.0 / 60, 15.0 / 60, 30.0 / 60, 1, 2, 5, 10, 20, 30};
        for (double s : steps) if (s >= raw * 0.999) return s;
        return 30;
    }

    /** Graticule lines inside bbox {west,south,east,north}. */
    public static List<GridLine> graticule(double[] bbox, int targetLines, boolean dms) {
        List<GridLine> res = new ArrayList<>();
        double step = niceDegreeStep(Math.max(bbox[2] - bbox[0], bbox[3] - bbox[1]), targetLines);
        for (double lon = Math.ceil(bbox[0] / step - 1e-9) * step; lon <= bbox[2] + 1e-12; lon += step) {
            double v = Math.round(lon / step) * step;
            res.add(new GridLine(new double[]{v, bbox[1], v, bbox[3]}, degLabel(v, step, true, dms), true, v));
        }
        for (double lat = Math.ceil(bbox[1] / step - 1e-9) * step; lat <= bbox[3] + 1e-12; lat += step) {
            double v = Math.round(lat / step) * step;
            res.add(new GridLine(new double[]{bbox[0], v, bbox[2], v}, degLabel(v, step, false, dms), false, v));
        }
        return res;
    }

    public static String degLabel(double v, double step, boolean lon, boolean dms) {
        char h = lon ? (v < 0 ? 'W' : 'E') : (v < 0 ? 'S' : 'N');
        double a = Math.abs(v);
        if (!dms) {
            int dec = step >= 1 ? 0 : step >= 0.1 ? 1 : step >= 0.01 ? 2 : step >= 0.001 ? 3 : 4;
            return String.format(Locale.US, "%." + dec + "f°%c", a, h);
        }
        long cs = Math.round(a * 3600);
        long d = cs / 3600, m = (cs % 3600) / 60, s = cs % 60;
        if (step >= 1) return String.format(Locale.US, "%d°%c", d, h);
        if (step >= 1.0 / 60 - 1e-9) return String.format(Locale.US, "%d°%02d'%c", d, m, h);
        return String.format(Locale.US, "%d°%02d'%02d\"%c", d, m, s, h);
    }

    /** Nice grid interval in metres (1,2,5 x 10^n) giving about target lines over spanM. */
    public static double niceMetreStep(double spanM, int targetLines) {
        double raw = spanM / Math.max(1, targetLines);
        double p = Math.pow(10, Math.floor(Math.log10(raw)));
        for (double k : new double[]{1, 2, 5, 10}) if (k * p >= raw * 0.999) return k * p;
        return 10 * p;
    }

    /**
     * UTM grid lines for bbox {west,south,east,north} in the given UTM CRS: easting lines and northing lines at nice
     * kilometre steps, each returned as a densified polyline in lon/lat (curved on a lon/lat map), label e.g. "444 km E".
     */
    public static List<GridLine> utmGrid(double[] bbox, Crs utm, int targetLines) {
        Crs wgs = Crs.wgs84();
        Crs.Tx fwd = wgs.to(utm), inv = utm.to(wgs);
        double[] e = {Double.MAX_VALUE, Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE};
        double[] o = new double[2];
        int n = 20;
        for (int i = 0; i <= n; i++) {
            for (int k = 0; k <= n; k++) {
                fwd.apply(bbox[0] + (bbox[2] - bbox[0]) * i / n, bbox[1] + (bbox[3] - bbox[1]) * k / n, o);
                e[0] = Math.min(e[0], o[0]);
                e[1] = Math.min(e[1], o[1]);
                e[2] = Math.max(e[2], o[0]);
                e[3] = Math.max(e[3], o[1]);
            }
        }
        double step = Math.max(1000, niceMetreStep(Math.max(e[2] - e[0], e[3] - e[1]), targetLines));
        List<GridLine> res = new ArrayList<>();
        int seg = 24;
        for (double x = Math.ceil(e[0] / step) * step; x <= e[2]; x += step) {
            double[] line = new double[(seg + 1) * 2];
            for (int i = 0; i <= seg; i++) {
                inv.apply(x, e[1] + (e[3] - e[1]) * i / seg, o);
                line[2 * i] = o[0];
                line[2 * i + 1] = o[1];
            }
            res.add(new GridLine(line, String.format(Locale.US, "%d km E", Math.round(x / 1000)), true, x));
        }
        for (double y = Math.ceil(e[1] / step) * step; y <= e[3]; y += step) {
            double[] line = new double[(seg + 1) * 2];
            for (int i = 0; i <= seg; i++) {
                inv.apply(e[0] + (e[2] - e[0]) * i / seg, y, o);
                line[2 * i] = o[0];
                line[2 * i + 1] = o[1];
            }
            res.add(new GridLine(line, String.format(Locale.US, "%d km N", Math.round(y / 1000)), false, y));
        }
        // keep only parts of lines within the bbox (clip by dropping points far outside)
        return res;
    }

    /** Angle (degrees, clockwise) to draw the north arrow when the map is rotated by mapRotationDeg (map "up" bearing). */
    public static double northArrowAngle(double mapRotationDeg) {
        double a = -mapRotationDeg % 360;
        return a < 0 ? a + 360 : a;
    }

    /** Grid convergence (degrees, +east) of a UTM zone at lon/lat: true north vs grid north. */
    public static double gridConvergence(double lon, double lat, int zone) {
        double cm = (zone - 1) * 6 - 180 + 3;
        return Math.toDegrees(Math.atan(Math.tan(Math.toRadians(lon - cm)) * Math.sin(Math.toRadians(lat))));
    }

    /** One legend row. */
    public static final class LegendEntry {
        public final String label;
        public final int argb;
        public final int geom; // Feature.POINT/LINE/POLYGON
        public final int count;

        public LegendEntry(String label, int argb, int geom, int count) {
            this.label = label;
            this.argb = argb;
            this.geom = geom;
            this.count = count;
        }
    }

    public static LegendEntry legend(String label, int argb, int geom, int count) {
        return new LegendEntry(label, argb, geom, count);
    }
}
