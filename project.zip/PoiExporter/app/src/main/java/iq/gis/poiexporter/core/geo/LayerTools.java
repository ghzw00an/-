package iq.gis.poiexporter.core.geo;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.Jts;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.Sectors;
import iq.gis.poiexporter.core.io.DupFinder;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Envelope;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.prep.PreparedGeometry;
import org.locationtech.jts.geom.prep.PreparedGeometryFactory;
import org.locationtech.jts.index.strtree.STRtree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Second family of layer tools: generating features (rings, points along lines, vertices, boundaries, random and
 * regular points, multipart split), overlay between two layers (erase, intersect, count in polygons, nearest join,
 * within distance of another layer), grouping (dissolve and hull by field, mean centre) and bulk editing
 * (auto sector, set / replace / clean text, add measures). Editing tools return before/after pairs so the caller can
 * apply them as ONE undo step.
 */
public final class LayerTools {
    private LayerTools() {
    }

    private static IllegalArgumentException bad(String ar, String en) {
        return new IllegalArgumentException(S.t(ar, en));
    }

    private static LayerData result(LayerData src, String label, int geom) {
        LayerData r = new LayerData("lt_" + Feature.newId(), label, geom);
        r.color = src.color;
        r.width = src.width;
        r.opacity = src.opacity;
        r.kind = "result";
        return r;
    }

    private static Feature meta(Feature from, Feature to) {
        to.name = from.name;
        to.type = from.type;
        to.category = from.category;
        to.qadaa = from.qadaa;
        to.nahiya = from.nahiya;
        to.governorate = from.governorate;
        to.attrs.putAll(from.attrs);
        return to;
    }

    private static Feature line(double[] pts) {
        Feature f = new Feature();
        f.geom = Feature.LINE;
        f.id = Feature.newId();
        f.parts.add(pts);
        Geo.setRepresentative(f);
        return f;
    }

    // ---------------------------------------------------------------------------------------------- rings

    /** Concentric ring buffers (donuts) at the given distances around every feature; attrs ring_m. */
    public static LayerData multiRing(LayerData src, double[] distances) {
        double[] d = Arrays.stream(distances).filter(x -> x > 0).sorted().distinct().toArray();
        if (d.length == 0) throw bad("أدخل مسافة موجبة واحدة على الأقل", "Enter at least one positive distance");
        if (d.length > 10) throw bad("حتى 10 حلقات", "Up to 10 rings");
        if (src.features.size() > 1500) throw bad("أكثر من 1500 عنصر: صفّ الطبقة أولاً", "More than 1500 features: filter the layer first");
        LayerData r = result(src, src.label + S.t(" (حلقات)", " (rings)"), Feature.POLYGON);
        for (Feature f : src.features) {
            if (f.parts.isEmpty()) continue;
            Feature prev = null;
            for (double m : d) {
                Feature b = GeoOps.buffer(f, m, 16);
                if (b == null) continue;
                Feature ring = prev == null ? b : GeoOps.difference(b, prev);
                prev = b;
                if (ring == null) continue;
                ring.id = Feature.newId();
                meta(f, ring);
                ring.attrs.put("ring_m", String.valueOf(Math.round(m)));
                r.features.add(ring);
            }
        }
        return r;
    }

    // ---------------------------------------------------------------------------------------------- along lines

    /** Points every intervalM metres along lines and polygon outlines (restarting on each part); attrs dist_m. */
    public static LayerData alongLines(LayerData src, double intervalM, boolean includeEnds) {
        if (!(intervalM > 0)) throw bad("المسافة يجب أن تكون موجبة", "Interval must be positive");
        List<Feature> fs = new ArrayList<>();
        for (Feature f : src.features) if (f.geom != Feature.POINT && !f.parts.isEmpty()) fs.add(f);
        if (fs.isEmpty()) throw bad("الطبقة بلا خطوط أو مضلعات", "The layer has no lines or polygons");
        double total = 0;
        for (Feature f : fs) for (double[] p : f.parts) total += Geodesy.pathLength(p);
        if (total / intervalM > 200_000) throw bad("عدد النقاط كبير جداً، زد المسافة", "Too many points; increase the interval");
        LayerData r = result(src, src.label + S.t(" (نقاط كل ", " (points every ") + Math.round(intervalM) + " m)", Feature.POINT);
        for (Feature f : fs) {
            for (double[] p : f.parts) {
                double next = 0, run = 0;
                int n = p.length / 2;
                for (int i = 0; i + 1 < n; i++) {
                    double seg = Geodesy.distance(p[2 * i + 1], p[2 * i], p[2 * i + 3], p[2 * i + 2]);
                    while (next <= run + seg + 1e-9) {
                        double t = seg == 0 ? 0 : (next - run) / seg;
                        Feature pt = Feature.point(p[2 * i + 1] + (p[2 * i + 3] - p[2 * i + 1]) * t, p[2 * i] + (p[2 * i + 2] - p[2 * i]) * t);
                        meta(f, pt);
                        pt.attrs.put("dist_m", String.valueOf(Math.round(next)));
                        r.features.add(pt);
                        next += intervalM;
                    }
                    run += seg;
                }
                if (includeEnds && n >= 2 && run - (next - intervalM) > 1e-6) {
                    Feature pt = Feature.point(p[2 * n - 1], p[2 * n - 2]);
                    meta(f, pt);
                    pt.attrs.put("dist_m", String.valueOf(Math.round(run)));
                    r.features.add(pt);
                }
            }
        }
        return r;
    }

    // ---------------------------------------------------------------------------------------------- vertices / boundaries / explode

    public static LayerData vertices(LayerData src) {
        long est = 0;
        for (Feature f : src.features) for (double[] p : f.parts) est += p.length / 2;
        if (est > 300_000) throw bad("عدد الرؤوس كبير جداً (" + est + ")", "Too many vertices (" + est + ")");
        LayerData r = result(src, src.label + S.t(" (رؤوس)", " (vertices)"), Feature.POINT);
        for (Feature f : src.features) {
            for (GeoOps.Vertex v : GeoOps.vertices(f)) {
                Feature pt = Feature.point(v.lat, v.lon);
                meta(f, pt);
                pt.attrs.put("part", String.valueOf(v.part));
                pt.attrs.put("index", String.valueOf(v.index));
                r.features.add(pt);
            }
        }
        return r;
    }

    /** Polygon outlines as lines (one line per ring). */
    public static LayerData boundaries(LayerData src) {
        LayerData r = result(src, src.label + S.t(" (حدود)", " (outlines)"), Feature.LINE);
        for (Feature f : src.features) {
            if (f.geom != Feature.POLYGON) continue;
            for (int i = 0; i < f.parts.size(); i++) {
                Feature l = line(f.parts.get(i).clone());
                meta(f, l);
                l.attrs.put("ring", f.isHole(i) ? "hole" : "outer");
                r.features.add(l);
            }
        }
        if (r.features.isEmpty()) throw bad("لا توجد مضلعات", "No polygons");
        return r;
    }

    /** One feature per part of multipart lines and polygons (holes stay with their polygon). */
    public static LayerData explode(LayerData src) {
        LayerData r = result(src, src.label + S.t(" (أجزاء)", " (parts)"), src.geom);
        for (Feature f : src.features) {
            if (f.geom == Feature.POINT) {
                r.features.add(f.copy());
                continue;
            }
            Geometry g = Jts.toGeometry(f);
            if (g == null) continue;
            for (int i = 0; i < g.getNumGeometries(); i++) {
                for (Feature x : Jts.toFeatures(g.getGeometryN(i), f)) {
                    if (x.geom != f.geom) continue;
                    x.id = Feature.newId();
                    r.features.add(x);
                }
            }
        }
        return r;
    }

    // ---------------------------------------------------------------------------------------------- random / regular points

    /** n random points inside the polygons (share per polygon proportional to its area); repeatable with the same seed. */
    public static LayerData randomPoints(LayerData src, int n, long seed) {
        if (n < 1 || n > 50_000) throw bad("العدد بين 1 و50000", "Count must be 1 to 50000");
        List<Feature> polys = new ArrayList<>();
        double[] area = new double[src.features.size()];
        double total = 0;
        for (Feature f : src.features) {
            if (f.geom != Feature.POLYGON) continue;
            double a;
            try {
                a = Geodesy.area(f);
            } catch (RuntimeException e) {
                continue;
            }
            if (a <= 0) continue;
            area[polys.size()] = a;
            total += a;
            polys.add(f);
        }
        if (polys.isEmpty()) throw bad("لا توجد مضلعات", "No polygons");
        Random rnd = new Random(seed);
        LayerData r = result(src, src.label + S.t(" (نقاط عشوائية)", " (random points)"), Feature.POINT);
        int made = 0;
        for (int i = 0; i < polys.size(); i++) {
            int share = i == polys.size() - 1 ? n - made : (int) Math.round(n * area[i] / total);
            share = Math.max(0, Math.min(share, n - made));
            Feature f = polys.get(i);
            Geometry g = Jts.toGeometry(f);
            if (g == null) continue;
            if (!g.isValid()) g = g.buffer(0);
            PreparedGeometry prep = PreparedGeometryFactory.prepare(g);
            Envelope e = g.getEnvelopeInternal();
            int got = 0, tries = 0;
            while (got < share && tries < share * 400L + 1000) {
                tries++;
                double x = e.getMinX() + rnd.nextDouble() * e.getWidth(), y = e.getMinY() + rnd.nextDouble() * e.getHeight();
                if (!prep.covers(Jts.GF.createPoint(new Coordinate(x, y)))) continue;
                Feature pt = Feature.point(y, x);
                pt.name = f.name;
                r.features.add(pt);
                got++;
            }
            made += got;
        }
        return r;
    }

    /** Regular point grid inside every polygon (spacing in metres). */
    public static LayerData regularPoints(LayerData src, double spacingM) {
        LayerData r = result(src, src.label + S.t(" (شبكة نقاط ", " (point grid ") + Math.round(spacingM) + " m)", Feature.POINT);
        for (Feature f : src.features) {
            if (f.geom != Feature.POLYGON) continue;
            for (Feature p : GeoOps.pointGrid(f, spacingM)) {
                p.id = Feature.newId();
                p.name = f.name;
                r.features.add(p);
                if (r.features.size() > 300_000) throw bad("عدد النقاط كبير جداً", "Too many points");
            }
        }
        if (r.features.isEmpty()) throw bad("لا نقاط ضمن المضلعات", "No points fall inside the polygons");
        return r;
    }

    // ---------------------------------------------------------------------------------------------- grouping

    private static Map<String, List<Feature>> groups(LayerData src, int fieldIdx) {
        if (fieldIdx < 0 || fieldIdx > 5) throw bad("حقل غير صالح", "Invalid field");
        Map<String, List<Feature>> m = new LinkedHashMap<>();
        Map<String, String> shown = new LinkedHashMap<>();
        for (Feature f : src.features) {
            String v = Analysis.field(f, fieldIdx).trim();
            String k = DupFinder.normName(v);
            if (!shown.containsKey(k)) shown.put(k, v);
            List<Feature> l = m.get(k);
            if (l == null) m.put(k, l = new ArrayList<>());
            l.add(f);
        }
        Map<String, List<Feature>> out = new LinkedHashMap<>();
        for (Map.Entry<String, List<Feature>> e : m.entrySet()) out.put(shown.get(e.getKey()), e.getValue());
        return out;
    }

    /** Polygons merged per value of the field (e.g. one polygon per governorate). */
    public static LayerData dissolveBy(LayerData src, int fieldIdx) {
        if (src.geom != Feature.POLYGON) throw bad("الدمج حسب حقل للمضلعات فقط", "Dissolve by field needs polygons");
        LayerData r = result(src, src.label + S.t(" (دمج حسب ", " (dissolved by ") + Analysis.FIELD_NAMES[fieldIdx] + ")", Feature.POLYGON);
        for (Map.Entry<String, List<Feature>> e : groups(src, fieldIdx).entrySet()) {
            Feature u = GeoOps.union(e.getValue());
            if (u == null) continue;
            u.id = Feature.newId();
            u.name = e.getKey();
            u.attrs.put("count", String.valueOf(e.getValue().size()));
            r.features.add(u);
        }
        return r;
    }

    /** Convex hull of the points/features of each value of the field (e.g. the spread of each sector). Groups of fewer than 3 are skipped. */
    public static LayerData hullBy(LayerData src, int fieldIdx) {
        LayerData r = result(src, src.label + S.t(" (غلاف حسب ", " (hull by ") + Analysis.FIELD_NAMES[fieldIdx] + ")", Feature.POLYGON);
        for (Map.Entry<String, List<Feature>> e : groups(src, fieldIdx).entrySet()) {
            if (e.getValue().size() < 3) continue;
            Feature h;
            try {
                h = GeoOps.convexHull(e.getValue());
            } catch (RuntimeException ex) {
                continue;
            }
            if (h == null || h.geom != Feature.POLYGON) continue;
            h.id = Feature.newId();
            h.name = e.getKey();
            h.attrs.put("count", String.valueOf(e.getValue().size()));
            r.features.add(h);
        }
        return r;
    }

    public static final class Centre {
        public double lat, lon, stdDistM;
        public int n;
    }

    /** Mean centre of the layer's points and the standard distance (radius containing about two thirds of a normal spread). */
    public static Centre meanCentre(LayerData src) {
        List<Feature> pts = new ArrayList<>();
        for (Feature f : src.features) if (f.geom == Feature.POINT) pts.add(f);
        if (pts.size() < 2) throw bad("يلزم نقطتان على الأقل", "At least 2 points are needed");
        Analysis.Plane pl = Analysis.Plane.around(pts);
        double sx = 0, sy = 0;
        for (Feature f : pts) {
            sx += pl.x(f.lon);
            sy += pl.y(f.lat);
        }
        double mx = sx / pts.size(), my = sy / pts.size(), ss = 0;
        for (Feature f : pts) {
            double dx = pl.x(f.lon) - mx, dy = pl.y(f.lat) - my;
            ss += dx * dx + dy * dy;
        }
        Centre c = new Centre();
        c.n = pts.size();
        c.lon = pl.lon(mx);
        c.lat = pl.lat(my);
        c.stdDistM = Math.sqrt(ss / pts.size());
        return c;
    }

    /** Layers: the mean centre point and, when radius > 0, the standard-distance circle. */
    public static List<LayerData> meanCentreLayers(LayerData src) {
        Centre c = meanCentre(src);
        LayerData p = result(src, src.label + S.t(" (المركز المتوسط)", " (mean centre)"), Feature.POINT);
        Feature pt = Feature.point(c.lat, c.lon);
        pt.name = S.t("المركز المتوسط", "Mean centre");
        pt.attrs.put("n", String.valueOf(c.n));
        pt.attrs.put("std_dist_m", String.valueOf(Math.round(c.stdDistM)));
        p.features.add(pt);
        List<LayerData> out = new ArrayList<>();
        out.add(p);
        if (c.stdDistM > 0) {
            LayerData circ = result(src, src.label + S.t(" (المسافة المعيارية)", " (standard distance)"), Feature.POLYGON);
            Feature b = GeoOps.buffer(pt, c.stdDistM, 32);
            if (b != null) {
                b.id = Feature.newId();
                b.name = S.t("المسافة المعيارية ", "Standard distance ") + Math.round(c.stdDistM) + " m";
                circ.features.add(b);
                out.add(circ);
            }
        }
        return out;
    }

    // ---------------------------------------------------------------------------------------------- two layers

    private static Feature unionOf(LayerData l, int geom) {
        List<Feature> fs = new ArrayList<>();
        for (Feature f : l.features) if (f.geom == geom && !f.parts.isEmpty()) fs.add(f);
        return fs.isEmpty() ? null : GeoOps.union(fs);
    }

    /** What remains of A after removing the area covered by the polygons of B. */
    public static LayerData erase(LayerData a, LayerData b) {
        if (a.geom == Feature.POINT) throw bad("المحو للخطوط والمضلعات (لا للنقاط)", "Erase works on lines and polygons (not points)");
        Feature cut = unionOf(b, Feature.POLYGON);
        if (cut == null) throw bad("الطبقة الثانية بلا مضلعات", "The second layer has no polygons");
        LayerData r = result(a, a.label + S.t(" − ", " − ") + b.label, a.geom);
        for (Feature f : a.features) {
            Feature d;
            try {
                d = GeoOps.difference(f, cut);
            } catch (RuntimeException e) {
                continue;
            }
            if (d == null || d.geom != a.geom) continue;
            d.id = Feature.newId();
            meta(f, d);
            r.features.add(d);
        }
        return r;
    }

    /** Parts of A that lie inside polygons of B (A's attributes kept, attr b_name = the B polygon's name). */
    public static LayerData intersect(LayerData a, LayerData b) {
        if (a.geom == Feature.POINT) throw bad("للخطوط والمضلعات؛ للنقاط استخدم «عدّ النقاط داخل المضلعات»", "For lines and polygons; for points use \"Count points in polygons\"");
        List<Feature> bs = new ArrayList<>();
        for (Feature f : b.features) if (f.geom == Feature.POLYGON && !f.parts.isEmpty()) bs.add(f);
        if (bs.isEmpty()) throw bad("الطبقة الثانية بلا مضلعات", "The second layer has no polygons");
        if ((long) a.features.size() * bs.size() > 2_000_000L) throw bad("حجم العملية كبير جداً", "Operation too large");
        LayerData r = result(a, a.label + " ∩ " + b.label, a.geom);
        for (Feature f : a.features) {
            double[] fb = Geo.bbox(f);
            for (Feature g : bs) {
                double[] gb = Geo.bbox(g);
                if (fb[0] > gb[2] || fb[2] < gb[0] || fb[1] > gb[3] || fb[3] < gb[1]) continue;
                GeoOps.Overlap o;
                try {
                    o = GeoOps.intersection(f, g);
                } catch (RuntimeException e) {
                    continue;
                }
                if (o == null || o.geometry.geom != a.geom) continue;
                Feature x = o.geometry;
                x.id = Feature.newId();
                meta(f, x);
                x.attrs.put("b_name", g.name);
                r.features.add(x);
            }
        }
        return r;
    }

    /** Copy of the polygons with attr count = number of the points layer's points inside each. */
    public static LayerData countInPolygons(LayerData points, LayerData polys) {
        STRtree tree = new STRtree();
        int np = 0;
        for (Feature f : points.features) {
            if (f.geom != Feature.POINT) continue;
            tree.insert(new Envelope(f.lon, f.lon, f.lat, f.lat), f);
            np++;
        }
        if (np == 0) throw bad("الطبقة الأولى بلا نقاط", "The points layer has no points");
        if (np > 0) tree.build();
        LayerData r = result(polys, polys.label + S.t(" (عدد النقاط)", " (point count)"), Feature.POLYGON);
        for (Feature poly : polys.features) {
            if (poly.geom != Feature.POLYGON) continue;
            Geometry g = Jts.toGeometry(poly);
            if (g == null) continue;
            if (!g.isValid()) g = g.buffer(0);
            PreparedGeometry prep = PreparedGeometryFactory.prepare(g);
            int c = 0;
            for (Object o : tree.query(g.getEnvelopeInternal())) {
                Feature p = (Feature) o;
                if (prep.covers(Jts.GF.createPoint(new Coordinate(p.lon, p.lat)))) c++;
            }
            Feature x = poly.copy();
            x.id = Feature.newId();
            x.attrs.put("count", String.valueOf(c));
            r.features.add(x);
        }
        return r;
    }

    /** Each feature of A gets attrs nearest_name, nearest_m, nearest_deg (compass bearing) of the closest feature of B. */
    public static LayerData nearestJoin(LayerData a, LayerData b) {
        if (b.features.isEmpty()) throw bad("الطبقة الثانية فارغة", "The second layer is empty");
        GeoOps.NearestIndex idx = new GeoOps.NearestIndex(b.features);
        LayerData r = result(a, a.label + S.t(" (+ الأقرب)", " (+ nearest)"), a.geom);
        for (Feature f : a.features) {
            Feature c = f.copy();
            c.id = Feature.newId();
            List<GeoOps.Hit> h = idx.query(f.lat, f.lon, 1);
            if (!h.isEmpty()) {
                c.attrs.put("nearest_name", h.get(0).feature.name);
                c.attrs.put("nearest_m", String.valueOf(Math.round(h.get(0).distanceM)));
                c.attrs.put("nearest_deg", String.valueOf(Math.round(h.get(0).bearingDeg)));
            }
            r.features.add(c);
        }
        return r;
    }

    /** Features of A within radiusM of any feature of B. */
    public static LayerData withinDistanceOf(LayerData a, LayerData b, double radiusM) {
        if (!(radiusM > 0)) throw bad("المسافة يجب أن تكون موجبة", "Distance must be positive");
        if (b.features.isEmpty()) throw bad("الطبقة الثانية فارغة", "The second layer is empty");
        GeoOps.NearestIndex idx = new GeoOps.NearestIndex(b.features);
        LayerData r = result(a, a.label + S.t(" (ضمن ", " (within ") + Math.round(radiusM) + S.t(" م من ", " m of ") + b.label + ")", a.geom);
        for (Feature f : a.features) {
            List<GeoOps.Hit> h = idx.query(f.lat, f.lon, 1);
            if (h.isEmpty() || h.get(0).distanceM > radiusM) continue;
            Feature c = f.copy();
            c.id = Feature.newId();
            c.attrs.put("nearest_m", String.valueOf(Math.round(h.get(0).distanceM)));
            r.features.add(c);
        }
        return r;
    }

    // ---------------------------------------------------------------------------------------------- bulk editing (before/after pairs)

    public static final class Edits {
        public final List<Feature[]> pairs = new ArrayList<>();
        public int skipped;
        public String note = "";
    }

    private static void put(Edits e, Feature before, Feature after) {
        e.pairs.add(new Feature[]{before.copy(), after});
    }

    /** Sets Gategory from type when exactly one sector contains that type. Features whose type fits several sectors or none are skipped. */
    public static Edits autoSector(List<Feature> fs, boolean overwrite) {
        Edits e = new Edits();
        int ambiguous = 0, unknown = 0;
        for (Feature f : fs) {
            if (f.geom != Feature.POINT) continue;
            if (!overwrite && !f.category.trim().isEmpty()) continue;
            List<Sectors.Sector> s = Sectors.allOfItem(f.type);
            if (s.isEmpty()) {
                if (!f.type.trim().isEmpty()) unknown++;
                e.skipped++;
                continue;
            }
            if (s.size() > 1) {
                ambiguous++;
                e.skipped++;
                continue;
            }
            if (s.get(0).name.equals(f.category)) continue;
            Feature a = f.copy();
            a.category = s.get(0).name;
            put(e, f, a);
        }
        e.note = S.t("غامض (يقع في أكثر من قطاع): " + ambiguous + " — نوع غير معروف: " + unknown, "Ambiguous (in several sectors): " + ambiguous + " — unknown type: " + unknown);
        return e;
    }

    private static void set(Feature f, int idx, String v) {
        switch (idx) {
            case 0:
                f.name = v;
                break;
            case 1:
                f.type = v;
                break;
            case 2:
                f.category = v;
                break;
            case 3:
                f.qadaa = v;
                break;
            case 4:
                f.nahiya = v;
                break;
            default:
                f.governorate = v;
        }
    }

    /** Sets a field to a value for every feature (or only the ones where it is empty). */
    public static Edits setField(List<Feature> fs, int fieldIdx, String value, boolean onlyEmpty) {
        if (fieldIdx < 0 || fieldIdx > 5) throw bad("حقل غير صالح", "Invalid field");
        Edits e = new Edits();
        for (Feature f : fs) {
            String cur = Analysis.field(f, fieldIdx);
            if (onlyEmpty && !cur.trim().isEmpty()) continue;
            if (cur.equals(value)) continue;
            Feature a = f.copy();
            set(a, fieldIdx, value);
            put(e, f, a);
        }
        return e;
    }

    /** Plain (case-sensitive) text replacement inside one field. */
    public static Edits replaceText(List<Feature> fs, int fieldIdx, String find, String repl) {
        if (fieldIdx < 0 || fieldIdx > 5) throw bad("حقل غير صالح", "Invalid field");
        if (find == null || find.isEmpty()) throw bad("اكتب النص المراد استبداله", "Enter the text to replace");
        Edits e = new Edits();
        for (Feature f : fs) {
            String cur = Analysis.field(f, fieldIdx);
            if (!cur.contains(find)) continue;
            Feature a = f.copy();
            set(a, fieldIdx, cur.replace(find, repl == null ? "" : repl));
            put(e, f, a);
        }
        return e;
    }

    /** Unifies Arabic letter variants (ى→ي, ک→ك, ی→ي), removes tatweel and diacritics-free spacing problems, trims and collapses spaces. */
    public static String cleanString(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 'ى' || c == 'ی') c = 'ي';
            else if (c == 'ک') c = 'ك';
            else if (c == 'ـ' || c == '‌' || c == '​') continue;
            else if (c == ' ') c = ' ';
            b.append(c);
        }
        return b.toString().trim().replaceAll("\\s+", " ");
    }

    /** Applies {@link #cleanString} to the six text fields. */
    public static Edits cleanText(List<Feature> fs) {
        Edits e = new Edits();
        for (Feature f : fs) {
            Feature a = f.copy();
            boolean ch = false;
            for (int i = 0; i < 6; i++) {
                String cur = Analysis.field(f, i), cl = cleanString(cur);
                if (!cur.equals(cl)) {
                    set(a, i, cl);
                    ch = true;
                }
            }
            if (ch) put(e, f, a);
        }
        return e;
    }

    /** Adds area_m2 + perimeter_m (polygons) or length_m (lines) as attributes. */
    public static Edits addMeasures(List<Feature> fs) {
        Edits e = new Edits();
        for (Feature f : fs) {
            if (f.geom == Feature.POINT) {
                e.skipped++;
                continue;
            }
            Feature a = f.copy();
            try {
                if (f.geom == Feature.POLYGON) {
                    a.attrs.put("area_m2", String.valueOf(Math.round(Geodesy.area(f))));
                    a.attrs.put("perimeter_m", String.valueOf(Math.round(Geodesy.perimeter(f))));
                } else a.attrs.put("length_m", String.valueOf(Math.round(Geodesy.length(f))));
            } catch (RuntimeException ex) {
                e.skipped++;
                continue;
            }
            put(e, f, a);
        }
        return e;
    }
}
