package iq.gis.poiexporter.core.raster;

import iq.gis.poiexporter.core.crs.Crs;

/** Placement of a raster on the map: pixel→CRS affine, corner positions in lon/lat, world-file parsing. */
public final class Georef {
    private Georef() {
    }

    /**
     * Corners of an image of width x height pixels as lon,lat pairs: top-left, top-right, bottom-right, bottom-left.
     * affine = {a,b,c,d,e,f}: x = a*col + b*row + c, y = d*col + e*row + f (pixel-corner based).
     * epsg 0 is treated as WGS84 lon/lat.
     */
    public static double[] corners(double[] affine, int width, int height, int epsg) {
        double[][] px = {{0, 0}, {width, 0}, {width, height}, {0, height}};
        double[] out = new double[8];
        Crs.Tx tx = null;
        if (epsg != 0 && epsg != 4326) tx = Crs.of(epsg).to(Crs.wgs84());
        double[] r = new double[2];
        for (int i = 0; i < 4; i++) {
            double x = affine[0] * px[i][0] + affine[1] * px[i][1] + affine[2];
            double y = affine[3] * px[i][0] + affine[4] * px[i][1] + affine[5];
            if (tx != null) {
                tx.apply(x, y, r);
                x = r[0];
                y = r[1];
            }
            out[2 * i] = x;
            out[2 * i + 1] = y;
        }
        return out;
    }

    /**
     * Six-line world file (.wld/.tfw/.jgw/.pgw): A (x pixel size), D, B, E (y pixel size, usually negative), C, F where C,F
     * is the CENTRE of the top-left pixel. Returns the affine for pixel corners, or throws IllegalArgumentException.
     */
    public static double[] parseWorldFile(String text) {
        String[] lines = text.trim().split("\\r?\\n");
        double[] v = new double[6];
        int n = 0;
        for (String l : lines) {
            String t = l.trim();
            if (t.isEmpty()) continue;
            if (n >= 6) break;
            try {
                v[n++] = Double.parseDouble(t.replace(',', '.'));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("World file line " + (n + 1) + " is not a number");
            }
        }
        if (n < 6) throw new IllegalArgumentException("A world file has 6 numbers");
        double a = v[0], d = v[1], b = v[2], e = v[3], c = v[4], f = v[5];
        if (a == 0 && b == 0 || e == 0 && d == 0) throw new IllegalArgumentException("World file has zero pixel size");
        return new double[]{a, b, c - a / 2 - b / 2, d, e, f - d / 2 - e / 2};
    }

    /** Affine for an unrotated image covering the lon/lat box {west, south, east, north}. */
    public static double[] fromBounds(double west, double south, double east, double north, int width, int height) {
        return new double[]{(east - west) / width, 0, west, 0, -(north - south) / height, north};
    }
}
