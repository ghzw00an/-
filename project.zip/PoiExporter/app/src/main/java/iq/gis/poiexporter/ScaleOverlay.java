package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

import iq.gis.poiexporter.core.geo.Geodesy;
import iq.gis.poiexporter.core.report.MapMath;

/** Own scale bar: white bar with a dark outline so it stays readable on satellite and plain maps (the library bar was invisible on them). */
final class ScaleOverlay extends Overlay {
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), halo = new Paint(Paint.ANTI_ALIAS_FLAG), tx = new Paint(Paint.ANTI_ALIAS_FLAG),
            txHalo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private final int bottomPx, rightPx;

    ScaleOverlay(float density, int bottomDp, int rightDp) {
        d = density;
        bottomPx = Math.round(bottomDp * density);
        rightPx = Math.round(rightDp * density);
        halo.setStyle(Paint.Style.STROKE);
        halo.setStrokeWidth(5.5f * d);
        halo.setColor(0xCC000000);
        halo.setStrokeCap(Paint.Cap.ROUND);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2.5f * d);
        line.setColor(0xFFFFFFFF);
        line.setStrokeCap(Paint.Cap.ROUND);
        tx.setColor(0xFFFFFFFF);
        tx.setTextSize(12.5f * d);
        tx.setFakeBoldText(true);
        tx.setTextAlign(Paint.Align.CENTER);
        txHalo.set(tx);
        txHalo.setStyle(Paint.Style.STROKE);
        txHalo.setStrokeWidth(3.2f * d);
        txHalo.setColor(0xCC000000);
    }

    private ScaleView view;

    void attach(ScaleView v) {
        view = v;
    }

    @Override
    public void setEnabled(boolean e) {
        super.setEnabled(e);
        if (view != null) view.setVisibility(e ? View.VISIBLE : View.GONE);
    }

    /** Called on every map draw: keeps the bar in step with zoom, scroll and rotation. */
    @Override
    public void draw(Canvas c, MapView map, boolean shadow) {
        if (!shadow && view != null) view.update();
    }
}
