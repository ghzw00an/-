package iq.gis.poiexporter.core.geo;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Jts;
import iq.gis.poiexporter.core.LayerData;

import org.locationtech.jts.algorithm.Orientation;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.LinearRing;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.index.strtree.STRtree;
import org.locationtech.jts.operation.union.UnaryUnionOp;
import org.locationtech.jts.operation.valid.IsValidOp;
import org.locationtech.jts.operation.valid.TopologyValidationError;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Topology checks for polygon layers (administrative boundaries): overlaps, gaps, self-intersections, duplicates. */
public final class Topology {
    private Topology() {
    }

    /** One problem with the geometry to show on the map. */
    public static final class Issue {
        public final String kind; // overlap, gap, self_intersection, duplicate
        public final Feature geometry; // polygon or point (lon/lat)
        public final double areaM2;
        public final Feature a, b; // involved features (b may be null)

        Issue(String kind, Feature g, double area, Feature a, Feature b) {
            this.kind = kind;
            this.geometry = g;
            this.areaM2 = area;
            this.a = a;
            this.b = b;
        }

        public String describe(boolean ar) {
            String na = a == null ? "" : label(a), nb = b == null ? "" : label(b);
            String ar2 = Measure.area(areaM2, ar).m2;
            switch (kind) {
                case "overlap":
                    return ar ? "تداخل بين «" + na + "» و«" + nb + "» بمساحة " + ar2
                            : "Overlap between \"" + na + "\" and \"" + nb + "\": " + ar2;
                case "gap":
                    return ar ? "فجوة بمساحة " + ar2 : "Gap of " + ar2;
                case "self_intersection":
                    return ar ? "تقاطع ذاتي في «" + na + "»" : "Self-intersection in \"" + na + "\"";
                default:
                    return ar ? "هندسة مكررة: «" + na + "» و«" + nb + "»" : "Duplicate geometry: \"" + na + "\" and \"" + nb + "\"";
            }
        }
    }

    private static String label(Feature f) {
        return f.name == null || f.name.isEmpty() ? f.id : f.name;
    }

    public static final class Report {
        public final List<Issue> overlaps = new ArrayList<>(), gaps = new ArrayList<>(),
                selfIntersections = new ArrayList<>(), duplicates = new ArrayList<>();
        public int polygons;
        public double minAreaM2;

        public int total() {
            return overlaps.size() + gaps.size() + selfIntersections.size() + duplicates.size();
        }

        public boolean clean() {
            return total() == 0;
        }

        public List<Issue> all() {
            List<Issue> l = new ArrayList<>();
            l.addAll(selfIntersections);
            l.addAll(duplicates);
            l.addAll(overlaps);
            l.addAll(gaps);
            return l;
        }

        /** Summary in Arabic or English. */
        public String text(boolean ar) {
            StringBuilder b = new StringBuilder();
            if (ar) {
                b.append("فحص طوبولوجي لـ ").append(polygons).append(" مضلع\n");
                b.append("• تداخلات: ").append(overlaps.size()).append('\n');
                b.append("• فجوات: ").append(gaps.size()).append('\n');
                b.append("• تقاطعات ذاتية: ").append(selfIntersections.size()).append('\n');
                b.append("• هندسات مكررة: ").append(duplicates.size()).append('\n');
                b.append(clean() ? "النتيجة: لا توجد أخطاء طوبولوجية.\n" : "النتيجة: توجد أخطاء، راجعها قبل التصدير.\n");
                b.append(String.format(Locale.US, "(أقل مساحة تُعدّ خطأً: %.2f م²)", minAreaM2));
            } else {
                b.append("Topology check of ").append(polygons).append(" polygons\n");
                b.append("• overlaps: ").append(overlaps.size()).append('\n');
                b.append("• gaps: ").append(gaps.size()).append('\n');
                b.append("• self-intersections: ").append(selfIntersections.size()).append('\n');
                b.append("• duplicate geometries: ").append(duplicates.size()).append('\n');
                b.append(clean() ? "Result: no topology errors.\n" : "Result: errors found, review before exporting.\n");
                b.append(String.format(Locale.US, "(smallest area counted as an error: %.2f m²)", minAreaM2));
            }
            return b.toString();
        }
    }

    private static List<Feature> polys(LayerData l) {
        List<Feature> r = new ArrayList<>();
        for (Feature f : l.features) if (f.geom == Feature.POLYGON && !f.parts.isEmpty()) r.add(f);
        return r;
    }

    private static void need(LayerData l) {
        if (l.geom != Feature.POLYGON && polys(l).isEmpty())
            throw new IllegalArgumentException(S.t("الطبقة لا تحتوي مضلعات", "The layer has no polygons"));
    }

    private static double area(Local loc, Geometry m) {
        return Geodesy.area(polyFeature(loc, m));
    }

    private static Feature polyFeature(Local loc, Geometry m) {
        List<Feature> fs = Jts.toFeatures(loc.from(m), null);
        Feature r = new Feature();
        r.geom = Feature.POLYGON;
        for (Feature f : fs) {
            if (f.geom != Feature.POLYGON) continue;
            for (int i = 0; i < f.parts.size(); i++) r.addPart(f.parts.get(i), f.isHole(i));
        }
        return r;
    }

    private static Feature asFeature(Local loc, Geometry m) {
        Feature f = polyFeature(loc, m);
        return f.parts.isEmpty() ? null : f;
    }

    /** Raw (unrepaired) local-metric geometry of a feature. */
    private static Geometry raw(Local loc, Feature f) {
        Geometry g = Jts.toGeometry(f);
        return g == null ? null : loc.to(g);
    }

    private static final double GAP_TOL = 0.05;

    private static Geometry grow(Geometry g, double d) {
        org.locationtech.jts.operation.buffer.BufferParameters bp = new org.locationtech.jts.operation.buffer.BufferParameters(
                1, org.locationtech.jts.operation.buffer.BufferParameters.CAP_FLAT,
                org.locationtech.jts.operation.buffer.BufferParameters.JOIN_MITRE, 5);
        return org.locationtech.jts.operation.buffer.BufferOp.bufferOp(g, d, bp);
    }

    /** Pairs of polygons that overlap by at least minAreaM2 (metric area in the local plane). */
    public static List<Issue> overlaps(LayerData layer, double minAreaM2) {
        need(layer);
        List<Feature> ps = polys(layer);
        Local loc = Local.around(ps);
        List<Geometry> gs = new ArrayList<>();
        STRtree tree = new STRtree();
        for (int i = 0; i < ps.size(); i++) {
            Geometry g = loc.geom(ps.get(i));
            gs.add(g);
            if (g != null && !g.isEmpty()) tree.insert(g.getEnvelopeInternal(), i);
        }
        List<Issue> res = new ArrayList<>();
        for (int i = 0; i < ps.size(); i++) {
            Geometry a = gs.get(i);
            if (a == null || a.isEmpty()) continue;
            @SuppressWarnings("unchecked")
            List<Integer> cand = tree.query(a.getEnvelopeInternal());
            for (int j : cand) {
                if (j <= i) continue;
                Geometry b = gs.get(j);
                if (!a.intersects(b)) continue;
                Geometry x = a.intersection(b);
                if (x.isEmpty() || x.getDimension() < 2) continue;
                double ar = x.getArea();
                if (ar < minAreaM2) continue;
                Feature gf = asFeature(loc, x);
                if (gf == null) continue;
                res.add(new Issue("overlap", gf, Geodesy.area(gf), ps.get(i), ps.get(j)));
            }
        }
        return res;
    }

    /**
     * Gaps: interior holes of the union of all polygons (uncovered areas completely surrounded by the layer) with area
     * of at least minAreaM2. Holes that are intentional in a single polygon are also reported only if no polygon covers
     * them, which is the definition of a gap.
     */
    public static List<Issue> gaps(LayerData layer, double minAreaM2) {
        need(layer);
        List<Feature> ps = polys(layer);
        Local loc = Local.around(ps);
        List<Geometry> gs = new ArrayList<>();
        for (Feature f : ps) {
            Geometry g = loc.geom(f);
            // grow by 5 cm (mitre joins) so neighbours that share an edge up to projection noise really touch
            if (g != null && !g.isEmpty()) g = grow(g, GAP_TOL);
            if (g != null && !g.isEmpty()) gs.add(g);
        }
        List<Issue> res = new ArrayList<>();
        if (gs.isEmpty()) return res;
        Geometry u = UnaryUnionOp.union(gs);
        for (int i = 0; i < u.getNumGeometries(); i++) {
            Geometry part = u.getGeometryN(i);
            if (!(part instanceof Polygon)) continue;
            Polygon pg = (Polygon) part;
            for (int k = 0; k < pg.getNumInteriorRing(); k++) {
                LinearRing r = pg.getInteriorRingN(k);
                Geometry hole = grow(Jts.GF.createPolygon(r.getCoordinates()), GAP_TOL);
                if (hole.getArea() < minAreaM2) continue;
                Feature gf = asFeature(loc, hole);
                if (gf == null) continue;
                res.add(new Issue("gap", gf, Geodesy.area(gf), null, null));
            }
        }
        return res;
    }

    /** Polygons that cross themselves (bow-ties, ring self-touch, hole outside shell...). Located by a point. */
    public static List<Issue> selfIntersections(LayerData layer) {
        need(layer);
        List<Issue> res = new ArrayList<>();
        for (Feature f : polys(layer)) {
            Geometry g = Jts.toGeometry(f);
            if (g == null) continue;
            IsValidOp op = new IsValidOp(g);
            TopologyValidationError e = op.getValidationError();
            if (e == null) continue;
            Coordinate c = e.getCoordinate();
            Feature pt = c == null ? null : Feature.point(c.y, c.x);
            if (pt != null) pt.name = e.getMessage();
            res.add(new Issue("self_intersection", pt, 0, f, null));
        }
        return res;
    }

    /** Pairs of polygons with equal geometry (same shape, any vertex order or start point). */
    public static List<Issue> duplicateGeometries(LayerData layer) {
        need(layer);
        List<Feature> ps = polys(layer);
        Local loc = Local.around(ps);
        List<Geometry> gs = new ArrayList<>();
        STRtree tree = new STRtree();
        for (int i = 0; i < ps.size(); i++) {
            Geometry g = loc.geom(ps.get(i));
            if (g != null) g = g.norm();
            gs.add(g);
            if (g != null && !g.isEmpty()) tree.insert(g.getEnvelopeInternal(), i);
        }
        List<Issue> res = new ArrayList<>();
        for (int i = 0; i < ps.size(); i++) {
            Geometry a = gs.get(i);
            if (a == null || a.isEmpty()) continue;
            @SuppressWarnings("unchecked")
            List<Integer> cand = tree.query(a.getEnvelopeInternal());
            for (int j : cand) {
                if (j <= i) continue;
                Geometry b = gs.get(j);
                if (b == null || !a.equalsExact(b, 1e-6)) {
                    if (b == null || !a.equalsTopo(b)) continue;
                }
                Feature gf = asFeature(loc, a);
                res.add(new Issue("duplicate", gf, gf == null ? 0 : Geodesy.area(gf), ps.get(i), ps.get(j)));
            }
        }
        return res;
    }

    /** Runs all checks. minAreaM2 filters out numerical slivers (default suggestion: 1 m²). */
    public static Report report(LayerData layer, double minAreaM2) {
        Report r = new Report();
        r.minAreaM2 = minAreaM2;
        r.polygons = polys(layer).size();
        r.selfIntersections.addAll(selfIntersections(layer));
        r.duplicates.addAll(duplicateGeometries(layer));
        r.overlaps.addAll(overlaps(layer, minAreaM2));
        r.gaps.addAll(gaps(layer, minAreaM2));
        return r;
    }

    public static Report report(LayerData layer) {
        return report(layer, 1.0);
    }

    /** Orientation helper kept for tests: true if the ring is clockwise in the lon/lat plane. */
    static boolean clockwise(double[] ring) {
        Coordinate[] c = new Coordinate[ring.length / 2];
        for (int i = 0; i < c.length; i++) c[i] = new Coordinate(ring[2 * i], ring[2 * i + 1]);
        return !Orientation.isCCW(c);
    }
}
