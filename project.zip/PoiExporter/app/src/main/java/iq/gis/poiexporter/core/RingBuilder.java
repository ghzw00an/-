package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;

/** Joins way fragments (lon,lat arrays) end to end into closed rings. Open leftovers are dropped. */
public final class RingBuilder {
    private RingBuilder() {}

    private static boolean same(double[] a, int ia, double[] b, int ib) {
        return Math.abs(a[ia] - b[ib]) < 1e-9 && Math.abs(a[ia + 1] - b[ib + 1]) < 1e-9;
    }

    public static List<double[]> build(List<double[]> ways) {
        List<double[]> rest = new ArrayList<>();
        for (double[] w : ways) if (w != null && w.length >= 4) rest.add(w);
        List<double[]> rings = new ArrayList<>();
        while (!rest.isEmpty()) {
            double[] cur = rest.remove(0);
            boolean progress = true;
            while (progress && !same(cur, 0, cur, cur.length - 2)) {
                progress = false;
                for (int k = 0; k < rest.size(); k++) {
                    double[] w = rest.get(k);
                    int end = cur.length - 2;
                    double[] add = null;
                    if (same(cur, end, w, 0)) add = w;
                    else if (same(cur, end, w, w.length - 2)) add = Geo.reversed(w);
                    if (add != null) {
                        double[] merged = new double[cur.length + add.length - 2];
                        System.arraycopy(cur, 0, merged, 0, cur.length);
                        System.arraycopy(add, 2, merged, cur.length, add.length - 2);
                        cur = merged;
                        rest.remove(k);
                        progress = true;
                        break;
                    }
                }
            }
            if (same(cur, 0, cur, cur.length - 2) && cur.length >= 8) rings.add(cur);
        }
        return rings;
    }
}
