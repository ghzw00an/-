package iq.gis.poiexporter;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;

/** Option sheets and editors for a landmark and for a group of landmarks. */
final class Landmarks {
    static final int[] PALETTE = {
            0xFFE53935, 0xFFD81B60, 0xFF8E24AA, 0xFF5E35B1, 0xFF3949AB, 0xFF1E88E5,
            0xFF00ACC1, 0xFF00897B, 0xFF43A047, 0xFF7CB342, 0xFFFDD835, 0xFFFB8C00,
            0xFFF4511E, 0xFF6D4C41, 0xFF546E7A, 0xFF212121, 0xFF0CA678, 0xFFFF8F00};

    interface ColorCb {
        void picked(int color, boolean applyAll);
    }

    private interface PickCb {
        void picked(Feature f, LayerData l);
    }

    private static final class Cand {
        final Feature f;
        final LayerData l;
        double dist;

        Cand(Feature f, LayerData l) {
            this.f = f;
            this.l = l;
        }
    }

    private final MainActivity a;

    Landmarks(MainActivity a) {
        this.a = a;
    }

    // ------------------------------------------------------------------ small helpers

    private TextView tx(String s, float sp, int col, boolean bold) {
        return Ui.text(a, s, sp, col, bold);
    }

    private static String nameOf(Feature f) {
        return f.name.isEmpty() ? S.t("(بدون اسم)", "(unnamed)") : f.name;
    }

    private int colorOf(Feature f, LayerData l) {
        return f.color != 0 ? f.color : FeatureOverlay.colorOf(l);
    }

    private void persistIf(LayerData l) {
        if (Library.isGroup(l)) a.persist(l);
    }

    private TextView swatch(int color, boolean selected, int sizeDp) {
        TextView t = new TextView(a);
        t.setText(selected ? "✔" : "");
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke(Ui.dp(a, selected ? 3 : 1), selected ? Theme.text : Theme.line);
        t.setBackground(g);
        t.setClickable(true);
        Ui.pressable(t);
        t.setLayoutParams(Ui.lp(Ui.dp(a, sizeDp), Ui.dp(a, sizeDp), 0, a, 4, 4, 4, 4));
        return t;
    }

    /** Horizontal colour row used when creating a group; sel[0] holds the chosen colour (0 = default). */
    View colorRow(final int[] sel) {
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        final LinearLayout row = new LinearLayout(a);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        hs.addView(row);
        fillColorRow(row, sel);
        return hs;
    }

    private void fillColorRow(final LinearLayout row, final int[] sel) {
        row.removeAllViews();
        for (int i = 0; i < 12; i++) {
            final int c = PALETTE[i];
            TextView s = swatch(c, sel[0] == c, 34);
            s.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    sel[0] = sel[0] == c ? 0 : c;
                    fillColorRow(row, sel);
                }
            });
            row.addView(s);
        }
    }

    // ------------------------------------------------------------------ colour dialog

    void colorDialog(int current, boolean showApplyAll, final ColorCb cb) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(tx(S.t("اختيار اللون", "Choose colour"), 18, Theme.text, true));
        final Dialog d = a.card(box);
        final boolean[] all = {false};
        LinearLayout grid = new LinearLayout(a);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout row = null;
        for (int i = 0; i < PALETTE.length; i++) {
            if (i % 6 == 0) {
                row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER);
                grid.addView(row);
            }
            final int c = PALETTE[i];
            TextView s = swatch(c, current == c, 40);
            s.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    d.dismiss();
                    cb.picked(c, all[0]);
                }
            });
            row.addView(s);
        }
        box.addView(grid, Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        LinearLayout hx = Ui.row(a);
        hx.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        final EditText hex = Ui.field(a, "#RRGGBB", InputType.TYPE_CLASS_TEXT);
        hx.addView(hex, Ui.lp(0, -2, 1f, a, 0, 0, 8, 0));
        hx.addView(Ui.button(a, S.t("تطبيق", "Apply"), true, new Runnable() {
            public void run() {
                try {
                    String s = hex.getText().toString().replace("#", "").trim();
                    int c = 0xFF000000 | (Integer.parseInt(s, 16) & 0xFFFFFF);
                    d.dismiss();
                    cb.picked(c, all[0]);
                } catch (Exception e) {
                    a.toast(S.t("لون غير صالح (مثال: #E53935)", "Invalid colour (e.g. #E53935)"));
                }
            }
        }), new LinearLayout.LayoutParams(-2, -2));
        box.addView(hx, Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        if (showApplyAll) {
            final TextView chip = Ui.chip(a, "☐  " + S.t("تطبيق على كل نقاط المجموعة أيضاً", "Also apply to every point"));
            chip.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    all[0] = !all[0];
                    chip.setText((all[0] ? "☑  " : "☐  ") + S.t("تطبيق على كل نقاط المجموعة أيضاً", "Also apply to every point"));
                    Ui.setChip(chip, all[0]);
                }
            });
            box.addView(chip, Ui.lp(-2, -2, 0, a, 0, 12, 0, 0));
        }
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("اللون الافتراضي", "Default colour"), false, new Runnable() {
            public void run() {
                d.dismiss();
                cb.picked(0, all[0]);
            }
        }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("إغلاق", "Close"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    // ------------------------------------------------------------------ landmark sheet

    void featureSheet(final Feature f, final LayerData layer) {
        final LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        final Dialog d = Ui.sheet(a, box);

        LinearLayout head = Ui.row(a);
        head.addView(Ui.dot(a, colorOf(f, layer), 16), Ui.lp(Ui.dp(a, 16), Ui.dp(a, 16), 0, a, 0, 0, 12, 0));
        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = tx(nameOf(f), 18, Theme.text, true);
        title.setMaxLines(2);
        titles.addView(title);
        titles.addView(tx(layer.label + (f.type.isEmpty() ? "" : "  •  " + f.type), 12.5f, Theme.sub, false));
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(head);

        IGeoPoint g = a.map.getMapCenter();
        double dist = Geo.haversine(g.getLatitude(), g.getLongitude(), f.lat, f.lon);
        final String coord = CoordFmt.format(a.fmt(), f.lat, f.lon);
        LinearLayout info = Ui.row(a);
        info.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        info.setBackground(Ui.stroke(Theme.field, Theme.line, 12, a));
        info.setPadding(Ui.dp(a, 12), Ui.dp(a, 10), Ui.dp(a, 12), Ui.dp(a, 10));
        TextView ct = tx(coord, 12.5f, Theme.accent, true);
        ct.setClickable(true);
        ct.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                a.copy(coord);
            }
        });
        info.addView(ct, new LinearLayout.LayoutParams(0, -2, 1f));
        info.addView(tx("↔ " + MainActivity.fmtLen(dist), 12.5f, Theme.text, true));
        box.addView(info, Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        if (!f.notes.isEmpty()) {
            TextView nt = tx(f.notes, 13, Theme.sub, false);
            nt.setMaxLines(4);
            nt.setPadding(0, Ui.dp(a, 8), 0, 0);
            box.addView(nt);
        }
        if (Library.isGroup(layer)) {
            TextView chip = Ui.chip(a, "🗂  " + S.t("خيارات المجموعة: ", "Group options: ") + layer.label + "  ›");
            chip.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    d.dismiss();
                    groupSheet(layer);
                }
            });
            box.addView(chip, Ui.lp(-2, -2, 0, a, 0, 10, 0, 0));
        }

        List<View> tiles = new ArrayList<>();
        tiles.add(Ui.tile(a, "🧭", S.t("نقطة توجيه", "Guide to point"), Theme.accent, new Runnable() {
            public void run() {
                d.dismiss();
                a.setGuide(f.lat, f.lon, nameOf(f));
            }
        }));
        tiles.add(Ui.tile(a, "✎", S.t("تعديل التفاصيل", "Edit details"), Theme.primary, new Runnable() {
            public void run() {
                d.dismiss();
                editDetails(f, layer);
            }
        }));
        tiles.add(Ui.tile(a, "⌖", S.t("تعديل النقطة", "Edit point"), Theme.primary, new Runnable() {
            public void run() {
                d.dismiss();
                editPoint(f, layer);
            }
        }));
        tiles.add(Ui.tile(a, f.hidden ? "👁" : "🚫", f.hidden ? S.t("إظهار", "Show") : S.t("إخفاء", "Hide"), Theme.sub, new Runnable() {
            public void run() {
                d.dismiss();
                f.hidden = !f.hidden;
                persistIf(layer);
                a.rebuild();
                a.toast(f.hidden ? S.t("تم إخفاء المعلم", "Landmark hidden") : S.t("تم إظهار المعلم", "Landmark shown"));
            }
        }));
        tiles.add(Ui.tile(a, "〰", S.t("رسم طريق", "Draw route"), Theme.accent, new Runnable() {
            public void run() {
                d.dismiss();
                routeFlow(f, null);
            }
        }));
        tiles.add(Ui.tile(a, "🎨", S.t("تعديل الألوان", "Colours"), 0xFFFB8C00, new Runnable() {
            public void run() {
                d.dismiss();
                colorDialog(f.color, false, new ColorCb() {
                    public void picked(int color, boolean all) {
                        f.color = color;
                        persistIf(layer);
                        a.rebuild();
                    }
                });
            }
        }));
        tiles.add(Ui.tile(a, "⤴", S.t("تصدير النقطة", "Export point"), Theme.primary, new Runnable() {
            public void run() {
                d.dismiss();
                exportOne(f, layer);
            }
        }));
        tiles.add(Ui.tile(a, "➦", S.t("مشاركة النقطة", "Share point"), Theme.primary, new Runnable() {
            public void run() {
                d.dismiss();
                shareFeature(f);
            }
        }));
        tiles.add(Ui.tile(a, "🗑", S.t("حذف النقطة", "Delete point"), Theme.danger, new Runnable() {
            public void run() {
                d.dismiss();
                a.message(S.t("حذف المعلم", "Delete landmark"), S.t("حذف «", "Delete \u201c") + nameOf(f) + S.t("»؟", "\u201d?"),
                        S.t("حذف", "Delete"), new Runnable() {
                            public void run() {
                                a.deleteFeature(f, layer);
                                a.toast(S.t("تم الحذف", "Deleted"));
                            }
                        });
            }
        }));
        box.addView(Ui.grid(a, tiles, 3), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        d.show();
    }

    // ------------------------------------------------------------------ group sheet

    void groupSheet(final LayerData l) {
        final LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        final Dialog d = Ui.sheet(a, box);
        final boolean saved = Library.isGroup(l);

        LinearLayout head = Ui.row(a);
        head.addView(Ui.dot(a, FeatureOverlay.colorOf(l), 16), Ui.lp(Ui.dp(a, 16), Ui.dp(a, 16), 0, a, 0, 0, 12, 0));
        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = tx(l.label, 18, Theme.text, true);
        title.setMaxLines(2);
        titles.addView(title);
        titles.addView(tx(l.features.size() + S.t(" عنصر", " items") + "  •  " + LayerData.geomName(l.geom)
                + (l.id.equals(MainActivity.ACTIVE) ? "  •  ★" : ""), 12.5f, Theme.sub, false));
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(head);

        List<View> tiles = new ArrayList<>();
        tiles.add(Ui.tile(a, "🧭", S.t("أقرب نقطة (توجيه)", "Guide to nearest"), Theme.accent, new Runnable() {
            public void run() {
                d.dismiss();
                IGeoPoint g = a.map.getMapCenter();
                Feature best = null;
                double bd = Double.MAX_VALUE;
                for (Feature f : l.features) {
                    if (f.hidden) continue;
                    double dd = Geo.haversine(g.getLatitude(), g.getLongitude(), f.lat, f.lon);
                    if (dd < bd) {
                        bd = dd;
                        best = f;
                    }
                }
                if (best == null) a.toast(S.t("لا توجد نقاط ظاهرة في المجموعة", "No visible points in the group"));
                else a.setGuide(best.lat, best.lon, l.label + " • " + nameOf(best));
            }
        }));
        tiles.add(Ui.tile(a, "☰", S.t("تعديل النقاط", "Edit points"), Theme.primary, new Runnable() {
            public void run() {
                d.dismiss();
                pointsManager(l);
            }
        }));
        tiles.add(Ui.tile(a, "✎", S.t("تعديل التفاصيل", "Edit details"), Theme.primary, new Runnable() {
            public void run() {
                d.dismiss();
                renameGroup(l);
            }
        }));
        final boolean hid = MainActivity.HIDDEN.contains(l.id);
        tiles.add(Ui.tile(a, hid ? "👁" : "🚫", hid ? S.t("إظهار المجموعة", "Show group") : S.t("إخفاء المجموعة", "Hide group"), Theme.sub, new Runnable() {
            public void run() {
                d.dismiss();
                if (hid) MainActivity.HIDDEN.remove(l.id);
                else MainActivity.HIDDEN.add(l.id);
                a.saveCsv("hidden", MainActivity.HIDDEN);
                a.rebuild();
                a.refreshPage("library");
            }
        }));
        tiles.add(Ui.tile(a, "〰", S.t("رسم طريق بين نقطتين", "Route between points"), Theme.accent, new Runnable() {
            public void run() {
                d.dismiss();
                routeFlow(null, l);
            }
        }));
        tiles.add(Ui.tile(a, "🎨", S.t("تعديل الألوان", "Colours"), 0xFFFB8C00, new Runnable() {
            public void run() {
                d.dismiss();
                colorDialog(l.color, true, new ColorCb() {
                    public void picked(int color, boolean all) {
                        l.color = color;
                        if (all) for (Feature f : l.features) f.color = 0;
                        persistIf(l);
                        a.rebuild();
                        a.refreshPage("library");
                    }
                });
            }
        }));
        tiles.add(Ui.tile(a, "🔍", S.t("عرض على الخريطة", "Show on map"), Theme.primary, new Runnable() {
            public void run() {
                d.dismiss();
                MainActivity.HIDDEN.remove(l.id);
                a.saveCsv("hidden", MainActivity.HIDDEN);
                a.rebuild();
                a.showMap();
                a.zoomToLayer(l);
            }
        }));
        tiles.add(Ui.tile(a, "⤴", S.t("تصدير المجموعة", "Export group"), Theme.primary, new Runnable() {
            public void run() {
                d.dismiss();
                List<LayerData> one = new ArrayList<>();
                one.add(l);
                exportFormats(one, l.label);
            }
        }));
        tiles.add(Ui.tile(a, "➦", S.t("مشاركة المجموعة", "Share group"), Theme.primary, new Runnable() {
            public void run() {
                d.dismiss();
                a.shareDialog(l);
            }
        }));
        if (saved && l.geom == Feature.POINT) {
            tiles.add(Ui.tile(a, "★", S.t("جعلها نشطة للإضافة", "Make active"), 0xFFFB8C00, new Runnable() {
                public void run() {
                    d.dismiss();
                    MainActivity.ACTIVE = l.id;
                    a.prefs.put("active", l.id);
                    a.toast(S.t("المجموعة النشطة: ", "Active group: ") + l.label);
                    a.refreshPage("library");
                }
            }));
        }
        tiles.add(Ui.tile(a, "🗑", S.t("حذف المجموعة", "Delete group"), Theme.danger, new Runnable() {
            public void run() {
                d.dismiss();
                a.deleteLayer(l);
            }
        }));
        box.addView(Ui.grid(a, tiles, 3), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        d.show();
    }

    // ------------------------------------------------------------------ points manager

    void pointsManager(final LayerData l) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(tx(l.label + "  (" + l.features.size() + ")", 18, Theme.text, true));
        final LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        final Dialog d = a.card(box);
        if (Library.isGroup(l) && l.geom == Feature.POINT) {
            box.addView(Ui.button(a, S.t("＋ إضافة نقطة في مركز الخريطة", "＋ Add a point at the map centre"), true, new Runnable() {
                public void run() {
                    d.dismiss();
                    a.addAtCenterTo(l);
                }
            }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        }
        box.addView(sv, Ui.lp(-1, Ui.dp(a, 320), 0, a, 0, 8, 0, 0));
        box.addView(Ui.button(a, S.t("إغلاق", "Close"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        fillPoints(list, l, d);
        d.show();
    }

    private void fillPoints(final LinearLayout list, final LayerData l, final Dialog d) {
        list.removeAllViews();
        if (l.features.isEmpty()) {
            list.addView(tx(S.t("لا توجد نقاط في هذه المجموعة.", "No points in this group."), 13.5f, Theme.sub, false));
            return;
        }
        int shown = 0;
        for (final Feature f : new ArrayList<>(l.features)) {
            if (shown++ >= 400) {
                list.addView(tx(S.t("… تم عرض أول 400 عنصر فقط", "… only the first 400 are shown"), 12, Theme.sub, false));
                break;
            }
            LinearLayout row = Ui.row(a);
            row.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
            row.addView(Ui.dot(a, colorOf(f, l), 12), Ui.lp(Ui.dp(a, 12), Ui.dp(a, 12), 0, a, 0, 0, 10, 0));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setClickable(true);
            col.addView(tx(nameOf(f), 14, f.hidden ? Theme.sub : Theme.text, true));
            String sub = (f.type.isEmpty() ? f.category : f.type);
            if (!sub.isEmpty()) col.addView(tx(sub, 11.5f, Theme.sub, false));
            col.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    d.dismiss();
                    featureSheet(f, l);
                }
            });
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView eye = tx(f.hidden ? "🚫" : "👁", 18, Theme.sub, false);
            eye.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6));
            eye.setClickable(true);
            eye.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    f.hidden = !f.hidden;
                    persistIf(l);
                    a.rebuild();
                    fillPoints(list, l, d);
                }
            });
            row.addView(eye);
            TextView del = tx("🗑", 18, Theme.danger, false);
            del.setPadding(Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 4), Ui.dp(a, 6));
            del.setClickable(true);
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    a.deleteFeature(f, l);
                    fillPoints(list, l, d);
                }
            });
            row.addView(del);
            list.addView(row);
        }
    }

    // ------------------------------------------------------------------ editors

    private EditText formField(LinearLayout form, String label, String value, boolean multi) {
        form.addView(tx(label, 12.5f, Theme.sub, false), Ui.lp(-2, -2, 0, a, 2, 10, 0, 3));
        EditText e = Ui.field(a, label, multi ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE)
                : InputType.TYPE_CLASS_TEXT);
        if (multi) e.setMinLines(2);
        e.setText(value);
        form.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    void editDetails(final Feature f, final LayerData layer) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(tx(S.t("تعديل التفاصيل", "Edit details"), 18, Theme.text, true));
        LinearLayout form = new LinearLayout(a);
        form.setOrientation(LinearLayout.VERTICAL);
        final EditText name = formField(form, S.t("الاسم NAME", "NAME"), f.name, false);
        final EditText type = formField(form, S.t("النوع TYPE", "TYPE"), f.type, false);
        final EditText cat = formField(form, S.t("الفئة CATEGORY", "CATEGORY"), f.category, false);
        final EditText notes = formField(form, S.t("ملاحظات / تفاصيل", "Notes / details"), f.notes, true);
        final EditText nah = formField(form, S.t("الناحية NAHIYA", "NAHIYA"), f.nahiya, false);
        final EditText qad = formField(form, S.t("القضاء QADAA", "QADAA"), f.qadaa, false);
        final EditText gov = formField(form, S.t("المحافظة GOVERNORAT", "GOVERNORAT"), f.governorate, false);
        ScrollView sv = new ScrollView(a);
        sv.addView(form);
        box.addView(sv, Ui.lp(-1, Ui.dp(a, 360), 0, a, 0, 4, 0, 0));
        final Dialog d = a.card(box);
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("حفظ", "Save"), true, new Runnable() {
            public void run() {
                f.name = name.getText().toString().trim();
                f.type = type.getText().toString().trim();
                f.category = cat.getText().toString().trim();
                f.notes = notes.getText().toString().trim();
                f.nahiya = nah.getText().toString().trim();
                f.qadaa = qad.getText().toString().trim();
                f.governorate = gov.getText().toString().trim();
                persistIf(layer);
                a.rebuild();
                a.refreshPage("library");
                d.dismiss();
                a.toast(S.t("تم حفظ التعديلات", "Changes saved"));
            }
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    void editPoint(final Feature f, final LayerData layer) {
        if (f.geom != Feature.POINT) {
            a.toast(S.t("تعديل الموقع متاح للنقاط فقط", "Moving is available for points only"));
            return;
        }
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(tx(S.t("تعديل موقع النقطة", "Edit point location"), 18, Theme.text, true));
        TextView nt = tx(S.t("اكتب إحداثيات جديدة بأي صيغة، أو انقل النقطة إلى مركز الخريطة بعد تحريك الخريطة.",
                "Type new coordinates in any format, or move the point to the map centre after panning the map."),
                12.5f, Theme.sub, false);
        nt.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
        box.addView(nt);
        final EditText fld = Ui.field(a, "33.3152, 44.3661", InputType.TYPE_CLASS_TEXT);
        fld.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        fld.setGravity(Gravity.START);
        fld.setText(CoordFmt.format(a.fmt(), f.lat, f.lon));
        box.addView(fld, new LinearLayout.LayoutParams(-1, -2));
        box.addView(Ui.button(a, S.t("⌖ استخدام مركز الخريطة", "⌖ Use map centre"), false, new Runnable() {
            public void run() {
                IGeoPoint g = a.map.getMapCenter();
                fld.setText(CoordFmt.format(a.fmt(), g.getLatitude(), g.getLongitude()));
            }
        }), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        final Dialog d = a.card(box);
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("حفظ الموقع", "Save location"), true, new Runnable() {
            public void run() {
                try {
                    CoordFmt.Parsed ps = CoordFmt.parse(fld.getText().toString());
                    f.lat = ps.lat;
                    f.lon = ps.lon;
                    f.parts.set(0, new double[]{ps.lon, ps.lat});
                    persistIf(layer);
                    a.rebuild();
                    a.fillAdminAsync(layer, f);
                    a.map.getController().animateTo(new GeoPoint(ps.lat, ps.lon));
                    d.dismiss();
                    a.toast(S.t("تم نقل النقطة", "Point moved"));
                } catch (Exception e) {
                    a.toast(S.t("إحداثيات غير صالحة", "Invalid coordinates"));
                }
            }
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    void renameGroup(final LayerData l) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(tx(S.t("تعديل تفاصيل المجموعة", "Edit group details"), 18, Theme.text, true));
        final EditText n = Ui.field(a, S.t("اسم المجموعة", "Group name"), InputType.TYPE_CLASS_TEXT);
        n.setText(l.label);
        box.addView(n, Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        final Dialog d = a.card(box);
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("حفظ", "Save"), true, new Runnable() {
            public void run() {
                String s = n.getText().toString().trim();
                if (s.isEmpty()) return;
                l.label = s;
                persistIf(l);
                a.rebuild();
                d.dismiss();
                a.refreshPage("library");
            }
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    // ------------------------------------------------------------------ export & share

    void exportOne(Feature f, LayerData l) {
        LayerData one = new LayerData(l.id, l.label, f.geom);
        one.color = l.color;
        one.features.add(f);
        List<LayerData> list = new ArrayList<>();
        list.add(one);
        exportFormats(list, f.name.isEmpty() ? l.label : f.name);
    }

    void exportFormats(final List<LayerData> data, final String prefix) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(tx(S.t("تصدير: ", "Export: ") + prefix, 18, Theme.text, true));
        TextView hint = tx(S.t("سيُحفظ الملف في: ", "Saved to: ") + a.saveWhere(), 12, Theme.sub, false);
        hint.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 8));
        box.addView(hint);
        final Dialog d = a.card(box);
        final String[] kinds = {"kml", "kmz", "shp", "csv"};
        String[] names = {"KML (" + S.t("بيني كويست", "PineQuest") + ")", "KMZ", "Shapefile (ZIP)", "CSV (Excel)"};
        for (int i = 0; i < kinds.length; i++) {
            final String k = kinds[i];
            box.addView(Ui.button(a, names[i], i == 0, new Runnable() {
                public void run() {
                    d.dismiss();
                    a.exportLayers(new ArrayList<>(data), k, prefix);
                }
            }), Ui.lp(-1, -2, 0, a, 0, 6, 0, 0));
        }
        d.show();
    }

    void shareFeature(Feature f) {
        String c = CoordFmt.format(a.fmt(), f.lat, f.lon);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, (f.name.isEmpty() ? "" : f.name + "\n") + (f.type.isEmpty() ? "" : f.type + "\n")
                + (f.notes.isEmpty() ? "" : f.notes + "\n") + c + "\nhttps://www.openstreetmap.org/?mlat=" + f.lat
                + "&mlon=" + f.lon + "#map=18/" + f.lat + "/" + f.lon);
        a.startActivity(Intent.createChooser(i, S.t("مشاركة", "Share")));
    }

    // ------------------------------------------------------------------ routes

    private List<Cand> pointsOf(LayerData scope) {
        List<Cand> out = new ArrayList<>();
        for (Feature f : scope.features) if (f.geom == Feature.POINT) out.add(new Cand(f, scope));
        return out;
    }

    private List<Cand> visiblePoints(Feature except) {
        List<Cand> out = new ArrayList<>();
        for (LayerData l : MainActivity.DATA) {
            for (Feature f : l.features) {
                if (f == except || f.hidden || f.geom != Feature.POINT) continue;
                out.add(new Cand(f, l));
            }
        }
        return out;
    }

    /** Starts the "draw a route between two points" flow. from == null: first choose the start in scope. */
    void routeFlow(final Feature from, LayerData scope) {
        if (from == null) {
            List<Cand> c = pointsOf(scope);
            if (c.size() < 1) {
                a.toast(S.t("لا توجد نقاط في المجموعة", "The group has no points"));
                return;
            }
            IGeoPoint g = a.map.getMapCenter();
            pickPoint(S.t("اختر نقطة البداية", "Choose the start point"), c, g.getLatitude(), g.getLongitude(), new PickCb() {
                public void picked(Feature f, LayerData l) {
                    routeFlow(f, null);
                }
            });
            return;
        }
        List<Cand> c = visiblePoints(from);
        if (c.isEmpty()) {
            a.toast(S.t("لا توجد نقطة أخرى ظاهرة لرسم طريق إليها", "No other visible point to route to"));
            return;
        }
        pickPoint(S.t("اختر نقطة النهاية", "Choose the end point"), c, from.lat, from.lon, new PickCb() {
            public void picked(Feature to, LayerData l) {
                routeOptions(from, to);
            }
        });
    }

    private void pickPoint(String title, final List<Cand> cands, double lat, double lon, final PickCb cb) {
        for (Cand c : cands) c.dist = Geo.haversine(lat, lon, c.f.lat, c.f.lon);
        Collections.sort(cands, new Comparator<Cand>() {
            public int compare(Cand x, Cand y) {
                return Double.compare(x.dist, y.dist);
            }
        });
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(tx(title, 18, Theme.text, true));
        final EditText q = Ui.field(a, S.t("🔍 بحث بالاسم…", "🔍 Search by name…"), InputType.TYPE_CLASS_TEXT);
        box.addView(q, Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        final LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        box.addView(sv, Ui.lp(-1, Ui.dp(a, 300), 0, a, 0, 8, 0, 0));
        final Dialog d = a.card(box);
        final Runnable render = new Runnable() {
            public void run() {
                list.removeAllViews();
                String key = q.getText().toString().trim().toLowerCase(Locale.ROOT);
                int shown = 0;
                for (final Cand c : cands) {
                    if (!key.isEmpty() && !(c.f.name.toLowerCase(Locale.ROOT).contains(key)
                            || c.l.label.toLowerCase(Locale.ROOT).contains(key)
                            || c.f.type.toLowerCase(Locale.ROOT).contains(key))) continue;
                    if (shown++ >= 60) break;
                    LinearLayout row = Ui.row(a);
                    row.setPadding(0, Ui.dp(a, 7), 0, Ui.dp(a, 7));
                    row.setClickable(true);
                    row.addView(Ui.dot(a, colorOf(c.f, c.l), 12), Ui.lp(Ui.dp(a, 12), Ui.dp(a, 12), 0, a, 0, 0, 10, 0));
                    LinearLayout col = new LinearLayout(a);
                    col.setOrientation(LinearLayout.VERTICAL);
                    col.addView(tx(nameOf(c.f), 14, Theme.text, true));
                    col.addView(tx(c.l.label + "  •  " + MainActivity.fmtLen(c.dist), 11.5f, Theme.sub, false));
                    row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
                    row.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            d.dismiss();
                            cb.picked(c.f, c.l);
                        }
                    });
                    list.addView(row);
                }
                if (shown == 0) list.addView(tx(S.t("لا توجد نتائج", "No results"), 13, Theme.sub, false));
            }
        };
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                render.run();
            }
        });
        box.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        render.run();
        d.show();
    }

    private static final String[] ROUTE_BASE = {"",
            "https://routing.openstreetmap.de/routed-car/route/v1/driving/",
            "https://routing.openstreetmap.de/routed-foot/route/v1/driving/",
            "https://routing.openstreetmap.de/routed-bike/route/v1/driving/"};

    private void routeOptions(final Feature from, final Feature to) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(tx(S.t("رسم طريق", "Draw a route"), 18, Theme.text, true));
        TextView ft = tx(nameOf(from) + "  →  " + nameOf(to), 13.5f, Theme.sub, false);
        ft.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
        box.addView(ft);
        final EditText name = Ui.field(a, S.t("اسم الطريق", "Route name"), InputType.TYPE_CLASS_TEXT);
        name.setText(nameOf(from) + " → " + nameOf(to));
        box.addView(name, new LinearLayout.LayoutParams(-1, -2));
        box.addView(tx(S.t("نوع الطريق", "Route type"), 13, Theme.sub, false), Ui.lp(-2, -2, 0, a, 0, 10, 0, 4));
        final int[] mode = {1};
        final String[] labels = {S.t("مستقيم", "Straight"), S.t("سيارة", "Car"), S.t("مشي", "Walk"), S.t("دراجة", "Bike")};
        box.addView(Ui.chipScroller(a, labels, 1, new Ui.OnPick() {
            public void pick(int i) {
                mode[0] = i;
            }
        }));
        box.addView(tx(S.t("الطرق الفعلية تحتاج إنترنت؛ إن تعذّرت يُرسم خط مستقيم بين النقطتين.",
                "Real routes need internet; if unavailable a straight line is drawn."), 12, Theme.sub, false),
                Ui.lp(-2, -2, 0, a, 0, 8, 0, 0));
        final Dialog d = a.card(box);
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("رسم", "Draw"), true, new Runnable() {
            public void run() {
                d.dismiss();
                makeRoute(from, to, name.getText().toString().trim(), mode[0], labels[mode[0]]);
            }
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    private void makeRoute(final Feature from, final Feature to, final String name, final int mode, final String modeLabel) {
        a.toast(S.t("جارٍ رسم الطريق…", "Drawing route…"));
        new Thread(new Runnable() {
            public void run() {
                double[] coords = null;
                double dist = 0, dur = 0;
                boolean fallback = false;
                if (mode > 0) {
                    try {
                        String u = ROUTE_BASE[mode] + String.format(Locale.US, "%.6f,%.6f;%.6f,%.6f", from.lon, from.lat, to.lon, to.lat)
                                + "?overview=full&geometries=geojson";
                        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(25000);
                        c.setRequestProperty("User-Agent", "PoiExporter/2.8 (iq.gis.poiexporter)");
                        InputStream in = c.getInputStream();
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                        in.close();
                        JSONObject o = new JSONObject(bo.toString("UTF-8"));
                        JSONObject rt = o.getJSONArray("routes").getJSONObject(0);
                        JSONArray cs = rt.getJSONObject("geometry").getJSONArray("coordinates");
                        coords = new double[cs.length() * 2];
                        for (int i = 0; i < cs.length(); i++) {
                            coords[2 * i] = cs.getJSONArray(i).getDouble(0);
                            coords[2 * i + 1] = cs.getJSONArray(i).getDouble(1);
                        }
                        dist = rt.getDouble("distance");
                        dur = rt.optDouble("duration", 0);
                        if (coords.length < 4) coords = null;
                    } catch (Exception e) {
                        coords = null;
                    }
                    if (coords == null) fallback = true;
                }
                if (coords == null) {
                    coords = new double[]{from.lon, from.lat, to.lon, to.lat};
                    dist = Geo.haversine(from.lat, from.lon, to.lat, to.lon);
                    dur = 0;
                }
                final double[] fc = coords;
                final double fd = dist, fdu = dur;
                final boolean fb = fallback;
                a.runOnUiThread(new Runnable() {
                    public void run() {
                        addRoute(name, mode == 0 || fb ? S.t("مستقيم", "Straight") : modeLabel, fc, fd, fdu, fb);
                    }
                });
            }
        }).start();
    }

    private void addRoute(String name, String modeLabel, double[] coords, double dist, double dur, boolean fallback) {
        String gl = S.t("الطرق", "Routes");
        LayerData grp = null;
        for (LayerData l : MainActivity.LIB) {
            if (l.geom == Feature.LINE && l.label.equals(gl)) {
                grp = l;
                break;
            }
        }
        if (grp == null) {
            grp = new LayerData(Library.newId(), gl, Feature.LINE);
            grp.color = 0xFF1E88E5;
            MainActivity.LIB.add(grp);
        }
        Feature rf = new Feature();
        rf.geom = Feature.LINE;
        rf.addPart(coords, false);
        Geo.setRepresentative(rf);
        rf.name = name.isEmpty() ? S.t("طريق", "Route") : name;
        rf.type = modeLabel;
        rf.category = gl;
        StringBuilder sb = new StringBuilder(S.t("المسافة: ", "Distance: ")).append(MainActivity.fmtLen(dist));
        if (dur > 0) sb.append(S.t("  •  المدة: ", "  •  Time: ")).append(fmtDur(dur));
        rf.notes = sb.toString();
        grp.features.add(rf);
        MainActivity.HIDDEN.remove(grp.id);
        a.saveCsv("hidden", MainActivity.HIDDEN);
        a.persist(grp);
        a.rebuild();
        a.showMap();
        a.zoomToBox(Geo.bbox(rf));
        a.message(S.t("تم رسم الطريق", "Route drawn"),
                rf.name + "\n" + rf.notes + (fallback ? "\n\n" + S.t("تعذّر الوصول لخدمة الطرق فرُسم خط مستقيم.",
                        "Routing service unavailable: a straight line was drawn.") : "")
                        + "\n\n" + S.t("حُفظ في المجموعة «", "Saved in group \u201c") + gl + S.t("».", "\u201d."), null, null);
        a.refreshPage("library");
    }

    private static String fmtDur(double sec) {
        long m = Math.round(sec / 60.0);
        if (m < 60) return m + " min";
        return (m / 60) + " h " + (m % 60) + " min";
    }
}
