package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.crs.Crs;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * DXF writer (AutoCAD R12 ASCII, read by every CAD program). One DXF layer per source layer and geometry type; points become POINT
 * entities, lines and polygons POLYLINE entities (polygons closed, holes as extra closed polylines). Point names go in a "_names"
 * layer as TEXT. Arabic text is written as \U+XXXX escapes, the way CAD programs expect it in R12 files.
 * With no CRS chosen, coordinates are UTM metres of the zone that holds the first feature (CAD work is almost always in metres).
 */
public final class Dxf {
    private Dxf() {
    }

    public static final class Result {
        public int points, lines, polygons, texts, skipped;
        public Crs crs;
    }

    public static Result write(List<LayerData> layers, ExportOptions o, OutputStream os) throws IOException {
        Result res = new Result();
        Crs target = o.target;
        if (target == null) {
            double lon = Double.NaN, lat = Double.NaN;
            for (LayerData l : layers) {
                for (Feature f : l.features) {
                    if (!f.parts.isEmpty() && f.parts.get(0).length >= 2) {
                        lon = f.parts.get(0)[0];
                        lat = f.parts.get(0)[1];
                        break;
                    }
                }
                if (!Double.isNaN(lon)) break;
            }
            target = Double.isNaN(lon) ? Crs.wgs84() : Crs.utm(Crs.utmZone(lon), lat >= 0);
        }
        res.crs = target;
        boolean wgs = target.epsg == 4326;
        Crs.Tx tx = wgs ? null : Crs.wgs84().to(target);
        double textH = wgs ? 0.00003 : 3.0;

        // layer names: ASCII, unique
        Map<String, String> names = new LinkedHashMap<>();
        List<String> order = new ArrayList<>();
        int idx = 0;
        for (LayerData l : layers) {
            idx++;
            String base = ascii(l.label);
            if (base.isEmpty()) base = "LAYER";
            for (String kind : new String[]{"PT", "LN", "PG"}) {
                String n = (base + "_" + kind + (idx > 1 ? "_" + idx : "")).toUpperCase(Locale.US);
                names.put(l.id + "|" + kind, n);
                order.add(n);
            }
        }
        order.add("_NAMES");

        Writer w = new BufferedWriter(new OutputStreamWriter(os, StandardCharsets.US_ASCII), 1 << 16);
        pair(w, 0, "SECTION");
        pair(w, 2, "HEADER");
        pair(w, 9, "$ACADVER");
        pair(w, 1, "AC1009");
        pair(w, 0, "ENDSEC");
        pair(w, 0, "SECTION");
        pair(w, 2, "TABLES");
        pair(w, 0, "TABLE");
        pair(w, 2, "LAYER");
        pair(w, 70, String.valueOf(order.size() + 1));
        layerRec(w, "0", 7);
        int color = 1;
        for (String n : order) {
            layerRec(w, n, n.equals("_NAMES") ? 7 : (color++ % 7) + 1);
        }
        pair(w, 0, "ENDTAB");
        pair(w, 0, "ENDSEC");
        pair(w, 0, "SECTION");
        pair(w, 2, "ENTITIES");

        double[] out = new double[2];
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                if (f.parts.isEmpty()) continue;
                try {
                    if (f.geom == Feature.POINT) {
                        double[] p = f.parts.get(0);
                        double[] xy = proj(tx, p[0], p[1], out);
                        w.write("  0\nPOINT\n  8\n" + names.get(l.id + "|PT") + "\n");
                        coord(w, xy[0], xy[1]);
                        res.points++;
                        if (!f.name.isEmpty()) {
                            w.write("  0\nTEXT\n  8\n_NAMES\n");
                            coord(w, xy[0] + textH * 0.6, xy[1] + textH * 0.6);
                            pair(w, 40, num(textH));
                            pair(w, 1, esc(f.name));
                            res.texts++;
                        }
                    } else {
                        boolean poly = f.geom == Feature.POLYGON;
                        String layer = names.get(l.id + (poly ? "|PG" : "|LN"));
                        for (double[] part : f.parts) {
                            int n = part.length / 2;
                            if (n < 2) continue;
                            w.write("  0\nPOLYLINE\n  8\n" + layer + "\n 66\n     1\n");
                            if (poly) pair(w, 70, "1");
                            int last = n;
                            if (poly && n > 2 && part[0] == part[2 * (n - 1)] && part[1] == part[2 * (n - 1) + 1]) last = n - 1;
                            for (int i = 0; i < last; i++) {
                                double[] xy = proj(tx, part[2 * i], part[2 * i + 1], out);
                                w.write("  0\nVERTEX\n  8\n" + layer + "\n");
                                coord(w, xy[0], xy[1]);
                            }
                            w.write("  0\nSEQEND\n  8\n" + layer + "\n");
                        }
                        if (poly) res.polygons++;
                        else res.lines++;
                    }
                } catch (IllegalArgumentException e) {
                    res.skipped++;
                }
            }
        }
        pair(w, 0, "ENDSEC");
        pair(w, 0, "EOF");
        w.flush();
        return res;
    }


    // ------------------------------------------------------------------ reading

    /**
     * Reads POINT, LINE, LWPOLYLINE, POLYLINE/VERTEX, CIRCLE, ARC (as a polyline) and SOLID/3DFACE outlines from an ASCII DXF.
     * The file's CRS is not stored in DXF, so info.crs stays null and the user picks it in the import preview.
     * Binary DXF and blocks (INSERT) are not read; a warning says so.
     */
    public static void read(java.io.File f, Visitor v, ReadInfo info) throws IOException {
        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(f), StandardCharsets.ISO_8859_1), 1 << 16);
        try {
            String code = r.readLine();
            if (code != null && code.startsWith("AutoCAD Binary DXF"))
                throw new IOException(iq.gis.poiexporter.S.t("ملف DXF ثنائي غير مدعوم؛ احفظه كـ ASCII DXF.", "Binary DXF is not supported; save it as ASCII DXF."));
            boolean inEntities = false;
            Ent cur = null, poly = null;
            int inserts = 0;
            while (code != null && !info.cancel) {
                String val = r.readLine();
                if (val == null) break;
                val = val.trim();
                int c;
                try {
                    c = Integer.parseInt(code.trim());
                } catch (NumberFormatException e) {
                    code = r.readLine();
                    continue;
                }
                if (c == 0) {
                    if (cur != null) {
                        if (cur.type.equals("POLYLINE")) {
                            poly = cur;
                        } else if (cur.type.equals("VERTEX")) {
                            if (poly != null) poly.pts.add(new double[]{cur.x, cur.y});
                        } else if (cur.type.equals("SEQEND")) {
                            if (poly != null && !emit(poly, v)) return;
                            poly = null;
                        } else if (inEntities && !emit(cur, v)) {
                            return;
                        }
                    }
                    if (val.equals("ENDSEC")) inEntities = false;
                    if (val.equals("INSERT")) inserts++;
                    if (val.equals("EOF")) {
                        cur = null;
                        break;
                    }
                    cur = new Ent(val);
                } else if (cur != null) {
                    if (c == 2 && cur.type.equals("SECTION")) inEntities = val.equals("ENTITIES");
                    else cur.add(c, val);
                }
                code = r.readLine();
            }
            if (cur != null && inEntities && !cur.type.equals("POLYLINE") && !cur.type.equals("VERTEX") && !cur.type.equals("SEQEND")) emit(cur, v);
            if (inserts > 0) info.warnings.add(iq.gis.poiexporter.S.t(inserts + " كتلة (INSERT) لم تُقرأ.", inserts + " block references (INSERT) were not read."));
        } finally {
            r.close();
        }
    }

    private static final class Ent {
        final String type;
        String layer = "0";
        boolean closed;
        double x, y, r, a0, a1 = 360;
        final List<double[]> pts = new ArrayList<>();
        double curX = Double.NaN;

        Ent(String t) {
            type = t;
        }

        void add(int code, String v) {
            try {
                switch (code) {
                    case 8:
                        layer = unesc(v);
                        break;
                    case 10:
                        x = Double.parseDouble(v);
                        curX = x;
                        break;
                    case 20: {
                        y = Double.parseDouble(v);
                        if (type.equals("LWPOLYLINE") || type.equals("LINE") || type.equals("SOLID") || type.equals("3DFACE"))
                            pts.add(new double[]{curX, y});
                        break;
                    }
                    case 11:
                    case 12:
                    case 13:
                        curX = Double.parseDouble(v);
                        break;
                    case 21:
                    case 22:
                    case 23:
                        pts.add(new double[]{curX, Double.parseDouble(v)});
                        break;
                    case 40:
                        r = Double.parseDouble(v);
                        break;
                    case 50:
                        a0 = Double.parseDouble(v);
                        break;
                    case 51:
                        a1 = Double.parseDouble(v);
                        break;
                    case 70:
                        if (!type.equals("VERTEX")) closed = (Integer.parseInt(v) & 1) == 1;
                        break;
                    default:
                        break;
                }
            } catch (NumberFormatException ignored) {
                // bad number: the entity is dropped later when it has too few points
            }
        }
    }

    private static boolean emit(Ent e, Visitor v) {
        Feature f = new Feature();
        f.id = Feature.newId();
        switch (e.type) {
            case "POINT":
                f = Feature.point(e.y, e.x);
                f.id = Feature.newId();
                break;
            case "CIRCLE":
            case "ARC": {
                boolean circle = e.type.equals("CIRCLE");
                double a0 = circle ? 0 : e.a0, a1 = circle ? 360 : (e.a1 <= e.a0 ? e.a1 + 360 : e.a1);
                int n = Math.max(8, (int) Math.ceil((a1 - a0) / 10));
                double[] c = new double[(n + 1) * 2];
                for (int i = 0; i <= n; i++) {
                    double a = Math.toRadians(a0 + (a1 - a0) * i / n);
                    c[2 * i] = e.x + e.r * Math.cos(a);
                    c[2 * i + 1] = e.y + e.r * Math.sin(a);
                }
                f.geom = circle ? Feature.POLYGON : Feature.LINE;
                f.addPart(c, false);
                f.lon = e.x;
                f.lat = e.y;
                break;
            }
            case "LINE":
            case "LWPOLYLINE":
            case "POLYLINE":
            case "SOLID":
            case "3DFACE": {
                if (e.pts.size() < 2) return true;
                int n = e.pts.size();
                boolean poly = e.closed && n >= 3 || e.type.equals("SOLID") || e.type.equals("3DFACE");
                if (poly && e.type.equals("SOLID") && n == 4) {
                    double[] t = e.pts.get(2);
                    e.pts.set(2, e.pts.get(3));
                    e.pts.set(3, t);
                }
                int m = e.pts.size();
                double[] c = new double[(m + (poly ? 1 : 0)) * 2];
                for (int i = 0; i < m; i++) {
                    c[2 * i] = e.pts.get(i)[0];
                    c[2 * i + 1] = e.pts.get(i)[1];
                }
                if (poly) {
                    c[2 * m] = c[0];
                    c[2 * m + 1] = c[1];
                }
                f.geom = poly ? Feature.POLYGON : Feature.LINE;
                f.addPart(c, false);
                f.lon = e.pts.get(0)[0];
                f.lat = e.pts.get(0)[1];
                break;
            }
            default:
                return true;
        }
        f.attrs.put("dxf_layer", e.layer);
        return v.feature(e.layer.isEmpty() ? "0" : e.layer, f);
    }

    /** \U+XXXX escapes back to characters. */
    static String unesc(String s) {
        if (s.indexOf("\\U+") < 0) return s;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (s.startsWith("\\U+", i) && i + 7 <= s.length()) {
                try {
                    b.append((char) Integer.parseInt(s.substring(i + 3, i + 7), 16));
                    i += 6;
                    continue;
                } catch (NumberFormatException ignored) {
                    // keep the text as it is
                }
            }
            b.append(s.charAt(i));
        }
        return b.toString();
    }

    private static double[] proj(Crs.Tx tx, double lon, double lat, double[] out) {
        if (tx == null) return new double[]{lon, lat};
        tx.apply(lon, lat, out);
        return new double[]{out[0], out[1]};
    }

    private static void layerRec(Writer w, String name, int color) throws IOException {
        pair(w, 0, "LAYER");
        pair(w, 2, name);
        pair(w, 70, "0");
        pair(w, 62, String.valueOf(color));
        pair(w, 6, "CONTINUOUS");
    }

    private static void coord(Writer w, double x, double y) throws IOException {
        pair(w, 10, num(x));
        pair(w, 20, num(y));
        pair(w, 30, "0.0");
    }

    private static void pair(Writer w, int code, String v) throws IOException {
        w.write(String.format(Locale.US, "%3d", code));
        w.write('\n');
        w.write(v);
        w.write('\n');
    }

    private static String num(double v) {
        String s = String.format(Locale.US, "%.8f", v);
        if (s.indexOf('.') >= 0) {
            int e = s.length();
            while (e > 1 && s.charAt(e - 1) == '0') e--;
            if (s.charAt(e - 1) == '.') e++;
            s = s.substring(0, e);
        }
        return s;
    }

    /** Letters, digits and underscore only; anything else (Arabic included) is dropped. */
    static String ascii(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) b.append(c);
            else if (c == ' ' || c == '_' || c == '-') b.append('_');
        }
        return b.toString();
    }

    /** Non-ASCII characters become \U+XXXX; line breaks become spaces. */
    static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\n' || c == '\r') b.append(' ');
            else if (c < 128) b.append(c);
            else b.append(String.format("\\U+%04X", (int) c));
        }
        return b.toString();
    }
}
