package iq.gis.poiexporter.core;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** WGS84 to MGRS and back (1 m precision at most). Covers 80S to 84N. */
public final class Mgrs {
    private static final String BANDS = "CDEFGHJKLMNPQRSTUVWX";
    private static final String[] COLS = {"ABCDEFGH", "JKLMNPQR", "STUVWXYZ"};
    private static final String ROWS = "ABCDEFGHJKLMNPQRSTUV";
    private static final Pattern P = Pattern.compile("^(\\d{1,2})([C-HJ-NP-X])([A-HJ-NP-Z])([A-HJ-NP-V])(\\d{0,10})$");

    private Mgrs() {}

    public static boolean looks(String compactUpper) {
        Matcher m = P.matcher(compactUpper);
        return m.matches() && m.group(5).length() % 2 == 0;
    }

    /** digits = digits per axis, 0..5 (5 means 1 m). */
    public static String fromLatLon(double lat, double lon, int digits) {
        if (lat < -80 || lat > 84) throw new IllegalArgumentException("MGRS covers 80S to 84N");
        Utm.Result u = Utm.fromLatLon(lat, lon);
        int band = Math.min(19, (int) Math.floor((lat + 80) / 8));
        int set = (u.zone - 1) % 3;
        int col = Math.max(0, Math.min(7, (int) Math.floor(u.easting / 100000) - 1));
        int row = ((int) Math.floor(u.northing / 100000) + (u.zone % 2 == 0 ? 5 : 0)) % 20;
        long e = (long) Math.floor(u.easting) % 100000;
        long n = (long) Math.floor(u.northing) % 100000;
        String es = String.format("%05d", e).substring(0, digits);
        String ns = String.format("%05d", n).substring(0, digits);
        return u.zone + "" + BANDS.charAt(band) + " " + COLS[set].charAt(col) + ROWS.charAt(row)
                + (digits > 0 ? " " + es + " " + ns : "");
    }

    /** Returns {lat, lon} of the south-west corner of the referenced square. */
    public static double[] toLatLon(String text) {
        String s = text.replaceAll("[\\s,;]+", "").toUpperCase();
        Matcher m = P.matcher(s);
        if (!m.matches() || m.group(5).length() % 2 != 0) throw new IllegalArgumentException("bad MGRS");
        int zone = Integer.parseInt(m.group(1));
        if (zone < 1 || zone > 60) throw new IllegalArgumentException("bad zone");
        int band = BANDS.indexOf(m.group(2).charAt(0));
        int set = (zone - 1) % 3;
        int col = COLS[set].indexOf(m.group(3).charAt(0));
        int row = ROWS.indexOf(m.group(4).charAt(0));
        if (col < 0) throw new IllegalArgumentException("bad column letter for zone");
        String d = m.group(5);
        int half = d.length() / 2;
        double e = half == 0 ? 0 : Double.parseDouble(pad(d.substring(0, half)));
        double n = half == 0 ? 0 : Double.parseDouble(pad(d.substring(half)));
        double easting = (col + 1) * 100000.0 + e;
        double n100 = (((row - (zone % 2 == 0 ? 5 : 0)) % 20) + 20) % 20 * 100000.0;
        boolean north = band >= 10;
        double bandLat = (band - 10) * 8 + (band == 19 ? 6 : 4);
        double bandMin = (band - 10) * 8, bandMax = bandMin + (band == 19 ? 12 : 8);
        double best = Double.NaN, bestDist = 1e9;
        for (int k = 0; k < 10; k++) {
            double northing = n100 + n + k * 2000000.0;
            if (northing > 10000000.0) break;
            double[] ll = Utm.toLatLon(zone, north, easting, northing);
            if (ll[0] >= bandMin - 1e-4 && ll[0] <= bandMax + 1e-4) {
                double dist = Math.abs(ll[0] - bandLat);
                if (dist < bestDist) {
                    bestDist = dist;
                    best = northing;
                }
            }
        }
        if (Double.isNaN(best)) throw new IllegalArgumentException("MGRS outside its latitude band");
        return Utm.toLatLon(zone, north, easting, best);
    }

    private static String pad(String digits) {
        StringBuilder sb = new StringBuilder(digits);
        while (sb.length() < 5) sb.append('0');
        return sb.toString();
    }
}
