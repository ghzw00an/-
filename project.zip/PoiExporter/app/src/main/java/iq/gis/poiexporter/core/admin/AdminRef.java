package iq.gis.poiexporter.core.admin;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.Jts;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.MiniJson;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.prep.PreparedGeometry;
import org.locationtech.jts.geom.prep.PreparedGeometryFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Reference administrative boundaries of Iraq bundled with the app: 18 governorates (level 1) and 101 districts (level 2).
 * Unofficial and generalized (see {@link #notes()}); sub-districts (nahiya) are not included.
 * A district knows its governorate, so qadaa and governorate are always consistent with each other.
 */
public final class AdminRef {
    public static final String RESOURCE = "/admin/iq_admin.json";

    public static final class Unit {
        public int level;
        public String nameEn = "", nameAr = "", parentEn = "", parentAr = "";
        public Feature poly;
        /** True for districts the user fetched from OpenStreetMap (ODbL) rather than the bundled set. */
        public boolean extra;
        public String source = "";
        public double[] bbox; // minLon, minLat, maxLon, maxLat
        Geometry geom;
        PreparedGeometry prep;

        public String name(boolean ar) {
            return ar && !nameAr.isEmpty() ? nameAr : nameEn;
        }

        public String parent(boolean ar) {
            return ar && !parentAr.isEmpty() ? parentAr : parentEn;
        }

        synchronized PreparedGeometry prep() {
            if (prep == null) {
                geom = Jts.toGeometry(poly);
                if (geom != null && !geom.isValid()) geom = geom.buffer(0);
                prep = PreparedGeometryFactory.prepare(geom);
            }
            return prep;
        }

        boolean covers(double lat, double lon) {
            if (lon < bbox[0] || lon > bbox[2] || lat < bbox[1] || lat > bbox[3]) return false;
            Point p = Jts.GF.createPoint(new Coordinate(lon, lat));
            return prep().covers(p);
        }

        /** Approximate distance in metres from the point to this unit's outline. */
        double boundaryDistanceM(double lat, double lon) {
            prep();
            Point p = Jts.GF.createPoint(new Coordinate(lon, lat));
            double dDeg = geom.getBoundary().distance(p);
            return dDeg * 111_320.0 * Math.max(0.2, Math.cos(Math.toRadians(lat)));
        }
    }

    public static final class Hit {
        public Unit district, governorate;
        /** Distance to the nearest district outline in metres (approximate), or -1 when unknown. */
        public double boundaryM = -1;

        public String qadaa(boolean ar) {
            return district == null ? "" : district.name(ar);
        }

        public String governorate(boolean ar) {
            if (district != null) return district.parent(ar);
            return governorate == null ? "" : governorate.name(ar);
        }

        public boolean found() {
            return district != null || governorate != null;
        }
    }

    private final List<Unit> adm1 = new ArrayList<>(), adm2 = new ArrayList<>();
    private String notes = "", built = "";
    private String[] sources = {"", ""}, licenses = {"", ""}, years = {"", ""};

    public List<Unit> units(int level) {
        return level == 1 ? adm1 : adm2;
    }

    public String notes() {
        return notes;
    }

    public String built() {
        return built;
    }

    public String source(int level) {
        return sources[level - 1];
    }

    public String license(int level) {
        return licenses[level - 1];
    }

    public String year(int level) {
        return years[level - 1];
    }

    // ------------------------------------------------------------------ loading

    private static AdminRef shared;
    private static boolean tried;

    /** The bundled data, or null when the resource is missing (the app then works without offline boundaries). */
    public static synchronized AdminRef get() {
        if (!tried) {
            tried = true;
            try (InputStream in = AdminRef.class.getResourceAsStream(RESOURCE)) {
                if (in != null) shared = load(in);
            } catch (IOException | RuntimeException e) {
                shared = null;
            }
        }
        return shared;
    }

    @SuppressWarnings("unchecked")
    public static AdminRef load(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(600_000);
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        Map<String, Object> root = MiniJson.obj(new String(b.toByteArray(), StandardCharsets.UTF_8));
        AdminRef r = new AdminRef();
        Object mo = root.get("meta");
        if (mo instanceof Map) {
            Map<String, Object> m = (Map<String, Object>) mo;
            r.notes = MiniJson.str(m, "notes", "");
            r.built = MiniJson.str(m, "built", "");
            for (int i = 1; i <= 2; i++) {
                Object lo = m.get("adm" + i);
                if (lo instanceof Map) {
                    Map<String, Object> lm = (Map<String, Object>) lo;
                    r.sources[i - 1] = MiniJson.str(lm, "source", "");
                    r.licenses[i - 1] = MiniJson.str(lm, "license", "");
                    r.years[i - 1] = MiniJson.str(lm, "year", "");
                }
            }
        }
        r.readFeatures(root, false);
        Comparator<Unit> byName = (x, y) -> x.nameEn.compareToIgnoreCase(y.nameEn);
        Collections.sort(r.adm1, byName);
        Collections.sort(r.adm2, byName);
        return r;
    }

    // ------------------------------------------------------------------ districts added by the user (from OpenStreetMap)

    public List<Unit> extras() {
        List<Unit> r = new ArrayList<>();
        for (Unit u : adm2) if (u.extra) r.add(u);
        return r;
    }

    /** Restores the districts saved by {@link #extrasJson()}. Replaces the current extras. */
    @SuppressWarnings("unchecked")
    public synchronized void loadExtras(String json) {
        adm2.removeIf(u -> u.extra);
        if (json != null && !json.trim().isEmpty()) {
            try {
                readFeatures(MiniJson.obj(json), true);
            } catch (RuntimeException e) {
                adm2.removeIf(u -> u.extra); // a damaged file must not break the bundled data
            }
        }
        Collections.sort(adm2, (x, y) -> x.nameEn.compareToIgnoreCase(y.nameEn));
    }

    public synchronized String extrasJson() {
        StringBuilder b = new StringBuilder("{\"type\":\"FeatureCollection\",\"features\":[");
        boolean first = true;
        for (Unit u : adm2) {
            if (!u.extra) continue;
            if (!first) b.append(',');
            first = false;
            b.append("{\"type\":\"Feature\",\"properties\":{\"level\":2,\"name_en\":").append(MiniJson.quote(u.nameEn))
                    .append(",\"name_ar\":").append(MiniJson.quote(u.nameAr)).append(",\"parent_en\":").append(MiniJson.quote(u.parentEn))
                    .append(",\"parent_ar\":").append(MiniJson.quote(u.parentAr)).append(",\"source\":").append(MiniJson.quote(u.source))
                    .append("},\"geometry\":{\"type\":\"MultiPolygon\",\"coordinates\":[");
            // each outer ring starts a polygon; holes follow their outer ring
            boolean firstPoly = true;
            for (int i = 0; i < u.poly.parts.size(); i++) {
                boolean hole = u.poly.isHole(i);
                if (!hole) {
                    if (!firstPoly) b.append("],");
                    b.append('[');
                    firstPoly = false;
                } else {
                    b.append(',');
                }
                appendRing(b, u.poly.parts.get(i));
            }
            if (!firstPoly) b.append(']');
            b.append("]}}");
        }
        return b.append("]}").toString();
    }

    private static void appendRing(StringBuilder b, double[] p) {
        b.append('[');
        for (int i = 0; i < p.length / 2; i++) {
            if (i > 0) b.append(',');
            b.append('[').append(p[2 * i]).append(',').append(p[2 * i + 1]).append(']');
        }
        b.append(']');
    }

    /**
     * Adds (or replaces, by name) a district the user fetched. The governorate is found from the polygon's interior
     * point in the bundled governorates; returns the new unit, or null when the polygon is unusable.
     */
    public synchronized Unit addExtra(String nameEn, String nameAr, Feature poly, String source) {
        if (poly == null || poly.parts.isEmpty() || poly.geom != Feature.POLYGON) return null;
        Unit u = new Unit();
        u.level = 2;
        u.extra = true;
        u.nameEn = nameEn == null ? "" : nameEn.trim();
        u.nameAr = nameAr == null ? "" : nameAr.trim();
        if (u.nameEn.isEmpty() && u.nameAr.isEmpty()) return null;
        if (u.nameEn.isEmpty()) u.nameEn = u.nameAr;
        u.source = source == null ? "" : source;
        Feature f = poly.copy();
        f.id = "adm2:" + u.nameEn + "#osm";
        f.name = u.nameAr.isEmpty() ? u.nameEn : u.nameAr;
        f.nameEn = u.nameEn;
        f.type = "District";
        Geo.setRepresentative(f);
        double[] bb = {1e9, 1e9, -1e9, -1e9};
        for (double[] p : f.parts) {
            for (int i = 0; i + 1 < p.length; i += 2) {
                bb[0] = Math.min(bb[0], p[i]);
                bb[1] = Math.min(bb[1], p[i + 1]);
                bb[2] = Math.max(bb[2], p[i]);
                bb[3] = Math.max(bb[3], p[i + 1]);
            }
        }
        u.poly = f;
        u.bbox = bb;
        Unit gov = find(1, f.lat, f.lon);
        if (gov != null) {
            u.parentEn = gov.nameEn;
            u.parentAr = gov.nameAr;
        }
        adm2.removeIf(x -> x.extra && DupName.same(x, u));
        adm2.add(u);
        Collections.sort(adm2, (x, y) -> x.nameEn.compareToIgnoreCase(y.nameEn));
        return u;
    }

    /**
     * True when a district with this name already exists (bundled or added). Arabic names are compared without the word
     * "قضاء" and the article "ال" and with alef/yaa variants unified; English names must match after dropping "Al-".
     */
    public boolean knowsDistrict(String nameAr, String nameEn) {
        String ka = arKey(nameAr), ke = enKey(nameEn);
        for (Unit u : adm2) {
            if (!ka.isEmpty() && ka.equals(arKey(u.nameAr))) return true;
            if (!ke.isEmpty() && ke.equals(enKey(u.nameEn))) return true;
        }
        return false;
    }

    static String arKey(String s) {
        if (s == null) return "";
        String t = iq.gis.poiexporter.core.io.DupFinder.normName(s);
        if (t.startsWith("قضاء")) t = t.substring(4);
        if (t.startsWith("ال") && t.length() > 3) t = t.substring(2);
        return t;
    }

    static String enKey(String s) {
        if (s == null) return "";
        String t = s.toLowerCase(java.util.Locale.ROOT).replaceAll("\\b(district|qada|qadaa|qadha)\\b", "").replaceAll("[^a-z0-9]", "");
        if (t.startsWith("al") && t.length() > 4) t = t.substring(2);
        return t;
    }

    private static final class DupName {
        static boolean same(Unit a, Unit b) {
            return norm(a.nameEn).equals(norm(b.nameEn)) || (!a.nameAr.isEmpty() && norm(a.nameAr).equals(norm(b.nameAr)));
        }

        static String norm(String s) {
            return iq.gis.poiexporter.core.io.DupFinder.normName(s);
        }
    }

    // ------------------------------------------------------------------ lookup

    @SuppressWarnings("unchecked")
    private void readFeatures(Map<String, Object> root, boolean extra) {
        for (Object fo : (List<Object>) root.get("features")) {
            Map<String, Object> fm = (Map<String, Object>) fo;
            Map<String, Object> pr = (Map<String, Object>) fm.get("properties");
            Unit u = new Unit();
            u.level = (int) MiniJson.num(pr, "level", 2);
            u.nameEn = MiniJson.str(pr, "name_en", "");
            u.nameAr = MiniJson.str(pr, "name_ar", "");
            u.parentEn = MiniJson.str(pr, "parent_en", "");
            u.parentAr = MiniJson.str(pr, "parent_ar", "");
            Feature f = new Feature();
            f.geom = Feature.POLYGON;
            f.id = (u.level == 1 ? "adm1:" : "adm2:") + u.nameEn + (extra ? "#osm" : "");
            Map<String, Object> g = (Map<String, Object>) fm.get("geometry");
            double[] bb = {1e9, 1e9, -1e9, -1e9};
            List<Object> polys = (List<Object>) g.get("coordinates");
            for (Object po : polys) {
                List<Object> rings = (List<Object>) po;
                for (int ri = 0; ri < rings.size(); ri++) {
                    List<Object> pts = (List<Object>) rings.get(ri);
                    double[] c = new double[pts.size() * 2];
                    for (int i = 0; i < pts.size(); i++) {
                        List<Object> xy = (List<Object>) pts.get(i);
                        double x = ((Number) xy.get(0)).doubleValue(), y = ((Number) xy.get(1)).doubleValue();
                        c[2 * i] = x;
                        c[2 * i + 1] = y;
                        bb[0] = Math.min(bb[0], x);
                        bb[1] = Math.min(bb[1], y);
                        bb[2] = Math.max(bb[2], x);
                        bb[3] = Math.max(bb[3], y);
                    }
                    f.addPart(c, ri > 0);
                }
            }
            f.name = u.nameAr.isEmpty() ? u.nameEn : u.nameAr;
            f.nameEn = u.nameEn;
            f.type = u.level == 1 ? "Governorate" : "District";
            Geo.setRepresentative(f);
            u.poly = f;
            u.bbox = bb;
            u.extra = extra;
            u.source = MiniJson.str(pr, "source", "");
            (u.level == 1 ? adm1 : adm2).add(u);
        }
    }

    /** The unit of the level containing the point, or null. When ranges overlap the smallest bounding box wins. */
    public Unit find(int level, double lat, double lon) {
        Unit best = null;
        double bestArea = Double.MAX_VALUE;
        for (Unit u : units(level)) {
            if (!u.covers(lat, lon)) continue;
            double a = (u.bbox[2] - u.bbox[0]) * (u.bbox[3] - u.bbox[1]);
            if (a < bestArea) {
                bestArea = a;
                best = u;
            }
        }
        return best;
    }

    public Hit locate(double lat, double lon) {
        Hit h = new Hit();
        h.district = find(2, lat, lon);
        if (h.district != null) {
            for (Unit g : adm1) if (g.nameEn.equals(h.district.parentEn)) h.governorate = g;
            try {
                h.boundaryM = h.district.boundaryDistanceM(lat, lon);
            } catch (RuntimeException e) {
                h.boundaryM = -1;
            }
        } else {
            h.governorate = find(1, lat, lon);
        }
        return h;
    }

    /** Fills qadaa and governorate of the feature if they are empty. Returns true when something was filled. */
    public boolean fill(Feature f, boolean ar) {
        if (!f.qadaa.isEmpty() && !f.governorate.isEmpty()) return false;
        Hit h = locate(f.lat, f.lon);
        boolean changed = false;
        if (f.qadaa.isEmpty() && !h.qadaa(ar).isEmpty()) {
            f.qadaa = h.qadaa(ar);
            changed = true;
        }
        if (f.governorate.isEmpty() && !h.governorate(ar).isEmpty()) {
            f.governorate = h.governorate(ar);
            changed = true;
        }
        return changed;
    }

    // ------------------------------------------------------------------ layers for the map

    public String accuracyNote(boolean ar) {
        return ar ? "حدود غير رسمية ومُبسَّطة؛ قد تُخطئ النقطة القريبة من الحد. لا تصلح للمساحة أو الأعمال القانونية."
                : "Unofficial, generalized boundaries; points near a border may be assigned wrongly. Not for surveying or legal use.";
    }

    /** A reference layer with the polygons of one level (optionally only the districts of one governorate). */
    public LayerData layer(int level, boolean ar, String parentEn) {
        String label = level == 1 ? (ar ? "المحافظات (غير رسمي)" : "Governorates (unofficial)") : (ar ? "الأقضية (غير رسمي)" : "Districts (unofficial)");
        if (parentEn != null) label = parentEn + " — " + label;
        LayerData l = new LayerData("ref_adm" + level + (parentEn == null ? "" : "_" + parentEn), label, Feature.POLYGON);
        l.kind = "reference";
        l.official = false;
        l.source = source(level) + " — " + license(level);
        l.sourceDate = year(level);
        l.accuracyNote = accuracyNote(ar);
        for (Unit u : units(level)) {
            if (parentEn != null && !parentEn.equals(u.parentEn)) continue;
            Feature f = u.poly.copy();
            f.name = u.name(ar);
            f.nameEn = u.nameEn;
            if (level == 2) {
                f.qadaa = u.name(ar);
                f.governorate = u.parent(ar);
            } else {
                f.governorate = u.name(ar);
            }
            l.features.add(f);
        }
        return l;
    }
}
