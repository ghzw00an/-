package iq.gis.poiexporter.core.db;

/** One undoable step: label for the UI and the JSON array of changes. */
public final class HistoryEntry {
    public long seq;
    public String ts, label, json;
    public boolean undone;
}
