package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.geo.Geodesy;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Finds duplicate points: identical position, or the same (normalised) name within a distance. Grid hashed, O(n). */
public final class DupFinder {
    private DupFinder() {
    }

    public static final class Group {
        public final List<Feature> members = new ArrayList<>();
        /** Largest distance from the first member (metres). */
        public double maxDistance;
        public boolean sameName, sameCoords;
    }

    /** Arabic-aware name normalisation: strips diacritics and tatweel, unifies alef/yaa/taa-marbuta, case-folds. */
    public static String normName(String s) {
        if (s == null) return "";
        String t = Normalizer.normalize(s, Normalizer.Form.NFKC);
        StringBuilder b = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if ((c >= 0x064B && c <= 0x065F) || c == 0x0670 || c == 0x0640 || (c >= 0x06D6 && c <= 0x06ED)) continue;
            switch (c) {
                case 'أ': case 'إ': case 'آ': case 'ٱ': c = 'ا'; break;
                case 'ى': case 'ی': case 'ئ': c = 'ي'; break;
                case 'ة': c = 'ه'; break;
                case 'ك': c = 'ك'; break;
                case 'ک': c = 'ك'; break;
                case 'ؤ': c = 'و'; break;
                default: break;
            }
            if (Character.isLetterOrDigit(c)) b.append(Character.toLowerCase(c));
        }
        return b.toString();
    }

    /**
     * @param meters   distance threshold for same-name duplicates
     * @param useName  false: only identical (within 0.1 m) positions count
     */
    public static List<Group> find(List<Feature> feats, double meters, boolean useName) {
        double cell = Math.max(meters, 1) / 111320.0 * 1.5;
        Map<Long, List<Integer>> grid = new HashMap<>();
        int n = feats.size();
        boolean[] used = new boolean[n];
        List<Group> out = new ArrayList<>();
        long[] key = new long[n];
        for (int i = 0; i < n; i++) {
            Feature f = feats.get(i);
            long cx = (long) Math.floor(f.lon / cell), cy = (long) Math.floor(f.lat / cell);
            key[i] = cx * 4000003L + cy;
            List<Integer> l = grid.get(key[i]);
            if (l == null) {
                l = new ArrayList<>(2);
                grid.put(key[i], l);
            }
            l.add(i);
        }
        String[] names = new String[n];
        for (int i = 0; i < n; i++) names[i] = useName ? normName(feats.get(i).name) : "";
        for (int i = 0; i < n; i++) {
            if (used[i]) continue;
            Feature a = feats.get(i);
            long cx = (long) Math.floor(a.lon / cell), cy = (long) Math.floor(a.lat / cell);
            Group g = null;
            for (long dx = -1; dx <= 1; dx++) {
                for (long dy = -1; dy <= 1; dy++) {
                    List<Integer> l = grid.get((cx + dx) * 4000003L + (cy + dy));
                    if (l == null) continue;
                    for (int j : l) {
                        if (j <= i || used[j]) continue;
                        Feature b = feats.get(j);
                        double d = Geodesy.distance(a.lat, a.lon, b.lat, b.lon);
                        boolean same = d <= 0.1;
                        boolean nm = useName && !names[i].isEmpty() && names[i].equals(names[j]) && d <= meters;
                        if (!same && !nm) continue;
                        if (g == null) {
                            g = new Group();
                            g.members.add(a);
                            used[i] = true;
                        }
                        g.members.add(b);
                        used[j] = true;
                        g.maxDistance = Math.max(g.maxDistance, d);
                        g.sameCoords |= same;
                        g.sameName |= nm || (!names[i].isEmpty() && names[i].equals(names[j]));
                    }
                }
            }
            if (g != null) out.add(g);
        }
        return out;
    }

    static String unused() {
        return String.valueOf(Locale.ROOT);
    }
}
