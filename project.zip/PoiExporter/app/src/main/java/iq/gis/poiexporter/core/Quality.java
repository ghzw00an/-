package iq.gis.poiexporter.core;

import iq.gis.poiexporter.core.admin.AdminRef;
import iq.gis.poiexporter.core.io.DupFinder;
import iq.gis.poiexporter.core.io.GeomCheck;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Data-quality checks of one layer and the safe automatic repairs. Nothing here changes data by itself. */
public final class Quality {
    private Quality() {
    }

    /** Rough bounding box of Iraq (lon/lat) used only to flag suspicious coordinates, not as a border. */
    public static final double[] IRAQ_BBOX = {38.6, 28.9, 48.9, 37.5};

    public static final class Report {
        public int total;
        public int emptyName, emptyType, emptyCategory, emptyGathaa, emptyNahia, emptyMohafadha;
        public final List<Feature> invalidGeometry = new ArrayList<>();
        public final Map<String, Integer> geometryCodes = new LinkedHashMap<>();
        public final List<Feature> outsideIraq = new ArrayList<>();
        public final List<DupFinder.Group> duplicates = new ArrayList<>();
        public int duplicateExtra; // features that would be removed (all but the first of each group)
        public final List<Feature> missingAdmin = new ArrayList<>();

        public int problems() {
            return invalidGeometry.size() + outsideIraq.size() + duplicateExtra;
        }

        public String toText(boolean ar) {
            StringBuilder b = new StringBuilder();
            b.append(ar ? "عدد العناصر: " : "Features: ").append(total).append('\n');
            b.append(ar ? "حقول فارغة — " : "Empty fields — ")
                    .append("name ").append(emptyName).append(" • type ").append(emptyType).append(" • Gategory ").append(emptyCategory)
                    .append(" • gathaa ").append(emptyGathaa).append(" • Nahia ").append(emptyNahia).append(" • mohafadha ").append(emptyMohafadha).append('\n');
            b.append(ar ? "هندسة غير صالحة: " : "Invalid geometry: ").append(invalidGeometry.size());
            for (Map.Entry<String, Integer> e : geometryCodes.entrySet())
                b.append("\n   • ").append(GeomCheck.message(e.getKey(), ar)).append(" (").append(e.getValue()).append(')');
            b.append('\n').append(ar ? "خارج نطاق العراق التقريبي: " : "Outside Iraq's rough extent: ").append(outsideIraq.size());
            b.append('\n').append(ar ? "مجموعات مكررة: " : "Duplicate groups: ").append(duplicates.size())
                    .append(ar ? " (يمكن حذف " : " (").append(duplicateExtra).append(ar ? " عنصراً مكرراً)" : " removable)");
            b.append('\n').append(ar ? "بلا قضاء/محافظة وقابلة للملء: " : "Missing qadaa/governorate, fillable: ").append(missingAdmin.size());
            return b.toString();
        }
    }

    private static boolean empty(String s) {
        return s == null || s.trim().isEmpty();
    }

    /** @param dupMeters distance within which same-name landmarks count as duplicates; admin may be null */
    public static Report analyze(LayerData layer, double dupMeters, AdminRef admin) {
        Report r = new Report();
        r.total = layer.features.size();
        List<Feature> points = new ArrayList<>();
        for (Feature f : layer.features) {
            if (empty(f.name)) r.emptyName++;
            if (empty(f.type)) r.emptyType++;
            if (empty(f.category)) r.emptyCategory++;
            if (empty(f.qadaa)) r.emptyGathaa++;
            if (empty(f.nahiya)) r.emptyNahia++;
            if (empty(f.governorate)) r.emptyMohafadha++;
            List<String> codes = GeomCheck.check(f, 0);
            if (!codes.isEmpty()) {
                r.invalidGeometry.add(f);
                for (String c : codes) r.geometryCodes.merge(c, 1, Integer::sum);
            }
            boolean bad = codes.contains(GeomCheck.OUT_OF_RANGE) || codes.contains(GeomCheck.EMPTY);
            if (!bad && (f.lon < IRAQ_BBOX[0] || f.lon > IRAQ_BBOX[2] || f.lat < IRAQ_BBOX[1] || f.lat > IRAQ_BBOX[3])) r.outsideIraq.add(f);
            if (f.geom == Feature.POINT && !bad) points.add(f);
            if (admin != null && !bad && (empty(f.qadaa) || empty(f.governorate))) {
                AdminRef.Hit h = admin.locate(f.lat, f.lon);
                if (h.found()) r.missingAdmin.add(f);
            }
        }
        if (points.size() > 1) {
            r.duplicates.addAll(DupFinder.find(points, dupMeters, true));
            for (DupFinder.Group g : r.duplicates) r.duplicateExtra += g.members.size() - 1;
        }
        return r;
    }

    /** Copies of the features with simple geometry problems repaired (closed rings, orientation, repeated vertices). */
    public static List<Feature[]> repairGeometry(List<Feature> bad, boolean makeValid) {
        List<Feature[]> out = new ArrayList<>();
        for (Feature f : bad) {
            Feature a = f.copy();
            boolean changed = GeomCheck.fix(a);
            if (makeValid && f.geom == Feature.POLYGON && GeomCheck.check(a, 0).contains(GeomCheck.SELF_INTERSECTION)) {
                Feature v = GeomCheck.makeValid(a);
                if (v != null) {
                    v.id = f.id;
                    v.name = f.name;
                    v.type = f.type;
                    v.category = f.category;
                    v.qadaa = f.qadaa;
                    v.nahiya = f.nahiya;
                    v.governorate = f.governorate;
                    v.attrs.putAll(f.attrs);
                    a = v;
                    changed = true;
                }
            }
            if (changed) out.add(new Feature[]{f.copy(), a});
        }
        return out;
    }

    /** Features to delete: all but the first member of each duplicate group. */
    public static List<String> duplicateIdsToRemove(List<DupFinder.Group> groups) {
        List<String> ids = new ArrayList<>();
        for (DupFinder.Group g : groups) for (int i = 1; i < g.members.size(); i++) ids.add(g.members.get(i).id);
        return ids;
    }

    /** Edited copies with qadaa / governorate filled where empty (Arabic names). */
    public static List<Feature[]> fillAdmin(List<Feature> fs, AdminRef admin) {
        List<Feature[]> out = new ArrayList<>();
        for (Feature f : fs) {
            Feature a = f.copy();
            if (admin.fill(a, true)) out.add(new Feature[]{f.copy(), a});
        }
        return out;
    }
}
