package iq.gis.poiexporter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** 3x3 pattern pad. Calls back with "0-1-4-…" (dot numbers, row by row) when the finger lifts. */
final class PatternView extends View {
    interface Done {
        void done(String pattern);
    }

    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Integer> path = new ArrayList<>();
    private float fx, fy;
    private boolean drawing, error;
    private Done cb;

    PatternView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(5f * d);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
    }

    void setDone(Done d) {
        cb = d;
    }

    void flashError() {
        error = true;
        invalidate();
        postDelayed(() -> {
            error = false;
            path.clear();
            invalidate();
        }, 600);
    }

    void reset() {
        path.clear();
        error = false;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        int s = Math.min(MeasureSpec.getSize(w), Math.round(getResources().getDisplayMetrics().density * 300));
        setMeasuredDimension(s, s);
    }

    private float cx(int i) {
        return getWidth() * (1 + 2 * (i % 3)) / 6f;
    }

    private float cy(int i) {
        return getHeight() * (1 + 2 * (i / 3)) / 6f;
    }

    private int hit(float x, float y) {
        float r = getWidth() / 6f * 0.8f;
        for (int i = 0; i < 9; i++) {
            float dx = x - cx(i), dy = y - cy(i);
            if (dx * dx + dy * dy <= r * r) return i;
        }
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (error) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                path.clear();
                drawing = true;
                getParent().requestDisallowInterceptTouchEvent(true);
            case MotionEvent.ACTION_MOVE:
                fx = e.getX();
                fy = e.getY();
                int h = hit(fx, fy);
                if (drawing && h >= 0 && !path.contains(h)) {
                    path.add(h);
                    performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                drawing = false;
                invalidate();
                if (e.getActionMasked() == MotionEvent.ACTION_UP && !path.isEmpty() && cb != null) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < path.size(); i++) sb.append(i > 0 ? "-" : "").append(path.get(i));
                    cb.done(sb.toString());
                }
                return true;
            default:
                return true;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        int col = error ? Theme.danger : Theme.primary;
        line.setColor(col);
        for (int i = 1; i < path.size(); i++) c.drawLine(cx(path.get(i - 1)), cy(path.get(i - 1)), cx(path.get(i)), cy(path.get(i)), line);
        if (drawing && !path.isEmpty()) {
            int l = path.get(path.size() - 1);
            c.drawLine(cx(l), cy(l), fx, fy, line);
        }
        for (int i = 0; i < 9; i++) {
            boolean on = path.contains(i);
            dot.setStyle(Paint.Style.FILL);
            dot.setColor(on ? col : Theme.line);
            c.drawCircle(cx(i), cy(i), (on ? 11f : 8f) * d, dot);
            if (on) {
                dot.setColor((col & 0x00FFFFFF) | 0x33000000);
                c.drawCircle(cx(i), cy(i), 22f * d, dot);
            }
        }
    }
}
