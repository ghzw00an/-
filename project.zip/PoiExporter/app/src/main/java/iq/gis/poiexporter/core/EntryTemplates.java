package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Saved sets of landmark field values used to speed up repeated entry (name and position stay per landmark). */
public final class EntryTemplates {
    public static final class Template {
        public String name = "", type = "", category = "", qadaa = "", nahiya = "", governorate = "";

        public Template copy() {
            Template t = new Template();
            t.name = name;
            t.type = type;
            t.category = category;
            t.qadaa = qadaa;
            t.nahiya = nahiya;
            t.governorate = governorate;
            return t;
        }

        /** Copies the template values into the feature; blank template values leave the feature field unchanged. */
        public void applyTo(Feature f) {
            if (!type.isEmpty()) f.type = type;
            if (!category.isEmpty()) f.category = category;
            if (!qadaa.isEmpty()) f.qadaa = qadaa;
            if (!nahiya.isEmpty()) f.nahiya = nahiya;
            if (!governorate.isEmpty()) f.governorate = governorate;
        }
    }

    private EntryTemplates() {
    }

    public static String toJson(List<Template> list) {
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            Template t = list.get(i);
            if (i > 0) b.append(',');
            b.append("{\"name\":").append(MiniJson.quote(t.name))
                    .append(",\"type\":").append(MiniJson.quote(t.type))
                    .append(",\"category\":").append(MiniJson.quote(t.category))
                    .append(",\"qadaa\":").append(MiniJson.quote(t.qadaa))
                    .append(",\"nahiya\":").append(MiniJson.quote(t.nahiya))
                    .append(",\"governorate\":").append(MiniJson.quote(t.governorate)).append('}');
        }
        return b.append(']').toString();
    }

    @SuppressWarnings("unchecked")
    public static List<Template> fromJson(String json) {
        List<Template> out = new ArrayList<>();
        if (json == null || json.trim().isEmpty()) return out;
        try {
            Object o = MiniJson.parse(json);
            if (!(o instanceof List)) return out;
            for (Object e : (List<Object>) o) {
                if (!(e instanceof Map)) continue;
                Map<String, Object> m = (Map<String, Object>) e;
                Template t = new Template();
                t.name = MiniJson.str(m, "name", "");
                if (t.name.isEmpty()) continue;
                t.type = MiniJson.str(m, "type", "");
                t.category = MiniJson.str(m, "category", "");
                t.qadaa = MiniJson.str(m, "qadaa", "");
                t.nahiya = MiniJson.str(m, "nahiya", "");
                t.governorate = MiniJson.str(m, "governorate", "");
                out.add(t);
            }
        } catch (RuntimeException ex) {
            // damaged setting: start with no templates
        }
        return out;
    }
}
