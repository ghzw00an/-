package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LandmarkFields;
import iq.gis.poiexporter.core.Kml;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.ShapeWriter;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.table.XlsxWriter;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Export of layers to every supported format, with a pre-flight check that shows problems BEFORE a file is written. */
public final class ExportHub {
    private ExportHub() {
    }

    /** Warnings for the user: invalid geometry, unsupported CRS, truncated names, size limits. Empty list = safe. */
    public static List<String> preflight(List<LayerData> layers, GeoFormat fmt, ExportOptions o) {
        List<String> w = new ArrayList<>();
        long n = 0;
        int bad = 0, empty = 0, selfX = 0, noName = 0;
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                n++;
                List<String> issues = GeomCheck.check(f, 0);
                if (issues.contains(GeomCheck.EMPTY) || issues.contains(GeomCheck.TOO_FEW_POINTS)) empty++;
                else if (issues.contains(GeomCheck.OUT_OF_RANGE)) bad++;
                else if (issues.contains(GeomCheck.SELF_INTERSECTION)) selfX++;
            }
        }
        if (n == 0) w.add(S.t("لا توجد عناصر للتصدير.", "Nothing to export."));
        if (empty > 0) w.add(S.t(empty + " عنصر بلا هندسة صالحة سيُتجاهل.", empty + " features without valid geometry will be skipped."));
        if (bad > 0) w.add(S.t(bad + " عنصر بإحداثيات خارج النطاق.", bad + " features have out-of-range coordinates."));
        if (selfX > 0) w.add(S.t(selfX + " مضلع يتقاطع مع نفسه؛ قد ترفضه برامج GIS. استخدم «فحص الجودة» للإصلاح.",
                selfX + " polygons cross themselves; GIS software may reject them. Use the quality check to repair."));
        Crs t = o.target();
        boolean wgsOnly = fmt == GeoFormat.KML || fmt == GeoFormat.KMZ || fmt == GeoFormat.GPX || fmt == GeoFormat.GPKG;
        if (wgsOnly && t.epsg != 4326)
            w.add(S.t(fmt.label + " يدعم WGS84 فقط؛ اختر WGS84 أو صيغة أخرى (Shapefile / CSV / GeoJSON).",
                    fmt.label + " supports WGS84 only; choose WGS84 or another format (Shapefile / CSV / GeoJSON)."));
        if (fmt == GeoFormat.SHP_ZIP) {
            try {
                Wkt.of(t);
            } catch (IllegalArgumentException e) {
                w.add(e.getMessage());
            }
            if (n > 5_000_000) w.add(S.t("عدد كبير جداً لملف Shapefile (حد 2 جيغابايت)", "Very large for a shapefile (2 GB limit)"));
        }
        if (fmt == GeoFormat.XLSX && n > 1_000_000)
            w.add(S.t("سيُقسَّم الجدول على عدة أوراق (حد Excel مليون صف).", "The table is split across sheets (Excel limit is 1M rows)."));
        if (fmt == GeoFormat.GPX) {
            boolean poly = false;
            for (LayerData l : layers) for (Feature f : l.features) if (f.geom == Feature.POLYGON) poly = true;
            if (poly) w.add(S.t("GPX لا يدعم المضلعات؛ ستُكتب حدودها كمسارات.", "GPX has no polygons; outlines are written as tracks."));
        }
        return w;
    }

    private static void requireWgs(GeoFormat fmt, ExportOptions o) {
        if (o.target().epsg != 4326)
            throw new IllegalArgumentException(S.t(fmt.label + " يدعم WGS84 فقط", fmt.label + " supports WGS84 only"));
    }

    /** Writes the layers to the stream. GPKG is written by {@link #writeGpkg}. */
    public static void write(List<LayerData> layers, GeoFormat fmt, ExportOptions o, OutputStream os) throws IOException {
        switch (fmt) {
            case GEOJSON:
                GeoJson.write(layers, o, os);
                break;
            case KML:
                requireWgs(fmt, o);
                Kml.write(layers, o.docName, CoordFmt.Fmt.DD, false, os);
                break;
            case KMZ:
                requireWgs(fmt, o);
                Kml.write(layers, o.docName, CoordFmt.Fmt.DD, true, os);
                break;
            case GPX:
                requireWgs(fmt, o);
                Gpx.write(layers, o, os);
                break;
            case SHP_ZIP:
                ShapeWriter.writeZipGeneric(layers, o.target, o.attributes, os);
                break;
            case CSV:
                writeTable(layers, o, os, false);
                break;
            case XLSX:
                writeTable(layers, o, os, true);
                break;
            default:
                throw new IOException(S.t("صيغة تصدير غير مدعومة", "Unsupported export format"));
        }
    }

    public static Gpkg.ExportResult writeGpkg(List<LayerData> layers, ExportOptions o, Gpkg.SqlExec db) throws IOException {
        requireWgs(GeoFormat.GPKG, o);
        return Gpkg.write(layers, db, o.attributes);
    }

    // ------------------------------------------------------------------ CSV / XLSX tables

    private static List<String> header(List<LayerData> layers, Set<String> attrKeys, boolean attributes, boolean anyNonPoint) {
        List<String> h = new ArrayList<>(java.util.Arrays.asList(LandmarkFields.NAMES));
        if (attributes) {
            for (LayerData l : layers) {
                for (Feature f : l.features) {
                    for (String k : f.attrs.keySet()) if (!LandmarkFields.isStd(k)) attrKeys.add(k);
                    if (attrKeys.size() > 200) break;
                }
            }
            h.addAll(attrKeys);
        }
        if (anyNonPoint) h.add("geometry");
        return h;
    }

    private static void writeTable(List<LayerData> layers, ExportOptions o, OutputStream os, boolean xlsx) throws IOException {
        // default (no system chosen): x, y = UTM of each point; otherwise x, y in the chosen system
        final boolean utm = o.target == null;
        Crs t = o.target();
        Crs.Tx tx = utm || t.epsg == 4326 ? null : Crs.wgs84().to(t);
        boolean anyNonPoint = false;
        for (LayerData l : layers) for (Feature f : l.features) if (f.geom != Feature.POINT) anyNonPoint = true;
        Set<String> keys = new LinkedHashSet<>();
        List<String> h = header(layers, keys, o.attributes, anyNonPoint);
        Writer w = null;
        XlsxWriter xw = null;
        if (xlsx) {
            xw = new XlsxWriter(os, "data", S.ar, 1_000_000);
            xw.header(h);
        } else {
            w = new BufferedWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8), 1 << 16);
            w.write('﻿');
            writeCsvRow(w, h.toArray(new String[0]));
        }
        int dec = !utm && t.geographic ? 9 : 3;
        double scale = Math.pow(10, dec);
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                if (f.parts.isEmpty()) continue;
                double[] xy;
                if (utm) xy = LandmarkFields.xy(f, null);
                else if (tx == null) xy = new double[]{f.lon, f.lat};
                else xy = LandmarkFields.xy(f, tx);
                if (Double.isNaN(xy[0]) || Double.isNaN(xy[1])) continue;
                List<Object> row = new ArrayList<>();
                String[] text = LandmarkFields.text(f);
                for (String s : text) row.add(s);
                if (xlsx) {
                    row.add(Double.valueOf(Math.round(xy[0] * scale) / scale));
                    row.add(Double.valueOf(Math.round(xy[1] * scale) / scale));
                } else {
                    row.add(num(xy[0], dec));
                    row.add(num(xy[1], dec));
                }
                row.add(LandmarkFields.link(f));
                if (o.attributes) for (String k : keys) row.add(f.attrs.containsKey(k) ? f.attrs.get(k) : "");
                if (anyNonPoint) row.add(f.geom == Feature.POINT ? "Point" : f.geom == Feature.LINE ? "Line" : "Polygon");
                if (xlsx) {
                    xw.row(row.toArray());
                } else {
                    String[] cells = new String[row.size()];
                    for (int i = 0; i < cells.length; i++) cells[i] = String.valueOf(row.get(i));
                    writeCsvRow(w, cells);
                }
            }
        }
        if (xlsx) xw.close();
        else w.flush();
    }

    private static String num(double v, int dec) {
        return String.format(Locale.US, "%." + dec + "f", v);
    }

    private static void writeCsvRow(Writer w, String[] cells) throws IOException {
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) w.write(',');
            String s = cells[i] == null ? "" : cells[i];
            boolean q = s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0;
            if (q) w.write("\"" + s.replace("\"", "\"\"") + "\"");
            else w.write(s);
        }
        w.write("\r\n");
    }
}
