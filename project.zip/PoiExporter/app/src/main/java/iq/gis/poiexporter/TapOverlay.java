package iq.gis.poiexporter;

import android.view.MotionEvent;

import org.osmdroid.api.IGeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

/** Reports single taps on the map while enabled (used for adding landmarks by hand). */
public final class TapOverlay extends Overlay {
    public interface Tapped {
        void at(double lat, double lon);
    }

    private boolean enabled;
    private Tapped cb;

    public void setEnabled2(boolean e, Tapped c) {
        enabled = e;
        cb = c;
    }

    public boolean isOn() {
        return enabled;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e, MapView map) {
        if (!enabled || cb == null) return false;
        IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
        cb.at(g.getLatitude(), g.getLongitude());
        return true;
    }
}
