package iq.gis.poiexporter.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/** KML and KMZ reading and writing (points, lines, polygons with holes). */
public final class Kml {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final String[] COLORS = {"e53935", "1e88e5", "43a047", "fb8c00", "8e24aa", "00acc1", "6d4c41", "546e7a", "d81b60", "7cb342"};

    private Kml() {}

    public static void write(List<LayerData> layers, String docName, CoordFmt.Fmt fmt, boolean kmz, OutputStream os)
            throws IOException {
        try {
            if (kmz) {
                ZipOutputStream z = new ZipOutputStream(os);
                z.setLevel(6);
                z.putNextEntry(new ZipEntry("doc.kml"));
                Writer w = new BufferedWriter(new OutputStreamWriter(z, UTF8), 1 << 16);
                emit(new Sink(w), layers, docName, fmt);
                w.flush();
                z.closeEntry();
                z.finish();
                z.flush();
            } else {
                Writer w = new BufferedWriter(new OutputStreamWriter(os, UTF8), 1 << 16);
                emit(new Sink(w), layers, docName, fmt);
                w.flush();
                os.flush();
            }
        } catch (UncheckedIOException e) {
            throw e.getCause();
        }
    }

    /** Small adapter so the XML can be written to a stream without building it in memory. */
    private static final class Sink {
        private final Writer w;

        Sink(Writer w) {
            this.w = w;
        }

        Sink append(String s) {
            try {
                w.write(s);
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
            return this;
        }

        Sink append(char c) {
            try {
                w.write(c);
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
            return this;
        }

        Sink append(long v) {
            return append(Long.toString(v));
        }
    }

    static String esc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&': sb.append("&amp;"); break;
                case '<': sb.append("&lt;"); break;
                case '>': sb.append("&gt;"); break;
                case '"': sb.append("&quot;"); break;
                case '\'': sb.append("&apos;"); break;
                default:
                    if (c >= 0x20 || c == '\n' || c == '\t' || c == '\r') sb.append(c);
            }
        }
        return sb.toString();
    }

    private static void num(Sink sb, double v) {
        long q = Math.round(v * 1e7);
        if (q < 0) {
            sb.append('-');
            q = -q;
        }
        long ip = q / 10000000L, fp = q % 10000000L;
        sb.append(ip).append('.');
        String f = Long.toString(fp);
        for (int i = f.length(); i < 7; i++) sb.append('0');
        sb.append(f);
    }

    private static void coords(Sink sb, double[] p) {
        sb.append("<coordinates>");
        for (int i = 0; i + 1 < p.length; i += 2) {
            if (i > 0) sb.append(' ');
            num(sb, p[i]);
            sb.append(',');
            num(sb, p[i + 1]);
            sb.append(",0");
        }
        sb.append("</coordinates>");
    }

    private static void data(Sink sb, String k, String v) {
        if (v == null || v.isEmpty()) return;
        sb.append("<Data name=\"").append(k).append("\"><value>").append(esc(v)).append("</value></Data>");
    }

    public static String toKml(List<LayerData> layers, String docName, CoordFmt.Fmt fmt) {
        StringWriter sw = new StringWriter(1 << 12);
        emit(new Sink(sw), layers, docName, fmt);
        return sw.toString();
    }

    private static void emit(Sink sb, List<LayerData> layers, String docName, CoordFmt.Fmt fmt) {
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>")
                .append(esc(docName)).append("</name>\n");
        for (int i = 0; i < layers.size(); i++) {
            String c = COLORS[i % COLORS.length];
            String abgr = "ff" + c.substring(4, 6) + c.substring(2, 4) + c.substring(0, 2);
            sb.append("<Style id=\"s").append(i).append("\"><IconStyle><color>").append(abgr)
                    .append("</color><scale>0.9</scale></IconStyle><LineStyle><color>").append(abgr)
                    .append("</color><width>2</width></LineStyle><PolyStyle><color>55").append(abgr.substring(2))
                    .append("</color></PolyStyle></Style>\n");
        }
        for (int i = 0; i < layers.size(); i++) {
            LayerData l = layers.get(i);
            sb.append("<Folder><name>").append(esc(l.label)).append("</name>\n");
            for (Feature f : l.features) placemark(sb, f, i, fmt);
            sb.append("</Folder>\n");
        }
        sb.append("</Document></kml>\n");
    }

    private static void placemark(Sink sb, Feature f, int style, CoordFmt.Fmt fmt) {
        if (f.parts.isEmpty()) return;
        String coord;
        try {
            coord = CoordFmt.format(fmt, f.lat, f.lon);
        } catch (RuntimeException e) {
            coord = CoordFmt.dd(f.lat, f.lon);
        }
        sb.append("<Placemark><name>").append(esc(f.name)).append("</name><styleUrl>#s").append(style).append("</styleUrl>");
        StringBuilder d = new StringBuilder();
        if (!f.category.isEmpty()) d.append(f.category).append('\n');
        if (!f.type.isEmpty()) d.append(f.type).append('\n');
        String admin = join(" / ", f.nahiya, f.qadaa, f.governorate);
        if (!admin.isEmpty()) d.append(admin).append('\n');
        d.append(coord);
        sb.append("<description>").append(esc(d.toString())).append("</description><ExtendedData>");
        data(sb, "name", f.name);
        data(sb, "type", f.type);
        data(sb, "Gategory", f.category);
        data(sb, "gathaa", f.qadaa);
        data(sb, "Nahia", f.nahiya);
        data(sb, "mohafadha", f.governorate);
        double[] xy = LandmarkFields.xy(f, null);
        data(sb, "x", LandmarkFields.num(xy[0], 2));
        data(sb, "y", LandmarkFields.num(xy[1], 2));
        data(sb, "link", LandmarkFields.link(f));
        sb.append("</ExtendedData>");
        if (f.geom == Feature.POINT) {
            sb.append("<Point>");
            coords(sb, f.parts.get(0));
            sb.append("</Point>");
        } else if (f.geom == Feature.LINE) {
            boolean multi = f.parts.size() > 1;
            if (multi) sb.append("<MultiGeometry>");
            for (double[] p : f.parts) {
                sb.append("<LineString>");
                coords(sb, p);
                sb.append("</LineString>");
            }
            if (multi) sb.append("</MultiGeometry>");
        } else {
            List<Integer> outers = new ArrayList<>();
            for (int i = 0; i < f.parts.size(); i++) if (!f.isHole(i)) outers.add(i);
            Map<Integer, List<Integer>> holesOf = new LinkedHashMap<>();
            for (int o : outers) holesOf.put(o, new ArrayList<Integer>());
            for (int i = 0; i < f.parts.size(); i++) {
                if (!f.isHole(i)) continue;
                double[] h = f.parts.get(i);
                int owner = outers.isEmpty() ? -1 : outers.get(0);
                for (int o : outers) {
                    if (Geo.pointInRing(h[0], h[1], f.parts.get(o))) {
                        owner = o;
                        break;
                    }
                }
                if (owner >= 0) holesOf.get(owner).add(i);
            }
            boolean multi = outers.size() > 1;
            if (multi) sb.append("<MultiGeometry>");
            for (int o : outers) {
                sb.append("<Polygon><outerBoundaryIs><LinearRing>");
                coords(sb, f.parts.get(o));
                sb.append("</LinearRing></outerBoundaryIs>");
                for (int h : holesOf.get(o)) {
                    sb.append("<innerBoundaryIs><LinearRing>");
                    coords(sb, f.parts.get(h));
                    sb.append("</LinearRing></innerBoundaryIs>");
                }
                sb.append("</Polygon>");
            }
            if (multi) sb.append("</MultiGeometry>");
        }
        sb.append("</Placemark>\n");
    }

    private static String join(String sep, String... v) {
        StringBuilder sb = new StringBuilder();
        for (String s : v) {
            if (s == null || s.isEmpty()) continue;
            if (sb.length() > 0) sb.append(sep);
            sb.append(s);
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ reading

    public static List<LayerData> read(InputStream in, String fileName) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        byte[] bytes = bo.toByteArray();
        if (bytes.length > 3 && bytes[0] == 'P' && bytes[1] == 'K') bytes = kmlFromZip(bytes);
        String base = fileName == null ? "Imported" : fileName.replaceAll("\\.[A-Za-z0-9]+$", "");
        Document doc;
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setNamespaceAware(false);
            try {
                f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            } catch (Exception ignored) {
                // not every parser supports it; Android's does not resolve external entities anyway
            }
            f.setExpandEntityReferences(false);
            DocumentBuilder b = f.newDocumentBuilder();
            doc = b.parse(new ByteArrayInputStream(bytes));
        } catch (Exception e) {
            throw new IOException("Not a valid KML file");
        }
        Map<String, LayerData> out = new LinkedHashMap<>();
        walk(doc.getDocumentElement(), base, out);
        return new ArrayList<>(out.values());
    }

    private static byte[] kmlFromZip(byte[] zip) throws IOException {
        ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(zip));
        byte[] best = null;
        ZipEntry e;
        while ((e = z.getNextEntry()) != null) {
            String nm = e.getName().toLowerCase(Locale.US);
            if (!nm.endsWith(".kml")) continue;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = z.read(buf)) > 0) bo.write(buf, 0, n);
            if (best == null || nm.equals("doc.kml")) best = bo.toByteArray();
        }
        if (best == null) throw new IOException("KMZ has no KML inside");
        return best;
    }

    private static String childText(Element e, String tag) {
        for (Node c = e.getFirstChild(); c != null; c = c.getNextSibling()) {
            if (c.getNodeType() == Node.ELEMENT_NODE && c.getNodeName().equals(tag)) return c.getTextContent().trim();
        }
        return "";
    }

    private static void walk(Element e, String folder, Map<String, LayerData> out) {
        String tag = e.getNodeName();
        if (tag.equals("Placemark")) {
            placemarkIn(e, folder, out);
            return;
        }
        String f = folder;
        boolean nested = e.getParentNode() != null && e.getParentNode().getNodeType() == Node.ELEMENT_NODE;
        if (tag.equals("Folder") || (tag.equals("Document") && nested)) {
            String nm = childText(e, "name");
            if (!nm.isEmpty()) f = nm;
        }
        for (Node c = e.getFirstChild(); c != null; c = c.getNextSibling()) {
            if (c.getNodeType() == Node.ELEMENT_NODE) walk((Element) c, f, out);
        }
    }

    private static void placemarkIn(Element pm, String folder, Map<String, LayerData> out) {
        String name = childText(pm, "name");
        Map<String, String> attrs = new LinkedHashMap<>();
        NodeList ds = pm.getElementsByTagName("Data");
        for (int i = 0; i < ds.getLength(); i++) {
            Element d = (Element) ds.item(i);
            attrs.put(d.getAttribute("name").toUpperCase(Locale.US), childText(d, "value"));
        }
        NodeList sd = pm.getElementsByTagName("SimpleData");
        for (int i = 0; i < sd.getLength(); i++) {
            Element d = (Element) sd.item(i);
            attrs.put(d.getAttribute("name").toUpperCase(Locale.US), d.getTextContent().trim());
        }
        List<double[]> points = new ArrayList<>();
        List<double[]> lines = new ArrayList<>();
        List<double[]> rings = new ArrayList<>();
        List<Boolean> holes = new ArrayList<>();
        collect(pm, points, lines, rings, holes);

        for (double[] p : points) {
            Feature f = Feature.point(p[1], p[0]);
            fill(f, name, attrs, folder);
            put(out, folder, f);
        }
        if (!lines.isEmpty()) {
            Feature f = new Feature();
            f.geom = Feature.LINE;
            for (double[] l : lines) f.addPart(l, false);
            Geo.setRepresentative(f);
            fill(f, name, attrs, folder);
            put(out, folder, f);
        }
        if (!rings.isEmpty()) {
            Feature f = new Feature();
            f.geom = Feature.POLYGON;
            for (int i = 0; i < rings.size(); i++) f.addPart(rings.get(i), holes.get(i));
            Geo.setRepresentative(f);
            fill(f, name, attrs, folder);
            put(out, folder, f);
        }
    }

    private static void fill(Feature f, String name, Map<String, String> a, String folder) {
        f.name = name.isEmpty() ? val(a, "NAME") : name;
        f.type = val(a, "TYPE");
        f.category = val(a, "GATEGORY");
        if (f.category.isEmpty()) f.category = val(a, "CATEGORY");
        if (f.category.isEmpty()) f.category = folder;
        f.nahiya = val(a, "NAHIA");
        if (f.nahiya.isEmpty()) f.nahiya = val(a, "NAHIYA");
        f.qadaa = val(a, "GATHAA");
        if (f.qadaa.isEmpty()) f.qadaa = val(a, "QADAA");
        f.governorate = val(a, "MOHAFADHA");
        if (f.governorate.isEmpty()) f.governorate = val(a, "GOVERNORAT");
        if (f.governorate.isEmpty()) f.governorate = val(a, "GOVERNORATE");
        LandmarkFields.setLink(f, val(a, "LINK"));
    }

    private static String val(Map<String, String> a, String k) {
        String v = a.get(k);
        return v == null ? "" : v;
    }

    private static void put(Map<String, LayerData> out, String folder, Feature f) {
        String id = "imp_" + ShapeWriter.safeName(folder) + "_" + LayerData.geomName(f.geom);
        LayerData l = out.get(id);
        if (l == null) {
            l = new LayerData(id, folder, f.geom);
            out.put(id, l);
        }
        l.features.add(f);
    }

    private static void collect(Element e, List<double[]> points, List<double[]> lines, List<double[]> rings, List<Boolean> holes) {
        for (Node c = e.getFirstChild(); c != null; c = c.getNextSibling()) {
            if (c.getNodeType() != Node.ELEMENT_NODE) continue;
            Element ch = (Element) c;
            String t = ch.getNodeName();
            if (t.equals("Point")) {
                double[] p = coordsOf(ch);
                if (p != null && p.length >= 2) points.add(new double[]{p[0], p[1]});
            } else if (t.equals("LineString")) {
                double[] p = coordsOf(ch);
                if (p != null && p.length >= 4) lines.add(p);
            } else if (t.equals("Polygon")) {
                for (Node pc = ch.getFirstChild(); pc != null; pc = pc.getNextSibling()) {
                    if (pc.getNodeType() != Node.ELEMENT_NODE) continue;
                    String pt = pc.getNodeName();
                    boolean hole = pt.equals("innerBoundaryIs");
                    if (!hole && !pt.equals("outerBoundaryIs")) continue;
                    NodeList lr = ((Element) pc).getElementsByTagName("LinearRing");
                    for (int i = 0; i < lr.getLength(); i++) {
                        double[] p = coordsOf((Element) lr.item(i));
                        if (p != null && p.length >= 6) {
                            rings.add(p);
                            holes.add(hole);
                        }
                    }
                }
            } else if (t.equals("MultiGeometry")) {
                collect(ch, points, lines, rings, holes);
            }
        }
    }

    private static double[] coordsOf(Element e) {
        NodeList nl = e.getElementsByTagName("coordinates");
        if (nl.getLength() == 0) return null;
        String[] tok = nl.item(0).getTextContent().trim().split("\\s+");
        double[] tmp = new double[tok.length * 2];
        int n = 0;
        for (String t : tok) {
            String[] p = t.split(",");
            if (p.length < 2) continue;
            try {
                double x = Double.parseDouble(p[0]), y = Double.parseDouble(p[1]);
                tmp[n++] = x;
                tmp[n++] = y;
            } catch (NumberFormatException ex) {
                // skip a malformed coordinate triple
            }
        }
        return java.util.Arrays.copyOf(tmp, n);
    }
}
