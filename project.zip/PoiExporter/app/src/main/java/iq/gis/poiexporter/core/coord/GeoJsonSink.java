package iq.gis.poiexporter.core.coord;

import iq.gis.poiexporter.core.MiniJson;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.Locale;

/** RFC 7946 FeatureCollection in WGS84; every column becomes a property. */
public final class GeoJsonSink implements Sink {
    private final BufferedWriter w;
    private List<String> cols;
    private boolean first = true;

    public GeoJsonSink(OutputStream os) throws IOException {
        w = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"), 1 << 16);
    }

    public void begin(List<String> columns) throws IOException {
        cols = columns;
        w.write("{\"type\":\"FeatureCollection\",\"features\":[");
    }

    public void row(Object[] cells, double lon, double lat) throws IOException {
        StringBuilder b = new StringBuilder(256);
        if (!first) b.append(',');
        first = false;
        b.append("\n{\"type\":\"Feature\",\"geometry\":{\"type\":\"Point\",\"coordinates\":[")
                .append(String.format(Locale.US, "%.9f", lon)).append(',').append(String.format(Locale.US, "%.9f", lat))
                .append("]},\"properties\":{");
        boolean any = false;
        for (int i = 0; i < cells.length && i < cols.size(); i++) {
            Object o = cells[i];
            if (o == null) continue;
            if (any) b.append(',');
            any = true;
            MiniJson.quote(cols.get(i), b);
            b.append(':');
            if (o instanceof BatchConverter.Num) b.append(((BatchConverter.Num) o).text());
            else if (o instanceof Number) b.append(o);
            else MiniJson.quote(String.valueOf(o), b);
        }
        b.append("}}");
        w.write(b.toString());
    }

    public void end() throws IOException {
        w.write("\n]}\n");
        w.flush();
        w.close();
    }
}
