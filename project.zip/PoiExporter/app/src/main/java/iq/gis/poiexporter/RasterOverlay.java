package iq.gis.poiexporter;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

/** Draws the placed aerial images under the data. Each image is stretched onto its four corner points. */
final class RasterOverlay extends Overlay {
    private final RasterStore store;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Matrix m = new Matrix();

    RasterOverlay(RasterStore s) {
        store = s;
    }

    @Override
    public void draw(Canvas c, MapView map, boolean shadow) {
        if (shadow) return;
        Point p = new Point();
        for (RasterStore.Item it : store.items) {
            if (!it.visible) continue;
            float[] dst = new float[8];
            boolean any = false;
            for (int i = 0; i < 4; i++) {
                map.getProjection().toPixels(new GeoPoint(it.corners[2 * i + 1], it.corners[2 * i]), p);
                dst[2 * i] = p.x;
                dst[2 * i + 1] = p.y;
            }
            float minX = Math.min(Math.min(dst[0], dst[2]), Math.min(dst[4], dst[6])), maxX = Math.max(Math.max(dst[0], dst[2]), Math.max(dst[4], dst[6]));
            float minY = Math.min(Math.min(dst[1], dst[3]), Math.min(dst[5], dst[7])), maxY = Math.max(Math.max(dst[1], dst[3]), Math.max(dst[5], dst[7]));
            if (maxX < 0 || maxY < 0 || minX > map.getWidth() || minY > map.getHeight()) continue; // off screen
            if (maxX - minX > 40000 || maxY - minY > 40000) continue; // absurdly zoomed in: skip rather than overflow
            Bitmap b = store.bitmap(it);
            if (b == null) continue;
            float[] src = {0, 0, b.getWidth(), 0, b.getWidth(), b.getHeight(), 0, b.getHeight()};
            m.setPolyToPoly(src, 0, dst, 0, 4);
            paint.setAlpha(Math.round(255 * Math.max(0f, Math.min(1f, it.opacity))));
            c.drawBitmap(b, m, paint);
        }
    }
}
