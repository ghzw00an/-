package iq.gis.poiexporter.core.raster;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/**
 * Pure-Java reader for TIFF and GeoTIFF aerial/satellite images (classic TIFF and BigTIFF).
 * Supports: strips and tiles; compression none, LZW, Deflate, PackBits; horizontal predictor; 1/8/16/32-bit samples
 * (32-bit as float); gray, palette, RGB, RGBA and CMYK. Not supported (clear error): JPEG-in-TIFF, separate planes,
 * YCbCr, JPEG2000. The image is subsampled while reading so that a huge file never has to fit in memory:
 * the longest side of the result is at most maxSide pixels.
 */
public final class TiffReader {
    private TiffReader() {
    }

    public static final class Image {
        public int srcW, srcH, w, h, step;
        /** Pixels as ARGB, w*h. */
        public int[] argb;
        /** x = a*col + b*row + c, y = d*col + e*row + f for the FULL-resolution image, pixel-corner based; null without georeferencing. */
        public double[] affine;
        /** EPSG code of the georeferencing, 0 when absent or user-defined. */
        public int epsg;
        public String note = "";
    }

    private static final int T_W = 256, T_H = 257, T_BITS = 258, T_COMP = 259, T_PHOTO = 262, T_STRIP_OFF = 273, T_SPP = 277, T_ROWS = 278,
            T_STRIP_CNT = 279, T_PLANAR = 284, T_PRED = 317, T_CMAP = 320, T_TW = 322, T_TH = 323, T_TILE_OFF = 324, T_TILE_CNT = 325,
            T_EXTRA = 338, T_SFMT = 339, T_SCALE = 33550, T_TIE = 33922, T_MATRIX = 34264, T_GEOKEYS = 34735, T_NODATA = 42113;

    private static final class Ifd {
        final Map<Integer, long[]> longs = new HashMap<>();
        final Map<Integer, double[]> doubles = new HashMap<>();
        final Map<Integer, String> ascii = new HashMap<>();

        long one(int tag, long def) {
            long[] v = longs.get(tag);
            return v == null || v.length == 0 ? def : v[0];
        }
    }

    private static final int[] TYPE_SIZE = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8, 4, 0, 0, 8, 8, 8};

    public static Image read(File file, int maxSide) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] head = new byte[16];
            raf.readFully(head, 0, 8);
            ByteOrder bo;
            if (head[0] == 'I' && head[1] == 'I') bo = ByteOrder.LITTLE_ENDIAN;
            else if (head[0] == 'M' && head[1] == 'M') bo = ByteOrder.BIG_ENDIAN;
            else throw new IOException("Not a TIFF file");
            ByteBuffer hb = ByteBuffer.wrap(head).order(bo);
            int magic = hb.getShort(2) & 0xFFFF;
            boolean big = magic == 43;
            if (magic != 42 && magic != 43) throw new IOException("Not a TIFF file");
            long ifdOff;
            if (big) {
                raf.seek(8);
                raf.readFully(head, 8, 8);
                ifdOff = hb.getLong(8);
            } else ifdOff = hb.getInt(4) & 0xFFFFFFFFL;
            Ifd ifd = readIfd(raf, ifdOff, bo, big);
            return decode(raf, ifd, bo, maxSide);
        }
    }

    private static Ifd readIfd(RandomAccessFile raf, long off, ByteOrder bo, boolean big) throws IOException {
        if (off <= 0 || off >= raf.length()) throw new IOException("Bad TIFF directory offset");
        raf.seek(off);
        byte[] c = new byte[8];
        raf.readFully(c, 0, big ? 8 : 2);
        long n = big ? ByteBuffer.wrap(c).order(bo).getLong() : ByteBuffer.wrap(c).order(bo).getShort() & 0xFFFF;
        if (n <= 0 || n > 5000) throw new IOException("Bad TIFF directory");
        int es = big ? 20 : 12;
        byte[] all = new byte[(int) (n * es)];
        raf.readFully(all);
        ByteBuffer b = ByteBuffer.wrap(all).order(bo);
        Ifd ifd = new Ifd();
        for (int i = 0; i < n; i++) {
            int p = i * es;
            int tag = b.getShort(p) & 0xFFFF, type = b.getShort(p + 2) & 0xFFFF;
            long count = big ? b.getLong(p + 4) : b.getInt(p + 4) & 0xFFFFFFFFL;
            int vp = p + (big ? 12 : 8);
            if (type < 1 || type >= TYPE_SIZE.length || TYPE_SIZE[type] == 0) continue;
            long bytes = count * TYPE_SIZE[type];
            if (bytes > 64L * 1024 * 1024 || count > 50_000_000L) continue;
            ByteBuffer data;
            if (bytes <= (big ? 8 : 4)) data = ByteBuffer.wrap(all, vp, (int) bytes).order(bo);
            else {
                long vo = big ? b.getLong(vp) : b.getInt(vp) & 0xFFFFFFFFL;
                if (vo < 0 || vo + bytes > raf.length()) continue;
                byte[] d = new byte[(int) bytes];
                raf.seek(vo);
                raf.readFully(d);
                data = ByteBuffer.wrap(d).order(bo);
            }
            int cnt = (int) count;
            if (type == 2) {
                byte[] s = new byte[cnt];
                data.get(s);
                ifd.ascii.put(tag, new String(s, java.nio.charset.StandardCharsets.ISO_8859_1).replace("\0", "|"));
            } else if (type == 12 || type == 11 || type == 5 || type == 10) {
                double[] v = new double[cnt];
                for (int k = 0; k < cnt; k++) {
                    if (type == 12) v[k] = data.getDouble();
                    else if (type == 11) v[k] = data.getFloat();
                    else {
                        long nu = data.getInt() & 0xFFFFFFFFL, de = data.getInt() & 0xFFFFFFFFL;
                        v[k] = de == 0 ? 0 : (double) nu / de;
                    }
                }
                ifd.doubles.put(tag, v);
            } else {
                long[] v = new long[cnt];
                for (int k = 0; k < cnt; k++) {
                    switch (type) {
                        case 1:
                        case 7:
                            v[k] = data.get() & 0xFF;
                            break;
                        case 6:
                            v[k] = data.get();
                            break;
                        case 3:
                            v[k] = data.getShort() & 0xFFFF;
                            break;
                        case 8:
                            v[k] = data.getShort();
                            break;
                        case 4:
                            v[k] = data.getInt() & 0xFFFFFFFFL;
                            break;
                        case 9:
                            v[k] = data.getInt();
                            break;
                        default:
                            v[k] = data.getLong();
                    }
                }
                ifd.longs.put(tag, v);
            }
        }
        return ifd;
    }

    // ------------------------------------------------------------------------------------------------ decoding

    private static Image decode(RandomAccessFile raf, Ifd ifd, ByteOrder bo, int maxSide) throws IOException {
        int W = (int) ifd.one(T_W, 0), H = (int) ifd.one(T_H, 0);
        if (W <= 0 || H <= 0) throw new IOException("Image has no size");
        int comp = (int) ifd.one(T_COMP, 1), photo = (int) ifd.one(T_PHOTO, 1), spp = (int) ifd.one(T_SPP, 1);
        int planar = (int) ifd.one(T_PLANAR, 1), pred = (int) ifd.one(T_PRED, 1), sfmt = (int) ifd.one(T_SFMT, 1);
        long[] bitsArr = ifd.longs.get(T_BITS);
        int bits = bitsArr == null || bitsArr.length == 0 ? 1 : (int) bitsArr[0];
        if (bitsArr != null) for (long x : bitsArr) if (x != bits) throw new IOException("Mixed sample sizes are not supported");
        if (planar != 1) throw new IOException("TIFF with separate colour planes is not supported");
        if (comp == 7 || comp == 6 || comp == 34712 || comp == 34925 || comp == 50000)
            throw new IOException("TIFF compression is not supported (JPEG/JPEG2000/LERC/ZSTD). Convert it first, e.g. gdal_translate -co COMPRESS=DEFLATE in.tif out.tif");
        if (comp != 1 && comp != 5 && comp != 8 && comp != 32946 && comp != 32773) throw new IOException("TIFF compression " + comp + " is not supported");
        if (photo == 6 || photo == 8 || photo == 9 || photo == 10) throw new IOException("YCbCr/Lab TIFF is not supported");
        if (bits != 1 && bits != 8 && bits != 16 && bits != 32) throw new IOException(bits + "-bit TIFF is not supported");
        if (bits == 32 && sfmt != 3 && sfmt != 1) throw new IOException("32-bit integer TIFF is not supported");
        if ((pred == 2 && bits != 8 && bits != 16) || pred > 2) throw new IOException("TIFF predictor " + pred + " is not supported");
        if (pred == 2 && bits == 1) throw new IOException("TIFF predictor on 1-bit data is not supported");
        boolean tiled = ifd.longs.containsKey(T_TW) && ifd.longs.containsKey(T_TILE_OFF);
        long[] offs = ifd.longs.get(tiled ? T_TILE_OFF : T_STRIP_OFF), cnts = ifd.longs.get(tiled ? T_TILE_CNT : T_STRIP_CNT);
        if (offs == null) throw new IOException("TIFF has no image data");
        int uw = tiled ? (int) ifd.one(T_TW, 0) : W;
        int uh = tiled ? (int) ifd.one(T_TH, 0) : (int) Math.min(H, ifd.one(T_ROWS, H));
        if (uw <= 0 || uh <= 0) throw new IOException("Bad TIFF block size");
        if (photo == 3 && bits != 8) throw new IOException("Palette TIFF must be 8-bit");
        if (photo == 3 && ifd.longs.get(T_CMAP) == null) throw new IOException("Palette TIFF without colour map");
        int nb = (photo == 2 || photo == 5) && spp >= 3 ? 3 : 1; // bands we show (CMYK folded to RGB)
        int step = Math.max(1, (int) Math.ceil(Math.max(W, H) / (double) Math.max(16, bits == 8 ? maxSide : Math.min(maxSide, 1600))));
        int w = (W + step - 1) / step, h = (H + step - 1) / step;
        boolean eightBit = bits == 8 || bits == 1 || photo == 3;
        int[] argb = eightBit ? new int[w * h] : null;
        float[] vals = eightBit ? null : new float[w * h * nb];
        float nodata = Float.NaN;
        String nd = ifd.ascii.get(T_NODATA);
        if (nd != null) {
            try {
                nodata = Float.parseFloat(nd.replace("|", "").trim());
            } catch (NumberFormatException ignored) {
                // no usable nodata value
            }
        }
        long[] extra = ifd.longs.get(T_EXTRA);
        boolean alpha = extra != null && extra.length > 0 && (extra[0] == 1 || extra[0] == 2) && ((photo == 2 && spp >= 4) || ((photo == 0 || photo == 1) && spp == 2));
        long[] cmap = ifd.longs.get(T_CMAP);
        int unitsAcross = (W + uw - 1) / uw, unitsDown = (H + uh - 1) / uh;
        int rowBytes = (int) (((long) uw * spp * bits + 7) / 8);
        long expected = (long) rowBytes * uh;
        if (expected > 512L * 1024 * 1024) throw new IOException("TIFF block too large");
        if (cnts == null && !tiled && offs.length == 1) cnts = new long[]{raf.length() - offs[0]};
        if (cnts == null || cnts.length < offs.length) throw new IOException("TIFF block sizes missing");
        int total = unitsAcross * unitsDown;
        if (offs.length < total) throw new IOException("TIFF has fewer blocks than expected");
        byte[] buf = new byte[0];
        for (int u = 0; u < total; u++) {
            int ux = u % unitsAcross, uy = u / unitsAcross;
            int x0 = ux * uw, y0 = uy * uh;
            int rows = Math.min(uh, H - y0);
            if (cnts[u] <= 0 || cnts[u] > 1L << 30) continue;
            // is any sampled pixel inside this block?
            int firstY = ((y0 + step - 1) / step) * step, firstX = ((x0 + step - 1) / step) * step;
            if (firstY >= y0 + rows || firstX >= Math.min(W, x0 + uw)) continue;
            if (buf.length < cnts[u]) buf = new byte[(int) cnts[u]];
            raf.seek(offs[u]);
            raf.readFully(buf, 0, (int) cnts[u]);
            int need = rowBytes * (tiled ? uh : rows);
            byte[] raw = inflate(comp, buf, (int) cnts[u], need);
            if (pred == 2) predict(raw, rowBytes, tiled ? uh : rows, spp, bits, bo);
            for (int y = firstY; y < y0 + rows; y += step) {
                int ro = (y - y0) * rowBytes;
                for (int x = firstX; x < Math.min(W, x0 + uw); x += step) {
                    int cx = x - x0, o = (y / step) * w + x / step;
                    if (eightBit) argb[o] = pixel8(raw, ro, cx, spp, bits, photo, cmap, alpha, extra);
                    else storeValue(vals, o * nb, raw, ro, cx, spp, bits, nb, sfmt, bo, photo);
                }
            }
        }
        if (!eightBit) argb = stretch(vals, w, h, nb, nodata, photo == 0);
        Image img = new Image();
        img.srcW = W;
        img.srcH = H;
        img.w = w;
        img.h = h;
        img.step = step;
        img.argb = argb;
        georef(ifd, img);
        if (step > 1) img.note = "Shown at 1/" + step + " of the original resolution";
        return img;
    }

    private static byte[] inflate(int comp, byte[] src, int len, int need) throws IOException {
        switch (comp) {
            case 1: {
                byte[] r = new byte[need];
                System.arraycopy(src, 0, r, 0, Math.min(len, need));
                return r;
            }
            case 8:
            case 32946: {
                Inflater inf = new Inflater();
                try {
                    inf.setInput(src, 0, len);
                    byte[] r = new byte[need];
                    int n = 0;
                    while (n < need && !inf.finished()) {
                        int k = inf.inflate(r, n, need - n);
                        if (k == 0 && (inf.needsInput() || inf.needsDictionary())) break;
                        n += k;
                    }
                    return r;
                } catch (DataFormatException e) {
                    throw new IOException("Damaged Deflate data in TIFF");
                } finally {
                    inf.end();
                }
            }
            case 32773:
                return packBits(src, len, need);
            default:
                return lzw(src, len, need);
        }
    }

    static byte[] packBits(byte[] in, int len, int need) {
        byte[] out = new byte[need];
        int ip = 0, op = 0;
        while (ip < len && op < need) {
            int n = in[ip++];
            if (n >= 0) {
                int c = Math.min(n + 1, Math.min(len - ip, need - op));
                System.arraycopy(in, ip, out, op, c);
                ip += n + 1;
                op += c;
            } else if (n != -128) {
                if (ip >= len) break;
                int c = Math.min(1 - n, need - op);
                java.util.Arrays.fill(out, op, op + c, in[ip++]);
                op += c;
            }
        }
        return out;
    }

    /** TIFF LZW: MSB-first codes of 9..12 bits, "early change". */
    static byte[] lzw(byte[] in, int len, int need) {
        byte[] out = new byte[need];
        int[] prefix = new int[4096];
        byte[] suffix = new byte[4096];
        int[] length = new int[4096];
        for (int i = 0; i < 256; i++) {
            suffix[i] = (byte) i;
            length[i] = 1;
            prefix[i] = -1;
        }
        int bitBuf = 0, bitCnt = 0, ip = 0, size = 9, next = 258, prev = -1, op = 0;
        while (op < need) {
            while (bitCnt < size) {
                if (ip >= len) return out;
                bitBuf = (bitBuf << 8) | (in[ip++] & 0xFF);
                bitCnt += 8;
            }
            int code = (bitBuf >> (bitCnt - size)) & ((1 << size) - 1);
            bitCnt -= size;
            bitBuf &= (1 << bitCnt) - 1;
            if (code == 257) break;
            if (code == 256) {
                size = 9;
                next = 258;
                prev = -1;
                continue;
            }
            if (prev == -1) {
                if (code > 255) return out; // corrupt
                out[op++] = (byte) code;
                prev = code;
                continue;
            }
            int first;
            if (code < next) {
                first = firstByte(code, prefix, suffix);
                if (next < 4096) {
                    prefix[next] = prev;
                    suffix[next] = (byte) first;
                    length[next] = length[prev] + 1;
                    next++;
                }
            } else if (code == next && next < 4096) {
                first = firstByte(prev, prefix, suffix);
                prefix[next] = prev;
                suffix[next] = (byte) first;
                length[next] = length[prev] + 1;
                next++;
            } else return out; // corrupt
            int l = length[code], p = code;
            int endOp = Math.min(need, op + l);
            for (int k = op + l - 1; k >= op; k--) {
                if (k < need) out[k] = suffix[p];
                p = prefix[p];
            }
            op = endOp;
            prev = code;
            if (next >= (1 << size) - 1 && size < 12) size++;
        }
        return out;
    }

    private static int firstByte(int code, int[] prefix, byte[] suffix) {
        while (prefix[code] != -1) code = prefix[code];
        return suffix[code] & 0xFF;
    }

    private static void predict(byte[] raw, int rowBytes, int rows, int spp, int bits, ByteOrder bo) {
        for (int r = 0; r < rows; r++) {
            int o = r * rowBytes;
            if (bits == 8) {
                for (int i = spp; i < rowBytes && o + i < raw.length; i++) raw[o + i] += raw[o + i - spp];
            } else {
                ByteBuffer b = ByteBuffer.wrap(raw).order(bo);
                int n = rowBytes / 2;
                for (int i = spp; i < n && o + 2 * i + 1 < raw.length; i++) {
                    b.putShort(o + 2 * i, (short) (b.getShort(o + 2 * i) + b.getShort(o + 2 * (i - spp))));
                }
            }
        }
    }

    private static int pixel8(byte[] raw, int ro, int x, int spp, int bits, int photo, long[] cmap, boolean alpha, long[] extra) {
        int a = 255, r, g, b;
        if (bits == 1) {
            int bit = (raw[ro + (x >> 3)] >> (7 - (x & 7))) & 1;
            int v = (photo == 0) == (bit == 1) ? 0 : 255; // photometric 0: white is zero
            return 0xFF000000 | (v << 16) | (v << 8) | v;
        }
        if (photo == 3) {
            int idx = raw[ro + x * spp] & 0xFF;
            int n = cmap.length / 3;
            if (idx >= n) idx = n - 1;
            return 0xFF000000 | (int) ((cmap[idx] >> 8) & 0xFF) << 16 | (int) ((cmap[n + idx] >> 8) & 0xFF) << 8 | (int) ((cmap[2 * n + idx] >> 8) & 0xFF);
        }
        int p = ro + x * spp;
        if (photo == 2 && spp >= 3) {
            r = raw[p] & 0xFF;
            g = raw[p + 1] & 0xFF;
            b = raw[p + 2] & 0xFF;
            if (alpha) a = raw[p + 3] & 0xFF;
        } else if (photo == 5 && spp >= 4) {
            int c = raw[p] & 0xFF, m = raw[p + 1] & 0xFF, y = raw[p + 2] & 0xFF, k = raw[p + 3] & 0xFF;
            r = (255 - c) * (255 - k) / 255;
            g = (255 - m) * (255 - k) / 255;
            b = (255 - y) * (255 - k) / 255;
        } else {
            int v = raw[p] & 0xFF;
            if (photo == 0) v = 255 - v;
            r = g = b = v;
            if (alpha) a = raw[p + 1] & 0xFF;
        }
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static void storeValue(float[] vals, int o, byte[] raw, int ro, int x, int spp, int bits, int nb, int sfmt, ByteOrder bo, int photo) {
        ByteBuffer b = ByteBuffer.wrap(raw).order(bo);
        for (int s = 0; s < nb; s++) {
            int p = ro + (x * spp + s) * (bits / 8);
            if (p + bits / 8 > raw.length) {
                vals[o + s] = Float.NaN;
                continue;
            }
            vals[o + s] = bits == 16 ? (sfmt == 2 ? b.getShort(p) : b.getShort(p) & 0xFFFF) : b.getFloat(p);
        }
    }

    /** Maps 16-bit/float samples to 8 bits with a 2%..98% stretch of the sampled values (NaN/nodata become transparent). */
    private static int[] stretch(float[] v, int w, int h, int nb, float nodata, boolean whiteIsZero) {
        float mn = Float.MAX_VALUE, mx = -Float.MAX_VALUE;
        for (float f : v) {
            if (Float.isNaN(f) || Float.isInfinite(f) || f == nodata) continue;
            mn = Math.min(mn, f);
            mx = Math.max(mx, f);
        }
        int[] out = new int[w * h];
        if (mn > mx) return out; // everything transparent
        int bins = 1024;
        int[] hist = new int[bins];
        long cnt = 0;
        float range = Math.max(1e-9f, mx - mn);
        for (float f : v) {
            if (Float.isNaN(f) || Float.isInfinite(f) || f == nodata) continue;
            hist[Math.min(bins - 1, (int) ((f - mn) / range * bins))]++;
            cnt++;
        }
        long acc = 0;
        float lo = mn, hi = mx;
        boolean gl = false;
        for (int i = 0; i < bins; i++) {
            acc += hist[i];
            if (!gl && acc >= cnt * 0.02) {
                lo = mn + range * i / bins;
                gl = true;
            }
            if (acc >= cnt * 0.98) {
                hi = mn + range * (i + 1) / bins;
                break;
            }
        }
        if (hi <= lo) {
            lo = mn;
            hi = Math.max(mx, mn + 1e-9f);
        }
        float sc = 255f / (hi - lo);
        for (int i = 0; i < w * h; i++) {
            boolean bad = false;
            int[] c = new int[3];
            for (int s = 0; s < 3; s++) {
                float f = v[i * nb + (nb == 3 ? s : 0)];
                if (Float.isNaN(f) || Float.isInfinite(f) || f == nodata) {
                    bad = true;
                    break;
                }
                int q = Math.round((f - lo) * sc);
                c[s] = Math.max(0, Math.min(255, q));
                if (whiteIsZero) c[s] = 255 - c[s];
            }
            out[i] = bad ? 0 : 0xFF000000 | (c[0] << 16) | (c[1] << 8) | c[2];
        }
        return out;
    }

    // ------------------------------------------------------------------------------------------------ georeferencing

    private static void georef(Ifd ifd, Image img) {
        double[] m = ifd.doubles.get(T_MATRIX), scale = ifd.doubles.get(T_SCALE), tie = ifd.doubles.get(T_TIE);
        long[] keys = ifd.longs.get(T_GEOKEYS);
        boolean pixelIsPoint = false;
        if (keys != null && keys.length >= 4) {
            int n = (int) Math.min(keys[3], (keys.length - 4) / 4);
            long geographic = 0, projected = 0;
            for (int i = 0; i < n; i++) {
                int id = (int) keys[4 + 4 * i], loc = (int) keys[5 + 4 * i];
                long val = keys[7 + 4 * i];
                if (loc != 0) continue;
                if (id == 1025) pixelIsPoint = val == 2;
                if (id == 2048) geographic = val;
                if (id == 3072) projected = val;
            }
            if (projected > 0 && projected < 32767) img.epsg = (int) projected;
            else if (geographic > 0 && geographic < 32767) img.epsg = (int) geographic;
        }
        double[] a = null;
        if (m != null && m.length >= 16) a = new double[]{m[0], m[1], m[3], m[4], m[5], m[7]};
        else if (scale != null && scale.length >= 2 && tie != null && tie.length >= 6) {
            double sx = scale[0], sy = scale[1];
            a = new double[]{sx, 0, tie[3] - tie[0] * sx, 0, -sy, tie[4] + tie[1] * sy};
        }
        if (a != null && pixelIsPoint) { // tie point refers to the pixel centre: move to the corner
            a[2] -= (a[0] + a[1]) / 2;
            a[5] -= (a[3] + a[4]) / 2;
        }
        img.affine = a;
    }
}
