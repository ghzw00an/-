package iq.gis.poiexporter.core.table;

import iq.gis.poiexporter.S;

import java.util.ArrayList;
import java.util.List;

/** Counts and the first messages about rows that were read, accepted or rejected. */
public final class RowReport {
    public static final int MAX_MESSAGES = 200;
    public long read, ok, bad;
    public final List<String> messages = new ArrayList<>();

    public void bad(long row, String ar, String en) {
        bad++;
        if (messages.size() < MAX_MESSAGES)
            messages.add(S.t("سجل " + row + ": " + ar, "Row " + row + ": " + en));
    }

    public String toText(boolean arabic) {
        StringBuilder b = new StringBuilder();
        if (arabic) b.append("المقروء: ").append(read).append(" • الناجح: ").append(ok).append(" • الخاطئ: ").append(bad);
        else b.append("Read: ").append(read).append(" • OK: ").append(ok).append(" • Bad: ").append(bad);
        for (String m : messages) b.append('\n').append(m);
        if (bad > messages.size())
            b.append('\n').append(arabic ? "… و" + (bad - messages.size()) + " سجلات أخرى" : "… and " + (bad - messages.size()) + " more");
        return b.toString();
    }
}
