package iq.gis.poiexporter;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.IraqPlaces;
import iq.gis.poiexporter.core.IraqPlaces.Place;
import iq.gis.poiexporter.core.LayerData;

/** Iraqi governorates, districts and cities (Arabic names): browse, search, go to, and add as a reference layer. */
final class PlacesPage {
    private final MainActivity a;
    private String openGov = "";

    PlacesPage(MainActivity a) {
        this.a = a;
    }

    View build() {
        final IraqPlaces.Data d = IraqPlaces.get();
        final LinearLayout p = UiKit.col(a);

        LinearLayout top = Ui.card(a);
        top.addView(UiKit.head(a, "🏙 " + S.t("مدن وأقضية العراق", "Iraqi cities & districts")));
        top.addView(UiKit.note(a, S.t(d.governorates.size() + " محافظة • " + d.districts.size() + " قضاء • " + d.cities.size() + " مدينة بأسماء عربية وإنجليزية، تعمل دون إنترنت.",
                d.governorates.size() + " governorates • " + d.districts.size() + " districts • " + d.cities.size() + " cities, Arabic and English, offline.")));
        final EditText q = Ui.field(a, S.t("ابحث: بغداد، Mosul، الحلة…", "Search: Baghdad, Mosul, Hilla…"), InputType.TYPE_CLASS_TEXT);
        top.addView(q, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        top.addView(Ui.button(a, "＋ " + S.t("كل المدن كطبقة (" + d.cities.size() + ")", "All cities as a layer (" + d.cities.size() + ")"), true,
                () -> addLayer(S.t("مدن العراق", "Iraqi cities"), d.cities)), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        top.addView(Ui.button(a, "ⓘ " + S.t("عن البيانات والتحذيرات", "About the data & cautions"), false, this::about), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(top);

        final LinearLayout body = UiKit.col(a);
        p.addView(body);
        fill(body, "");
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                fill(body, e.toString().trim());
            }
        });
        return p;
    }

    private void fill(LinearLayout body, String query) {
        body.removeAllViews();
        if (!query.isEmpty()) {
            List<Place> hits = IraqPlaces.search(query, 40);
            if (hits.isEmpty()) {
                body.addView(UiKit.empty(a, "🔎", S.t("لا نتائج", "No results"),
                        S.t("جرّب كتابة الاسم بالعربية أو الإنجليزية، أو جزءاً منه.", "Try the name in Arabic or English, or part of it."), null, null));
                return;
            }
            for (Place h : hits) body.addView(placeRow(h, true));
            return;
        }
        for (final Place g : IraqPlaces.get().governorates) {
            final List<Place> cities = IraqPlaces.citiesOf(g.ar), districts = IraqPlaces.districtsOf(g.ar);
            boolean open = g.ar.equals(openGov);
            LinearLayout c = Ui.card(a);
            c.addView(UiKit.headerRow(a, 0, g.ar, String.valueOf(cities.size()),
                    g.en + "  •  " + districts.size() + S.t(" قضاء", " districts") + "  •  " + cities.size() + S.t(" مدينة", " cities"), false));
            c.addView(UiKit.tiles(a,
                    UiKit.tile(a, "⌖", S.t("عرض", "Show"), false, () -> go(g)),
                    UiKit.tile(a, open ? "▲" : "▼", open ? S.t("طيّ", "Fold") : S.t("التفاصيل", "Details"), false, () -> {
                        openGov = open ? "" : g.ar;
                        fill(body, "");
                    }),
                    UiKit.tile(a, "＋", S.t("طبقة", "Layer"), false, () -> addLayer(S.t("مدن ", "Cities of ") + g.ar, cities))));
            if (open) {
                c.addView(UiKit.label(a, S.t("الأقضية", "Districts")));
                StringBuilder sb = new StringBuilder();
                for (Place dd : districts) sb.append(sb.length() == 0 ? "" : " • ").append(dd.ar);
                c.addView(UiKit.note(a, sb.toString()));
                c.addView(UiKit.label(a, S.t("المدن", "Cities")));
                for (Place city : cities) c.addView(placeRow(city, false));
            }
            body.addView(c);
        }
    }

    private View placeRow(final Place p, boolean card) {
        String sub = p.kind == IraqPlaces.Kind.CITY
                ? p.districtAr + " — " + p.govAr + (p.pop > 0 ? "  •  " + String.format(java.util.Locale.US, "%,d", p.pop) : "")
                : (p.kind == IraqPlaces.Kind.DISTRICT ? S.t("قضاء — ", "District — ") + p.govAr : S.t("محافظة", "Governorate"));
        LinearLayout row = UiKit.headerRow(a, p.kind == IraqPlaces.Kind.CITY ? 0 : p.kind == IraqPlaces.Kind.DISTRICT ? 0xFF1C7ED6 : 0xFFE8590C,
                p.ar + (p.en.isEmpty() ? "" : "  (" + p.en + ")"), null, sub, false);
        row.setClickable(true);
        Ui.pressable(row);
        row.setOnClickListener(v -> go(p));
        row.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
        if (!card) return row;
        LinearLayout c = Ui.card(a);
        c.addView(row);
        return c;
    }

    /** Zoom the map to a place; governorates and districts have no coordinates in the source, so their view is approximate. */
    void go(Place p) {
        double[] c = IraqPlaces.approxCenter(p);
        if (c == null) {
            a.toast(S.t("لا موقع لهذا العنصر", "No position for this item"));
            return;
        }
        a.showMap();
        if (p.hasPosition()) {
            Feature f = Feature.point(c[0], c[1]);
            f.name = p.ar;
            a.flashTo(f);
        } else {
            a.map.getController().setZoom(p.kind == IraqPlaces.Kind.GOVERNORATE ? 9.0 : 11.0);
            a.map.getController().animateTo(new org.osmdroid.util.GeoPoint(c[0], c[1]));
            a.toast(S.t("موقع تقريبي (متوسط مدن ", "Approximate view (mean of the cities of ") + p.ar + S.t(")؛ المصدر لا يحوي حدوداً", "); the source has no boundaries"));
        }
    }

    private void about() {
        IraqPlaces.Data d = IraqPlaces.get();
        a.message(S.t("عن البيانات", "About the data"),
                S.t("المصدر: ", "Source: ") + d.source + "\n" + S.t("الإصدار (commit): ", "Commit: ") + d.commit + "\n" + S.t("الترخيص: ", "Licence: ") + d.license + "\n\n"
                        + S.t("الأسماء العربية أُضيفت لهذا التطبيق وليست من المصدر. الإحداثيات والسكان كما نُشرت في المصدر دون تحقق (أرقام السكان قد تكون قديمة أو تخص القضاء كله). "
                                + "المصدر نقاط مدن فقط: لا حدود، وللمحافظات والأقضية لا إحداثيات (العرض فيها تقريبي).\n\n"
                                + "تنبيهات من البيانات: مدينة «Al Anbar» في المصدر هي الرطبة؛ «Al Qadisiyah» هي الديوانية؛ هناك قضاءان مكرّران في المصدر (أبو غريب، مخمور) بصيغتين؛ "
                                + "«Hindiya» في بابل غير الهندية (طويريج) في كربلاء. التهجئة العربية لبعض الأسماء الكردية تقريبية.",
                        "Arabic names were added for this app and are not part of the source. Coordinates and population are as published, unverified (population may be old or for the whole district). "
                                + "The source holds city points only: no boundaries, and no coordinates for governorates and districts (their view is approximate).\n\n"
                                + "Data cautions: the source city “Al Anbar” is Rutba; “Al Qadisiyah” is Diwaniyah; two districts are duplicated in the source (Abu Ghraib, Makhmur); "
                                + "“Hindiya” in Babil is not Al-Hindiya (Tuwairij) in Karbala. Arabic spelling of some Kurdish names is approximate."),
                null, null);
    }

    private void addLayer(String label, List<Place> cities) {
        IraqPlaces.Data d = IraqPlaces.get();
        LayerData l = new LayerData(Library.newId(), label, Feature.POINT);
        l.kind = "reference";
        l.official = false;
        l.source = d.source + " @ " + d.commit.substring(0, 7) + " (" + d.license + ")";
        l.sourceDate = java.time.LocalDate.now().toString();
        l.accuracyNote = S.t("غير رسمي: إحداثيات وسكان كما في المصدر دون تحقق؛ الأسماء العربية أُضيفت للتطبيق.",
                "Unofficial: coordinates and population as published in the source, unverified; Arabic names added for the app.");
        String day = java.time.LocalDate.now().toString();
        for (Place c : cities) {
            Feature f = Feature.point(c.lat, c.lon);
            f.name = c.ar;
            f.type = "مدينة";
            f.qadaa = c.districtAr;
            f.governorate = c.govAr;
            f.source = "iraqi-geography-data (MIT)";
            f.updated = day;
            f.notes = c.note;
            f.nameEn = c.en;
            f.attrs.put("population", String.valueOf(c.pop));
            l.features.add(f);
        }
        LayerData added = MainActivity.WS.addLayerWithFeatures(l);
        a.rebuild();
        a.showMap();
        a.zoomToLayer(added);
        a.toast(S.t("أُضيفت طبقة «" + label + "» (" + cities.size() + ")", "Layer added: " + label + " (" + cities.size() + ")"));
    }
}
