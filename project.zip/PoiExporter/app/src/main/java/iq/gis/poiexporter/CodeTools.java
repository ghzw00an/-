package iq.gis.poiexporter;

import android.app.Dialog;
import android.content.Intent;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.CodeGen;
import iq.gis.poiexporter.core.LayerData;

/** Map layers as source code: pick layers and a language, preview, copy, share or save. */
final class CodeTools {
    private CodeTools() {
    }

    static void dialog(final MainActivity a) {
        final List<LayerData> ls = new ArrayList<>(MainActivity.LIB);
        ls.addAll(MainActivity.DL);
        if (ls.isEmpty()) {
            a.toast(S.t("لا توجد طبقات", "No layers"));
            return;
        }
        final boolean[] sel = new boolean[ls.size()];
        final int[] lang = {0};
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, "</> " + S.t("الطبقات ككود", "Layers as code")));
        box.addView(UiKit.note(a, S.t("اختر الطبقات واللغة ثم اضغط «إنشاء». الإحداثيات WGS84 (EPSG:4326). خريطة Leaflet تستخدم بلاط OpenStreetMap.",
                "Pick layers and a language, then Generate. Coordinates are WGS84 (EPSG:4326). The Leaflet map uses OpenStreetMap tiles.")));
        for (int i = 0; i < ls.size(); i++) {
            final int k = i;
            if (ls.get(i).features.isEmpty()) continue;
            sel[i] = true;
            box.addView(UiKit.check(a, ls.get(i).label + "  (" + ls.get(i).features.size() + ")", true, v -> sel[k] = v));
        }
        box.addView(Ui.text(a, S.t("اللغة", "Language"), 13, Theme.text, true));
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(a);
        hs.addView(Ui.chips(a, CodeGen.LANGS, 0, i -> lang[0] = i));
        box.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        ScrollView sv = new ScrollView(a);
        sv.addView(box);
        LinearLayout o = new LinearLayout(a);
        o.setOrientation(LinearLayout.VERTICAL);
        o.addView(sv, new LinearLayout.LayoutParams(-1, Ui.dp(a, 480)));
        final Dialog d = a.card(o);
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, d::dismiss), Ui.lp(0, -2, 1f, a, 0, 10, 4, 0));
        r.addView(Ui.button(a, S.t("إنشاء", "Generate"), true, () -> {
            List<LayerData> chosen = new ArrayList<>();
            for (int i = 0; i < ls.size(); i++) if (sel[i]) chosen.add(ls.get(i));
            if (chosen.isEmpty()) {
                a.toast(S.t("اختر طبقة", "Pick a layer"));
                return;
            }
            String code;
            try {
                code = CodeGen.generate(lang[0], chosen);
            } catch (Throwable e) {
                ErrorLog.add("codegen", e);
                a.toast(S.t("تعذّر الإنشاء", "Could not generate"));
                return;
            }
            d.dismiss();
            show(a, code, lang[0]);
        }), Ui.lp(0, -2, 1f, a, 4, 10, 0, 0));
        box.addView(r);
        d.show();
    }

    private static void show(final MainActivity a, final String code, final int lang) {
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, CodeGen.LANGS[lang]));
        String preview = code.length() > 20000 ? code.substring(0, 20000) + "\n…" : code;
        TextView t = Ui.text(a, preview, 11, Theme.text, false);
        t.setTypeface(android.graphics.Typeface.MONOSPACE);
        t.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_LTR);
        t.setGravity(Gravity.START);
        t.setTextIsSelectable(true);
        box.addView(t);
        if (code.length() > 20000)
            box.addView(UiKit.note(a, S.t("المعاينة مقتطعة؛ النسخ والمشاركة والحفظ تشمل الكود كاملاً.", "Preview is truncated; copy, share and save use the full code.")));
        ScrollView sv = new ScrollView(a);
        sv.addView(box);
        LinearLayout o = new LinearLayout(a);
        o.setOrientation(LinearLayout.VERTICAL);
        o.addView(sv, new LinearLayout.LayoutParams(-1, Ui.dp(a, 480)));
        final Dialog d = a.card(o);
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("نسخ", "Copy"), false, () -> a.copy(code)), Ui.lp(0, -2, 1f, a, 0, 10, 3, 0));
        r.addView(Ui.button(a, S.t("حفظ ومشاركة ملف", "Save & share file"), false, () -> {
            try {
                final byte[] bytes = code.getBytes("UTF-8");
                Storage.Saved sv2 = Storage.save(a, a.prefs, "layers." + CodeGen.EXT[lang],
                        lang == 3 ? "text/html" : "text/plain", os -> os.write(bytes));
                a.toast(S.t("حُفظ في ", "Saved to ") + sv2.where);
                Storage.share(a, sv2.uri, lang == 3 ? "text/html" : "text/plain");
            } catch (Throwable e) {
                ErrorLog.add("codegen-save", e);
                a.toast(S.t("تعذّر الحفظ", "Could not save"));
            }
        }), Ui.lp(0, -2, 1f, a, 3, 10, 3, 0));
        r.addView(Ui.button(a, S.t("مشاركة نص", "Share text"), true, () -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, code);
            a.startActivity(Intent.createChooser(i, S.t("مشاركة", "Share")));
        }), Ui.lp(0, -2, 1f, a, 3, 10, 0, 0));
        box.addView(r);
        d.show();
    }
}
