package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;

/** The user's own sector list (Gategory) with the items (type) that belong to each sector. Wording is exactly as supplied. */
public final class Sectors {
    private Sectors() {
    }

    public static final class Sector {
        public final String name;
        public final String[] items;

        Sector(String name, String... items) {
            this.name = name;
            this.items = items;
        }
    }

    public static final Sector[] ALL = {
            new Sector("قطاع المواصلات", "تقاطع", "طريق رئيسي", "كراج", "سيطرة", "طريق فرعي", "محطة قطار", "مجسر", "طريق ثانوي", "نفق", "طريق نيسمي", "جسر مشاة", "سكة حديد"),
            new Sector("القطاع السياسي", "مقر حزب", "مكتب حزب", "سفارة", "قنصلية"),
            new Sector("القطاع الإداري", "دائرة", "وزارة", "نقابة", "مكتب", "محكمة", "بلدية", "مديرية", "قسم", "شعبة", "هيئة", "جمعية"),
            new Sector("القطاع المدني", "مؤسسة مجتمع مدني", "جمعية خيرية", "مؤسسة", "دار رعاية"),
            new Sector("القطاع التجاري", "شركة", "محل", "سوق", "مقهى", "مطعم", "مكتب تجاري", "فندق", "قاعة مناسبات", "علوة", "مول", "مجمع تجاري", "مخزن", "مشتل", "معرض", "محطة تعبئة وقود"),
            new Sector("القطاع المالي", "مصرف", "صيرفة", "شركة"),
            new Sector("القطاع التربوي والتعليم", "روضة", "مدرسة", "معهد", "جامعة", "مركز أبحاث", "أقسام داخلية", "حضانة", "كلية", "رئاسة جامعة", "عمادة"),
            new Sector("القطاع الترفيهي", "متنزه", "مدينة ألعاب", "حديقة حيوانات", "حديقة"),
            new Sector("القطاع الرياضي", "ملعب", "مسبح", "مركز شباب", "نادي", "قاعة"),
            new Sector("القطاع الخدماتي", "محطة صرف صحي"),
            new Sector("القطاع الديني", "مسجد", "مصلى", "كنيسة", "مقام", "مرقد", "حسينية", "وقف", "مغتسل", "مقبرة", "معبد", "موكب"),
            new Sector("القطاع الزراعي", "سايلو", "حقل", "بستان", "مزرعة", "بحيرة أسماك", "محمية"),
            new Sector("القطاع الصحي", "مستشفى", "مستوصف", "صيدلية", "مركز صحي", "مختبر", "عيادة", "مذخر", "مجمع طبي", "مركز تجميل"),
            new Sector("القطاع الصناعي", "معمل", "مخزن", "مصنع"),
            new Sector("القطاع الثقافي", "متحف", "معرض", "مسرح", "سينما", "مكتبة", "اتحاد", "مركز ثقافي"),
    };

    /** Sector whose name equals the text (Arabic-normalised, so alef/yaa variants and diacritics do not matter), or null. */
    public static Sector find(String text) {
        if (text == null) return null;
        String t = norm(text);
        if (t.isEmpty()) return null;
        for (Sector s : ALL) if (norm(s.name).equals(t)) return s;
        return null;
    }

    /** Sector that contains the item (first match), or null. */
    public static Sector ofItem(String item) {
        String t = norm(item);
        if (t.isEmpty()) return null;
        for (Sector s : ALL) for (String i : s.items) if (norm(i).equals(t)) return s;
        return null;
    }

    /** Sectors that contain the item (an item such as "مخزن" belongs to several). */
    public static List<Sector> allOfItem(String item) {
        List<Sector> r = new ArrayList<>();
        String t = norm(item);
        if (t.isEmpty()) return r;
        for (Sector s : ALL) for (String i : s.items) if (norm(i).equals(t)) {
            r.add(s);
            break;
        }
        return r;
    }

    private static String norm(String s) {
        return iq.gis.poiexporter.core.io.DupFinder.normName(s);
    }
}
