package iq.gis.poiexporter.core;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Minimal .xlsx writer (one sheet): name type Gategory gather Nahia mohafadha x y link. */
public final class XlsxWriter {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final String[] HEAD = {"name", "type", "Gategory", "gather", "Nahia", "mohafadha", "x", "y", "link"};
    private static final String NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static final String XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";

    private XlsxWriter() {
    }

    public static void write(List<LayerData> layers, OutputStream os) throws IOException {
        ZipOutputStream z = new ZipOutputStream(os);
        put(z, "[Content_Types].xml", XML
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
                + "</Types>");
        put(z, "_rels/.rels", XML
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                + "</Relationships>");
        put(z, "xl/workbook.xml", XML
                + "<workbook xmlns=\"" + NS + "\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
                + "<sheets><sheet name=\"poi\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
        put(z, "xl/_rels/workbook.xml.rels", XML
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
                + "</Relationships>");

        z.putNextEntry(new ZipEntry("xl/worksheets/sheet1.xml"));
        StringBuilder sb = new StringBuilder(1 << 16);
        sb.append(XML).append("<worksheet xmlns=\"").append(NS).append("\"><sheetData>");
        sb.append("<row r=\"1\">");
        for (int c = 0; c < HEAD.length; c++) str(sb, c, 1, HEAD[c]);
        sb.append("</row>");
        int r = 1;
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                r++;
                Utm.Result u = Utm.fromLatLon(f.lat, f.lon);
                sb.append("<row r=\"").append(r).append("\">");
                str(sb, 0, r, f.name);
                str(sb, 1, r, f.type);
                str(sb, 2, r, f.category);
                str(sb, 3, r, f.qadaa);
                str(sb, 4, r, f.nahiya);
                str(sb, 5, r, f.governorate);
                num(sb, 6, r, u.easting);
                num(sb, 7, r, u.northing);
                str(sb, 8, r, CoordFmt.link(f.lat, f.lon));
                sb.append("</row>");
                if (sb.length() > (1 << 20)) {
                    z.write(sb.toString().getBytes(UTF8));
                    sb.setLength(0);
                }
            }
        }
        sb.append("</sheetData></worksheet>");
        z.write(sb.toString().getBytes(UTF8));
        z.closeEntry();
        z.finish();
    }

    private static void put(ZipOutputStream z, String name, String content) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(UTF8));
        z.closeEntry();
    }

    private static String ref(int col, int row) {
        return String.valueOf((char) ('A' + col)) + row;
    }

    private static void str(StringBuilder sb, int col, int row, String s) {
        if (s == null) s = "";
        sb.append("<c r=\"").append(ref(col, row)).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">");
        esc(sb, s);
        sb.append("</t></is></c>");
    }

    private static void num(StringBuilder sb, int col, int row, double v) {
        sb.append("<c r=\"").append(ref(col, row)).append("\"><v>")
                .append(String.format(Locale.US, "%.2f", v)).append("</v></c>");
    }

    private static void esc(StringBuilder sb, String s) {
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '&') sb.append("&amp;");
            else if (ch == '<') sb.append("&lt;");
            else if (ch == '>') sb.append("&gt;");
            else if (ch < 0x20 && ch != '\t' && ch != '\n' && ch != '\r') continue;
            else if (ch == 0xFFFE || ch == 0xFFFF) continue;
            else sb.append(ch);
        }
    }
}
