package iq.gis.poiexporter.core.coord;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Mgrs;
import iq.gis.poiexporter.core.Utm;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.table.PointTable;
import iq.gis.poiexporter.core.table.RowReport;
import iq.gis.poiexporter.core.table.TableReader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Converts a table of coordinates (CSV/TXT/XLSX, up to millions of rows) row by row into a sink, with constant
 * memory. Bad rows are counted, reported and optionally written to an errors file; they never stop the run.
 */
public final class BatchConverter {
    private BatchConverter() {
    }

    /** A number with its display decimals (CSV prints it fixed, Excel stores the rounded value). */
    public static final class Num {
        public final double value;
        public final int decimals;

        public Num(double v, int decimals) {
            this.decimals = decimals;
            double sc = Math.pow(10, Math.min(decimals, 9));
            this.value = Math.abs(v) < 9e8 ? Math.round(v * sc) / sc : v;
        }

        public String text() {
            return Precision.fixed(value, decimals);
        }

        public String toString() {
            return text();
        }
    }

    public static final class Options {
        public PointTable.Mapping mapping = new PointTable.Mapping();
        /** null = WGS84 / auto. */
        public Crs src;
        /** Extra X/Y columns in this system (null or WGS84 = none). */
        public Crs target;
        public boolean keepOriginal = true;
        public boolean outDD = false, outDMS, outDDM, outUTM, outMGRS;
        /** Fixed decimals for numeric outputs, or -1 for automatic from the input precision. */
        public int fixedDecimals = -1;
        /** If not null every bad record is written here (CSV: row, reason, original cells). */
        public File errorsFile;
        public int sheet;
    }

    public interface Progress {
        void update(long rows);

        boolean cancelled();
    }

    public static final class Summary {
        public long read, converted, bad;
        public final List<String> messages = new ArrayList<>();
        public File errorsCsv;
        public boolean cancelled;

        public String toText(boolean ar) {
            StringBuilder b = new StringBuilder();
            if (ar) b.append("المقروء: ").append(read).append(" • المحوَّل: ").append(converted).append(" • الخاطئ: ").append(bad);
            else b.append("Read: ").append(read).append(" • Converted: ").append(converted).append(" • Bad: ").append(bad);
            if (cancelled) b.append(ar ? "\n(أُوقفت العملية)" : "\n(cancelled)");
            for (String m : messages) b.append('\n').append(m);
            if (bad > messages.size()) b.append(ar ? "\n… و" + (bad - messages.size()) + " سجلات أخرى" : "\n… and " + (bad - messages.size()) + " more");
            return b.toString();
        }
    }

    public static Summary run(File in, String name, Options o, Sink sink, Progress pr) throws IOException {
        Summary sum = new Summary();
        Crs wgs = Crs.wgs84();
        TableReader r = TableReader.open(in, name);
        BufferedWriter errW = null;
        try {
            if (o.sheet > 0) r.openSheet(o.sheet);
            PointTable.RowParser parser = new PointTable.RowParser(o.mapping, o.src);
            List<String> hdr = r.header();
            PointTable.Mapping m = o.mapping;
            boolean extra = o.target != null && o.target.epsg != 4326;
            Crs.Tx tgt = extra ? wgs.to(o.target) : null;

            List<String> cols = new ArrayList<>();
            int nOrig;
            if (o.keepOriginal) {
                cols.addAll(hdr);
                nOrig = hdr.size();
            } else {
                nOrig = m.name >= 0 ? 1 : 0;
                if (m.name >= 0) cols.add(hdr.get(m.name));
            }
            int base = cols.size();
            cols.add("lat_wgs84");
            cols.add("lon_wgs84");
            if (o.outUTM) {
                cols.add("utm_zone");
                cols.add("utm_e");
                cols.add("utm_n");
            }
            if (o.outMGRS) cols.add("mgrs");
            if (o.outDD) cols.add("dd");
            if (o.outDMS) cols.add("dms");
            if (o.outDDM) cols.add("ddm");
            if (extra) {
                if (o.target.geographic) {
                    cols.add("lon_" + o.target.epsg);
                    cols.add("lat_" + o.target.epsg);
                } else {
                    cols.add("x_" + o.target.epsg);
                    cols.add("y_" + o.target.epsg);
                }
            }
            sink.begin(cols);
            if (o.errorsFile != null) {
                errW = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(o.errorsFile), "UTF-8"), 1 << 16);
                errW.write('﻿');
                errW.write(csvLine(prepend(hdr, S.t("رقم السجل", "row"), S.t("سبب الرفض", "reason"))));
                sum.errorsCsv = o.errorsFile;
            }
            String[] row;
            double[] t2 = new double[2];
            while ((row = r.next()) != null) {
                sum.read++;
                if ((sum.read & 0x3FFF) == 0 && pr != null) {
                    pr.update(sum.read);
                    if (pr.cancelled()) {
                        sum.cancelled = true;
                        break;
                    }
                }
                double[] ll;
                try {
                    ll = parser.parse(row);
                } catch (PointTable.BadRow e) {
                    sum.bad++;
                    long rn = r.rowNumber();
                    if (sum.messages.size() < RowReport.MAX_MESSAGES)
                        sum.messages.add(S.t("سجل " + rn + ": ", "Row " + rn + ": ") + e.reason());
                    if (errW != null) {
                        List<String> cells = new ArrayList<>();
                        cells.add(String.valueOf(rn));
                        cells.add(e.reason());
                        for (String c : row) cells.add(c == null ? "" : c);
                        errW.write(csvLine(cells));
                    }
                    continue;
                }
                double lon = ll[0], lat = ll[1];
                double res = parser.resolutionMetres(row, lat);
                int dd = o.fixedDecimals >= 0 ? o.fixedDecimals : Precision.degreeDecimals(res);
                int pd = o.fixedDecimals >= 0 ? Math.min(o.fixedDecimals, 3) : Precision.projectedDecimals(res);
                Object[] out = new Object[cols.size()];
                int k = 0;
                if (o.keepOriginal) {
                    for (int c = 0; c < hdr.size(); c++) out[k++] = c < row.length && row[c] != null ? row[c] : "";
                } else if (m.name >= 0) {
                    out[k++] = m.name < row.length && row[m.name] != null ? row[m.name] : "";
                }
                out[k++] = new Num(lat, dd);
                out[k++] = new Num(lon, dd);
                if (o.outUTM) {
                    if (lat >= -80 && lat <= 84) {
                        Utm.Result u = Utm.fromLatLon(lat, lon);
                        out[k++] = u.zoneLabel();
                        out[k++] = new Num(u.easting, pd);
                        out[k++] = new Num(u.northing, pd);
                    } else {
                        out[k++] = "";
                        out[k++] = null;
                        out[k++] = null;
                    }
                }
                if (o.outMGRS) out[k++] = lat >= -80 && lat <= 84 ? Mgrs.fromLatLon(lat, lon, Precision.mgrsDigits(res)).replace(" ", "") : "";
                if (o.outDD) out[k++] = Precision.fixed(lat, dd) + ", " + Precision.fixed(lon, dd);
                if (o.outDMS) out[k++] = text(CoordFmt.Fmt.DMS, lat, lon, res);
                if (o.outDDM) out[k++] = text(CoordFmt.Fmt.DDM, lat, lon, res);
                if (extra) {
                    boolean ok = true;
                    try {
                        tgt.apply(lon, lat, t2);
                    } catch (IllegalArgumentException e) {
                        ok = false;
                    }
                    if (ok) {
                        int td = o.target.geographic ? dd : pd;
                        out[k++] = new Num(t2[0], td);
                        out[k++] = new Num(t2[1], td);
                    } else {
                        out[k++] = null;
                        out[k++] = null;
                    }
                }
                sink.row(out, lon, lat);
                sum.converted++;
            }
            if (pr != null) pr.update(sum.read);
            sink.end();
        } finally {
            r.close();
            if (errW != null) errW.close();
        }
        return sum;
    }

    private static String text(CoordFmt.Fmt f, double lat, double lon, double res) {
        // reuse CoordService's digit rules
        CoordService.Result rs = null;
        return f == CoordFmt.Fmt.DMS ? dms(lat, lon, Precision.dmsSecondDecimals(res)) : ddm(lat, lon, Precision.ddmMinuteDecimals(res));
    }

    private static String dms(double lat, double lon, int sd) {
        return dms1(lat, 'N', 'S', sd) + " " + dms1(lon, 'E', 'W', sd);
    }

    private static String dms1(double v, char pos, char neg, int sd) {
        double sc = Math.pow(10, sd);
        long units = Math.round(Math.abs(v) * 3600 * sc);
        long per = (long) (3600 * sc);
        long deg = units / per, rem = units % per;
        long min = rem / (long) (60 * sc);
        long secU = rem % (long) (60 * sc);
        String sec = Precision.fixed(secU / sc, sd);
        if (secU / sc < 10) sec = "0" + sec;
        return String.format(Locale.US, "%d°%02d'%s\"%c", deg, min, sec, v < 0 ? neg : pos);
    }

    private static String ddm(double lat, double lon, int md) {
        return ddm1(lat, 'N', 'S', md) + " " + ddm1(lon, 'E', 'W', md);
    }

    private static String ddm1(double v, char pos, char neg, int md) {
        double sc = Math.pow(10, md);
        long units = Math.round(Math.abs(v) * 60 * sc);
        long per = (long) (60 * sc);
        long deg = units / per;
        double min = (units % per) / sc;
        String ms = Precision.fixed(min, md);
        if (min < 10) ms = "0" + ms;
        return String.format(Locale.US, "%d°%s'%c", deg, ms, v < 0 ? neg : pos);
    }

    private static List<String> prepend(List<String> hdr, String a, String b) {
        List<String> l = new ArrayList<>();
        l.add(a);
        l.add(b);
        l.addAll(hdr);
        return l;
    }

    private static String csvLine(List<String> cells) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < cells.size(); i++) {
            if (i > 0) b.append(',');
            String s = cells.get(i);
            if (s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0)
                b.append('"').append(s.replace("\"", "\"\"")).append('"');
            else b.append(s);
        }
        return b.append("\r\n").toString();
    }
}
