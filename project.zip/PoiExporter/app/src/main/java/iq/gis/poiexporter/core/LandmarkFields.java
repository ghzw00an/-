package iq.gis.poiexporter.core;

import iq.gis.poiexporter.core.crs.Crs;

import java.util.Locale;

/**
 * The attribute table of a landmark, exactly as the user specified (spelling and order are part of the format):
 * name, type, Gategory, gathaa, Nahia, mohafadha, x, y, link.
 * x, y are UTM easting/northing of the point (zone chosen automatically) unless an export target system is chosen.
 */
public final class LandmarkFields {
    private LandmarkFields() {
    }

    public static final String[] NAMES = {"name", "type", "Gategory", "gathaa", "Nahia", "mohafadha", "x", "y", "link"};
    public static final int N_TEXT = 6; // name .. mohafadha

    public static boolean isStd(String key) {
        for (String s : NAMES) if (s.equalsIgnoreCase(key)) return true;
        return false;
    }

    /** The six text fields in table order. */
    public static String[] text(Feature f) {
        return new String[]{nz(f.name), nz(f.type), nz(f.category), nz(f.qadaa), nz(f.nahiya), nz(f.governorate)};
    }

    public static String link(Feature f) {
        String v = f.attrs.get("link");
        return v == null ? "" : v;
    }

    public static void setLink(Feature f, String v) {
        if (v == null || v.isEmpty()) f.attrs.remove("link");
        else f.attrs.put("link", v);
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    /** Easting/northing of the representative point: UTM when {@code tx} is null, otherwise in the transform's system. NaN if impossible. */
    public static double[] xy(Feature f, Crs.Tx tx) {
        try {
            if (tx == null) {
                Utm.Result u = Utm.fromLatLon(f.lat, f.lon);
                return new double[]{u.easting, u.northing};
            }
            double[] o = new double[2];
            tx.apply(f.lon, f.lat, o);
            return o;
        } catch (RuntimeException e) {
            return new double[]{Double.NaN, Double.NaN};
        }
    }

    public static String num(double v, int dec) {
        if (Double.isNaN(v)) return "";
        return String.format(Locale.US, "%." + dec + "f", v);
    }

    /** Value of a table column by key (case-insensitive) for lookups when importing. */
    public static Integer index(String key) {
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equalsIgnoreCase(key)) return i;
        return null;
    }
}
