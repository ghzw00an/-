package iq.gis.poiexporter;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.Utm;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.report.MapMath;
import iq.gis.poiexporter.core.report.Paper;
import iq.gis.poiexporter.core.report.ReportLayout;

/**
 * Draws a printed map and attribute-table pages with Android Canvas. The same drawing code feeds PdfDocument (vector)
 * and Bitmap (PNG). Layout and scale maths come from core.report and are unit-tested; this class is device-only code.
 * Base-map tiles are deliberately NOT drawn: OSM/Google tile terms do not allow bulk copying into exported files.
 */
final class ReportRenderer {
    static final int GRID_NONE = 0, GRID_GRATICULE = 1, GRID_UTM = 2;

    static final class Options {
        String title = "", subtitle = "";
        Paper paper = Paper.A4;
        boolean landscape = true;
        List<LayerData> layers = new ArrayList<>();
        double[] bbox;          // lon/lat west,south,east,north
        double fixedScale;      // 0 = automatic
        int grid = GRID_NONE;
        boolean legend = true, table = true;
        double mapRotation;     // degrees, for the north arrow
        /** Screenshot of the map exactly as shown (base map + everything on it). When set, layers are not redrawn. */
        Bitmap snapshot;
        double snapMetresPerPx;
        String snapCredit = "";
        List<iq.gis.poiexporter.core.Annotations.Item> notes = new ArrayList<>();
        java.util.function.Function<String, Bitmap> images;
    }

    private final Options o;
    private final ReportLayout L;
    private final List<MapMath.LegendEntry> legend = new ArrayList<>();
    private final List<String[]> rows;
    private final boolean ar = S.ar;
    private static final double ROW_PT = 14;

    ReportRenderer(Options o) {
        this.o = o;
        for (LayerData l : o.layers) legend.add(MapMath.legend(l.label, l.color, l.geom, l.features.size()));
        double[] bb = o.bbox != null ? o.bbox : ReportLayout.extent(o.layers);
        if (bb == null) bb = new double[]{44.0, 33.0, 44.1, 33.1};
        L = ReportLayout.compute(o.paper, o.landscape, bb, o.legend ? legend.size() : 0, o.fixedScale);
        rows = o.table ? ReportLayout.tableRows(o.layers, 3000) : new ArrayList<String[]>();
    }

    ReportLayout layout() {
        return L;
    }

    int tablePages() {
        if (rows.size() <= 1) return 0;
        int per = ReportLayout.rowsPerPage(o.paper, o.landscape, ROW_PT);
        return (rows.size() - 1 + per - 1) / per;
    }

    int pageCount() {
        return 1 + tablePages();
    }

    void writePdf(OutputStream os) throws IOException {
        PdfDocument doc = new PdfDocument();
        try {
            for (int i = 0; i < pageCount(); i++) {
                PdfDocument.PageInfo pi = new PdfDocument.PageInfo.Builder((int) L.pageW, (int) L.pageH, i + 1).create();
                PdfDocument.Page pg = doc.startPage(pi);
                drawPage(pg.getCanvas(), i);
                doc.finishPage(pg);
            }
            doc.writeTo(os);
        } finally {
            doc.close();
        }
    }

    /** One page as a bitmap for the on-screen preview (dpi 100 keeps A3 within a few MB). */
    Bitmap renderPage(int index, int dpi) {
        float k = dpi / 72f;
        Bitmap bmp = Bitmap.createBitmap(Math.round((float) L.pageW * k), Math.round((float) L.pageH * k), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.scale(k, k);
        drawPage(c, index);
        return bmp;
    }

    /** The map page as PNG. dpi 150 is a good print/screen compromise; A3 at 300 would exceed typical phone memory. */
    void writePng(OutputStream os, int dpi) throws IOException {
        float k = dpi / 72f;
        int w = Math.round((float) L.pageW * k), h = Math.round((float) L.pageH * k);
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        try {
            Canvas c = new Canvas(bmp);
            c.scale(k, k);
            drawPage(c, 0);
            if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, os)) throw new IOException("PNG encode failed");
        } finally {
            bmp.recycle();
        }
    }

    // ---------------------------------------------------------------------------------------------------------

    private Paint paint(int color, Paint.Style st, float w) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setStyle(st);
        p.setStrokeWidth(w);
        return p;
    }

    private Paint textPaint(float size, boolean bold, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(size);
        p.setColor(color);
        p.setFakeBoldText(bold);
        return p;
    }

    void drawPage(Canvas c, int index) {
        c.drawColor(Color.WHITE);
        if (index == 0) drawMapPage(c);
        else drawTablePage(c, index - 1);
    }

    private void drawMapPage(Canvas c) {
        float fx = (float) L.frameX, fy = (float) L.frameY, fw = (float) L.frameW, fh = (float) L.frameH;
        // title
        Paint tp = textPaint(18, true, Color.BLACK);
        c.drawText(o.title.isEmpty() ? (ar ? "خريطة" : "Map") : o.title, (float) ReportLayout.MARGIN_PT, (float) ReportLayout.MARGIN_PT + 18, tp);
        if (!o.subtitle.isEmpty())
            c.drawText(o.subtitle, (float) ReportLayout.MARGIN_PT, (float) ReportLayout.MARGIN_PT + 34, textPaint(10, false, 0xFF444444));

        c.save();
        c.clipRect(fx, fy, fx + fw, fy + fh);
        double snapMpp = 0;
        if (o.snapshot != null) {
            Bitmap b = o.snapshot;
            float k = Math.min(fw / b.getWidth(), fh / b.getHeight());
            float dw = b.getWidth() * k, dh = b.getHeight() * k;
            float dx = fx + (fw - dw) / 2, dy = fy + (fh - dh) / 2;
            c.drawBitmap(b, null, new RectF(dx, dy, dx + dw, dy + dh), new Paint(Paint.FILTER_BITMAP_FLAG));
            snapMpp = o.snapMetresPerPx / k; // ground metres per PDF point
        } else {
            if (o.grid != GRID_NONE) drawGrid(c);
            for (LayerData l : o.layers) drawLayer(c, l);
            drawNotes(c);
        }
        c.restore();
        c.drawRect(fx, fy, fx + fw, fy + fh, paint(Color.BLACK, Paint.Style.STROKE, 1f));

        drawScaleBar(c, snapMpp);
        drawNorthArrow(c);
        if (o.legend) drawLegend(c);

        if (o.snapshot != null) {
            long scale = Math.round(snapMpp / (0.0254 / 72));
            String f2 = (ar ? "المقياس التقريبي 1:" : "Approx. scale 1:") + scale + (ar ? " (لقطة للخريطة كما تظهر على الشاشة، الاتجاه كما في العرض)" : " (screenshot of the map as shown)")
                    + (o.snapCredit.isEmpty() ? "" : " — " + o.snapCredit);
            c.drawText(f2, (float) ReportLayout.MARGIN_PT, (float) (L.pageH - ReportLayout.MARGIN_PT), textPaint(7, false, 0xFF666666));
            return;
        }

        String foot = (ar ? "المقياس التقريبي 1:" : "Approx. scale 1:") + (long) L.fit.niceScale
                + (ar ? " — الإسقاط: خطوط الطول والعرض المتساوية (WGS84)" : " — plate carrée (WGS84)")
                + (ar ? " — بيانات الخرائط الأساسية غير مضمنة" : " — no base-map tiles included");
        c.drawText(foot, (float) ReportLayout.MARGIN_PT, (float) (L.pageH - ReportLayout.MARGIN_PT), textPaint(7, false, 0xFF666666));
    }

    private void drawNotes(Canvas c) {
        for (iq.gis.poiexporter.core.Annotations.Item it : o.notes) {
            float x = (float) L.px(it.lon), y = (float) L.py(it.lat);
            if (iq.gis.poiexporter.core.Annotations.IMAGE.equals(it.kind)) {
                Bitmap b = o.images == null ? null : o.images.apply(it.file);
                if (b == null) continue;
                float w = it.widthDp * 0.75f, h = w * b.getHeight() / b.getWidth();
                c.drawBitmap(b, null, new RectF(x - w / 2, y - h / 2, x + w / 2, y + h / 2), null);
            } else {
                Paint t = textPaint(it.sizeSp * 0.75f, false, it.color);
                String[] lines = it.text.split("\n");
                float w = 0;
                for (String l : lines) w = Math.max(w, t.measureText(l));
                float lh = t.getFontSpacing(), pad = 3, h = lh * lines.length;
                RectF r = new RectF(x - w / 2 - pad, y - h / 2 - pad, x + w / 2 + pad, y + h / 2 + pad);
                if (it.background != 0) {
                    c.drawRect(r, paint(it.background, Paint.Style.FILL, 1f));
                    c.drawRect(r, paint(0x55000000, Paint.Style.STROKE, 0.5f));
                }
                float yy = r.top + pad - t.ascent();
                for (String l : lines) {
                    c.drawText(l, x - t.measureText(l) / 2, yy, t);
                    yy += lh;
                }
            }
        }
    }

    private void drawLayer(Canvas c, LayerData l) {
        int alpha = Math.round(255 * Math.max(0f, Math.min(1f, l.opacity)));
        float w = Math.max(0.6f, l.width * 0.5f);
        for (Feature f : l.features) {
            if (f.geom == Feature.POINT) {
                float x = (float) L.px(f.lon), y = (float) L.py(f.lat);
                Paint fill = paint(l.color, Paint.Style.FILL, 1f);
                fill.setAlpha(alpha);
                c.drawCircle(x, y, 3f, fill);
                c.drawCircle(x, y, 3f, paint(Color.WHITE, Paint.Style.STROKE, 0.6f));
            } else if (f.geom == Feature.LINE) {
                Paint st = paint(l.color, Paint.Style.STROKE, w);
                st.setAlpha(alpha);
                for (double[] part : f.parts) c.drawPath(path(part, false), st);
            } else {
                Path path = new Path();
                path.setFillType(Path.FillType.EVEN_ODD);
                for (double[] part : f.parts) path.addPath(path(part, true));
                Paint fill = paint(l.color, Paint.Style.FILL, 1f);
                fill.setAlpha(Math.round(alpha * 0.25f));
                c.drawPath(path, fill);
                Paint st = paint(l.color, Paint.Style.STROKE, w);
                st.setAlpha(alpha);
                c.drawPath(path, st);
            }
        }
    }

    private Path path(double[] p, boolean close) {
        Path r = new Path();
        int n = p.length / 2;
        for (int i = 0; i < n; i++) {
            float x = (float) L.px(p[2 * i]), y = (float) L.py(p[2 * i + 1]);
            if (i == 0) r.moveTo(x, y);
            else r.lineTo(x, y);
        }
        if (close) r.close();
        return r;
    }

    private void drawGrid(Canvas c) {
        List<MapMath.GridLine> lines;
        double[] sb = L.shown;
        if (o.grid == GRID_UTM) {
            double lon = (sb[0] + sb[2]) / 2, lat = (sb[1] + sb[3]) / 2;
            lines = MapMath.utmGrid(sb, Crs.utm(Utm.zoneFor(lon), lat >= 0), 6);
        } else {
            lines = MapMath.graticule(sb, 6, false);
        }
        Paint gp = paint(0xFF8899AA, Paint.Style.STROKE, 0.4f);
        Paint tp = textPaint(6.5f, false, 0xFF445566);
        for (MapMath.GridLine g : lines) {
            Path p = path(g.lonlat, false);
            c.drawPath(p, gp);
            if (g.lonlat.length >= 4) {
                // label where the line enters the frame: first point for verticals (top), first point for horizontals (left)
                float x = (float) L.px(g.lonlat[0]), y = (float) L.py(g.lonlat[1]);
                if (g.vertical) c.drawText(g.label, Math.max((float) L.frameX + 2, x + 2), (float) L.frameY + 8, tp);
                else c.drawText(g.label, (float) L.frameX + 2, Math.max((float) L.frameY + 8, y - 2), tp);
            }
        }
    }

    private void drawScaleBar(Canvas c, double metresPerPt) {
        double m, lenD;
        if (metresPerPt > 0) {
            m = MapMath.niceScaleBarLength(L.frameW * 0.35 * metresPerPt);
            lenD = m / metresPerPt;
        } else {
            m = L.scaleBarMetres();
            lenD = L.barPoints(m);
        }
        float len = (float) lenD;
        float x = (float) L.frameX, y = (float) (L.frameY + L.frameH + 16);
        Paint b = paint(Color.BLACK, Paint.Style.FILL, 1f), s = paint(Color.BLACK, Paint.Style.STROKE, 0.8f);
        for (int i = 0; i < 4; i++) {
            RectF r = new RectF(x + len / 4 * i, y, x + len / 4 * (i + 1), y + 5);
            c.drawRect(r, i % 2 == 0 ? b : paint(Color.WHITE, Paint.Style.FILL, 1f));
            c.drawRect(r, s);
        }
        Paint t = textPaint(8, false, Color.BLACK);
        c.drawText("0", x - 2, y + 15, t);
        c.drawText(MapMath.scaleBarLabel(m, ar), x + len - 8, y + 15, t);
    }

    private void drawNorthArrow(Canvas c) {
        float cx = (float) (L.frameX + L.frameW - 22), cy = (float) (L.frameY + 34);
        double ang = MapMath.northArrowAngle(o.mapRotation);
        c.save();
        c.rotate((float) ang, cx, cy);
        Path p = new Path();
        p.moveTo(cx, cy - 18);
        p.lineTo(cx + 8, cy + 10);
        p.lineTo(cx, cy + 5);
        p.lineTo(cx - 8, cy + 10);
        p.close();
        c.drawPath(p, paint(Color.BLACK, Paint.Style.FILL, 1f));
        c.restore();
        c.drawText("N", cx - 4, cy - 22, textPaint(11, true, Color.BLACK));
    }

    private void drawLegend(Canvas c) {
        float x = (float) L.frameX, y = (float) L.legendY + 10;
        Paint t = textPaint(8, false, Color.BLACK);
        c.drawText(ar ? "دليل الخريطة" : "Legend", x, y, textPaint(9, true, Color.BLACK));
        y += 4;
        int shown = Math.min(legend.size(), 12);
        for (int i = 0; i < shown; i++) {
            MapMath.LegendEntry e = legend.get(i);
            y += 13;
            Paint sw = paint(e.argb, Paint.Style.FILL, 1f);
            if (e.geom == Feature.POINT) c.drawCircle(x + 5, y - 3, 3.5f, sw);
            else if (e.geom == Feature.LINE) c.drawLine(x, y - 3, x + 10, y - 3, paint(e.argb, Paint.Style.STROKE, 2f));
            else c.drawRect(x, y - 7, x + 10, y, sw);
            c.drawText(e.label + " (" + e.count + ")", x + 16, y, t);
        }
        if (legend.size() > shown) c.drawText("…", x + 16, y + 11, t);
    }

    private void drawTablePage(Canvas c, int page) {
        int per = ReportLayout.rowsPerPage(o.paper, o.landscape, ROW_PT);
        float m = (float) ReportLayout.MARGIN_PT;
        float usable = (float) L.pageW - 2 * m;
        Paint head = textPaint(8, true, Color.BLACK), cell = textPaint(7, false, Color.BLACK);
        // column widths: proportional to the typical content length, name wider than x/y
        float[] wts = {2.4f, 1.6f, 1.6f, 1.4f, 1.4f, 1.4f, 1.1f, 1.2f, 1.6f};
        float tot = 0;
        for (float v : wts) tot += v;
        float[] xs = new float[10];
        for (int i = 0; i < 9; i++) xs[i + 1] = xs[i] + usable * wts[i] / tot;
        float y = m + 12;
        c.drawText((o.title.isEmpty() ? (ar ? "الجدول" : "Attribute table") : o.title) + " — " + (page + 1) + "/" + tablePages(), m, y, textPaint(11, true, Color.BLACK));
        y += 18;
        String[] h = rows.get(0);
        for (int i = 0; i < 9; i++) c.drawText(h[i], m + xs[i], y, head);
        c.drawLine(m, y + 3, m + usable, y + 3, paint(Color.BLACK, Paint.Style.STROKE, 0.6f));
        int from = 1 + page * per, to = Math.min(rows.size(), from + per);
        for (int r = from; r < to; r++) {
            y += (float) ROW_PT;
            String[] row = rows.get(r);
            for (int i = 0; i < 9; i++) c.drawText(clip(row[i], cell, xs[i + 1] - xs[i] - 3), m + xs[i], y, cell);
        }
        if (rows.size() >= 3000 && page == tablePages() - 1)
            c.drawText(ar ? "اقتُطع الجدول عند 3000 صف؛ استخدم التصدير الكامل." : "Table truncated at 3000 rows; use the full export.", m, y + 16, textPaint(7, false, 0xFF884400));
    }

    private static String clip(String s, Paint p, float maxW) {
        if (s == null) return "";
        if (p.measureText(s) <= maxW) return s;
        int n = p.breakText(s, true, maxW - p.measureText("…"), null);
        return s.substring(0, Math.max(0, n)) + "…";
    }
}
