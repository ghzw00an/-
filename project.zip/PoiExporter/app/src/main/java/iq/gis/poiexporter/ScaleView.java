package iq.gis.poiexporter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import org.osmdroid.api.IGeoPoint;
import org.osmdroid.views.MapView;

import iq.gis.poiexporter.core.geo.Geodesy;
import iq.gis.poiexporter.core.report.MapMath;

/** Scale bar as an ordinary view above the map (not an overlay): it is never rotated, clipped or hidden by other layers. */
final class ScaleView extends View {
    private final MapView map;
    private final float d;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), halo = new Paint(Paint.ANTI_ALIAS_FLAG), tx = new Paint(Paint.ANTI_ALIAS_FLAG),
            txHalo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float lenPx;
    private String label = "";

    ScaleView(Context c, MapView map) {
        super(c);
        this.map = map;
        d = c.getResources().getDisplayMetrics().density;
        halo.setStyle(Paint.Style.STROKE);
        halo.setStrokeWidth(5.5f * d);
        halo.setColor(0xCC000000);
        halo.setStrokeCap(Paint.Cap.ROUND);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2.5f * d);
        line.setColor(0xFFFFFFFF);
        line.setStrokeCap(Paint.Cap.ROUND);
        tx.setColor(0xFFFFFFFF);
        tx.setTextSize(12.5f * d);
        tx.setFakeBoldText(true);
        tx.setTextAlign(Paint.Align.CENTER);
        txHalo.set(tx);
        txHalo.setStyle(Paint.Style.STROKE);
        txHalo.setStrokeWidth(3.2f * d);
        txHalo.setColor(0xCC000000);
        setClickable(false);
    }

    /** Fixed size so the bar never changes the layout while it is redrawn. */
    int widthPx() {
        return Math.round(130 * d);
    }

    int heightPx() {
        return Math.round(34 * d);
    }

    /** Recomputes the length from the current map view; call from the map listener and after each draw. */
    void update() {
        try {
            int w = map.getWidth(), h = map.getHeight();
            if (w == 0 || h == 0) return;
            IGeoPoint p1 = map.getProjection().fromPixels(w / 2 - 50, h / 2);
            IGeoPoint p2 = map.getProjection().fromPixels(w / 2 + 50, h / 2);
            double mpp = Geodesy.distance(p1.getLatitude(), p1.getLongitude(), p2.getLatitude(), p2.getLongitude()) / 100.0;
            if (!(mpp > 0) || Double.isInfinite(mpp)) return;
            double metres = MapMath.niceScaleBarLength(mpp * 110 * d);
            float len = (float) (metres / mpp);
            String s = MapMath.scaleBarLabel(metres, S.ar);
            if (Math.abs(len - lenPx) > 0.5f || !s.equals(label)) {
                lenPx = len;
                label = s;
                invalidate();
            }
        } catch (RuntimeException ignored) {
            // map not ready yet
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (lenPx <= 0) return;
        float right = getWidth() - 4 * d, left = Math.max(4 * d, right - lenPx), y = getHeight() - 6 * d, tick = 6 * d;
        c.drawLine(left, y, right, y, halo);
        c.drawLine(left, y - tick, left, y, halo);
        c.drawLine(right, y - tick, right, y, halo);
        c.drawLine(left, y, right, y, line);
        c.drawLine(left, y - tick, left, y, line);
        c.drawLine(right, y - tick, right, y, line);
        float ty = y - tick - 4 * d;
        c.drawText(label, (left + right) / 2f, ty, txHalo);
        c.drawText(label, (left + right) / 2f, ty, tx);
    }
}
