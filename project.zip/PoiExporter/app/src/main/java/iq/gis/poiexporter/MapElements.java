package iq.gis.poiexporter;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.net.Uri;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import iq.gis.poiexporter.core.Annotations;

/**
 * Map decorations reachable from the flag button: north arrow, scale bar, text boxes and small pictures.
 * Text boxes and pictures are anchored to a geographic position and saved in a small file of their own
 * (never in the landmark layers, so they do not leak into exports). Tap one on the map to edit, move or delete it.
 */
final class MapElements {
    static final int REQ_IMAGE = 17;
    private final MainActivity a;
    private Annotations store;
    private final Map<String, Bitmap> bitmaps = new HashMap<>();
    private final Layer layer = new Layer();
    private final Arrow arrow = new Arrow();
    private ScaleOverlay scale;

    MapElements(MainActivity a) {
        this.a = a;
    }

    Annotations store() {
        return store;
    }

    /** Adds the overlays; call once after the map exists. scale is the bar created by MainActivity. */
    void install(MapView map, ScaleOverlay sbar) {
        scale = sbar;
        load();
        map.getOverlays().add(layer);
        map.getOverlays().add(arrow);
        scale.setEnabled(a.prefs.flag("scaleBar", true));
        arrow.on = a.prefs.flag("northArrow", false);
    }

    boolean scaleOn() {
        return a.prefs.flag("scaleBar", true);
    }

    boolean arrowOn() {
        return arrow.on;
    }

    void toggleScale() {
        boolean v = !scaleOn();
        a.prefs.setFlag("scaleBar", v);
        scale.setEnabled(v);
        a.map.invalidate();
        a.toast(v ? S.t("مقياس الرسم: ظاهر", "Scale bar: shown") : S.t("مقياس الرسم: مخفي", "Scale bar: hidden"));
    }

    void toggleArrow() {
        arrow.on = !arrow.on;
        a.prefs.setFlag("northArrow", arrow.on);
        a.map.invalidate();
        a.toast(arrow.on ? S.t("سهم الشمال: ظاهر", "North arrow: shown") : S.t("سهم الشمال: مخفي", "North arrow: hidden"));
    }

    // ----------------------------------------------------------------------------------------------- persistence

    private File dir() {
        File d = new File(a.getFilesDir(), "annot");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private void load() {
        File f = new File(dir(), "annotations.json");
        String s = "";
        try {
            if (f.isFile()) {
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                try (InputStream in = new java.io.FileInputStream(f)) {
                    byte[] b = new byte[8192];
                    int n;
                    while ((n = in.read(b)) > 0) bo.write(b, 0, n);
                }
                s = bo.toString("UTF-8");
            }
        } catch (Exception e) {
            ErrorLog.add("annotations-load", e);
        }
        store = Annotations.fromJson(s);
    }

    private void save() {
        try (FileOutputStream os = new FileOutputStream(new File(dir(), "annotations.json"))) {
            os.write(store.toJson().getBytes("UTF-8"));
        } catch (Exception e) {
            ErrorLog.add("annotations-save", e);
        }
        a.map.invalidate();
    }

    // ----------------------------------------------------------------------------------------------- text box

    void addText() {
        org.osmdroid.api.IGeoPoint c = a.map.getMapCenter();
        Annotations.Item it = new Annotations.Item();
        it.lat = c.getLatitude();
        it.lon = c.getLongitude();
        editText(it, true);
    }

    private void editText(final Annotations.Item it, final boolean isNew) {
        LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, isNew ? S.t("مربع نص", "Text box") : S.t("تعديل مربع النص", "Edit text box")));
        final EditText t = Ui.field(a, S.t("النص (يمكن عدة أسطر)", "Text (multi-line ok)"), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        t.setText(it.text);
        box.addView(t);
        box.addView(UiKit.label(a, S.t("حجم الخط", "Font size")));
        final float[] sizes = {10, 14, 20, 28};
        int sel = 1;
        for (int i = 0; i < sizes.length; i++) if (Math.abs(sizes[i] - it.sizeSp) < 1) sel = i;
        final float[] chosenSize = {it.sizeSp};
        box.addView(Ui.chips(a, new String[]{S.t("صغير", "S"), S.t("متوسط", "M"), S.t("كبير", "L"), S.t("ضخم", "XL")}, sel, i -> chosenSize[0] = sizes[i]));
        box.addView(UiKit.label(a, S.t("لون النص", "Text colour")));
        final int[] cols = {0xFF000000, 0xFFD32F2F, 0xFF1565C0, 0xFF2E7D32, 0xFFFFFFFF};
        int cs = 0;
        for (int i = 0; i < cols.length; i++) if (cols[i] == it.color) cs = i;
        final int[] chosenColor = {it.color};
        box.addView(Ui.chips(a, new String[]{"⬛", "🟥", "🟦", "🟩", "⬜"}, cs, i -> chosenColor[0] = cols[i]));
        final boolean[] bg = {it.background != 0};
        box.addView(UiKit.check(a, S.t("خلفية بيضاء", "White background"), bg[0], v -> bg[0] = v));
        final Dialog d = a.card(box);
        LinearLayout r = Ui.row(a);
        if (!isNew)
            r.addView(Ui.button(a, S.t("حذف", "Delete"), false, () -> {
                d.dismiss();
                store.remove(it.id);
                save();
            }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("حفظ", "Save"), true, () -> {
            String s = t.getText().toString();
            if (s.trim().isEmpty()) {
                a.toast(S.t("اكتب نصاً", "Enter some text"));
                return;
            }
            it.text = s;
            it.sizeSp = chosenSize[0];
            it.color = chosenColor[0];
            it.background = bg[0] ? 0xE6FFFFFF : 0;
            if (isNew) store.items().add(it);
            d.dismiss();
            save();
        }), Ui.lp(0, -2, 1f, a, isNew ? 0 : 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    // ----------------------------------------------------------------------------------------------- picture

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        a.startActivityForResult(i, REQ_IMAGE);
    }

    /** Result of the picker: copy a downscaled version (max 1024 px) into app storage and place it at the screen centre. */
    void imagePicked(final Uri u) {
        new Thread(() -> {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = UriIO.open(a, u)) {
                    BitmapFactory.decodeStream(in, null, o);
                }
                int sample = 1;
                while (o.outWidth / sample > 1600 || o.outHeight / sample > 1600) sample *= 2;
                o.inJustDecodeBounds = false;
                o.inSampleSize = sample;
                Bitmap bmp;
                try (InputStream in = UriIO.open(a, u)) {
                    bmp = BitmapFactory.decodeStream(in, null, o);
                }
                if (bmp == null) throw new java.io.IOException(S.t("ليست صورة صالحة", "Not a valid image"));
                final String name = "img_" + System.currentTimeMillis() + ".png";
                try (FileOutputStream os = new FileOutputStream(new File(dir(), name))) {
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
                }
                final Bitmap fb = bmp;
                a.runOnUiThread(() -> {
                    org.osmdroid.api.IGeoPoint c = a.map.getMapCenter();
                    Annotations.Item it = new Annotations.Item();
                    it.kind = Annotations.IMAGE;
                    it.lat = c.getLatitude();
                    it.lon = c.getLongitude();
                    it.file = name;
                    bitmaps.put(name, fb);
                    store.items().add(it);
                    save();
                    a.toast(S.t("أُضيفت الصورة عند منتصف الشاشة. المسها للتعديل.", "Picture added at the screen centre. Tap it to edit."));
                });
            } catch (Throwable t) {
                ErrorLog.add("annotation-image", t);
                a.runOnUiThread(() -> a.message(S.t("تعذّرت إضافة الصورة", "Could not add the picture"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }

    private void editImage(final Annotations.Item it) {
        LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, S.t("صورة", "Picture")));
        box.addView(UiKit.label(a, S.t("العرض", "Width")));
        final int[] ws = {48, 96, 160, 240};
        int sel = 1;
        for (int i = 0; i < ws.length; i++) if (ws[i] == it.widthDp) sel = i;
        box.addView(Ui.chips(a, new String[]{S.t("صغير", "S"), S.t("متوسط", "M"), S.t("كبير", "L"), S.t("ضخم", "XL")}, sel, i -> {
            it.widthDp = ws[i];
            save();
        }));
        final Dialog d = a.card(box);
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("حذف", "Delete"), false, () -> {
            d.dismiss();
            store.remove(it.id);
            new File(dir(), it.file).delete();
            bitmaps.remove(it.file);
            save();
        }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("نقل إلى منتصف الشاشة", "Move to screen centre"), false, () -> {
            org.osmdroid.api.IGeoPoint c = a.map.getMapCenter();
            it.lat = c.getLatitude();
            it.lon = c.getLongitude();
            d.dismiss();
            save();
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    private void editExisting(Annotations.Item it) {
        if (Annotations.IMAGE.equals(it.kind)) editImage(it);
        else {
            // allow moving text too: the edit dialog keeps the position, so offer the move through a confirm
            editText(it, false);
        }
    }

    Bitmap bitmap(String file) {
        Bitmap b = bitmaps.get(file);
        if (b == null) {
            try {
                b = BitmapFactory.decodeFile(new File(dir(), file).getPath());
            } catch (Throwable t) {
                ErrorLog.add("annotation-bitmap", t);
            }
            if (b != null) bitmaps.put(file, b);
        }
        return b;
    }

    // ----------------------------------------------------------------------------------------------- overlays

    private final class Layer extends Overlay {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG), stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        Layer() {
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setColor(0x55000000);
            stroke.setStrokeWidth(1.5f);
        }

        @Override
        public void draw(Canvas c, MapView map, boolean shadow) {
            if (shadow || store == null) return;
            float d = map.getResources().getDisplayMetrics().density;
            Point p = new Point();
            for (Annotations.Item it : store.items()) {
                map.getProjection().toPixels(new GeoPoint(it.lat, it.lon), p);
                if (p.x < -400 * d || p.y < -400 * d || p.x > map.getWidth() + 400 * d || p.y > map.getHeight() + 400 * d) continue;
                if (Annotations.IMAGE.equals(it.kind)) {
                    Bitmap b = bitmap(it.file);
                    if (b == null) continue;
                    float w = it.widthDp * d, h = w * b.getHeight() / b.getWidth();
                    c.drawBitmap(b, null, new RectF(p.x - w / 2, p.y - h / 2, p.x + w / 2, p.y + h / 2), null);
                } else {
                    txt.setTextSize(it.sizeSp * d);
                    txt.setColor(it.color);
                    String[] lines = it.text.split("\n");
                    float w = 0;
                    for (String l : lines) w = Math.max(w, txt.measureText(l));
                    float lh = txt.getFontSpacing(), pad = 6 * d;
                    float h = lh * lines.length;
                    RectF r = new RectF(p.x - w / 2 - pad, p.y - h / 2 - pad, p.x + w / 2 + pad, p.y + h / 2 + pad);
                    if (it.background != 0) {
                        fill.setColor(it.background);
                        c.drawRoundRect(r, 6 * d, 6 * d, fill);
                        c.drawRoundRect(r, 6 * d, 6 * d, stroke);
                    }
                    float y = r.top + pad - txt.ascent();
                    for (String l : lines) {
                        c.drawText(l, p.x - txt.measureText(l) / 2, y, txt);
                        y += lh;
                    }
                }
            }
        }

        @Override
        public boolean onSingleTapConfirmed(MotionEvent e, MapView map) {
            if (store == null || store.items().isEmpty()) return false;
            org.osmdroid.api.IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
            double mPerPx = map.getProjection().metersToPixels(1f) > 0 ? 1.0 / map.getProjection().metersToPixels(1f) : 1;
            Annotations.Item it = store.nearest(g.getLatitude(), g.getLongitude(), 36 * map.getResources().getDisplayMetrics().density * mPerPx);
            if (it == null) return false;
            editExisting(it);
            return true;
        }
    }

    private final class Arrow extends Overlay {
        boolean on;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);

        @Override
        public void draw(Canvas c, MapView map, boolean shadow) {
            if (shadow || !on) return;
            float d = map.getResources().getDisplayMetrics().density;
            float cx = map.getWidth() - 34 * d, cy = 170 * d;
            c.save();
            c.rotate(-map.getMapOrientation(), cx, cy);
            Path n = new Path();
            n.moveTo(cx, cy - 22 * d);
            n.lineTo(cx + 10 * d, cy + 12 * d);
            n.lineTo(cx, cy + 6 * d);
            n.lineTo(cx - 10 * d, cy + 12 * d);
            n.close();
            p.setColor(0xCC000000);
            p.setStyle(Paint.Style.FILL);
            c.drawPath(n, p);
            p.setColor(0xFFFFFFFF);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * d);
            c.drawPath(n, p);
            t.setColor(0xFF000000);
            t.setTextSize(14 * d);
            t.setFakeBoldText(true);
            c.drawText("N", cx - 5 * d, cy - 26 * d, t);
            c.restore();
        }
    }
}
