package iq.gis.poiexporter.core.geo;

import java.util.Locale;

/** Human readable measurements. */
public final class Measure {
    private Measure() {
    }

    /** Area expressed in all three units. */
    public static final class AreaText {
        public final String m2, ha, km2;

        AreaText(String m2, String ha, String km2) {
            this.m2 = m2;
            this.ha = ha;
            this.km2 = km2;
        }

        public String all() {
            return m2 + " = " + ha + " = " + km2;
        }
    }

    public static AreaText area(double m2, boolean arabicDigits) {
        String a = fmt(m2, m2 >= 100 ? 0 : 2) + " m²";
        String h = fmt(m2 / 10000.0, 4) + " ha";
        String k = fmt(m2 / 1e6, m2 >= 1e8 ? 2 : 6) + " km²";
        if (arabicDigits) return new AreaText(digits(a), digits(h), digits(k));
        return new AreaText(a, h, k);
    }

    /** "850 m", "1.25 km". */
    public static String length(double m, boolean arabicDigits) {
        String s;
        if (m >= 10000) s = fmt(m / 1000, 2) + " km";
        else if (m >= 1000) s = fmt(m / 1000, 3) + " km";
        else if (m >= 100) s = fmt(m, 1) + " m";
        else s = fmt(m, 2) + " m";
        return arabicDigits ? digits(s) : s;
    }

    /** Grouped fixed-decimal number, trailing zeros removed beyond 2 decimals. */
    static String fmt(double v, int dec) {
        String s = String.format(Locale.US, "%,." + dec + "f", v);
        if (dec > 2 && s.indexOf('.') >= 0) {
            int cut = s.length();
            while (cut > 0 && s.charAt(cut - 1) == '0' && s.length() - cut < dec - 2) cut--;
            s = s.substring(0, cut);
        }
        return s;
    }

    /** Converts 0-9 to Arabic-Indic digits and separators. */
    public static String digits(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c >= '0' && c <= '9') b.append((char) ('٠' + (c - '0')));
            else if (c == '.') b.append('٫');
            else if (c == ',') b.append('٬');
            else b.append(c);
        }
        return b.toString();
    }
}
