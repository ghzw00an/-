package iq.gis.poiexporter.core;

/** WGS84 <-> UTM using the Kruger series (Karney 2011), accurate to well under a millimetre. */
public final class Utm {
    private static final double A = 6378137.0;
    private static final double F = 1.0 / 298.257223563;
    private static final double K0 = 0.9996;
    private static final double E0 = 500000.0;
    private static final double N0_SOUTH = 10000000.0;

    private static final double N = F / (2.0 - F);
    private static final double N2 = N * N, N3 = N2 * N, N4 = N3 * N;
    private static final double E = Math.sqrt(F * (2.0 - F));
    private static final double AA = A / (1 + N) * (1 + N2 / 4 + N4 / 64);

    private static final double[] ALPHA = {
            N / 2 - 2 * N2 / 3 + 5 * N3 / 16 + 41 * N4 / 180,
            13 * N2 / 48 - 3 * N3 / 5 + 557 * N4 / 1440,
            61 * N3 / 240 - 103 * N4 / 140,
            49561 * N4 / 161280};
    private static final double[] BETA = {
            N / 2 - 2 * N2 / 3 + 37 * N3 / 96 - N4 / 360,
            N2 / 48 + N3 / 15 - 437 * N4 / 1440,
            17 * N3 / 480 - 37 * N4 / 840,
            4397 * N4 / 161280};
    private static final double[] DELTA = {
            2 * N - 2 * N2 / 3 - 2 * N3 + 116 * N4 / 45,
            7 * N2 / 3 - 8 * N3 / 5 - 227 * N4 / 45,
            56 * N3 / 15 - 136 * N4 / 35,
            4279 * N4 / 630};

    private Utm() {}

    /** Result of a forward conversion. */
    public static final class Result {
        public final int zone;
        public final boolean north;
        public final double easting;
        public final double northing;

        Result(int zone, boolean north, double easting, double northing) {
            this.zone = zone;
            this.north = north;
            this.easting = easting;
            this.northing = northing;
        }

        /** e.g. "38N" */
        public String zoneLabel() {
            return zone + (north ? "N" : "S");
        }
    }

    public static int zoneFor(double lon) {
        double l = lon;
        while (l >= 180) l -= 360;
        while (l < -180) l += 360;
        int z = (int) Math.floor((l + 180.0) / 6.0) + 1;
        return Math.max(1, Math.min(60, z));
    }

    private static double atanh(double x) {
        return 0.5 * Math.log((1 + x) / (1 - x));
    }

    /** Converts to the natural zone of the point. */
    public static Result fromLatLon(double lat, double lon) {
        return fromLatLon(lat, lon, zoneFor(lon));
    }

    /** Converts using a forced zone. */
    public static Result fromLatLon(double lat, double lon, int zone) {
        double lon0 = Math.toRadians((zone - 1) * 6 - 180 + 3);
        double phi = Math.toRadians(lat);
        double lam = Math.toRadians(lon) - lon0;
        while (lam > Math.PI) lam -= 2 * Math.PI;
        while (lam < -Math.PI) lam += 2 * Math.PI;

        double sinPhi = Math.sin(phi);
        double t = Math.sinh(atanh(sinPhi) - E * atanh(E * sinPhi));
        double xiP = Math.atan2(t, Math.cos(lam));
        double etaP = atanh(Math.sin(lam) / Math.sqrt(1 + t * t));

        double xi = xiP, eta = etaP;
        for (int j = 1; j <= 4; j++) {
            xi += ALPHA[j - 1] * Math.sin(2 * j * xiP) * Math.cosh(2 * j * etaP);
            eta += ALPHA[j - 1] * Math.cos(2 * j * xiP) * Math.sinh(2 * j * etaP);
        }
        boolean north = lat >= 0;
        double easting = E0 + K0 * AA * eta;
        double northing = K0 * AA * xi + (north ? 0.0 : N0_SOUTH);
        return new Result(zone, north, easting, northing);
    }

    /** Returns {lat, lon} in degrees. */
    public static double[] toLatLon(int zone, boolean north, double easting, double northing) {
        double lon0 = Math.toRadians((zone - 1) * 6 - 180 + 3);
        double xi = (northing - (north ? 0.0 : N0_SOUTH)) / (K0 * AA);
        double eta = (easting - E0) / (K0 * AA);

        double xiP = xi, etaP = eta;
        for (int j = 1; j <= 4; j++) {
            xiP -= BETA[j - 1] * Math.sin(2 * j * xi) * Math.cosh(2 * j * eta);
            etaP -= BETA[j - 1] * Math.cos(2 * j * xi) * Math.sinh(2 * j * eta);
        }
        double chi = Math.asin(Math.sin(xiP) / Math.cosh(etaP));
        double phi = chi;
        for (int j = 1; j <= 4; j++) {
            phi += DELTA[j - 1] * Math.sin(2 * j * chi);
        }
        double lam = lon0 + Math.atan2(Math.sinh(etaP), Math.cos(xiP));
        return new double[]{Math.toDegrees(phi), Math.toDegrees(lam)};
    }
}
