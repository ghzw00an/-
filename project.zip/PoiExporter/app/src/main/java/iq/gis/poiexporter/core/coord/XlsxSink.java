package iq.gis.poiexporter.core.coord;

import iq.gis.poiexporter.core.table.XlsxWriter;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/** Excel output with real numeric cells; a new sheet starts every 1,000,000 rows. */
public final class XlsxSink implements Sink {
    private final XlsxWriter x;

    public XlsxSink(OutputStream os, boolean rtl) {
        x = new XlsxWriter(os, "Coordinates", rtl, XlsxWriter.DEFAULT_MAX_ROWS);
    }

    /** For tests: custom sheet split size. */
    public XlsxSink(OutputStream os, boolean rtl, int maxRows) {
        x = new XlsxWriter(os, "Coordinates", rtl, maxRows);
    }

    public void begin(List<String> columns) throws IOException {
        x.header(columns);
    }

    public void row(Object[] cells, double lon, double lat) throws IOException {
        Object[] c = new Object[cells.length];
        for (int i = 0; i < c.length; i++) {
            Object o = cells[i];
            c[i] = o instanceof BatchConverter.Num ? (Object) Double.valueOf(((BatchConverter.Num) o).value) : o;
        }
        x.row(c);
    }

    public void end() throws IOException {
        x.close();
    }
}
