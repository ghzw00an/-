package iq.gis.poiexporter.core.report;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LandmarkFields;
import iq.gis.poiexporter.core.LayerData;

import java.util.ArrayList;
import java.util.List;

/** Page layout of a printed map in PDF points (1/72 inch), independent of Android so it can be tested. */
public final class ReportLayout {
    public final Paper paper;
    public final double pageW, pageH;
    /** Map frame: x, y (top-left), width, height. */
    public final double frameX, frameY, frameW, frameH;
    public final MapMath.Fit fit;
    /** Shown bbox: west, south, east, north. */
    public final double[] shown;
    public final double titleY, legendY, legendH;

    private ReportLayout(Paper p, double fx, double fy, double fw, double fh, MapMath.Fit fit, double titleY, double legendY, double legendH) {
        paper = p;
        pageW = p.widthPt();
        pageH = p.heightPt();
        frameX = fx;
        frameY = fy;
        frameW = fw;
        frameH = fh;
        this.fit = fit;
        shown = fit.shown;
        this.titleY = titleY;
        this.legendY = legendY;
        this.legendH = legendH;
    }

    public static final double MARGIN_PT = Paper.mmToPt(10);
    public static final double TITLE_H = 44;   // title + subtitle block
    public static final double FOOTER_H = 22;
    public static final double SCALEBAR_H = 30;

    /**
     * @param bbox       lon/lat {west,south,east,north} that must be visible
     * @param legendRows number of legend rows (0 = no legend)
     * @param fixedScale 0 = automatic nice scale that fits, otherwise the scale denominator to use (bbox is centred)
     */
    public static ReportLayout compute(Paper base, boolean landscape, double[] bbox, int legendRows, double fixedScale) {
        Paper p = base.orient(landscape);
        double w = p.widthPt(), h = p.heightPt();
        double legendH = legendRows <= 0 ? 0 : 14 + 13 * Math.min(legendRows, 12);
        double fx = MARGIN_PT, fy = MARGIN_PT + TITLE_H;
        double fw = w - 2 * MARGIN_PT;
        double fh = h - fy - MARGIN_PT - FOOTER_H - SCALEBAR_H - legendH;
        double wMm = fw / 72 * 25.4, hMm = fh / 72 * 25.4;
        MapMath.Fit fit;
        if (fixedScale > 0) {
            double lat0 = (bbox[1] + bbox[3]) / 2, cx = (bbox[0] + bbox[2]) / 2;
            double dLon = wMm / 1000.0 * fixedScale / 2 / MapMath.metresPerDegLon(lat0);
            double dLat = hMm / 1000.0 * fixedScale / 2 / MapMath.metresPerDegLat();
            double[] shown = {cx - dLon, lat0 - dLat, cx + dLon, lat0 + dLat};
            fit = MapMath.fit(shown, wMm, hMm);
            // fit() picks a nice scale >= exact; force the requested one
            fit = forced(shown, fixedScale, wMm, hMm);
        } else {
            double[] padded = pad(bbox, 0.05);
            fit = MapMath.fit(padded, wMm, hMm);
        }
        return new ReportLayout(p, fx, fy, fw, fh, fit, MARGIN_PT, fy + fh + SCALEBAR_H, legendH);
    }

    private static MapMath.Fit forced(double[] shown, double scale, double wMm, double hMm) {
        // MapMath.Fit has a package-private constructor; same package, so build it directly
        return new MapMath.Fit(scale, scale, shown, wMm / 1000.0 * scale, hMm / 1000.0 * scale);
    }

    /** bbox grown by a fraction on every side; degenerate boxes (one point) get a minimum extent. */
    public static double[] pad(double[] b, double frac) {
        double w = b[2] - b[0], h = b[3] - b[1];
        double minSpan = 0.002;
        if (w < minSpan) {
            double c = (b[0] + b[2]) / 2;
            b = new double[]{c - minSpan / 2, b[1], c + minSpan / 2, b[3]};
            w = minSpan;
        }
        if (h < minSpan) {
            double c = (b[1] + b[3]) / 2;
            b = new double[]{b[0], c - minSpan / 2, b[2], c + minSpan / 2};
            h = minSpan;
        }
        return new double[]{b[0] - w * frac, b[1] - h * frac, b[2] + w * frac, b[3] + h * frac};
    }

    public double px(double lon) {
        return frameX + (lon - shown[0]) / (shown[2] - shown[0]) * frameW;
    }

    public double py(double lat) {
        return frameY + (shown[3] - lat) / (shown[3] - shown[1]) * frameH;
    }

    /** Length in points of a scale bar of the given ground length. */
    public double barPoints(double metres) {
        double mm = metres / fit.mPerMm;
        return mm / 25.4 * 72;
    }

    /** Nice scale-bar ground length that is at most ~35% of the frame width. */
    public double scaleBarMetres() {
        double maxMm = frameW / 72 * 25.4 * 0.35;
        return MapMath.niceScaleBarLength(maxMm * fit.mPerMm);
    }

    /** bbox of all features of the layers {west,south,east,north}, or null if none. */
    public static double[] extent(List<LayerData> layers) {
        double[] r = null;
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                double[] b;
                if (f.geom == Feature.POINT || f.parts.isEmpty()) b = new double[]{f.lon, f.lat, f.lon, f.lat};
                else b = iq.gis.poiexporter.core.Geo.bbox(f);
                if (Double.isNaN(b[0]) || b[0] > 180 || b[0] < -180 || b[1] > 90 || b[1] < -90) continue;
                if (r == null) r = b.clone();
                else {
                    r[0] = Math.min(r[0], b[0]);
                    r[1] = Math.min(r[1], b[1]);
                    r[2] = Math.max(r[2], b[2]);
                    r[3] = Math.max(r[3], b[3]);
                }
            }
        }
        return r;
    }

    /** Attribute table of the point features: header + rows in the fixed landmark order. Rows are capped. */
    public static List<String[]> tableRows(List<LayerData> layers, int maxRows) {
        List<String[]> rows = new ArrayList<>();
        rows.add(LandmarkFields.NAMES.clone());
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                if (f.geom != Feature.POINT) continue;
                if (rows.size() > maxRows) return rows;
                String[] t = LandmarkFields.text(f);
                double[] xy = LandmarkFields.xy(f, null);
                String[] r = new String[9];
                System.arraycopy(t, 0, r, 0, 6);
                r[6] = LandmarkFields.num(xy[0], 0);
                r[7] = LandmarkFields.num(xy[1], 0);
                r[8] = LandmarkFields.link(f);
                rows.add(r);
            }
        }
        return rows;
    }

    public static int rowsPerPage(Paper p, boolean landscape, double rowPt) {
        Paper o = p.orient(landscape);
        double usable = o.heightPt() - 2 * MARGIN_PT - 40;
        return Math.max(5, (int) (usable / rowPt) - 1);
    }
}
