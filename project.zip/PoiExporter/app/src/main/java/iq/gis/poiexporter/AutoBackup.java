package iq.gis.poiexporter;

import android.content.Context;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.ShapeWriter;
import iq.gis.poiexporter.core.db.ProjectArchive;
import iq.gis.poiexporter.core.db.ProjectInfo;

/** Daily automatic backups of every project into the app's private folder (newest 14 are kept). */
final class AutoBackup {
    static final int KEEP = 14;
    private static final long INTERVAL = 20L * 3600 * 1000;
    private static boolean running;

    private AutoBackup() {
    }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "backups");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static List<File> list(Context c) {
        File[] fs = dir(c).listFiles();
        List<File> out = new ArrayList<>();
        if (fs != null) {
            for (File f : fs) if (f.getName().endsWith(".poiproj.zip")) out.add(f);
        }
        Collections.sort(out, new Comparator<File>() {
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        return out;
    }

    /** Called when the app goes to the background; does nothing when a backup is recent or the feature is off. */
    static void maybe(final MainActivity a) {
        if (!a.prefs.flag("autoBackup", true)) return;
        long last = Long.parseLong(a.prefs.get("lastBackup", "0"));
        if (System.currentTimeMillis() - last < INTERVAL) return;
        run(a, null);
    }

    /** Writes one archive per non-empty project; done (may be null) is called on the UI thread with the count written. */
    static void run(final MainActivity a, final java.util.function.IntConsumer done) {
        if (Store.ws() == null) return;
        synchronized (AutoBackup.class) {
            if (running) return;
            running = true;
        }
        Store.flush();
        new Thread(new Runnable() {
            public void run() {
                int n = 0;
                try {
                    String stamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.US).format(new java.util.Date());
                    for (ProjectInfo pi : Store.ws().repo().projects()) {
                        if (pi.features == 0 && pi.layers == 0) continue;
                        List<LayerData> layers = Store.ws().repo().loadLayers(pi.id);
                        File f = new File(dir(a), "auto_" + stamp + "_" + ShapeWriter.safeName(pi.name) + ".poiproj.zip");
                        File tmp = new File(f.getPath() + ".tmp");
                        OutputStream os = new BufferedOutputStream(new FileOutputStream(tmp));
                        try {
                            ProjectArchive.write(pi.name, layers, os);
                        } finally {
                            os.close();
                        }
                        if (!tmp.renameTo(f)) tmp.delete();
                        else n++;
                    }
                    a.prefs.put("lastBackup", String.valueOf(System.currentTimeMillis()));
                    prune(a);
                } catch (Throwable t) {
                    ErrorLog.add("auto-backup", t);
                } finally {
                    synchronized (AutoBackup.class) {
                        running = false;
                    }
                }
                final int count = n;
                if (done != null) a.runOnUiThread(new Runnable() {
                    public void run() {
                        done.accept(count);
                    }
                });
            }
        }).start();
    }

    private static void prune(Context c) {
        List<File> fs = list(c);
        for (int i = KEEP; i < fs.size(); i++) fs.get(i).delete();
        File[] all = dir(c).listFiles();
        if (all != null) for (File f : all) if (f.getName().endsWith(".tmp")) f.delete();
    }

    static String size(File f) {
        long b = f.length();
        return b < 1024 ? b + " B" : b < 1048576 ? (b / 1024) + " KB" : String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0);
    }
}
