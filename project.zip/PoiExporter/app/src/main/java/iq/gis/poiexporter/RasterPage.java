package iq.gis.poiexporter;

import android.net.Uri;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import org.osmdroid.util.BoundingBox;

import iq.gis.poiexporter.core.raster.Georef;

/** Aerial / satellite images: add GeoTIFF or pictures with a world file or bounds, set opacity, zoom, delete. */
final class RasterPage {
    private final MainActivity a;
    private String worldEpsg = "4326";

    RasterPage(MainActivity a) {
        this.a = a;
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        final RasterStore st = a.rasters;
        LinearLayout add = Ui.card(a);
        add.addView(UiKit.head(a, S.t("إضافة صورة جوية أو فضائية", "Add an aerial / satellite image")));
        add.addView(UiKit.note(a, S.t(
                "المدعوم: TIFF وGeoTIFF (بلا ضغط أو LZW أو Deflate أو PackBits، حتى BigTIFF، 8/16/32 بت، ألوان أو رمادي أو لوحة)، وكذلك JPG وPNG وWebP وBMP وGIF مع ملف إحداثيات (World file) أو حدود تدخلها.\n"
                        + "غير المدعوم: ECW وMrSID وJPEG2000 وTIFF المضغوط بـ JPEG (حوّلها مسبقاً، مثلاً بـ gdal_translate -co COMPRESS=DEFLATE).\n"
                        + "حد الذاكرة: تُخزَّن الصورة بدقة أقصاها 2048 بكسل للضلع الأطول لتناسب الهاتف؛ للتغطية التفصيلية الكبيرة استخدم ملف بلاطات (MBTiles) من «أوفلاين». الصور الكبيرة جداً تُصغَّر.",
                "Supported: TIFF and GeoTIFF (uncompressed, LZW, Deflate, PackBits; BigTIFF; 8/16/32-bit; colour, gray or palette), plus JPG, PNG, WebP, BMP, GIF with a world file or bounds you enter.\n"
                        + "Not supported: ECW, MrSID, JPEG2000, JPEG-compressed TIFF (convert first, e.g. gdal_translate -co COMPRESS=DEFLATE).\n"
                        + "Memory limit: an image is kept at up to 2048 px on its longest side so it fits a phone; for large detailed coverage use an MBTiles file in Offline. Very large images are reduced.")));
        add.addView(Ui.button(a, S.t("اختيار صورة…", "Choose image…"), true, a::pickRaster));
        p.addView(add);

        if (st.pending != null) p.addView(pendingCard(st));

        LinearLayout list = Ui.card(a);
        list.addView(UiKit.head(a, S.t("الصور على الخريطة (" + st.items.size() + ")", "Images on the map (" + st.items.size() + ")")));
        if (st.items.isEmpty()) list.addView(UiKit.note(a, S.t("لا توجد صور.", "No images.")));
        for (final RasterStore.Item it : new java.util.ArrayList<>(st.items)) {
            list.addView(UiKit.head(a, it.name));
            list.addView(UiKit.note(a, RasterStore.describe(it) + (it.note.isEmpty() ? "" : "\n" + it.note)));
            list.addView(UiKit.check(a, S.t("إظهار", "Visible"), it.visible, v -> {
                it.visible = v;
                st.save();
                a.map.invalidate();
            }));
            int sel = it.opacity < 0.4f ? 0 : it.opacity < 0.65f ? 1 : it.opacity < 0.95f ? 2 : 3;
            final float[] ops = {0.3f, 0.5f, 0.85f, 1f};
            list.addView(Ui.chips(a, new String[]{"30%", "50%", "85%", "100%"}, sel, i -> {
                it.opacity = ops[i];
                st.save();
                a.map.invalidate();
            }));
            LinearLayout row = Ui.row(a);
            row.addView(Ui.button(a, S.t("تقريب", "Zoom to"), false, () -> {
                double[] b = RasterStore.bounds(it);
                a.showMap();
                a.map.post(() -> a.map.zoomToBoundingBox(new BoundingBox(Math.min(85, b[3]), b[2], Math.max(-85, b[1]), b[0]), true, Ui.dp(a, 30)));
            }), Ui.lp(0, -2, 1f, a, 0, 6, 4, 0));
            row.addView(Ui.button(a, S.t("حذف", "Delete"), false, () -> a.messageConfirm(S.t("حذف الصورة", "Delete image"), it.name, S.t("حذف", "Delete"), () -> {
                st.remove(it);
                a.map.invalidate();
                a.showPage("raster");
            })), Ui.lp(0, -2, 1f, a, 4, 6, 0, 0));
            list.addView(row);
        }
        p.addView(list);
        return p;
    }

    private View pendingCard(final RasterStore st) {
        final RasterStore.Pending pd = st.pending;
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("تحديد مكان الصورة: ", "Place the image: ") + pd.name));
        c.addView(UiKit.note(a, S.t("الصورة بلا إحداثيات جغرافية (" + pd.srcW + "×" + pd.srcH + "). اختر طريقة:", "No georeferencing (" + pd.srcW + "×" + pd.srcH + "). Choose a method:")));
        c.addView(UiKit.label(a, S.t("١) ملف الإحداثيات (World file: .wld .tfw .jgw .pgw)", "1) World file (.wld .tfw .jgw .pgw)")));
        final EditText ep = Ui.field(a, S.t("EPSG لنظام الملف (4326 للدرجات، 32638 لـ UTM 38N، 32639 لـ 39N)", "EPSG of the file's system (4326 degrees, 32638 UTM 38N, 32639 39N)"), InputType.TYPE_CLASS_NUMBER);
        ep.setText(worldEpsg);
        c.addView(ep);
        c.addView(Ui.button(a, S.t("اختيار ملف الإحداثيات…", "Choose world file…"), false, () -> {
            worldEpsg = ep.getText().toString().trim();
            a.pickWorld();
        }));
        c.addView(UiKit.label(a, S.t("٢) حدود بالدرجات (خط الطول/العرض)", "2) Bounds in degrees (lon/lat)")));
        final EditText w = Ui.field(a, S.t("غرب (أقل خط طول)", "West (min lon)"), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        final EditText s = Ui.field(a, S.t("جنوب (أقل خط عرض)", "South (min lat)"), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        final EditText e = Ui.field(a, S.t("شرق (أكبر خط طول)", "East (max lon)"), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        final EditText n = Ui.field(a, S.t("شمال (أكبر خط عرض)", "North (max lat)"), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        for (EditText x : new EditText[]{w, s, e, n}) {
            x.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            c.addView(x);
        }
        c.addView(Ui.button(a, S.t("وضع الصورة بهذه الحدود", "Place with these bounds"), false, () -> {
            try {
                double[] b = {Double.parseDouble(w.getText().toString().trim()), Double.parseDouble(s.getText().toString().trim()),
                        Double.parseDouble(e.getText().toString().trim()), Double.parseDouble(n.getText().toString().trim())};
                if (!(b[0] < b[2] && b[1] < b[3]) || Math.abs(b[0]) > 180 || Math.abs(b[2]) > 180 || Math.abs(b[1]) > 90 || Math.abs(b[3]) > 90)
                    throw new IllegalArgumentException();
                done(st, pd, Georef.corners(Georef.fromBounds(b[0], b[1], b[2], b[3], pd.bitmap.getWidth(), pd.bitmap.getHeight()), pd.bitmap.getWidth(), pd.bitmap.getHeight(), 0), 4326);
            } catch (RuntimeException ex) {
                a.toast(S.t("حدود غير صالحة (الغرب < الشرق والجنوب < الشمال)", "Invalid bounds (west < east, south < north)"));
            }
        }));
        c.addView(UiKit.label(a, S.t("٣) تقريبي: على العرض الحالي للخريطة", "3) Rough: fit to the current map view")));
        c.addView(Ui.button(a, S.t("ملء العرض الحالي مع الحفاظ على النسبة", "Fit the current view, keeping the aspect ratio"), false, () -> {
            BoundingBox bb = a.map.getBoundingBox();
            double vw = bb.getLonEast() - bb.getLonWest(), vh = bb.getLatNorth() - bb.getLatSouth();
            double lat0 = (bb.getLatNorth() + bb.getLatSouth()) / 2;
            double k = Math.cos(Math.toRadians(lat0));
            double ia = (double) pd.bitmap.getWidth() / pd.bitmap.getHeight(); // width/height in metres
            double w1 = vw * k, h1 = vh; // view in comparable units
            double iw, ih;
            if (w1 / h1 > ia) {
                ih = h1 * 0.9;
                iw = ih * ia;
            } else {
                iw = w1 * 0.9;
                ih = iw / ia;
            }
            double cx = (bb.getLonEast() + bb.getLonWest()) / 2, cy = lat0;
            double dw = iw / k / 2, dh = ih / 2;
            done(st, pd, Georef.corners(Georef.fromBounds(cx - dw, cy - dh, cx + dw, cy + dh, pd.bitmap.getWidth(), pd.bitmap.getHeight()), pd.bitmap.getWidth(), pd.bitmap.getHeight(), 0), 4326);
        }));
        c.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, () -> {
            st.pending = null;
            a.showPage("raster");
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        return c;
    }

    private void done(RasterStore st, RasterStore.Pending pd, double[] corners, int epsg) {
        st.place(pd, corners, epsg);
        a.map.invalidate();
        a.toast(S.t("تم وضع الصورة", "Image placed"));
        a.showPage("raster");
    }

    /** The user picked an image file. */
    void picked(Uri u, String name) {
        a.toast(S.t("جارٍ قراءة الصورة…", "Reading the image…"));
        a.rasters.read(u, name, (placed, msg) -> {
            if (msg.startsWith("ERR:")) {
                a.message(S.t("تعذّرت قراءة الصورة", "Could not read the image"), msg.substring(4), null, null);
                return;
            }
            a.toast(msg);
            a.showPage("raster");
        });
    }

    /** The user picked a world file for the pending image. */
    void worldPicked(final Uri u) {
        final RasterStore.Pending pd = a.rasters.pending;
        if (pd == null) return;
        new Thread(() -> {
            try (java.io.InputStream in = UriIO.open(a, u)) {
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] b = new byte[2048];
                int n;
                while ((n = in.read(b)) > 0 && bo.size() < 4096) bo.write(b, 0, n);
                double[] aff = Georef.parseWorldFile(bo.toString("UTF-8"));
                // the file describes the FULL-size image; our bitmap may be smaller but covers the same ground
                int ep = 4326;
                try {
                    ep = Integer.parseInt(worldEpsg.trim());
                } catch (NumberFormatException ignored) {
                    // default
                }
                final double[] corners = Georef.corners(aff, pd.srcW, pd.srcH, ep);
                final int epf = ep;
                a.runOnUiThread(() -> done(a.rasters, pd, corners, epf));
            } catch (Throwable t) {
                ErrorLog.add("world-file", t);
                a.runOnUiThread(() -> a.message(S.t("تعذّرت قراءة ملف الإحداثيات", "Could not use the world file"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }
}
