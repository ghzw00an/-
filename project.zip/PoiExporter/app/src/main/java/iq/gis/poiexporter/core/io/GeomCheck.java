package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.Jts;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.operation.valid.IsValidOp;
import org.locationtech.jts.operation.valid.TopologyValidationError;

import java.util.ArrayList;
import java.util.List;

/** Geometry validation with Arabic/English messages and automatic repairs for the safe cases. */
public final class GeomCheck {
    private GeomCheck() {
    }

    public static final String EMPTY = "EMPTY", TOO_FEW_POINTS = "TOO_FEW_POINTS", NOT_CLOSED = "NOT_CLOSED",
            SELF_INTERSECTION = "SELF_INTERSECTION", RING_ORIENTATION = "RING_ORIENTATION",
            DUPLICATE_VERTEX = "DUPLICATE_VERTEX", OUT_OF_RANGE = "OUT_OF_RANGE", TYPE_MISMATCH = "TYPE_MISMATCH";

    /** Issue codes of one feature; layerGeom is the geometry type of the layer (Feature.POINT/LINE/POLYGON, 0 = any). */
    public static List<String> check(Feature f, int layerGeom) {
        List<String> r = new ArrayList<>();
        if (f.parts.isEmpty()) {
            r.add(EMPTY);
            return r;
        }
        if (layerGeom != 0 && f.geom != layerGeom) r.add(TYPE_MISMATCH);
        boolean range = false, dup = false, open = false, few = false, orient = false;
        for (int i = 0; i < f.parts.size(); i++) {
            double[] p = f.parts.get(i);
            int n = p.length / 2;
            if (n == 0) {
                few = true;
                continue;
            }
            for (int k = 0; k < n; k++) {
                double x = p[2 * k], y = p[2 * k + 1];
                if (Double.isNaN(x) || Double.isNaN(y) || Math.abs(x) > 180 || Math.abs(y) > 90) range = true;
                if (k > 0 && x == p[2 * k - 2] && y == p[2 * k - 1] && !(f.geom == Feature.POLYGON && k == n - 1 && n > 3 && false)) dup = true;
            }
            if (f.geom == Feature.LINE && n < 2) few = true;
            if (f.geom == Feature.POLYGON) {
                if (p[0] != p[2 * n - 2] || p[1] != p[2 * n - 1]) open = true;
                int distinct = n - ((p[0] == p[2 * n - 2] && p[1] == p[2 * n - 1]) ? 1 : 0);
                if (distinct < 3) few = true;
                else {
                    boolean cw = Geo.signedArea(p) < 0;
                    if (cw == f.isHole(i)) orient = true;
                }
            }
        }
        if (range) r.add(OUT_OF_RANGE);
        if (few) r.add(TOO_FEW_POINTS);
        if (open) r.add(NOT_CLOSED);
        if (dup) r.add(DUPLICATE_VERTEX);
        if (orient) r.add(RING_ORIENTATION);
        if (f.geom == Feature.POLYGON && !range && !few) {
            try {
                Geometry g = Jts.toGeometry(f);
                if (g != null) {
                    TopologyValidationError e = new IsValidOp(g).getValidationError();
                    if (e != null) r.add(SELF_INTERSECTION);
                }
            } catch (RuntimeException e) {
                r.add(SELF_INTERSECTION);
            }
        }
        return r;
    }

    /** True for issues that cannot be repaired automatically and make the feature unsafe to export. */
    public static boolean isBlocking(String code) {
        return code.equals(EMPTY) || code.equals(TOO_FEW_POINTS) || code.equals(OUT_OF_RANGE) || code.equals(SELF_INTERSECTION)
                || code.equals(TYPE_MISMATCH);
    }

    public static String message(String code, boolean ar) {
        switch (code) {
            case EMPTY:
                return ar ? "لا توجد إحداثيات. احذف السجل أو أعد رسمه." : "No coordinates. Delete or redraw the feature.";
            case TOO_FEW_POINTS:
                return ar ? "عدد النقاط قليل (الخط يحتاج نقطتين والمضلع 3 رؤوس). أضف رؤوساً أو احذفه."
                        : "Too few points (line needs 2, polygon 3 vertices). Add vertices or delete it.";
            case NOT_CLOSED:
                return ar ? "المضلع غير مغلق؛ يمكن إغلاقه تلقائياً." : "Polygon is not closed; it can be closed automatically.";
            case SELF_INTERSECTION:
                return ar ? "المضلع يتقاطع مع نفسه. عدّل الرؤوس أو استخدم «إصلاح الهندسة»."
                        : "The polygon crosses itself. Edit the vertices or use \"Repair geometry\".";
            case RING_ORIENTATION:
                return ar ? "اتجاه الحلقة غير قياسي؛ يُصحَّح تلقائياً." : "Ring orientation is non-standard; fixed automatically.";
            case DUPLICATE_VERTEX:
                return ar ? "نقاط متتالية مكررة؛ تُحذف تلقائياً." : "Consecutive duplicate vertices; removed automatically.";
            case OUT_OF_RANGE:
                return ar ? "إحداثيات خارج النطاق (خط العرض ±90، خط الطول ±180). تحقق من نظام الإحداثيات أو من ترتيب X وY."
                        : "Coordinates out of range (lat ±90, lon ±180). Check the CRS or the X/Y order.";
            case TYPE_MISMATCH:
                return ar ? "نوع الهندسة لا يطابق نوع الطبقة." : "Geometry type does not match the layer type.";
            default:
                return code;
        }
    }

    /** Closes rings, orients them and removes consecutive duplicate vertices. Returns true if anything changed. */
    public static boolean fix(Feature f) {
        boolean changed = false;
        for (int i = 0; i < f.parts.size(); i++) {
            double[] p = f.parts.get(i);
            // remove consecutive duplicates
            int n = p.length / 2;
            double[] q = new double[p.length];
            int m = 0;
            for (int k = 0; k < n; k++) {
                if (m > 0 && q[2 * m - 2] == p[2 * k] && q[2 * m - 1] == p[2 * k + 1]) continue;
                q[2 * m] = p[2 * k];
                q[2 * m + 1] = p[2 * k + 1];
                m++;
            }
            if (m != n) {
                p = java.util.Arrays.copyOf(q, m * 2);
                changed = true;
            }
            if (f.geom == Feature.POLYGON && m >= 3) {
                if (p[0] != p[2 * m - 2] || p[1] != p[2 * m - 1]) {
                    p = java.util.Arrays.copyOf(p, p.length + 2);
                    p[p.length - 2] = p[0];
                    p[p.length - 1] = p[1];
                    changed = true;
                }
                if (p.length >= 8) {
                    boolean cw = Geo.signedArea(p) < 0;
                    if (cw == f.isHole(i)) {
                        p = Geo.reversed(p);
                        changed = true;
                    }
                }
            }
            f.parts.set(i, p);
        }
        if (changed) Geo.setRepresentative(f);
        return changed;
    }

    /** Repairs self-intersections with JTS GeometryFixer. Returns the repaired feature or null if not possible. */
    public static Feature makeValid(Feature f) {
        try {
            Geometry g = Jts.toGeometry(f);
            if (g == null) return null;
            Geometry v = org.locationtech.jts.geom.util.GeometryFixer.fix(g);
            List<Feature> fs = Jts.toFeatures(v, f);
            for (Feature x : fs) if (x.geom == f.geom) {
                x.id = f.id;
                return x;
            }
        } catch (RuntimeException ignored) {
            // fall through
        }
        return null;
    }

    /** Short combined text for a list of codes. */
    public static String describe(List<String> codes, boolean ar) {
        StringBuilder b = new StringBuilder();
        for (String c : codes) b.append(b.length() > 0 ? " • " : "").append(message(c, ar));
        return b.toString();
    }

    static String unused() {
        return S.t("", "");
    }
}
