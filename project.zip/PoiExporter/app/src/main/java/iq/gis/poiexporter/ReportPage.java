package iq.gis.poiexporter;

import android.graphics.Bitmap;
import android.text.InputType;
import android.widget.TextView;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.report.Paper;

/** Print layout: title, paper, extent, scale, grid, legend and attribute table → PDF (vector) or PNG. */
final class ReportPage {
    private final MainActivity a;
    private final Set<String> picked = new HashSet<>();
    private boolean pickedInit;
    private int paperIdx = 1, gridIdx, extentIdx, scaleIdx;
    private boolean landscape = true, legend = true, table = true, notes = true, snap;
    private String title = "", subtitle = "";
    private static final double[] SCALES = {0, 5000, 10000, 25000, 50000, 100000};

    ReportPage(MainActivity a) {
        this.a = a;
    }

    private List<LayerData> all() {
        List<LayerData> r = new ArrayList<>(MainActivity.LIB);
        r.addAll(MainActivity.DL);
        return r;
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        final List<LayerData> ls = all();
        if (ls.isEmpty()) {
            LinearLayout c = Ui.card(a);
            c.addView(UiKit.note(a, S.t("لا توجد طبقات للطباعة.", "No layers to print.")));
            p.addView(c);
            return p;
        }
        if (!pickedInit) {
            for (LayerData l : ls) if (l.visible && !MainActivity.HIDDEN.contains(l.id)) picked.add(l.id);
            pickedInit = true;
        }
        LinearLayout t = Ui.card(a);
        t.addView(UiKit.head(a, S.t("العنوان", "Title")));
        final EditText ti = Ui.field(a, S.t("عنوان الخريطة", "Map title"), InputType.TYPE_CLASS_TEXT);
        ti.setText(title);
        final EditText su = Ui.field(a, S.t("سطر فرعي (اختياري)", "Subtitle (optional)"), InputType.TYPE_CLASS_TEXT);
        su.setText(subtitle);
        t.addView(ti);
        t.addView(su);
        p.addView(t);

        LinearLayout lc = Ui.card(a);
        lc.addView(UiKit.head(a, S.t("الطبقات", "Layers")));
        for (final LayerData l : ls) {
            lc.addView(UiKit.check(a, l.label + "  (" + l.features.size() + ")", picked.contains(l.id), v -> {
                if (v) picked.add(l.id);
                else picked.remove(l.id);
            }));
        }
        p.addView(lc);

        LinearLayout pg = Ui.card(a);
        pg.addView(UiKit.head(a, S.t("الصفحة", "Page")));
        pg.addView(Ui.chips(a, new String[]{"A5", "A4", "A3"}, paperIdx, i -> paperIdx = i));
        pg.addView(Ui.chips(a, new String[]{S.t("أفقي", "Landscape"), S.t("عمودي", "Portrait")}, landscape ? 0 : 1, i -> landscape = i == 0));
        pg.addView(UiKit.label(a, S.t("النطاق", "Extent")));
        pg.addView(Ui.chips(a, new String[]{S.t("كل الطبقات", "All layers"), S.t("العرض الحالي", "Current view")}, extentIdx, i -> extentIdx = i));
        pg.addView(UiKit.label(a, S.t("مقياس الرسم", "Scale")));
        pg.addView(Ui.chips(a, new String[]{S.t("تلقائي", "Auto"), "1:5k", "1:10k", "1:25k", "1:50k", "1:100k"}, scaleIdx, i -> scaleIdx = i));
        pg.addView(UiKit.label(a, S.t("الشبكة", "Grid")));
        pg.addView(Ui.chips(a, new String[]{S.t("بلا", "None"), S.t("درجات", "Lat/Lon"), "UTM"}, gridIdx, i -> gridIdx = i));
        pg.addView(UiKit.check(a, S.t("دليل الخريطة (Legend)", "Legend"), legend, v -> legend = v));
        pg.addView(UiKit.check(a, S.t("📸 تضمين الخريطة المعروضة كما تظهر على الشاشة (بالخريطة الأساسية وكل ما عليها)", "📸 Include the map exactly as shown on screen (base map and everything on it)"), snap, v -> snap = v));
        pg.addView(UiKit.note(a, S.t("عند تفعيله تُطبع لقطة العرض الحالي (اضبط الخريطة والتقريب أولاً من الخريطة الرئيسية)، ويُهمل النطاق والمقياس والشبكة أعلاه. خرائط Google وEsri لها شروط استخدام تقيّد نسخها وإعادة نشرها؛ استعمل اللقطة للاستخدام الشخصي وتحمّل مسؤولية الترخيص. أنصح بـ OpenStreetMap عند النشر.",
                "When on, a screenshot of the current view is printed (set the map and zoom on the main map first); extent, scale and grid above are ignored. Google and Esri tiles have terms limiting copying and republishing: use the screenshot for personal use and mind the licence. OpenStreetMap is the safe choice for publishing.")));
        pg.addView(UiKit.check(a, S.t("مربعات النص والصور المضافة للخريطة", "Text boxes and pictures added to the map"), notes, v -> notes = v));
        pg.addView(UiKit.check(a, S.t("جدول الخصائص (name…link) في صفحات لاحقة (PDF)", "Attribute table pages (PDF)"), table, v -> table = v));
        pg.addView(UiKit.note(a, S.t(
                "ملاحظة صادقة: لا تُدرَج بلاطات الخرائط الأساسية (OSM/Google) في الملف لأن شروطها لا تسمح بنسخها؛ يُرسم المحتوى الاتجاهي فقط. المقياس صحيح على الورق عند الطباعة بحجم 100%.",
                "Honest note: base-map tiles (OSM/Google) are not included because their terms do not allow copying them into files; only your data is drawn. The scale is true when printed at 100%.")));
        p.addView(pg);

        LinearLayout go = Ui.card(a);
        go.addView(Ui.button(a, "👁 " + S.t("معاينة قبل الحفظ", "Preview before saving"), true,
                () -> preview(ls, ti.getText().toString(), su.getText().toString())), Ui.lp(-1, -2, 0, a, 0, 0, 0, 8));
        LinearLayout row = Ui.row(a);
        row.addView(Ui.button(a, S.t("حفظ PDF", "Save PDF"), false, () -> export(ls, ti.getText().toString(), su.getText().toString(), true)), Ui.lp(0, -2, 1f, a, 0, 0, 4, 0));
        row.addView(Ui.button(a, S.t("حفظ PNG", "Save PNG"), false, () -> export(ls, ti.getText().toString(), su.getText().toString(), false)), Ui.lp(0, -2, 1f, a, 4, 0, 0, 0));
        go.addView(row);
        p.addView(go);
        return p;
    }

    private ReportRenderer.Options options(List<LayerData> ls, String ti, String su, boolean pdf) {
        title = ti;
        subtitle = su;
        final ReportRenderer.Options o = new ReportRenderer.Options();
        o.title = ti.trim();
        o.subtitle = su.trim();
        o.paper = Paper.ALL[paperIdx];
        o.landscape = landscape;
        o.legend = legend;
        o.table = table && pdf;
        o.grid = gridIdx;
        o.fixedScale = SCALES[scaleIdx];
        for (LayerData l : ls) if (picked.contains(l.id) && !l.features.isEmpty()) o.layers.add(l);
        if (notes && a.elements != null && a.elements.store() != null) {
            for (iq.gis.poiexporter.core.Annotations.Item it : a.elements.store().items()) o.notes.add(it.copy());
            o.images = a.elements::bitmap;
        }
        if (o.layers.isEmpty() && !snap) {
            a.toast(S.t("اختر طبقة تحتوي عناصر.", "Pick a layer that has features."));
            return null;
        }
        if (snap && a.map != null) {
            captureSnapshot(o);
        } else if (extentIdx == 1 && a.map != null) {
            org.osmdroid.util.BoundingBox b = a.map.getBoundingBox();
            o.bbox = new double[]{b.getLonWest(), b.getLatSouth(), b.getLonEast(), b.getLatNorth()};
            o.mapRotation = a.map.getMapOrientation();
        }
        return o;
    }

    /** Draws the map view into a bitmap with the area rectangle hidden, and records the scale and the provider credit. Runs on the UI thread. */
    private void captureSnapshot(ReportRenderer.Options o) {
        org.osmdroid.views.MapView m = a.map;
        boolean wasVisible = a.ao.isVisible2();
        a.ao.setVisible2(false);
        try {
            Bitmap b = Bitmap.createBitmap(m.getWidth(), m.getHeight(), Bitmap.Config.ARGB_8888);
            m.draw(new android.graphics.Canvas(b));
            o.snapshot = b;
            org.osmdroid.util.GeoPoint p1 = (org.osmdroid.util.GeoPoint) m.getProjection().fromPixels(m.getWidth() / 2 - 50, m.getHeight() / 2);
            org.osmdroid.util.GeoPoint p2 = (org.osmdroid.util.GeoPoint) m.getProjection().fromPixels(m.getWidth() / 2 + 50, m.getHeight() / 2);
            o.snapMetresPerPx = iq.gis.poiexporter.core.geo.Geodesy.distance(p1.getLatitude(), p1.getLongitude(), p2.getLatitude(), p2.getLongitude()) / 100.0;
            o.mapRotation = m.getMapOrientation();
            o.landscape = b.getWidth() >= b.getHeight();
            BaseMaps.Def d = BaseMaps.ALL[Math.max(0, Math.min(BaseMaps.ALL.length - 1, parse(a.prefs.get("basemap", "3"))))];
            o.snapCredit = d.isOsm() ? "© OpenStreetMap contributors" : d.kind.equals("esri") ? "Imagery © Esri and its data providers" : "Map data © Google";
        } finally {
            a.ao.setVisible2(wasVisible);
        }
    }

    private static int parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 3;
        }
    }

    private void preview(List<LayerData> ls, String ti, String su) {
        final ReportRenderer.Options o = options(ls, ti, su, true);
        if (o == null) return;
        a.toast(S.t("جارٍ إنشاء المعاينة…", "Preparing preview…"));
        new Thread(() -> {
            try {
                final ReportRenderer r = new ReportRenderer(o);
                final int pages = r.pageCount();
                final Bitmap[] cache = new Bitmap[pages];
                cache[0] = r.renderPage(0, 110);
                a.runOnUiThread(() -> showPreview(r, cache));
            } catch (Throwable t) {
                ErrorLog.add("report-preview", t);
                a.runOnUiThread(() -> a.message(S.t("تعذّرت المعاينة", "Preview failed"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }

    private void showPreview(final ReportRenderer r, final Bitmap[] cache) {
        final int pages = cache.length;
        final int[] cur = {0};
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        final android.widget.TextView head = Ui.text(a, "", 15, Theme.text, true);
        box.addView(head);
        final ZoomImageView iv = new ZoomImageView(a);
        iv.setBackgroundColor(0xFFCCCCCC);
        box.addView(iv, new LinearLayout.LayoutParams(-1, Ui.dp(a, 430)));
        final Runnable[] show = new Runnable[1];
        show[0] = () -> {
            head.setText(S.t("معاينة — صفحة ", "Preview — page ") + (cur[0] + 1) + " / " + pages + S.t("   (قرّب بإصبعين، نقرتان للتكبير)", "   (pinch to zoom, double-tap)"));
            if (cache[cur[0]] == null) cache[cur[0]] = r.renderPage(cur[0], 110);
            iv.show(cache[cur[0]]);
        };
        final android.app.Dialog d = a.card(box);
        LinearLayout row = Ui.row(a);
        row.addView(Ui.button(a, "◀", false, () -> {
            if (cur[0] > 0) {
                cur[0]--;
                show[0].run();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 8, 4, 0));
        row.addView(Ui.button(a, S.t("إغلاق", "Close"), true, d::dismiss), Ui.lp(0, -2, 2f, a, 4, 8, 4, 0));
        row.addView(Ui.button(a, "▶", false, () -> {
            if (cur[0] < pages - 1) {
                cur[0]++;
                show[0].run();
            }
        }), Ui.lp(0, -2, 1f, a, 4, 8, 0, 0));
        box.addView(row);
        d.show();
        show[0].run();
    }

    private void export(List<LayerData> ls, String ti, String su, final boolean pdf) {
        final ReportRenderer.Options o = options(ls, ti, su, pdf);
        if (o == null) return;
        final String base = (o.title.isEmpty() ? "map" : o.title.replaceAll("[^\\p{L}\\p{N}_-]+", "_")) + "_" + System.currentTimeMillis() / 1000;
        final LinearLayout bx = UiKit.col(a);
        bx.addView(Ui.text(a, S.t("جارٍ إنشاء الملف…", "Creating the file…"), 16, Theme.text, true));
        final android.app.Dialog busy = a.card(bx);
        busy.setCancelable(false);
        busy.show();
        new Thread(() -> {
            try {
                final ReportRenderer r = new ReportRenderer(o);
                final String mime = pdf ? "application/pdf" : "image/png";
                final Storage.Saved sv = Storage.save(a, a.prefs, base + (pdf ? ".pdf" : ".png"), mime, os -> {
                    if (pdf) r.writePdf(os);
                    else r.writePng(os, 150);
                });
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    saved(sv, mime, (pdf ? S.t("الصفحات: ", "Pages: ") + r.pageCount() + "   " : "") + "1:" + (long) r.layout().fit.niceScale);
                });
            } catch (Throwable t) {
                ErrorLog.add("report", t);
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("تعذّر إنشاء التقرير", "Report failed"), String.valueOf(t.getMessage()), null, null);
                });
            }
        }).start();
    }

    void saved(final Storage.Saved sv, final String mime, String info) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(a, S.t("تم الحفظ", "Saved"), 18, Theme.text, true));
        android.widget.TextView t = Ui.text(a, sv.where + "\n" + info, 14, Theme.sub, false);
        t.setPadding(0, Ui.dp(a, 10), 0, Ui.dp(a, 10));
        box.addView(t);
        final android.app.Dialog d = a.card(box);
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إغلاق", "Close"), false, d::dismiss), Ui.lp(0, -2, 1f, a, 0, 6, 4, 0));
        r.addView(Ui.button(a, S.t("مشاركة", "Share"), false, () -> {
            d.dismiss();
            Storage.share(a, sv.uri, mime);
        }), Ui.lp(0, -2, 1f, a, 2, 6, 2, 0));
        r.addView(Ui.button(a, S.t("فتح", "Open"), true, () -> {
            if (!Storage.open(a, sv.uri, mime)) a.toast(S.t("لا يوجد تطبيق يفتح هذا الملف؛ استخدم المشاركة.", "No app can open this file; use Share."));
        }), Ui.lp(0, -2, 1f, a, 4, 6, 0, 0));
        box.addView(r);
        d.show();
    }
}
