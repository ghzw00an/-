package iq.gis.poiexporter;

import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.report.Paper;

/** Print layout: title, paper, extent, scale, grid, legend and attribute table → PDF (vector) or PNG. */
final class ReportPage {
    private final MainActivity a;
    private final Set<String> picked = new HashSet<>();
    private boolean pickedInit;
    private int paperIdx = 1, gridIdx, extentIdx, scaleIdx;
    private boolean landscape = true, legend = true, table = true;
    private String title = "", subtitle = "";
    private static final double[] SCALES = {0, 5000, 10000, 25000, 50000, 100000};

    ReportPage(MainActivity a) {
        this.a = a;
    }

    private List<LayerData> all() {
        List<LayerData> r = new ArrayList<>(MainActivity.LIB);
        r.addAll(MainActivity.DL);
        return r;
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        final List<LayerData> ls = all();
        if (ls.isEmpty()) {
            LinearLayout c = Ui.card(a);
            c.addView(UiKit.note(a, S.t("لا توجد طبقات للطباعة.", "No layers to print.")));
            p.addView(c);
            return p;
        }
        if (!pickedInit) {
            for (LayerData l : ls) if (l.visible && !MainActivity.HIDDEN.contains(l.id)) picked.add(l.id);
            pickedInit = true;
        }
        LinearLayout t = Ui.card(a);
        t.addView(UiKit.head(a, S.t("العنوان", "Title")));
        final EditText ti = Ui.field(a, S.t("عنوان الخريطة", "Map title"), InputType.TYPE_CLASS_TEXT);
        ti.setText(title);
        final EditText su = Ui.field(a, S.t("سطر فرعي (اختياري)", "Subtitle (optional)"), InputType.TYPE_CLASS_TEXT);
        su.setText(subtitle);
        t.addView(ti);
        t.addView(su);
        p.addView(t);

        LinearLayout lc = Ui.card(a);
        lc.addView(UiKit.head(a, S.t("الطبقات", "Layers")));
        for (final LayerData l : ls) {
            lc.addView(UiKit.check(a, l.label + "  (" + l.features.size() + ")", picked.contains(l.id), v -> {
                if (v) picked.add(l.id);
                else picked.remove(l.id);
            }));
        }
        p.addView(lc);

        LinearLayout pg = Ui.card(a);
        pg.addView(UiKit.head(a, S.t("الصفحة", "Page")));
        pg.addView(Ui.chips(a, new String[]{"A5", "A4", "A3"}, paperIdx, i -> paperIdx = i));
        pg.addView(Ui.chips(a, new String[]{S.t("أفقي", "Landscape"), S.t("عمودي", "Portrait")}, landscape ? 0 : 1, i -> landscape = i == 0));
        pg.addView(UiKit.label(a, S.t("النطاق", "Extent")));
        pg.addView(Ui.chips(a, new String[]{S.t("كل الطبقات", "All layers"), S.t("العرض الحالي", "Current view")}, extentIdx, i -> extentIdx = i));
        pg.addView(UiKit.label(a, S.t("مقياس الرسم", "Scale")));
        pg.addView(Ui.chips(a, new String[]{S.t("تلقائي", "Auto"), "1:5k", "1:10k", "1:25k", "1:50k", "1:100k"}, scaleIdx, i -> scaleIdx = i));
        pg.addView(UiKit.label(a, S.t("الشبكة", "Grid")));
        pg.addView(Ui.chips(a, new String[]{S.t("بلا", "None"), S.t("درجات", "Lat/Lon"), "UTM"}, gridIdx, i -> gridIdx = i));
        pg.addView(UiKit.check(a, S.t("دليل الخريطة (Legend)", "Legend"), legend, v -> legend = v));
        pg.addView(UiKit.check(a, S.t("جدول الخصائص (name…link) في صفحات لاحقة (PDF)", "Attribute table pages (PDF)"), table, v -> table = v));
        pg.addView(UiKit.note(a, S.t(
                "ملاحظة صادقة: لا تُدرَج بلاطات الخرائط الأساسية (OSM/Google) في الملف لأن شروطها لا تسمح بنسخها؛ يُرسم المحتوى الاتجاهي فقط. المقياس صحيح على الورق عند الطباعة بحجم 100%.",
                "Honest note: base-map tiles (OSM/Google) are not included because their terms do not allow copying them into files; only your data is drawn. The scale is true when printed at 100%.")));
        p.addView(pg);

        LinearLayout go = Ui.card(a);
        LinearLayout row = Ui.row(a);
        row.addView(Ui.button(a, "PDF", true, () -> export(ls, ti.getText().toString(), su.getText().toString(), true)), Ui.lp(0, -2, 1f, a, 0, 0, 4, 0));
        row.addView(Ui.button(a, "PNG", false, () -> export(ls, ti.getText().toString(), su.getText().toString(), false)), Ui.lp(0, -2, 1f, a, 4, 0, 0, 0));
        go.addView(row);
        p.addView(go);
        return p;
    }

    private void export(List<LayerData> ls, String ti, String su, final boolean pdf) {
        title = ti;
        subtitle = su;
        final ReportRenderer.Options o = new ReportRenderer.Options();
        o.title = ti.trim();
        o.subtitle = su.trim();
        o.paper = Paper.ALL[paperIdx];
        o.landscape = landscape;
        o.legend = legend;
        o.table = table && pdf;
        o.grid = gridIdx;
        o.fixedScale = SCALES[scaleIdx];
        for (LayerData l : ls) if (picked.contains(l.id) && !l.features.isEmpty()) o.layers.add(l);
        if (o.layers.isEmpty()) {
            a.toast(S.t("اختر طبقة تحتوي عناصر.", "Pick a layer that has features."));
            return;
        }
        if (extentIdx == 1 && a.map != null) {
            org.osmdroid.util.BoundingBox b = a.map.getBoundingBox();
            o.bbox = new double[]{b.getLonWest(), b.getLatSouth(), b.getLonEast(), b.getLatNorth()};
            o.mapRotation = a.map.getMapOrientation();
        }
        final String base = (o.title.isEmpty() ? "map" : o.title.replaceAll("[^\\p{L}\\p{N}_-]+", "_")) + "_" + System.currentTimeMillis() / 1000;
        final LinearLayout bx = UiKit.col(a);
        bx.addView(Ui.text(a, S.t("جارٍ إنشاء الملف…", "Creating the file…"), 16, Theme.text, true));
        final android.app.Dialog busy = a.card(bx);
        busy.setCancelable(false);
        busy.show();
        new Thread(() -> {
            try {
                final ReportRenderer r = new ReportRenderer(o);
                final String mime = pdf ? "application/pdf" : "image/png";
                final Storage.Saved sv = Storage.save(a, a.prefs, base + (pdf ? ".pdf" : ".png"), mime, os -> {
                    if (pdf) r.writePdf(os);
                    else r.writePng(os, 150);
                });
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("تم الحفظ", "Saved"), sv.where + (pdf ? "\n" + S.t("الصفحات: ", "Pages: ") + r.pageCount() : "")
                            + "\n1:" + (long) r.layout().fit.niceScale, S.t("مشاركة", "Share"), () -> Storage.share(a, sv.uri, mime));
                });
            } catch (Throwable t) {
                ErrorLog.add("report", t);
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("تعذّر إنشاء التقرير", "Report failed"), String.valueOf(t.getMessage()), null, null);
                });
            }
        }).start();
    }
}
