package iq.gis.poiexporter;

import android.net.Uri;
import android.view.View;
import android.widget.LinearLayout;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.db.ProjectArchive;
import iq.gis.poiexporter.core.db.ProjectInfo;
import iq.gis.poiexporter.core.db.Workspace;

/** Lists the automatic backups with restore / share / delete, and lets the user back up right now. */
final class BackupPage {
    private final MainActivity a;

    BackupPage(MainActivity a) {
        this.a = a;
    }

    View build() {
        LinearLayout p = UiKit.col(a);
        p.addView(UiKit.note(a, S.t("تُحفظ نسخة من كل مشروع تلقائياً مرة يومياً عند الخروج من التطبيق (آخر " + AutoBackup.KEEP + " نسخة). "
                        + "النسخ داخل مساحة التطبيق وتُحذف مع حذفه، لذلك شارك نسخة إلى مكان آخر من حين لآخر.",
                "A copy of every project is saved automatically once a day when you leave the app (last " + AutoBackup.KEEP + " kept). "
                        + "They live in the app's private storage and are deleted with it, so share a copy elsewhere now and then.")));
        p.addView(UiKit.check(a, S.t("نسخ احتياطي تلقائي يومي", "Daily automatic backup"), a.prefs.flag("autoBackup", true),
                v -> a.prefs.setFlag("autoBackup", v)));
        p.addView(Ui.button(a, S.t("💾 نسخ احتياطي الآن", "💾 Back up now"), true, () -> {
            a.toast(S.t("جارٍ النسخ…", "Backing up…"));
            AutoBackup.run(a, n -> {
                a.toast(n == 0 ? S.t("لا توجد بيانات لنسخها", "Nothing to back up") : S.t("تم حفظ " + n + " نسخة ✔", n + " backup(s) saved ✔"));
                a.showPage("backups");
            });
        }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 6));

        List<File> fs = AutoBackup.list(a);
        if (fs.isEmpty()) {
            LinearLayout empty = Ui.card(a);
            empty.setGravity(android.view.Gravity.CENTER);
            empty.addView(Ui.text(a, "🗄", 40, Theme.sub, false));
            empty.addView(Ui.text(a, S.t("لا توجد نسخ بعد", "No backups yet"), 16, Theme.text, true));
            empty.addView(UiKit.note(a, S.t("اضغط «نسخ احتياطي الآن» لإنشاء أول نسخة.", "Tap “Back up now” to create the first one.")));
            p.addView(empty);
            return p;
        }
        for (final File f : fs) {
            LinearLayout c = Ui.card(a);
            String when = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(new java.util.Date(f.lastModified()));
            String nm = f.getName().replaceFirst("^auto_\\d{8}_\\d{4}_", "").replace(".poiproj.zip", "");
            c.addView(Ui.text(a, nm, 16, Theme.text, true));
            c.addView(UiKit.note(a, when + "  •  " + AutoBackup.size(f)));
            LinearLayout r = Ui.row(a);
            r.addView(Ui.button(a, S.t("استرجاع", "Restore"), true, () -> a.messageConfirm(S.t("استرجاع النسخة", "Restore backup"),
                    S.t("سيُنشأ مشروع جديد من هذه النسخة ولن يتغير أي مشروع موجود.", "A new project is created from this backup; existing projects are not changed."),
                    S.t("استرجاع", "Restore"), () -> restore(f))), Ui.lp(0, -2, 1f, a, 0, 8, 2, 0));
            r.addView(Ui.button(a, S.t("مشاركة", "Share"), false, () -> share(f)), Ui.lp(0, -2, 1f, a, 2, 8, 2, 0));
            r.addView(Ui.button(a, S.t("حذف", "Delete"), false, () -> a.messageConfirm(S.t("حذف النسخة", "Delete backup"), nm + "\n" + when,
                    S.t("حذف", "Delete"), () -> {
                        f.delete();
                        a.showPage("backups");
                    })), Ui.lp(0, -2, 1f, a, 2, 8, 0, 0));
            c.addView(r);
            p.addView(c);
        }
        return p;
    }

    private void share(final File f) {
        new Thread(() -> {
            try {
                final Storage.Saved sv = Storage.save(a, a.prefs, f.getName(), "application/zip", os -> {
                    try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
                        byte[] b = new byte[65536];
                        int n;
                        while ((n = in.read(b)) > 0) os.write(b, 0, n);
                    }
                });
                a.runOnUiThread(() -> a.message(S.t("تم حفظ نسخة خارجية ✔", "External copy saved ✔"), sv.where, S.t("مشاركة", "Share"),
                        () -> Storage.share(a, sv.uri, "application/zip")));
            } catch (final Throwable t) {
                a.runOnUiThread(() -> a.message(S.t("فشل الحفظ", "Save failed"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }

    private void restore(final File f) {
        new Thread(() -> {
            try {
                final ProjectArchive.Restored rs;
                try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
                    rs = ProjectArchive.read(in);
                }
                a.runOnUiThread(() -> {
                    Workspace w = Store.ws();
                    w.flush();
                    ProjectInfo pi = w.repo().createProject(rs.name + S.t(" (مسترجع)", " (restored)"));
                    w.open(pi.id);
                    for (LayerData l : rs.layers) w.addLayerWithFeatures(l);
                    w.clearHistory();
                    MainActivity.ACTIVE = null;
                    a.rebuild();
                    a.showPage("projects");
                    a.toast(S.t("تم الاسترجاع كمشروع جديد", "Restored as a new project"));
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> a.message(S.t("نسخة غير صالحة", "Invalid backup"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }
}
