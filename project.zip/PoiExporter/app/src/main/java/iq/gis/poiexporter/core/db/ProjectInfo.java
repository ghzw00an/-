package iq.gis.poiexporter.core.db;

/** Summary of one project for the project list. */
public final class ProjectInfo {
    public String id, name, created, updated;
    public int layers;
    public long features;
}
