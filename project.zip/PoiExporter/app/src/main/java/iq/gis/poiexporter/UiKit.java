package iq.gis.poiexporter;

import android.app.Dialog;
import android.content.Context;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;
import java.util.function.Consumer;

import iq.gis.poiexporter.core.crs.Crs;

/** Small view builders shared by the newer pages. */
final class UiKit {
    private UiKit() {
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static TextView head(Context c, String s) {
        TextView t = Ui.text(c, s, 16, Theme.text, true);
        t.setPadding(0, 0, 0, Ui.dp(c, 8));
        return t;
    }

    static TextView note(Context c, String s) {
        TextView t = Ui.text(c, s, 12.5f, Theme.sub, false);
        t.setPadding(0, Ui.dp(c, 4), 0, Ui.dp(c, 4));
        return t;
    }

    static TextView label(Context c, String s) {
        TextView t = Ui.text(c, s, 13, Theme.sub, false);
        t.setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 4));
        return t;
    }

    static View check(final Context c, String text, boolean on, final Consumer<Boolean> cb) {
        final boolean[] st = {on};
        LinearLayout r = Ui.row(c);
        r.setPadding(0, Ui.dp(c, 6), 0, Ui.dp(c, 6));
        r.setClickable(true);
        final TextView box = Ui.text(c, on ? "☑" : "☐", 22, on ? Theme.primary : Theme.sub, true);
        TextView t = Ui.text(c, text, 14.5f, Theme.text, false);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.setMargins(Ui.dp(c, 10), 0, 0, 0);
        r.addView(box, new LinearLayout.LayoutParams(Ui.dp(c, 30), -2));
        r.addView(t, tl);
        Ui.pressable(r);
        r.setOnClickListener(v -> {
            st[0] = !st[0];
            box.setText(st[0] ? "☑" : "☐");
            box.setTextColor(st[0] ? Theme.primary : Theme.sub);
            if (cb != null) cb.accept(st[0]);
        });
        return r;
    }

    /** Dialog with a search box listing CRS; "auto" adds a first row that returns null. */
    static void pickCrs(final MainActivity a, final String autoLabel, final Consumer<Crs> done) {
        final LinearLayout box = col(a);
        box.addView(head(a, S.t("اختيار نظام الإحداثيات", "Choose coordinate system")));
        final EditText q = Ui.field(a, S.t("ابحث: رقم EPSG أو اسم (UTM 38، Ain، Nahrwan…)", "Search: EPSG code or name"), InputType.TYPE_CLASS_TEXT);
        q.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        box.addView(q);
        final LinearLayout list = col(a);
        ScrollView sv = new ScrollView(a);
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(-1, Ui.dp(a, 300)));
        final Dialog d = a.card(box);
        final Runnable fill = new Runnable() {
            public void run() {
                list.removeAllViews();
                String s = q.getText().toString().trim();
                if (autoLabel != null && s.isEmpty()) list.addView(row(a, autoLabel, null, d, done));
                List<Crs.Entry> es = new java.util.ArrayList<>();
                if (s.isEmpty()) {
                    for (int code : Crs.favourites()) for (Crs.Entry e : Crs.search(String.valueOf(code), 5)) if (e.code == code) es.add(e);
                } else {
                    es = Crs.search(s, 40);
                }
                for (Crs.Entry e : es) {
                    try {
                        list.addView(row(a, "EPSG:" + e.code + "  " + e.name, Crs.of(e.code), d, done));
                    } catch (RuntimeException ignored) {
                        // unusable entry
                    }
                }
                if (es.isEmpty() && !s.isEmpty()) list.addView(note(a, S.t("لا نتائج", "No results")));
            }
        };
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                fill.run();
            }
        });
        fill.run();
        d.show();
    }

    private static View row(MainActivity a, String text, final Crs crs, final Dialog d, final Consumer<Crs> done) {
        TextView t = Ui.text(a, text, 14, Theme.text, false);
        t.setPadding(Ui.dp(a, 4), Ui.dp(a, 10), Ui.dp(a, 4), Ui.dp(a, 10));
        t.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(v -> {
            d.dismiss();
            done.accept(crs);
        });
        return t;
    }

    static String crsText(Crs c, String auto) {
        return c == null ? auto : c.code() + " " + c.name;
    }
}
