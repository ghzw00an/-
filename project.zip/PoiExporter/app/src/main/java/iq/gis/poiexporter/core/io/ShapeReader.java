package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.crs.Crs;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Reads shapefiles (.shp/.dbf/.prj/.cpg) from a ZIP. Streaming: records are visited one by one. */
public final class ShapeReader {
    private ShapeReader() {
    }

    /** One shapefile inside the zip. */
    public static final class Item {
        public String name; // base name without folders and extension
        public String path; // base path inside the zip
        public int shapeType;
        public long records;
        public Crs crs; // null when .prj missing or unknown
        public boolean hasPrj;
        public String prjText = "";
    }

    private static String lower(String s) {
        return s.toLowerCase(Locale.ROOT);
    }

    private static ZipEntry find(ZipFile z, String base, String ext) {
        Enumeration<? extends ZipEntry> en = z.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            if (!e.isDirectory() && lower(e.getName()).equals(lower(base) + ext)) return e;
        }
        return null;
    }

    /** Lists the shapefiles of the zip with their type, record count and CRS. */
    public static List<Item> list(File zip) throws IOException {
        List<Item> out = new ArrayList<>();
        ZipFile z = new ZipFile(zip);
        try {
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory() || e.getName().contains("..") || e.getName().startsWith("__MACOSX")) continue;
                if (!lower(e.getName()).endsWith(".shp")) continue;
                Item it = new Item();
                it.path = e.getName().substring(0, e.getName().length() - 4);
                int sl = Math.max(it.path.lastIndexOf('/'), it.path.lastIndexOf('\\'));
                it.name = sl >= 0 ? it.path.substring(sl + 1) : it.path;
                InputStream in = z.getInputStream(e);
                try {
                    byte[] h = new byte[100];
                    new DataInputStream(in).readFully(h);
                    ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
                    it.shapeType = b.getInt(32);
                } finally {
                    in.close();
                }
                ZipEntry dbf = find(z, it.path, ".dbf");
                if (dbf != null) {
                    InputStream di = z.getInputStream(dbf);
                    try {
                        byte[] h = new byte[8];
                        new DataInputStream(di).readFully(h);
                        it.records = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN).getInt(4) & 0xFFFFFFFFL;
                    } catch (EOFException ignored) {
                        // damaged dbf: count stays 0
                    } finally {
                        di.close();
                    }
                }
                ZipEntry prj = find(z, it.path, ".prj");
                if (prj != null) {
                    it.hasPrj = true;
                    it.prjText = new String(readAll(z.getInputStream(prj), 1 << 16), StandardCharsets.UTF_8);
                    try {
                        it.crs = Wkt.detect(it.prjText);
                    } catch (RuntimeException ex) {
                        it.crs = null;
                    }
                }
                out.add(it);
            }
        } finally {
            z.close();
        }
        if (out.isEmpty())
            throw new IOException(S.t("لا يحتوي ملف ZIP على ملفات .shp. تأكد من ضغط ملفات shp وshx وdbf معاً.",
                    "The ZIP has no .shp files. Zip the .shp, .shx and .dbf files together."));
        return out;
    }

    private static byte[] readAll(InputStream in, int max) throws IOException {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && bo.size() < max) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
        }
    }

    // ------------------------------------------------------------------ dbf

    private static final class Dbf {
        final List<String> names = new ArrayList<>();
        final List<Character> types = new ArrayList<>();
        final List<Integer> lens = new ArrayList<>(), decs = new ArrayList<>();
        int recLen, headerLen;
        long count;
        Charset cs = StandardCharsets.UTF_8;
        DataInputStream in;

        boolean next(String[] vals) throws IOException {
            byte[] rec = new byte[recLen];
            try {
                in.readFully(rec);
            } catch (EOFException e) {
                return false;
            }
            boolean deleted = rec[0] == '*';
            int pos = 1;
            for (int i = 0; i < names.size(); i++) {
                int len = lens.get(i);
                if (types.get(i) == 'M' || types.get(i) == 'B' || types.get(i) == 'G') {
                    vals[i] = "";
                } else {
                    vals[i] = new String(rec, pos, len, cs).trim();
                    int z = vals[i].indexOf('\0');
                    if (z >= 0) vals[i] = vals[i].substring(0, z).trim();
                    if (types.get(i) == 'D' && vals[i].length() == 8)
                        vals[i] = vals[i].substring(0, 4) + "-" + vals[i].substring(4, 6) + "-" + vals[i].substring(6);
                    if (types.get(i) == 'L') vals[i] = vals[i].equals("T") || vals[i].equals("t") || vals[i].equals("Y") ? "true"
                            : vals[i].equals("F") || vals[i].equals("f") || vals[i].equals("N") ? "false" : "";
                }
                pos += len;
            }
            vals[vals.length - 1] = deleted ? "1" : "0";
            return true;
        }
    }

    private static Charset charsetFor(String cpg, byte[] sample) {
        if (cpg != null) {
            String c = cpg.trim().toUpperCase(Locale.ROOT);
            try {
                if (c.equals("1256") || c.equals("CP1256") || c.equals("WINDOWS-1256")) return Charset.forName("windows-1256");
                if (c.equals("UTF-8") || c.equals("UTF8") || c.equals("65001")) return StandardCharsets.UTF_8;
                if (c.contains("1252")) return Charset.forName("windows-1252");
                if (c.contains("8859")) return Charset.forName("ISO-8859-1");
                return Charset.forName(cpg.trim());
            } catch (Exception ignored) {
                // unknown name: detect below
            }
        }
        try {
            StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(sample));
            return StandardCharsets.UTF_8;
        } catch (CharacterCodingException e) {
            return Charset.forName("windows-1256"); // Arabic legacy code page used by most Iraqi GIS data
        }
    }

    private static Dbf openDbf(ZipFile z, String path, String cpgText) throws IOException {
        ZipEntry e = find(z, path, ".dbf");
        if (e == null) return null;
        Dbf d = new Dbf();
        // pass 1: sample for charset detection
        byte[] all = new byte[0];
        InputStream s1 = z.getInputStream(e);
        try {
            all = readAll(s1, 1 << 20);
        } finally {
            // readAll closes
        }
        if (all.length < 33) return null;
        ByteBuffer b = ByteBuffer.wrap(all).order(ByteOrder.LITTLE_ENDIAN);
        d.count = b.getInt(4) & 0xFFFFFFFFL;
        d.headerLen = b.getShort(8) & 0xFFFF;
        d.recLen = b.getShort(10) & 0xFFFF;
        int p = 32;
        while (p + 32 <= d.headerLen && all[p] != 0x0D) {
            int nl = 0;
            while (nl < 11 && all[p + nl] != 0) nl++;
            d.names.add(new String(all, p, nl, StandardCharsets.ISO_8859_1).trim());
            d.types.add((char) all[p + 11]);
            d.lens.add(all[p + 16] & 0xFF);
            d.decs.add(all[p + 17] & 0xFF);
            p += 32;
        }
        // sample of the text bytes of the first records
        ByteArrayOutputStream sample = new ByteArrayOutputStream();
        for (int r = 0; r < Math.min(d.count, 400); r++) {
            int off = d.headerLen + r * d.recLen;
            if (off + d.recLen > all.length) break;
            sample.write(all, off, d.recLen);
        }
        d.cs = charsetFor(cpgText, sample.toByteArray());
        d.in = new DataInputStream(new BufferedInputStream(z.getInputStream(e), 1 << 16));
        d.in.skipBytes(d.headerLen);
        return d;
    }

    // ------------------------------------------------------------------ shp

    /**
     * Visits every record of one shapefile (coordinates in the file CRS). Deleted dbf records and null shapes are
     * counted in info.messages and skipped.
     */
    public static void read(File zip, Item it, Visitor v, ReadInfo info) throws IOException {
        ZipFile z = new ZipFile(zip);
        try {
            ZipEntry shp = find(z, it.path, ".shp");
            if (shp == null) throw new IOException("missing .shp");
            ZipEntry cpgE = find(z, it.path, ".cpg");
            String cpg = cpgE == null ? null : new String(readAll(z.getInputStream(cpgE), 256), StandardCharsets.UTF_8);
            Dbf dbf = openDbf(z, it.path, cpg);
            DataInputStream in = new DataInputStream(new BufferedInputStream(z.getInputStream(shp), 1 << 16));
            try {
                byte[] hd = new byte[100];
                in.readFully(hd);
                String[] vals = dbf == null ? null : new String[dbf.names.size() + 1];
                long rec = 0;
                byte[] hdr = new byte[8];
                while (!info.cancel) {
                    try {
                        in.readFully(hdr);
                    } catch (EOFException e) {
                        break;
                    }
                    rec++;
                    ByteBuffer rh = ByteBuffer.wrap(hdr).order(ByteOrder.BIG_ENDIAN);
                    int words = rh.getInt(4);
                    int len = words * 2;
                    if (len < 4 || len > (1 << 28)) {
                        info.unreadable++;
                        info.messages.add(S.t("سجل " + rec + ": طول غير صالح، توقفت القراءة", "Record " + rec + ": bad length, reading stopped"));
                        break;
                    }
                    byte[] body = new byte[len];
                    in.readFully(body);
                    boolean haveRow = dbf != null && dbf.next(vals);
                    if (haveRow && "1".equals(vals[vals.length - 1])) continue; // deleted in dbf
                    ByteBuffer bb = ByteBuffer.wrap(body).order(ByteOrder.LITTLE_ENDIAN);
                    int type = bb.getInt(0);
                    Feature f;
                    try {
                        f = geometry(bb, type, rec, info);
                    } catch (RuntimeException ex) {
                        info.unreadable++;
                        if (info.messages.size() < 200) info.messages.add(S.t("سجل " + rec + ": هندسة تالفة", "Record " + rec + ": damaged geometry"));
                        continue;
                    }
                    if (f == null) {
                        info.unreadable++;
                        if (info.messages.size() < 200)
                            info.messages.add(S.t("سجل " + rec + ": بلا هندسة", "Record " + rec + ": no geometry"));
                        continue;
                    }
                    if (haveRow) {
                        Map<String, String> props = new LinkedHashMap<>();
                        for (int i = 0; i < dbf.names.size(); i++) props.put(dbf.names.get(i), vals[i]);
                        Mapper.apply(f, props);
                    }
                    if (f.id.isEmpty()) f.id = Feature.newId();
                    if (!v.feature(it.name, f)) break;
                }
            } finally {
                in.close();
                if (dbf != null) dbf.in.close();
            }
        } finally {
            z.close();
        }
    }

    private static Feature geometry(ByteBuffer b, int type, long rec, ReadInfo info) {
        int base = type % 10; // 1 point, 3 polyline, 5 polygon, 8 multipoint (also Z=+10, M=+20)
        if (type == 0) return null;
        Feature f = new Feature();
        if (base == 1) {
            double x = b.getDouble(4), y = b.getDouble(12);
            if (Double.isNaN(x) || Double.isNaN(y)) return null;
            f.geom = Feature.POINT;
            f.parts.add(new double[]{x, y});
            f.holes.add(Boolean.FALSE);
            f.lon = x;
            f.lat = y;
            return f;
        }
        if (base == 8) {
            int n = b.getInt(36);
            if (n <= 0) return null;
            double x = b.getDouble(40), y = b.getDouble(48);
            f.geom = Feature.POINT;
            f.parts.add(new double[]{x, y});
            f.holes.add(Boolean.FALSE);
            f.lon = x;
            f.lat = y;
            if (n > 1 && info.warnings.size() < 5)
                info.warnings.add(S.t("سجلات MultiPoint: أُخذت أول نقطة فقط", "MultiPoint records: only the first point was kept"));
            return f;
        }
        if (base != 3 && base != 5) {
            if (info.warnings.size() < 5)
                info.warnings.add(S.t("نوع هندسة غير مدعوم: " + type, "Unsupported shape type: " + type));
            return null;
        }
        int np = b.getInt(36), nn = b.getInt(40);
        if (np < 0 || nn < 0 || nn > (1 << 26)) throw new IllegalArgumentException("counts");
        int partsOff = 44, ptsOff = 44 + 4 * np;
        int[] starts = new int[np + 1];
        for (int i = 0; i < np; i++) starts[i] = b.getInt(partsOff + 4 * i);
        starts[np] = nn;
        f.geom = base == 3 ? Feature.LINE : Feature.POLYGON;
        List<double[]> rings = new ArrayList<>();
        for (int i = 0; i < np; i++) {
            int a = starts[i], e = starts[i + 1];
            if (e <= a) continue;
            double[] c = new double[(e - a) * 2];
            for (int k = 0; k < e - a; k++) {
                c[2 * k] = b.getDouble(ptsOff + 16 * (a + k));
                c[2 * k + 1] = b.getDouble(ptsOff + 16 * (a + k) + 8);
            }
            rings.add(c);
        }
        if (rings.isEmpty()) return null;
        if (base == 3) {
            for (double[] r : rings) if (r.length >= 4) f.addPart(r, false);
            if (f.parts.isEmpty()) return null;
        } else {
            boolean anyCw = false;
            for (double[] r : rings) if (Geo.signedArea(r) < 0) anyCw = true;
            for (double[] r : rings) {
                if (r.length < 6) continue;
                if (r[0] != r[r.length - 2] || r[1] != r[r.length - 1]) {
                    r = java.util.Arrays.copyOf(r, r.length + 2);
                    r[r.length - 2] = r[0];
                    r[r.length - 1] = r[1];
                }
                boolean cw = Geo.signedArea(r) < 0;
                // standard: clockwise = outer. Files with no clockwise ring at all use the opposite convention.
                boolean hole = anyCw ? !cw : false;
                f.addPart(Geo.oriented(r, !hole), hole);
            }
            if (f.parts.isEmpty()) return null;
        }
        Geo.setRepresentative(f);
        return f;
    }
}
