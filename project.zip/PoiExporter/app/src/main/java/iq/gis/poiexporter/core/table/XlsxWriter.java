package iq.gis.poiexporter.core.table;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Streaming .xlsx writer (inline strings, real numeric cells). Starts a new sheet after maxRows data rows, so any
 * number of rows can be written with constant memory. Opens in Excel, LibreOffice and Google Sheets.
 */
public final class XlsxWriter {
    public static final int DEFAULT_MAX_ROWS = 1000000;

    private final ZipOutputStream zip;
    private final boolean rtl;
    private final int maxRows;
    private final String baseName;
    private Writer w;
    private List<String> header = new ArrayList<>();
    private final List<String> sheetNames = new ArrayList<>();
    private int rowInSheet;
    private boolean closed;
    private final StringBuilder sb = new StringBuilder(512);

    public XlsxWriter(OutputStream os, String sheetName, boolean rtl, int maxRows) {
        this.zip = new ZipOutputStream(os);
        this.rtl = rtl;
        this.maxRows = Math.max(1, maxRows);
        this.baseName = sheetName == null || sheetName.trim().isEmpty() ? "Sheet" : sheetName.replaceAll("[\\[\\]:*?/\\\\]", "_");
    }

    public void header(List<String> cols) throws IOException {
        header = new ArrayList<>(cols);
        startSheet();
    }

    private void startSheet() throws IOException {
        endSheet();
        String nm = sheetNames.isEmpty() ? baseName : baseName + "_" + (sheetNames.size() + 1);
        if (nm.length() > 31) nm = nm.substring(0, 31 - (sheetNames.isEmpty() ? 0 : 3)) + (sheetNames.isEmpty() ? "" : "_" + (sheetNames.size() + 1));
        sheetNames.add(nm);
        zip.putNextEntry(new ZipEntry("xl/worksheets/sheet" + sheetNames.size() + ".xml"));
        w = new OutputStreamWriter(zip, Charset.forName("UTF-8")) {
            @Override
            public void close() throws IOException {
                flush();
            }
        };
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<sheetViews><sheetView workbookViewId=\"0\"" + (rtl ? " rightToLeft=\"1\"" : "")
                + "><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><sheetData>");
        rowInSheet = 0;
        writeRow(new ArrayList<Object>(header), true);
    }

    /** Cells: String, Number (written as numbers), null (empty). */
    public void row(Object[] cells) throws IOException {
        if (w == null) startSheet();
        if (rowInSheet >= maxRows + 1) startSheet();
        List<Object> l = new ArrayList<>(cells.length);
        for (Object o : cells) l.add(o);
        writeRow(l, false);
    }

    private void writeRow(List<Object> cells, boolean head) throws IOException {
        rowInSheet++;
        sb.setLength(0);
        sb.append("<row r=\"").append(rowInSheet).append("\">");
        for (int i = 0; i < cells.size(); i++) {
            Object o = cells.get(i);
            if (o == null) continue;
            sb.append("<c r=\"").append(col(i)).append(rowInSheet).append('"');
            if (o instanceof Number) {
                double d = ((Number) o).doubleValue();
                if (Double.isNaN(d) || Double.isInfinite(d)) {
                    sb.append("/>");
                    continue;
                }
                sb.append("><v>");
                if (o instanceof Double || o instanceof Float) sb.append(num(d));
                else sb.append(((Number) o).longValue());
                sb.append("</v></c>");
            } else {
                sb.append(head ? " s=\"1\"" : "").append(" t=\"inlineStr\"><is><t xml:space=\"preserve\">");
                esc(String.valueOf(o), sb);
                sb.append("</t></is></c>");
            }
        }
        sb.append("</row>");
        w.write(sb.toString());
    }

    private static String num(double d) {
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return Long.toString((long) d);
        return Double.toString(d);
    }

    static String col(int i) {
        StringBuilder s = new StringBuilder();
        i++;
        while (i > 0) {
            int m = (i - 1) % 26;
            s.insert(0, (char) ('A' + m));
            i = (i - 1) / 26;
        }
        return s.toString();
    }

    private static void esc(String s, StringBuilder b) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '&') b.append("&amp;");
            else if (c == '<') b.append("&lt;");
            else if (c == '>') b.append("&gt;");
            else if (c == '"') b.append("&quot;");
            else if (c < 0x20 && c != '\t' && c != '\n' && c != '\r' || c == 0xFFFE || c == 0xFFFF) continue;
            else b.append(c);
        }
    }

    private void endSheet() throws IOException {
        if (w == null) return;
        w.write("</sheetData></worksheet>");
        w.flush();
        zip.closeEntry();
        w = null;
    }

    /** Finishes the file (writes workbook parts). Does not close the underlying stream's owner semantics: it closes it. */
    public void close() throws IOException {
        if (closed) return;
        closed = true;
        if (sheetNames.isEmpty() && w == null) startSheet();
        endSheet();
        StringBuilder ct = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        for (int i = 1; i <= sheetNames.size(); i++)
            ct.append("<Override PartName=\"/xl/worksheets/sheet").append(i).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        ct.append("</Types>");
        put("[Content_Types].xml", ct.toString());
        put("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        StringBuilder wb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        StringBuilder rels = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (int i = 0; i < sheetNames.size(); i++) {
            StringBuilder n = new StringBuilder();
            esc(sheetNames.get(i), n);
            wb.append("<sheet name=\"").append(n).append("\" sheetId=\"").append(i + 1).append("\" r:id=\"rId").append(i + 1).append("\"/>");
            rels.append("<Relationship Id=\"rId").append(i + 1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i + 1).append(".xml\"/>");
        }
        wb.append("</sheets></workbook>");
        rels.append("<Relationship Id=\"rId").append(sheetNames.size() + 1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
        put("xl/workbook.xml", wb.toString());
        put("xl/_rels/workbook.xml.rels", rels.toString());
        put("xl/styles.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>"
                + "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
        zip.finish();
        zip.close();
    }

    private void put(String name, String content) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(content.getBytes("UTF-8"));
        zip.closeEntry();
    }
}
