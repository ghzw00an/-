package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Turns layers into source code: GeoJSON, WKT, CSV, Leaflet page, Python, PostGIS SQL and R. */
public final class CodeGen {
    private CodeGen() {
    }

    public static final String[] LANGS = {"GeoJSON", "WKT", "CSV", "Leaflet (HTML)", "Python (geopandas)", "Python (folium)", "PostGIS (SQL)", "R (sf)"};
    public static final String[] EXT = {"geojson", "wkt", "csv", "html", "py", "py", "sql", "R"};

    public static String generate(int lang, List<LayerData> layers) {
        switch (lang) {
            case 0: return geoJson(layers);
            case 1: return wkt(layers);
            case 2: return csv(layers);
            case 3: return leaflet(layers);
            case 4: return geopandas(layers);
            case 5: return folium(layers);
            case 6: return postgis(layers);
            default: return rsf(layers);
        }
    }

    // ---------------------------------------------------------------- helpers

    static String num(double v) {
        String s = String.format(Locale.US, "%.7f", v);
        int e = s.length();
        while (e > 0 && s.charAt(e - 1) == '0') e--;
        if (e > 0 && s.charAt(e - 1) == '.') e--;
        return s.substring(0, e);
    }

    public static String jsonStr(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                case '<': b.append("\\u003c"); break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        return b.append('"').toString();
    }

    static String sqlStr(String s) {
        return "'" + s.replace("'", "''") + "'";
    }

    static String pyStr(String s) {
        return "\"\"\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"\"\"";
    }

    static List<String[]> props(Feature f, LayerData l) {
        List<String[]> p = new ArrayList<>();
        p.add(new String[]{"name", f.name});
        p.add(new String[]{"type", f.type});
        p.add(new String[]{"Gategory", f.category});
        p.add(new String[]{"gathaa", f.qadaa});
        p.add(new String[]{"Nahia", f.nahiya});
        p.add(new String[]{"mohafadha", f.governorate});
        if (!f.nameEn.isEmpty()) p.add(new String[]{"name_en", f.nameEn});
        for (java.util.Map.Entry<String, String> e : f.attrs.entrySet())
            p.add(new String[]{e.getKey(), e.getValue()});
        p.add(new String[]{"layer", l.label});
        return p;
    }

    /** Rings grouped into polygons: each outer ring followed by its holes. */
    static List<List<double[]>> polygons(Feature f) {
        List<List<double[]>> out = new ArrayList<>();
        for (int i = 0; i < f.parts.size(); i++) {
            if (!f.isHole(i) || out.isEmpty()) out.add(new ArrayList<>());
            out.get(out.size() - 1).add(f.parts.get(i));
        }
        return out;
    }

    static String coords(double[] p, boolean closeRing) {
        StringBuilder b = new StringBuilder("[");
        int n = p.length / 2;
        for (int i = 0; i < n; i++) {
            if (i > 0) b.append(',');
            b.append('[').append(num(p[2 * i])).append(',').append(num(p[2 * i + 1])).append(']');
        }
        if (closeRing && n > 0 && (p[0] != p[2 * n - 2] || p[1] != p[2 * n - 1]))
            b.append(",[").append(num(p[0])).append(',').append(num(p[1])).append(']');
        return b.append(']').toString();
    }

    static String geomJson(Feature f) {
        if (f.geom == Feature.POINT) {
            double[] p = f.parts.get(0);
            return "{\"type\":\"Point\",\"coordinates\":[" + num(p[0]) + "," + num(p[1]) + "]}";
        }
        if (f.geom == Feature.LINE) {
            if (f.parts.size() == 1) return "{\"type\":\"LineString\",\"coordinates\":" + coords(f.parts.get(0), false) + "}";
            StringBuilder b = new StringBuilder("{\"type\":\"MultiLineString\",\"coordinates\":[");
            for (int i = 0; i < f.parts.size(); i++) b.append(i > 0 ? "," : "").append(coords(f.parts.get(i), false));
            return b.append("]}").toString();
        }
        List<List<double[]>> pg = polygons(f);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < pg.size(); i++) {
            if (i > 0) b.append(',');
            b.append('[');
            for (int j = 0; j < pg.get(i).size(); j++) b.append(j > 0 ? "," : "").append(coords(pg.get(i).get(j), true));
            b.append(']');
        }
        if (pg.size() == 1) return "{\"type\":\"Polygon\",\"coordinates\":" + b + "}";
        return "{\"type\":\"MultiPolygon\",\"coordinates\":[" + b + "]}";
    }

    static String wktCoords(double[] p, boolean closeRing) {
        StringBuilder b = new StringBuilder("(");
        int n = p.length / 2;
        for (int i = 0; i < n; i++) b.append(i > 0 ? ", " : "").append(num(p[2 * i])).append(' ').append(num(p[2 * i + 1]));
        if (closeRing && n > 0 && (p[0] != p[2 * n - 2] || p[1] != p[2 * n - 1]))
            b.append(", ").append(num(p[0])).append(' ').append(num(p[1]));
        return b.append(')').toString();
    }

    public static String wktOf(Feature f) {
        if (f.parts.isEmpty()) return "GEOMETRYCOLLECTION EMPTY";
        if (f.geom == Feature.POINT) {
            double[] p = f.parts.get(0);
            return "POINT (" + num(p[0]) + " " + num(p[1]) + ")";
        }
        if (f.geom == Feature.LINE) {
            if (f.parts.size() == 1) return "LINESTRING " + wktCoords(f.parts.get(0), false);
            StringBuilder b = new StringBuilder("MULTILINESTRING (");
            for (int i = 0; i < f.parts.size(); i++) b.append(i > 0 ? ", " : "").append(wktCoords(f.parts.get(i), false));
            return b.append(')').toString();
        }
        List<List<double[]>> pg = polygons(f);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < pg.size(); i++) {
            b.append(i > 0 ? ", " : "").append('(');
            for (int j = 0; j < pg.get(i).size(); j++) b.append(j > 0 ? ", " : "").append(wktCoords(pg.get(i).get(j), true));
            b.append(')');
        }
        return pg.size() == 1 ? "POLYGON " + b : "MULTIPOLYGON (" + b + ")";
    }

    // ---------------------------------------------------------------- GeoJSON

    public static String geoJson(List<LayerData> layers) {
        StringBuilder b = new StringBuilder("{\"type\":\"FeatureCollection\",\"features\":[\n");
        boolean first = true;
        for (LayerData l : layers) for (Feature f : l.features) {
            if (f.parts.isEmpty()) continue;
            if (!first) b.append(",\n");
            first = false;
            b.append("{\"type\":\"Feature\",\"properties\":{");
            boolean fp = true;
            for (String[] kv : props(f, l)) {
                if (!fp) b.append(',');
                fp = false;
                b.append(jsonStr(kv[0])).append(':').append(jsonStr(kv[1] == null ? "" : kv[1]));
            }
            b.append("},\"geometry\":").append(geomJson(f)).append('}');
        }
        return b.append("\n]}\n").toString();
    }

    // ---------------------------------------------------------------- WKT and CSV

    public static String wkt(List<LayerData> layers) {
        StringBuilder b = new StringBuilder();
        for (LayerData l : layers) for (Feature f : l.features) if (!f.parts.isEmpty()) b.append(wktOf(f)).append('\n');
        return b.toString();
    }

    static String csvCell(String s) {
        if (s == null) return "";
        if (s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0) return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }

    public static String csv(List<LayerData> layers) {
        StringBuilder b = new StringBuilder("wkt,name,type,Gategory,gathaa,Nahia,mohafadha,layer\n");
        for (LayerData l : layers) for (Feature f : l.features) {
            if (f.parts.isEmpty()) continue;
            b.append(csvCell(wktOf(f))).append(',').append(csvCell(f.name)).append(',').append(csvCell(f.type)).append(',')
                    .append(csvCell(f.category)).append(',').append(csvCell(f.qadaa)).append(',').append(csvCell(f.nahiya)).append(',')
                    .append(csvCell(f.governorate)).append(',').append(csvCell(l.label)).append('\n');
        }
        return b.toString();
    }

    // ---------------------------------------------------------------- Leaflet

    public static String leaflet(List<LayerData> layers) {
        StringBuilder b = new StringBuilder();
        b.append("<!doctype html>\n<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n")
                .append("<title>Map</title>\n<link rel=\"stylesheet\" href=\"https://unpkg.com/leaflet@1.9.4/dist/leaflet.css\">\n")
                .append("<script src=\"https://unpkg.com/leaflet@1.9.4/dist/leaflet.js\"></script>\n")
                .append("<style>html,body,#map{height:100%;margin:0}</style></head>\n<body><div id=\"map\"></div>\n<script>\n")
                .append("var map = L.map('map');\n")
                .append("L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 19, attribution: '&copy; OpenStreetMap contributors'}).addTo(map);\n")
                .append("var all = L.featureGroup().addTo(map);\n")
                .append("function popup(f, l) { var p = f.properties, h = ''; for (var k in p) if (p[k]) h += '<b>' + k + '</b>: ' + String(p[k]).replace(/</g, '&lt;') + '<br>'; l.bindPopup(h); }\n");
        int i = 0;
        for (LayerData l : layers) {
            if (l.features.isEmpty()) continue;
            List<LayerData> one = new ArrayList<>();
            one.add(l);
            String color = l.color != 0 ? String.format("#%06x", l.color & 0xFFFFFF) : "#d4a017";
            b.append("var layer").append(i).append(" = L.geoJSON(").append(geoJson(one).trim())
                    .append(", {style: {color: '").append(color).append("', weight: 2}, onEachFeature: popup}).addTo(all);\n");
            i++;
        }
        b.append("if (all.getLayers().length) map.fitBounds(all.getBounds()); else map.setView([33.3, 44.4], 6);\n");
        if (i > 1) {
            b.append("L.control.layers(null, {");
            int k = 0;
            for (LayerData l : layers) {
                if (l.features.isEmpty()) continue;
                b.append(k > 0 ? ", " : "").append(jsonStr(l.label)).append(": layer").append(k);
                k++;
            }
            b.append("}).addTo(map);\n");
        }
        return b.append("</script></body></html>\n").toString();
    }

    // ---------------------------------------------------------------- Python

    public static String geopandas(List<LayerData> layers) {
        StringBuilder b = new StringBuilder("import geopandas as gpd\nfrom shapely import wkt\n\n");
        int i = 0;
        for (LayerData l : layers) {
            if (l.features.isEmpty()) continue;
            b.append("# ").append(l.label.replace('\n', ' ')).append('\n');
            b.append("rows").append(i).append(" = [\n");
            for (Feature f : l.features) {
                if (f.parts.isEmpty()) continue;
                b.append("    {\"geometry\": wkt.loads(\"").append(wktOf(f)).append("\")");
                for (String[] kv : props(f, l)) b.append(", ").append(jsonStr(kv[0])).append(": ").append(jsonStr(kv[1] == null ? "" : kv[1]));
                b.append("},\n");
            }
            b.append("]\ngdf").append(i).append(" = gpd.GeoDataFrame(rows").append(i).append(", geometry=\"geometry\", crs=\"EPSG:4326\")\n\n");
            i++;
        }
        if (i > 0) {
            b.append("# save: gdf0.to_file(\"layer0.gpkg\", driver=\"GPKG\")   # or .to_file(\"layer0.shp\")\n");
            b.append("# utm = gdf0.to_crs(gdf0.estimate_utm_crs())\n");
        }
        return b.toString();
    }

    public static String folium(List<LayerData> layers) {
        StringBuilder b = new StringBuilder("import folium\nimport json\n\nm = folium.Map(location=[33.3, 44.4], zoom_start=6)\n");
        int i = 0;
        for (LayerData l : layers) {
            if (l.features.isEmpty()) continue;
            List<LayerData> one = new ArrayList<>();
            one.add(l);
            b.append("data").append(i).append(" = json.loads(r'''").append(geoJson(one).replace("'''", "")).append("''')\n");
            b.append("folium.GeoJson(data").append(i).append(", name=").append(jsonStr(l.label))
                    .append(", tooltip=folium.GeoJsonTooltip(fields=[\"name\", \"type\"])).add_to(m)\n");
            i++;
        }
        b.append("folium.LayerControl().add_to(m)\nm.save(\"map.html\")\n");
        return b.toString();
    }

    // ---------------------------------------------------------------- SQL and R

    public static String postgis(List<LayerData> layers) {
        StringBuilder b = new StringBuilder("CREATE EXTENSION IF NOT EXISTS postgis;\n\n")
                .append("CREATE TABLE IF NOT EXISTS landmarks (\n  id serial PRIMARY KEY,\n  layer text,\n  name text,\n  type text,\n  \"Gategory\" text,\n  gathaa text,\n  \"Nahia\" text,\n  mohafadha text,\n  geom geometry(Geometry, 4326)\n);\n\n");
        for (LayerData l : layers) for (Feature f : l.features) {
            if (f.parts.isEmpty()) continue;
            b.append("INSERT INTO landmarks (layer, name, type, \"Gategory\", gathaa, \"Nahia\", mohafadha, geom) VALUES (")
                    .append(sqlStr(l.label)).append(", ").append(sqlStr(f.name)).append(", ").append(sqlStr(f.type)).append(", ")
                    .append(sqlStr(f.category)).append(", ").append(sqlStr(f.qadaa)).append(", ").append(sqlStr(f.nahiya)).append(", ")
                    .append(sqlStr(f.governorate)).append(", ST_GeomFromText('").append(wktOf(f)).append("', 4326));\n");
        }
        return b.append("\nCREATE INDEX IF NOT EXISTS landmarks_geom_idx ON landmarks USING gist (geom);\n").toString();
    }

    public static String rsf(List<LayerData> layers) {
        StringBuilder b = new StringBuilder("library(sf)\n\nd <- data.frame(\n");
        StringBuilder nm = new StringBuilder(), ty = new StringBuilder(), ct = new StringBuilder(), gt = new StringBuilder(),
                nh = new StringBuilder(), gv = new StringBuilder(), wk = new StringBuilder();
        boolean first = true;
        for (LayerData l : layers) for (Feature f : l.features) {
            if (f.parts.isEmpty()) continue;
            String sep = first ? "" : ",\n    ";
            first = false;
            nm.append(sep).append(jsonStr(f.name));
            ty.append(sep).append(jsonStr(f.type));
            ct.append(sep).append(jsonStr(f.category));
            gt.append(sep).append(jsonStr(f.qadaa));
            nh.append(sep).append(jsonStr(f.nahiya));
            gv.append(sep).append(jsonStr(f.governorate));
            wk.append(sep).append(jsonStr(wktOf(f)));
        }
        b.append("  name = c(").append(nm).append("),\n  type = c(").append(ty).append("),\n  Gategory = c(").append(ct)
                .append("),\n  gathaa = c(").append(gt).append("),\n  Nahia = c(").append(nh).append("),\n  mohafadha = c(").append(gv)
                .append("),\n  wkt = c(").append(wk).append("),\n  stringsAsFactors = FALSE\n)\n")
                .append("layer <- st_as_sf(d, wkt = \"wkt\", crs = 4326)\nplot(st_geometry(layer))\n")
                .append("# st_write(layer, \"layer.gpkg\")\n");
        return b.toString();
    }
}
