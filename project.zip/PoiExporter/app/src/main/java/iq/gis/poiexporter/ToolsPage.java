package iq.gis.poiexporter;

import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.admin.AdminRef;
import iq.gis.poiexporter.core.geo.AreaTools;
import iq.gis.poiexporter.core.geo.GeoOps;
import iq.gis.poiexporter.core.geo.Geodesy;
import iq.gis.poiexporter.core.geo.Measure;
import iq.gis.poiexporter.core.geo.Topology;

/** Area and spatial tools. Every result is a new layer in the project, so it can be undone from the layer manager. */
final class ToolsPage {
    private final MainActivity a;
    private int layerIdx, modeIdx, unitIdx;

    ToolsPage(MainActivity a) {
        this.a = a;
    }

    private List<LayerData> candidates() {
        List<LayerData> r = new ArrayList<>(MainActivity.WS.layers());
        r.addAll(MainActivity.DL);
        return r;
    }

    private int tab;

    /** Tabs: basic tools, analysis, generate, two layers, bulk edit, measure. */
    View build() {
        LinearLayout root = UiKit.col(a);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(a);
        String[] labels = {S.t("أساسية", "Basic"), S.t("تحليل", "Analysis"), S.t("توليد", "Generate"), S.t("طبقتان", "Two layers"),
                S.t("تحرير جماعي", "Bulk edit"), S.t("📐 قياس", "📐 Measure")};
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            android.widget.TextView ch = Ui.chip(a, labels[i]);
            Ui.setChip(ch, i == tab);
            ch.setOnClickListener(v -> {
                if (idx == 5) {
                    a.measure.start(a.mapRoot);
                    return;
                }
                tab = idx;
                a.showPage("tools");
            });
            chips.addView(ch, Ui.lp(-2, -2, 0, a, 3, 4, 3, 4));
        }
        hs.addView(chips);
        root.addView(hs);
        root.addView(tab == 0 ? basic() : a.analysis.build(tab));
        return root;
    }

    private View basic() {
        final LinearLayout p = UiKit.col(a);
        final List<LayerData> ls = candidates();
        LinearLayout pick = Ui.card(a);
        pick.addView(UiKit.head(a, S.t("الطبقة", "Layer")));
        if (ls.isEmpty()) {
            pick.addView(UiKit.note(a, S.t("لا توجد طبقات. أضف معالم أو نزّل بيانات أو أضف حدوداً إدارية أولاً.", "No layers yet.")));
            p.addView(pick);
            return p;
        }
        List<String> names = new ArrayList<>();
        for (LayerData l : ls) names.add(l.label + "  (" + l.features.size() + ")");
        if (layerIdx >= ls.size()) layerIdx = 0;
        final Spinner sp = ConverterPage.spinner(a, names, layerIdx);
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> parent, View v, int pos, long id) {
                layerIdx = pos;
            }

            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });
        pick.addView(sp);
        p.addView(pick);

        final AreaSpec area = a.area();
        LinearLayout ar = Ui.card(a);
        ar.addView(UiKit.head(a, S.t("المنطقة المحددة", "Selected area")));
        ar.addView(UiKit.note(a, String.format(java.util.Locale.US, "%.3f km²  •  %.0f × %.0f m", area.areaKm2(), area.widthM(), area.heightM())));
        final Spinner ms = ConverterPage.spinner(a, java.util.Arrays.asList(S.t("داخل المنطقة (دون الحافة)", "Inside (not touching the edge)"),
                S.t("داخل مع الحافة", "Inside, edge allowed"), S.t("يمسّ المنطقة", "Touches the area")), modeIdx);
        ms.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> parent, View v, int pos, long id) {
                modeIdx = pos;
            }

            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });
        ar.addView(ms);
        ar.addView(Ui.button(a, S.t("استخراج ما داخل المنطقة", "Extract inside the area"), true, () -> run(() -> {
            LayerData src = ls.get(layerIdx);
            GeoOps.Mode m = modeIdx == 0 ? GeoOps.Mode.INSIDE : modeIdx == 1 ? GeoOps.Mode.BOUNDARY_INCLUDED : GeoOps.Mode.INTERSECTS;
            return AreaTools.extract(src, area, m, src.label + S.t(" (داخل المنطقة)", " (in area)"));
        })), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        ar.addView(Ui.button(a, S.t("قص الطبقة بحدود المنطقة", "Clip the layer to the area"), false, () -> run(() -> {
            LayerData src = ls.get(layerIdx);
            LayerData c = GeoOps.clip(src, AreaTools.polygon(area), true);
            c.label = src.label + S.t(" (مقصوصة)", " (clipped)");
            return c;
        })), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(ar);

        final AdminRef ref = AdminRef.get();
        if (ref != null) {
            LinearLayout ad = Ui.card(a);
            ad.addView(UiKit.head(a, S.t("القص بحدود إدارية (غير رسمية)", "Clip by an administrative unit (unofficial)")));
            final List<AdminRef.Unit> units = new ArrayList<>(ref.units(1));
            units.addAll(ref.units(2));
            List<String> un = new ArrayList<>();
            for (AdminRef.Unit u : units) un.add((u.level == 1 ? S.t("محافظة ", "Gov. ") : S.t("قضاء ", "Dist. ")) + u.name(S.ar)
                    + (u.level == 2 ? " — " + u.parent(S.ar) : ""));
            final Spinner us = ConverterPage.spinner(a, un, unitIdx);
            us.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                public void onItemSelected(android.widget.AdapterView<?> parent, View v, int pos, long id) {
                    unitIdx = pos;
                }

                public void onNothingSelected(android.widget.AdapterView<?> parent) {
                }
            });
            ad.addView(us);
            ad.addView(Ui.button(a, S.t("قص الطبقة بهذه الوحدة", "Clip the layer by this unit"), false, () -> run(() -> {
                LayerData src = ls.get(layerIdx);
                AdminRef.Unit u = units.get(unitIdx);
                LayerData c = GeoOps.clip(src, u.poly, true);
                c.label = src.label + " — " + u.name(S.ar);
                return c;
            })), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
            ad.addView(UiKit.note(a, ref.accuracyNote(S.ar)));
            p.addView(ad);
        }

        LinearLayout ops = Ui.card(a);
        ops.addView(UiKit.head(a, S.t("عمليات على الطبقة", "Layer operations")));
        final EditText dist = Ui.field(a, S.t("مسافة الحاجز بالمتر (Buffer)", "Buffer distance in metres"), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        dist.setText("100");
        ops.addView(dist);
        ops.addView(Ui.button(a, S.t("إنشاء حاجز (Buffer)", "Create buffer"), false, () -> run(() -> {
            LayerData src = ls.get(layerIdx);
            double d;
            try {
                d = Double.parseDouble(dist.getText().toString().trim());
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException(S.t("مسافة غير صالحة", "Invalid distance"));
            }
            if (src.features.size() > 5000) throw new IllegalArgumentException(S.t("أكثر من 5000 عنصر: صفّ الطبقة أولاً", "More than 5000 features: filter the layer first"));
            LayerData r = new LayerData("buf_" + Feature.newId(), src.label + S.t(" (حاجز ", " (buffer ") + dist.getText().toString().trim() + " m)", Feature.POLYGON);
            for (Feature f : src.features) {
                Feature b = GeoOps.buffer(f, d, 16);
                if (b == null) continue;
                b.id = Feature.newId();
                b.name = f.name;
                r.features.add(b);
            }
            return r;
        })), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        ops.addView(Ui.button(a, S.t("دمج المضلعات في مضلع واحد (Dissolve)", "Merge polygons into one (Dissolve)"), false, () -> run(() -> {
            LayerData src = ls.get(layerIdx);
            List<Feature> polys = new ArrayList<>();
            for (Feature f : src.features) if (f.geom == Feature.POLYGON) polys.add(f);
            if (polys.isEmpty()) throw new IllegalArgumentException(S.t("لا توجد مضلعات في الطبقة", "No polygons in the layer"));
            Feature u = GeoOps.union(polys);
            if (u == null) throw new IllegalArgumentException(S.t("نتيجة فارغة", "Empty result"));
            u.id = Feature.newId();
            u.name = src.label;
            LayerData r = new LayerData("merge_" + Feature.newId(), src.label + S.t(" (مدموجة)", " (merged)"), Feature.POLYGON);
            r.features.add(u);
            return r;
        })), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        ops.addView(Ui.button(a, S.t("الغلاف المحدّب (Convex hull)", "Convex hull"), false, () -> run(() -> {
            LayerData src = ls.get(layerIdx);
            Feature h = GeoOps.convexHull(src.features);
            if (h == null) throw new IllegalArgumentException(S.t("لا يمكن إنشاء غلاف", "Cannot build a hull"));
            h.id = Feature.newId();
            h.name = src.label;
            LayerData r = new LayerData("hull_" + Feature.newId(), src.label + S.t(" (غلاف)", " (hull)"), Feature.POLYGON);
            r.features.add(h);
            return r;
        })), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        ops.addView(Ui.button(a, S.t("إحصاءات الطبقة", "Layer statistics"), false, () -> stats(ls.get(layerIdx))), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        ops.addView(Ui.button(a, S.t("أقرب 5 عناصر لمركز الخريطة", "5 nearest features to the map centre"), false, () -> nearest(ls.get(layerIdx))),
                Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        ops.addView(Ui.button(a, S.t("فحص الطبولوجيا (تداخل، فجوات، تقاطع ذاتي)", "Topology check (overlaps, gaps, self-intersections)"), false, () -> topology(ls.get(layerIdx))),
                Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(ops);
        return p;
    }

    private interface Job {
        LayerData make();
    }

    /** Runs an operation off the UI thread and adds the result as a project layer. */
    private void run(final Job job) {
        a.toast(S.t("جارٍ التنفيذ…", "Working…"));
        new Thread(() -> {
            try {
                final LayerData r = job.make();
                a.runOnUiThread(() -> {
                    if (r.features.isEmpty()) {
                        a.message(S.t("النتيجة فارغة", "Empty result"), S.t("لم يُعثر على عناصر تطابق الشرط.", "No features matched."), null, null);
                        return;
                    }
                    LayerData added = MainActivity.WS.addLayerWithFeatures(r);
                    a.rebuild();
                    a.showMap();
                    a.zoomToLayer(added);
                    a.toast(S.t("أُنشئت طبقة: ", "Layer created: ") + added.label + " (" + added.features.size() + ")");
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> a.message(S.t("تعذّرت العملية", "Operation failed"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }

    private void stats(LayerData l) {
        int pts = 0, lines = 0, polys = 0;
        double len = 0, area = 0;
        for (Feature f : l.features) {
            if (f.geom == Feature.POINT) pts++;
            else if (f.geom == Feature.LINE) {
                lines++;
                len += Geodesy.length(f);
            } else {
                polys++;
                try {
                    area += Geodesy.area(f);
                } catch (RuntimeException ignored) {
                    // degenerate polygon
                }
            }
        }
        StringBuilder b = new StringBuilder();
        b.append(S.t("العناصر: ", "Features: ")).append(l.features.size()).append('\n');
        b.append(S.t("نقاط: ", "Points: ")).append(pts).append("   ").append(S.t("خطوط: ", "Lines: ")).append(lines).append("   ").append(S.t("مضلعات: ", "Polygons: ")).append(polys).append('\n');
        if (lines > 0) b.append(S.t("الطول الكلي: ", "Total length: ")).append(Measure.length(len, S.ar)).append('\n');
        if (polys > 0) b.append(S.t("المساحة الكلية: ", "Total area: ")).append(Measure.area(area, S.ar).all()).append('\n');
        int named = 0;
        for (Feature f : l.features) if (!f.name.isEmpty()) named++;
        b.append(S.t("بأسماء: ", "With names: ")).append(named).append(" / ").append(l.features.size());
        a.message(l.label, b.toString(), null, null);
    }

    private void nearest(LayerData l) {
        org.osmdroid.api.IGeoPoint c = a.map.getMapCenter();
        List<GeoOps.Hit> hits = GeoOps.nearest(l, c.getLatitude(), c.getLongitude(), 5);
        if (hits.isEmpty()) {
            a.toast(S.t("الطبقة فارغة", "Layer is empty"));
            return;
        }
        StringBuilder b = new StringBuilder();
        for (GeoOps.Hit h : hits) {
            b.append("• ").append(h.feature.name.isEmpty() ? S.t("(بدون اسم)", "(unnamed)") : h.feature.name).append(" — ")
                    .append(Measure.length(h.distanceM, S.ar)).append("  ").append(Math.round(h.bearingDeg)).append("°\n");
        }
        a.message(S.t("الأقرب إلى مركز الخريطة", "Nearest to the map centre"), b.toString().trim(), null, null);
    }

    private void topology(final LayerData l) {
        a.toast(S.t("جارٍ الفحص…", "Checking…"));
        new Thread(() -> {
            try {
                final Topology.Report r = Topology.report(l);
                final StringBuilder b = new StringBuilder();
                b.append(S.t("المضلعات: ", "Polygons: ")).append(r.polygons).append('\n');
                b.append(S.t("تداخلات: ", "Overlaps: ")).append(r.overlaps.size()).append("   ")
                        .append(S.t("فجوات: ", "Gaps: ")).append(r.gaps.size()).append('\n');
                b.append(S.t("تقاطعات ذاتية: ", "Self-intersections: ")).append(r.selfIntersections.size()).append("   ")
                        .append(S.t("مكررة: ", "Duplicates: ")).append(r.duplicates.size()).append("\n\n");
                int n = 0;
                List<Topology.Issue> all = new ArrayList<>();
                all.addAll(r.selfIntersections);
                all.addAll(r.duplicates);
                all.addAll(r.overlaps);
                all.addAll(r.gaps);
                for (Topology.Issue i : all) {
                    if (n++ >= 15) break;
                    b.append("• ").append(i.describe(S.ar)).append('\n');
                }
                if (all.size() > 15) b.append("…\n");
                final LayerData issues = new LayerData("topo_" + Feature.newId(), l.label + S.t(" (مشاكل)", " (issues)"), Feature.POLYGON);
                for (Topology.Issue i : all) {
                    if (i.geometry == null || i.geometry.geom != Feature.POLYGON) continue;
                    Feature f = i.geometry.copy();
                    f.id = Feature.newId();
                    f.name = i.describe(S.ar);
                    f.type = i.kind;
                    issues.features.add(f);
                }
                a.runOnUiThread(() -> {
                    if (issues.features.isEmpty()) {
                        a.message(S.t("نتيجة الفحص", "Check result"), all.isEmpty() ? S.t("لا توجد مشاكل.", "No problems found.") : b.toString(), null, null);
                    } else {
                        a.messageConfirm(S.t("نتيجة الفحص", "Check result"), b.toString(), S.t("إضافة المشاكل كطبقة", "Add problems as a layer"), () -> {
                            LayerData added = MainActivity.WS.addLayerWithFeatures(issues);
                            a.rebuild();
                            a.showMap();
                            a.zoomToLayer(added);
                        });
                    }
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> a.message(S.t("تعذّر الفحص", "Check failed"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }
}
