package iq.gis.poiexporter;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import iq.gis.poiexporter.core.raster.Georef;
import iq.gis.poiexporter.core.raster.TiffReader;

/**
 * Aerial / satellite images placed on the map. GeoTIFF is read in full by core.raster.TiffReader; ordinary pictures
 * (JPG, PNG, WebP, BMP, GIF) need a world file or bounds. Each image is stored once as a PNG of at most 2048 px on its
 * longest side (memory-safe on phones) with its four corner positions in a small JSON index.
 */
final class RasterStore {
    static final int MAX_SIDE = 2048;

    static final class Item {
        String id, name, note = "";
        double[] corners; // lon,lat of TL, TR, BR, BL
        int w, h;
        float opacity = 0.85f;
        boolean visible = true;
        int epsg;
    }

    /** An image that was read but has no placement yet. */
    static final class Pending {
        String name;
        Bitmap bitmap;
        int srcW, srcH;
        String note = "";
    }

    private final MainActivity a;
    final List<Item> items = new ArrayList<>();
    Pending pending;

    RasterStore(MainActivity a) {
        this.a = a;
        load();
    }

    private File dir() {
        File d = new File(a.getFilesDir(), "raster");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private void load() {
        File f = new File(dir(), "rasters.json");
        if (!f.isFile()) return;
        try (InputStream in = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            JSONArray arr = new JSONObject(bo.toString("UTF-8")).getJSONArray("items");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Item it = new Item();
                it.id = o.getString("id");
                it.name = o.optString("name", it.id);
                it.note = o.optString("note", "");
                it.w = o.optInt("w");
                it.h = o.optInt("h");
                it.opacity = (float) o.optDouble("opacity", 0.85);
                it.visible = o.optBoolean("visible", true);
                it.epsg = o.optInt("epsg");
                JSONArray c = o.getJSONArray("corners");
                it.corners = new double[8];
                for (int k = 0; k < 8; k++) it.corners[k] = c.getDouble(k);
                if (new File(dir(), it.id + ".png").isFile()) items.add(it);
            }
        } catch (Exception e) {
            ErrorLog.add("raster-load", e);
        }
    }

    void save() {
        try {
            JSONArray arr = new JSONArray();
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("id", it.id).put("name", it.name).put("note", it.note).put("w", it.w).put("h", it.h)
                        .put("opacity", it.opacity).put("visible", it.visible).put("epsg", it.epsg);
                JSONArray c = new JSONArray();
                for (double v : it.corners) c.put(v);
                o.put("corners", c);
                arr.put(o);
            }
            try (FileOutputStream os = new FileOutputStream(new File(dir(), "rasters.json"))) {
                os.write(new JSONObject().put("items", arr).toString().getBytes("UTF-8"));
            }
        } catch (Exception e) {
            ErrorLog.add("raster-save", e);
        }
    }

    // ------------------------------------------------------------------------------------------------ reading

    interface Done {
        /** placed = true when the image already has a position (GeoTIFF). */
        void result(boolean placed, String message);
    }

    /** Reads the picked file on a background thread. GeoTIFF with georeferencing is placed at once; other images become {@link #pending}. */
    void read(final Uri u, final String name, final Done done) {
        new Thread(() -> {
            try {
                File f = ConverterPage.copyToCache(a, u, name);
                String lower = name.toLowerCase(Locale.ROOT);
                Pending p = new Pending();
                p.name = name.replaceAll("\\.[^.]*$", "");
                double[] affine = null;
                int epsg = 0;
                if (lower.endsWith(".tif") || lower.endsWith(".tiff") || lower.endsWith(".gtif")) {
                    TiffReader.Image im = TiffReader.read(f, MAX_SIDE);
                    p.bitmap = Bitmap.createBitmap(im.argb, im.w, im.h, Bitmap.Config.ARGB_8888);
                    p.srcW = im.srcW;
                    p.srcH = im.srcH;
                    p.note = im.note;
                    affine = im.affine;
                    epsg = im.epsg;
                } else {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(f.getPath(), o);
                    if (o.outWidth <= 0) throw new java.io.IOException(S.t("صيغة الصورة غير مدعومة. المدعوم: TIFF/GeoTIFF وJPG وPNG وWebP وBMP وGIF.",
                            "Unsupported image format. Supported: TIFF/GeoTIFF, JPG, PNG, WebP, BMP, GIF."));
                    int s = 1;
                    while (Math.max(o.outWidth, o.outHeight) / s > MAX_SIDE) s *= 2;
                    o.inJustDecodeBounds = false;
                    o.inSampleSize = s;
                    p.bitmap = BitmapFactory.decodeFile(f.getPath(), o);
                    if (p.bitmap == null) throw new java.io.IOException("decode failed");
                    p.srcW = o.outWidth;
                    p.srcH = o.outHeight;
                    if (s > 1) p.note = "1/" + s;
                }
                f.delete();
                if (affine != null) {
                    final double[] corners;
                    try {
                        corners = Georef.corners(affine, p.srcW, p.srcH, epsg);
                    } catch (RuntimeException e) {
                        // unknown EPSG: keep the picture and let the user place it
                        pending = p;
                        a.runOnUiThread(() -> done.result(false, S.t("نظام الإحداثيات غير معروف (EPSG " + 0 + "). حدّد الحدود يدوياً.", "Unknown coordinate system. Set the bounds by hand.")));
                        return;
                    }
                    final Item it = place(p, corners, epsg);
                    a.runOnUiThread(() -> done.result(true, S.t("تم وضع الصورة على الخريطة: ", "Placed on the map: ") + it.name));
                } else {
                    pending = p;
                    a.runOnUiThread(() -> done.result(false, S.t("الصورة بلا إحداثيات جغرافية. اختر طريقة التحديد.", "The image has no georeferencing. Choose how to place it.")));
                }
            } catch (Throwable t) {
                ErrorLog.add("raster-read", t);
                a.runOnUiThread(() -> done.result(false, "ERR:" + t.getMessage()));
            }
        }).start();
    }

    Item place(Pending p, double[] corners, int epsg) {
        Item it = new Item();
        it.id = "r" + System.currentTimeMillis();
        it.name = p.name;
        it.corners = corners;
        it.w = p.bitmap.getWidth();
        it.h = p.bitmap.getHeight();
        it.epsg = epsg;
        it.note = p.note;
        try (FileOutputStream os = new FileOutputStream(new File(dir(), it.id + ".png"))) {
            p.bitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
        } catch (Exception e) {
            ErrorLog.add("raster-store", e);
        }
        bitmaps.put(it.id, p.bitmap);
        items.add(it);
        save();
        if (pending == p) pending = null;
        return it;
    }

    private final java.util.Map<String, Bitmap> bitmaps = new java.util.HashMap<>();

    Bitmap bitmap(Item it) {
        Bitmap b = bitmaps.get(it.id);
        if (b == null) {
            try {
                b = BitmapFactory.decodeFile(new File(dir(), it.id + ".png").getPath());
            } catch (Throwable t) {
                ErrorLog.add("raster-bitmap", t);
            }
            if (b != null) bitmaps.put(it.id, b);
        }
        return b;
    }

    void remove(Item it) {
        items.remove(it);
        bitmaps.remove(it.id);
        new File(dir(), it.id + ".png").delete();
        save();
    }

    /** lon/lat bounding box {w,s,e,n} of the corners. */
    static double[] bounds(Item it) {
        double w = 1e9, s = 1e9, e = -1e9, n = -1e9;
        for (int i = 0; i < 4; i++) {
            w = Math.min(w, it.corners[2 * i]);
            e = Math.max(e, it.corners[2 * i]);
            s = Math.min(s, it.corners[2 * i + 1]);
            n = Math.max(n, it.corners[2 * i + 1]);
        }
        return new double[]{w, s, e, n};
    }

    static String describe(Item it) {
        double[] b = bounds(it);
        return String.format(Locale.US, "%.4f, %.4f → %.4f, %.4f", b[0], b[1], b[2], b[3]) + (it.epsg != 0 ? "  EPSG:" + it.epsg : "");
    }
}
