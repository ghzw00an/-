package iq.gis.poiexporter.core.geo;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.GeomCodec;
import iq.gis.poiexporter.core.crs.Crs;

/**
 * Ellipsoidal (WGS84) geodesy.
 *
 * <p>Distances/bearings: Vincenty inverse and direct formulae, accurate to about 0.1 mm for all but nearly antipodal
 * points; for those (no convergence in 200 iterations) a spherical haversine fallback is used (error up to ~0.5 %).
 * Areas: exact ellipsoidal area through a Lambert azimuthal equal-area projection centred on the polygon (equal-area
 * projection => no area distortion; edges are straight lines in that projection, i.e. near-geodesic for polygons up to
 * regional size; for very large polygons densify long edges first). Perimeters: sum of geodesic edge lengths.
 * Nothing here uses screen or pixel geometry.
 */
public final class Geodesy {
    public static final double A = 6378137.0, F = 1 / 298.257223563, B = A * (1 - F);

    private Geodesy() {
    }

    /** Result of the inverse problem. */
    public static final class Inverse {
        public final double distance, azimuth1, azimuth2;

        Inverse(double d, double a1, double a2) {
            distance = d;
            azimuth1 = a1;
            azimuth2 = a2;
        }
    }

    /** Distance (m), initial and final azimuth (degrees clockwise from north, 0..360). */
    public static Inverse inverse(double lat1, double lon1, double lat2, double lon2) {
        if (Math.abs(lat1) > 90 || Math.abs(lat2) > 90 || Double.isNaN(lat1 + lat2 + lon1 + lon2))
            throw new IllegalArgumentException(S.t("إحداثيات غير صالحة", "Invalid coordinates"));
        if (lat1 == lat2 && lon1 == lon2) return new Inverse(0, 0, 0);
        double L = Math.toRadians(lon2 - lon1);
        double U1 = Math.atan((1 - F) * Math.tan(Math.toRadians(lat1)));
        double U2 = Math.atan((1 - F) * Math.tan(Math.toRadians(lat2)));
        double sinU1 = Math.sin(U1), cosU1 = Math.cos(U1), sinU2 = Math.sin(U2), cosU2 = Math.cos(U2);
        double lambda = L, lambdaP;
        double sinSigma = 0, cosSigma = 0, sigma = 0, sinAlpha, cos2Alpha = 0, cos2SigmaM = 0, sinLambda = 0, cosLambda = 0;
        int iter = 0;
        boolean ok = false;
        do {
            sinLambda = Math.sin(lambda);
            cosLambda = Math.cos(lambda);
            double t1 = cosU2 * sinLambda, t2 = cosU1 * sinU2 - sinU1 * cosU2 * cosLambda;
            sinSigma = Math.sqrt(t1 * t1 + t2 * t2);
            if (sinSigma == 0) return new Inverse(0, 0, 0);
            cosSigma = sinU1 * sinU2 + cosU1 * cosU2 * cosLambda;
            sigma = Math.atan2(sinSigma, cosSigma);
            sinAlpha = cosU1 * cosU2 * sinLambda / sinSigma;
            cos2Alpha = 1 - sinAlpha * sinAlpha;
            cos2SigmaM = cos2Alpha != 0 ? cosSigma - 2 * sinU1 * sinU2 / cos2Alpha : 0;
            double C = F / 16 * cos2Alpha * (4 + F * (4 - 3 * cos2Alpha));
            lambdaP = lambda;
            lambda = L + (1 - C) * F * sinAlpha
                    * (sigma + C * sinSigma * (cos2SigmaM + C * cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM)));
            if (Math.abs(lambda) > Math.PI) break;
            if (Math.abs(lambda - lambdaP) < 1e-12) {
                ok = true;
                break;
            }
        } while (++iter < 200);
        if (!ok) return spherical(lat1, lon1, lat2, lon2);
        double u2 = cos2Alpha * (A * A - B * B) / (B * B);
        double Aa = 1 + u2 / 16384 * (4096 + u2 * (-768 + u2 * (320 - 175 * u2)));
        double Bb = u2 / 1024 * (256 + u2 * (-128 + u2 * (74 - 47 * u2)));
        double dSigma = Bb * sinSigma * (cos2SigmaM + Bb / 4 * (cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM)
                - Bb / 6 * cos2SigmaM * (-3 + 4 * sinSigma * sinSigma) * (-3 + 4 * cos2SigmaM * cos2SigmaM)));
        double s = B * Aa * (sigma - dSigma);
        double a1 = Math.atan2(cosU2 * sinLambda, cosU1 * sinU2 - sinU1 * cosU2 * cosLambda);
        double a2 = Math.atan2(cosU1 * sinLambda, -sinU1 * cosU2 + cosU1 * sinU2 * cosLambda);
        return new Inverse(s, norm360(Math.toDegrees(a1)), norm360(Math.toDegrees(a2)));
    }

    private static Inverse spherical(double lat1, double lon1, double lat2, double lon2) {
        double R = 6371008.8;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2), dl = Math.toRadians(lon2 - lon1);
        double h = Math.pow(Math.sin((p2 - p1) / 2), 2) + Math.cos(p1) * Math.cos(p2) * Math.pow(Math.sin(dl / 2), 2);
        double d = 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
        double y = Math.sin(dl) * Math.cos(p2), x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
        double a1 = norm360(Math.toDegrees(Math.atan2(y, x)));
        return new Inverse(d, a1, norm360(a1 + 180));
    }

    public static double distance(double lat1, double lon1, double lat2, double lon2) {
        return inverse(lat1, lon1, lat2, lon2).distance;
    }

    /** Initial bearing in degrees clockwise from north (0..360). */
    public static double bearing(double lat1, double lon1, double lat2, double lon2) {
        return inverse(lat1, lon1, lat2, lon2).azimuth1;
    }

    /** Destination {lat, lon} after travelling dist metres on the initial bearing (Vincenty direct). */
    public static double[] destination(double lat1, double lon1, double bearingDeg, double dist) {
        double alpha1 = Math.toRadians(bearingDeg);
        double sinAlpha1 = Math.sin(alpha1), cosAlpha1 = Math.cos(alpha1);
        double tanU1 = (1 - F) * Math.tan(Math.toRadians(lat1));
        double cosU1 = 1 / Math.sqrt(1 + tanU1 * tanU1), sinU1 = tanU1 * cosU1;
        double sigma1 = Math.atan2(tanU1, cosAlpha1);
        double sinAlpha = cosU1 * sinAlpha1, cos2Alpha = 1 - sinAlpha * sinAlpha;
        double u2 = cos2Alpha * (A * A - B * B) / (B * B);
        double Aa = 1 + u2 / 16384 * (4096 + u2 * (-768 + u2 * (320 - 175 * u2)));
        double Bb = u2 / 1024 * (256 + u2 * (-128 + u2 * (74 - 47 * u2)));
        double sigma = dist / (B * Aa), sigmaP, cos2SigmaM, sinSigma, cosSigma;
        int it = 0;
        do {
            cos2SigmaM = Math.cos(2 * sigma1 + sigma);
            sinSigma = Math.sin(sigma);
            cosSigma = Math.cos(sigma);
            double dSigma = Bb * sinSigma * (cos2SigmaM + Bb / 4 * (cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM)
                    - Bb / 6 * cos2SigmaM * (-3 + 4 * sinSigma * sinSigma) * (-3 + 4 * cos2SigmaM * cos2SigmaM)));
            sigmaP = sigma;
            sigma = dist / (B * Aa) + dSigma;
        } while (Math.abs(sigma - sigmaP) > 1e-12 && ++it < 200);
        double x = sinU1 * sinSigma - cosU1 * cosSigma * cosAlpha1;
        double lat2 = Math.atan2(sinU1 * cosSigma + cosU1 * sinSigma * cosAlpha1,
                (1 - F) * Math.sqrt(sinAlpha * sinAlpha + x * x));
        double lambda = Math.atan2(sinSigma * sinAlpha1, cosU1 * cosSigma - sinU1 * sinSigma * cosAlpha1);
        double C = F / 16 * cos2Alpha * (4 + F * (4 - 3 * cos2Alpha));
        double L = lambda - (1 - C) * F * sinAlpha
                * (sigma + C * sinSigma * (cos2SigmaM + C * cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM)));
        double lon2 = lon1 + Math.toDegrees(L);
        lon2 = ((lon2 + 540) % 360) - 180;
        return new double[]{Math.toDegrees(lat2), lon2};
    }

    static double norm360(double d) {
        d %= 360;
        return d < 0 ? d + 360 : d;
    }

    /** Length of a path given as interleaved lon,lat. */
    public static double pathLength(double[] p) {
        double t = 0;
        for (int i = 1; i < p.length / 2; i++) t += distance(p[2 * i - 1], p[2 * i - 2], p[2 * i + 1], p[2 * i]);
        return t;
    }

    /** Lengths of each edge of a path or ring (interleaved lon,lat); n-1 values for n vertices. */
    public static double[] sideLengths(double[] p) {
        int n = p.length / 2;
        double[] r = new double[Math.max(0, n - 1)];
        for (int i = 1; i < n; i++) r[i - 1] = distance(p[2 * i - 1], p[2 * i - 2], p[2 * i + 1], p[2 * i]);
        return r;
    }

    private static Crs laea(double lon, double lat) {
        return Crs.fromProj4("laea", String.format(java.util.Locale.US,
                "+proj=laea +lat_0=%.8f +lon_0=%.8f +datum=WGS84 +units=m +no_defs", lat, lon));
    }

    /** Unsigned ellipsoidal area (m²) of one ring (interleaved lon,lat; closed or not). */
    public static double ringArea(double[] ring, double centreLon, double centreLat) {
        Crs.Tx tx = Crs.wgs84().to(laea(centreLon, centreLat));
        return ringArea(ring, tx);
    }

    private static double ringArea(double[] ring, Crs.Tx tx) {
        int n = ring.length / 2;
        if (n < 3) return 0;
        double[] o = new double[2];
        double[] xs = new double[n], ys = new double[n];
        for (int i = 0; i < n; i++) {
            tx.apply(ring[2 * i], ring[2 * i + 1], o);
            xs[i] = o[0];
            ys[i] = o[1];
        }
        double a = 0;
        for (int i = 0, j = n - 1; i < n; j = i++) a += xs[j] * ys[i] - xs[i] * ys[j];
        return Math.abs(a) / 2;
    }

    /** Ellipsoidal area in m² of a polygon feature: outer rings minus holes. */
    public static double area(Feature f) {
        if (f.geom != Feature.POLYGON) throw new IllegalArgumentException(S.t("ليس مضلعاً", "Not a polygon"));
        if (f.parts.isEmpty()) return 0;
        double[] bb = GeomCodec.bbox(f);
        Crs.Tx tx = Crs.wgs84().to(laea((bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2));
        double a = 0;
        for (int i = 0; i < f.parts.size(); i++) {
            double r = ringArea(f.parts.get(i), tx);
            a += f.isHole(i) ? -r : r;
        }
        return Math.max(0, a);
    }

    /** Perimeter in metres: all rings (outer and holes) for polygons, total length for lines, 0 for points. */
    public static double perimeter(Feature f) {
        if (f.geom == Feature.POINT) return 0;
        double t = 0;
        for (double[] p : f.parts) t += pathLength(p);
        return t;
    }

    /** Length of a line feature in metres. */
    public static double length(Feature f) {
        return f.geom == Feature.LINE ? perimeter(f) : 0;
    }
}
