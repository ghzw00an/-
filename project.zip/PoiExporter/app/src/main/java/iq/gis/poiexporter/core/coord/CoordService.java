package iq.gis.poiexporter.core.coord;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Mgrs;
import iq.gis.poiexporter.core.Utm;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.table.PointTable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** One call that converts a typed coordinate into every representation used by the converter screen. */
public final class CoordService {
    private CoordService() {
    }

    public static final class Result {
        /** WGS84 position the other fields were derived from. */
        public double lat, lon;
        public String dd, dms, ddm, utm, utmZone, utmEasting, utmNorthing, mgrs, plus, plusShort;
        public boolean utmNorth;
        /** The chosen target system. */
        public Crs target;
        public String targetX = "", targetY = "", xLabel = "", yLabel = "", unit = "";
        public String targetText = "";
        public String detectedFormat = "";
        public double resolutionM;
        public String precisionNote = "";
        public final List<String> warnings = new ArrayList<>();

        /** All values as plain text, ready for the clipboard. */
        public String copyText(boolean ar) {
            StringBuilder b = new StringBuilder();
            b.append("WGS84 DD:   ").append(dd).append('\n');
            b.append("WGS84 DMS:  ").append(dms).append('\n');
            b.append("WGS84 DDM:  ").append(ddm).append('\n');
            b.append("UTM:        ").append(utm).append('\n');
            if (mgrs != null) b.append("MGRS:       ").append(mgrs).append('\n');
            if (plus != null) b.append("Plus Code:  ").append(plus).append('\n');
            if (plusShort != null) b.append("Plus short: ").append(plusShort).append('\n');
            if (target != null && target.epsg != 4326)
                b.append(target.code()).append(":  ").append(targetText).append('\n');
            b.append(precisionNote);
            return b.toString();
        }
    }

    /**
     * @param input    typed text: DD, DMS, DDM, UTM or MGRS (auto-detected) or two plain numbers
     * @param src      source CRS, or null to auto-detect WGS84 DD/DMS/DDM/UTM/MGRS text
     * @param latFirst for plain decimal numbers without hemisphere letters: true = "lat lon", false = "lon lat"
     * @param target   system of the extra X/Y result (null = WGS84)
     */
    public static Result convert(String input, Crs src, boolean latFirst, Crs target) {
        boolean ar = S.ar;
        if (input == null || input.trim().isEmpty())
            throw new IllegalArgumentException(S.t("أدخل إحداثيات", "Enter coordinates"));
        Crs wgs = Crs.wgs84();
        if (target == null) target = wgs;
        Result r = new Result();
        r.target = target;
        double lat, lon;
        if (src == null || src.epsg == 4326 || src.geographic) {
            double[] ll = parseGeographic(input, latFirst, r);
            lat = ll[0];
            lon = ll[1];
            if (src != null && src.epsg != 4326) {
                try {
                    double[] w = src.to(wgs).apply(lon, lat);
                    lon = w[0];
                    lat = w[1];
                } catch (IllegalArgumentException e) {
                    throw new IllegalArgumentException(S.t("تعذّر التحويل من " + src.code() + ": " + e.getMessage(),
                            "Cannot convert from " + src.code() + ": " + e.getMessage()));
                }
                if (Crs.approximateShift(src, wgs)) r.warnings.add(shiftWarning(src));
            }
        } else {
            double[] nums = twoNumbers(input);
            double x = nums[0], y = nums[1];
            r.detectedFormat = src.code();
            r.resolutionM = Precision.projectedResolution(input);
            try {
                double[] w = src.to(wgs).apply(x, y);
                lon = w[0];
                lat = w[1];
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException(S.t("الإحداثيات لا تقع ضمن مجال النظام " + src.code()
                                + ". تحقق من ترتيب X وY ومن رقم المنطقة.",
                        "Coordinates are outside the valid area of " + src.code() + ". Check the X/Y order and the zone."));
            }
            if (Math.abs(lat) > 90 || Math.abs(lon) > 180)
                throw new IllegalArgumentException(S.t("النتيجة خارج النطاق الجغرافي؛ تحقق من النظام المرجعي.",
                        "Result outside geographic range; check the CRS."));
            if (Crs.approximateShift(src, wgs)) r.warnings.add(shiftWarning(src));
        }
        r.lat = lat;
        r.lon = lon;
        fill(r, lat, lon, target, ar);
        return r;
    }

    private static String shiftWarning(Crs c) {
        return S.t("تحويل المرجعية من " + c.code() + " إلى WGS84 تقريبي (معاملات Helmert، خطأ يصل إلى عدة أمتار). لا يصلح للمساحة الدقيقة.",
                "Datum shift " + c.code() + " to WGS84 uses approximate Helmert parameters (metre-level error).");
    }

    private static double[] twoNumbers(String input) {
        String[] parts = input.trim().split("[\\s,;،]+");
        if (parts.length != 2) {
            // a single comma may be a decimal comma inside "123,4 567,8"? no: require two numbers
            throw new IllegalArgumentException(S.t("أدخل رقمين: X وY مفصولين بمسافة أو فاصلة",
                    "Enter two numbers: X and Y separated by a space or comma"));
        }
        double a = PointTable.parseNum(parts[0]), b = PointTable.parseNum(parts[1]);
        if (Double.isNaN(a) || Double.isNaN(b))
            throw new IllegalArgumentException(S.t("قيمة غير رقمية في الإحداثيات", "Non-numeric value in the coordinates"));
        return new double[]{a, b};
    }

    private static double[] parseGeographic(String input, boolean latFirst, Result r) {
        CoordFmt.Parsed p;
        input = input.replaceAll("\\(\\s*[NSns]\\s*\\)", " ").trim();
        try {
            p = CoordFmt.parse(input);
        } catch (IllegalArgumentException e) {
            String m = String.valueOf(e.getMessage());
            if (m.contains("out of range"))
                throw new IllegalArgumentException(S.t(
                        "خط العرض يجب أن يكون بين -90 و90 وخط الطول بين -180 و180. إن كانت القيمتان معكوستين فبدّل الترتيب.",
                        "Latitude must be within ±90 and longitude within ±180. If they are swapped, change the order."));
            throw new IllegalArgumentException(S.t(
                    "لم أتعرف على الصيغة. أمثلة: 33.3152 44.3661 • 33°18'54.7\"N 44°21'58\"E • 38S 444000 3686000 • 38SMB4400086860",
                    "Format not recognised. Examples: 33.3152 44.3661 • 33°18'54.7\"N 44°21'58\"E • 38S 444000 3686000 • 38SMB4400086860"));
        }
        double lat = p.lat, lon = p.lon;
        boolean hasLetters = input.toUpperCase(Locale.ROOT).matches(".*[NSEW].*");
        if (p.fmt == CoordFmt.Fmt.DD && !hasLetters && !latFirst) {
            double t = lat;
            lat = lon;
            lon = t;
            if (Math.abs(lat) > 90)
                throw new IllegalArgumentException(S.t("خط العرض خارج ±90 بعد اعتبار الترتيب (طول، عرض)",
                        "Latitude outside ±90 with the lon, lat order"));
        }
        r.detectedFormat = p.fmt.name();
        r.resolutionM = Precision.resolutionMetres(input, p.fmt);
        return new double[]{lat, lon};
    }

    private static void fill(Result r, double lat, double lon, Crs target, boolean ar) {
        double res = r.resolutionM > 0 ? r.resolutionM : 1;
        r.resolutionM = res;
        r.precisionNote = Precision.note(res, ar);
        int dd = Precision.degreeDecimals(res / Math.max(0.2, Math.cos(Math.toRadians(lat))));
        dd = Math.max(dd, Precision.degreeDecimals(res));
        r.dd = Precision.fixed(lat, dd) + ", " + Precision.fixed(lon, dd);
        r.dms = dms(lat, lon, Precision.dmsSecondDecimals(res));
        r.ddm = ddm(lat, lon, Precision.ddmMinuteDecimals(res));
        int plen = res <= 0.5 ? 12 : res <= 3.5 ? 11 : 10; // never claim more precision than the input had
        r.plus = iq.gis.poiexporter.core.PlusCode.encode(lat, lon, plen);
        String sh = iq.gis.poiexporter.core.PlusCode.shorten(r.plus, lat, lon);
        r.plusShort = sh.equals(r.plus) ? null : sh;

        int pd = Precision.projectedDecimals(res);
        if (lat >= -80 && lat <= 84) {
            Utm.Result u = Utm.fromLatLon(lat, lon);
            r.utmZone = u.zoneLabel();
            r.utmNorth = u.north;
            r.utmEasting = Precision.fixed(u.easting, pd);
            r.utmNorthing = Precision.fixed(u.northing, pd);
            r.utm = u.zoneLabel() + " " + r.utmEasting + " " + r.utmNorthing + (u.north ? " (N)" : " (S)");
            r.mgrs = Mgrs.fromLatLon(lat, lon, Precision.mgrsDigits(res));
        } else {
            r.utm = S.t("UTM غير معرّف عند هذا العرض (القطبان)", "UTM is not defined near the poles");
            r.utmZone = "";
            r.utmEasting = "";
            r.utmNorthing = "";
            r.mgrs = null;
            r.warnings.add(S.t("MGRS/UTM يغطيان من 80°S إلى 84°N فقط", "MGRS/UTM cover 80°S to 84°N only"));
        }
        // target system
        r.unit = target.geographic ? "°" : "m";
        if (target.geographic) {
            r.xLabel = S.t("خط الطول (Lon)", "Longitude (Lon)");
            r.yLabel = S.t("خط العرض (Lat)", "Latitude (Lat)");
        } else {
            r.xLabel = S.t("شرقي Easting (X)", "Easting (X)");
            r.yLabel = S.t("شمالي Northing (Y)", "Northing (Y)");
        }
        try {
            double[] t = Crs.wgs84().to(target).apply(lon, lat);
            int td = target.geographic ? Precision.degreeDecimals(res) : pd;
            r.targetX = Precision.fixed(t[0], td);
            r.targetY = Precision.fixed(t[1], td);
            r.targetText = target.geographic ? r.targetY + ", " + r.targetX + " (lat, lon)" : "E " + r.targetX + "  N " + r.targetY;
            if (Crs.approximateShift(Crs.wgs84(), target)) r.warnings.add(shiftWarning(target));
        } catch (IllegalArgumentException e) {
            r.warnings.add(S.t("الموقع خارج مجال النظام " + target.code() + " فلا يمكن حساب X/Y له",
                    "Location is outside the valid area of " + target.code() + "; no X/Y available"));
        }
        if (r.detectedFormat.equals("DD") || r.detectedFormat.equals("DMS") || r.detectedFormat.equals("DDM")) {
            // nothing extra
        }
        if (r.resolutionM >= 1000)
            r.warnings.add(S.t("الإدخال منخفض الدقة (كم)", "Input has low precision (km)"));
    }

    private static String dms(double lat, double lon, int sd) {
        return dms1(lat, 'N', 'S', sd) + " " + dms1(lon, 'E', 'W', sd);
    }

    private static String dms1(double v, char pos, char neg, int sd) {
        double sc = Math.pow(10, sd);
        long units = Math.round(Math.abs(v) * 3600 * sc);
        long per = (long) (3600 * sc);
        long deg = units / per;
        long rem = units % per;
        long min = rem / (long) (60 * sc);
        long secU = rem % (long) (60 * sc);
        String sec = sd == 0 ? String.format(Locale.US, "%02d", secU) : Precision.fixed(secU / sc, sd);
        if (sd > 0 && secU / sc < 10) sec = "0" + sec;
        return String.format(Locale.US, "%d°%02d'%s\"%c", deg, min, sec, v < 0 ? neg : pos);
    }

    private static String ddm(double lat, double lon, int md) {
        return ddm1(lat, 'N', 'S', md) + " " + ddm1(lon, 'E', 'W', md);
    }

    private static String ddm1(double v, char pos, char neg, int md) {
        double sc = Math.pow(10, md);
        long units = Math.round(Math.abs(v) * 60 * sc);
        long per = (long) (60 * sc);
        long deg = units / per;
        double min = (units % per) / sc;
        String m = Precision.fixed(min, md);
        if (min < 10) m = "0" + m;
        return String.format(Locale.US, "%d°%s'%c", deg, m, v < 0 ? neg : pos);
    }
}
