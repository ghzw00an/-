package iq.gis.poiexporter.core.io;

/** Receives records from a reader. Coordinates are in the file's own CRS (see ReadInfo). */
public interface Visitor {
    /** @return false to stop reading. */
    boolean feature(String layer, iq.gis.poiexporter.core.Feature f);
}
