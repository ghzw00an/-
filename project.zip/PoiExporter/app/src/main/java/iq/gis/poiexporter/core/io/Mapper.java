package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.core.Feature;

import java.util.Locale;
import java.util.Map;

/** Maps well known field names of imported files onto the landmark model; everything else goes to Feature.attrs. */
public final class Mapper {
    private Mapper() {
    }

    private static String norm(String k) {
        return k.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
    }

    static boolean isName(String k) {
        String n = norm(k);
        return n.equals("name") || n.equals("name:ar") || n.equals("name_ar") || n.equals("الاسم") || n.equals("اسم")
                || n.equals("title") || n.equals("label") || n.equals("اسم_المعلم");
    }

    /** Fills the landmark fields from properties (keys in file order); remaining keys keep their original names. */
    public static void apply(Feature f, Map<String, String> props) {
        String nameFallback = null;
        for (Map.Entry<String, String> e : props.entrySet()) {
            String k = e.getKey();
            String v = e.getValue() == null ? "" : e.getValue();
            String n = norm(k);
            switch (n) {
                case "name":
                case "name:ar":
                case "name_ar":
                case "الاسم":
                case "اسم":
                case "اسم_المعلم":
                    if (!v.isEmpty() && (f.name.isEmpty() || n.equals("name") || n.equals("name:ar"))) f.name = v;
                    break;
                case "title":
                case "label":
                    if (nameFallback == null && !v.isEmpty()) nameFallback = v;
                    else f.attrs.put(k, v);
                    break;
                case "name_en":
                case "name:en":
                case "name_eng":
                    f.nameEn = v;
                    break;
                case "type":
                    f.type = v;
                    break;
                case "category":
                case "gategory":
                case "cat":
                    f.category = v;
                    break;
                case "nahiya":
                case "nahia":
                    f.nahiya = v;
                    break;
                case "qadaa":
                case "gathaa":
                    f.qadaa = v;
                    break;
                case "governorat":
                case "mohafadha":
                case "governorate":
                    f.governorate = v;
                    break;
                case "status":
                    f.status = parseStatus(v);
                    break;
                case "source":
                    f.source = v;
                    break;
                case "updated":
                    f.updated = v;
                    break;
                case "acc_m":
                case "accuracy":
                    try {
                        f.accuracy = v.isEmpty() ? Double.NaN : Double.parseDouble(v);
                    } catch (NumberFormatException ex) {
                        f.attrs.put(k, v);
                    }
                    break;
                case "descr":
                case "description":
                    f.description = v;
                    break;
                case "notes":
                    f.notes = v;
                    break;
                case "x":
                case "y":
                    break; // derived from the geometry
                case "link":
                    if (!v.isEmpty()) f.attrs.put("link", v);
                    break;
                case "id":
                case "uid":
                    f.id = v;
                    break;
                default:
                    f.attrs.put(k, v);
            }
        }
        if (f.name.isEmpty() && nameFallback != null) f.name = nameFallback;
    }

    static int parseStatus(String v) {
        String s = v.trim().toLowerCase(Locale.ROOT);
        if (s.equals("1") || s.startsWith("review") || s.contains("مراجعة")) return Feature.STATUS_REVIEW;
        if (s.equals("2") || s.startsWith("verif") || s.contains("موثق") || s.contains("موثّق")) return Feature.STATUS_VERIFIED;
        return Feature.STATUS_NEW;
    }

    static String statusText(int s) {
        return s == Feature.STATUS_REVIEW ? "review" : s == Feature.STATUS_VERIFIED ? "verified" : "new";
    }
}
