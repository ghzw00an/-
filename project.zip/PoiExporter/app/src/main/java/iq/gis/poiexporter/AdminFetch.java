package iq.gis.poiexporter;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerBuilder;
import iq.gis.poiexporter.core.Overpass;
import iq.gis.poiexporter.core.Pipeline;
import iq.gis.poiexporter.core.admin.AdminRef;

/**
 * Fetches administrative districts from OpenStreetMap on the device (the bundled set is incomplete: for example it has
 * no Abu Ghraib, Al-Karma, Al-Shu'ab or Al-Habbaniyah) and keeps them in a small file next to the bundled data.
 * OSM data is ODbL: "© OpenStreetMap contributors". Boundaries are whatever OSM mapped, not official ones.
 */
final class AdminFetch {
    private AdminFetch() {
    }

    static final String CREDIT = "© OpenStreetMap contributors (ODbL)";

    /** A candidate district found online, not yet added. */
    static final class Found {
        String nameEn = "", nameAr = "", detail = "";
        Feature poly;
    }

    static File file(Context c) {
        return new File(c.getFilesDir(), "admin_extra.json");
    }

    /** Loads the saved extras into the shared AdminRef. Call once at start-up. */
    static void restore(Context c) {
        AdminRef r = AdminRef.get();
        File f = file(c);
        if (r == null || !f.isFile()) return;
        try (InputStream in = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            r.loadExtras(bo.toString("UTF-8"));
        } catch (Exception e) {
            ErrorLog.add("admin-extra-load", e);
        }
    }

    static void save(Context c) {
        AdminRef r = AdminRef.get();
        if (r == null) return;
        try (FileOutputStream os = new FileOutputStream(file(c))) {
            os.write(r.extrasJson().getBytes("UTF-8"));
        } catch (Exception e) {
            ErrorLog.add("admin-extra-save", e);
        }
    }

    // ------------------------------------------------------------------------------------------ by name (Nominatim)

    static List<Found> byName(String query) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&polygon_geojson=1&polygon_threshold=0.0003"
                + "&countrycodes=iq&accept-language=ar,en&q=" + URLEncoder.encode(query, "UTF-8")).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent", "PoiExporter/3.2 (iq.gis.poiexporter)");
        try (InputStream in = c.getInputStream()) {
            return parseNominatim(in);
        } finally {
            c.disconnect();
        }
    }

    private static List<Found> parseNominatim(InputStream in) throws IOException {
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            JSONArray arr = new JSONArray(bo.toString("UTF-8"));
            List<Found> out = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                JSONObject g = o.optJSONObject("geojson");
                if (g == null) continue;
                String t = g.optString("type");
                if (!t.equals("Polygon") && !t.equals("MultiPolygon")) continue; // a point result is not a boundary
                Feature f = fromGeoJson(g);
                if (f == null) continue;
                Found fd = new Found();
                fd.poly = f;
                fd.nameAr = o.optString("name", "");
                fd.nameEn = fd.nameAr;
                fd.detail = o.optString("display_name", "") + "  [" + o.optString("category", "") + "/" + o.optString("type", "") + "]";
                out.add(fd);
            }
            return out;
        } catch (org.json.JSONException e) {
            throw new IOException("bad response: " + e.getMessage());
        }
    }

    static Feature fromGeoJson(JSONObject g) {
        Feature f = new Feature();
        f.geom = Feature.POLYGON;
        f.id = Feature.newId();
        JSONArray co = g.optJSONArray("coordinates");
        if (co == null) return null;
        boolean multi = g.optString("type").equals("MultiPolygon");
        try {
            int np = multi ? co.length() : 1;
            for (int p = 0; p < np; p++) {
                JSONArray rings = multi ? co.getJSONArray(p) : co;
                for (int r = 0; r < rings.length(); r++) {
                    JSONArray pts = rings.getJSONArray(r);
                    double[] a = new double[pts.length() * 2];
                    for (int i = 0; i < pts.length(); i++) {
                        JSONArray xy = pts.getJSONArray(i);
                        a[2 * i] = xy.getDouble(0);
                        a[2 * i + 1] = xy.getDouble(1);
                    }
                    if (a.length >= 8) f.addPart(a, r > 0);
                }
            }
        } catch (org.json.JSONException e) {
            return null;
        }
        if (f.parts.isEmpty()) return null;
        Geo.setRepresentative(f);
        return f;
    }

    // ------------------------------------------------------------------------------------------ by area (Overpass)

    /** Districts (OSM admin_level = level) that intersect the area. Uses the same server rotation as downloads. */
    static List<Found> inArea(AreaSpec area, int level) throws IOException {
        InputStream in = new Net().post(Pipeline.adminQuery(new int[]{level}, area));
        List<Overpass.Elem> els;
        try {
            els = Overpass.parse(in);
        } finally {
            in.close();
        }
        List<Found> out = new ArrayList<>();
        for (Overpass.Elem e : els) {
            if (LayerBuilder.adminLevel(e.tags) != level) continue;
            Feature poly = LayerBuilder.polygonFrom(e);
            if (poly == null) continue;
            Found fd = new Found();
            fd.poly = poly;
            fd.nameAr = e.tag("name:ar").isEmpty() ? e.tag("name") : e.tag("name:ar");
            fd.nameEn = e.tag("name:en").isEmpty() ? (e.tag("int_name").isEmpty() ? e.tag("name") : e.tag("int_name")) : e.tag("name:en");
            fd.detail = "admin_level=" + level + "  OSM relation " + e.id;
            if (!fd.nameAr.isEmpty() || !fd.nameEn.isEmpty()) out.add(fd);
        }
        return out;
    }
}
