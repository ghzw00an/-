package iq.gis.poiexporter.core;

/** One landmark (point of interest) to be exported. */
public final class Poi {
    public String id = "";
    public String name = "";
    public String type = "";
    public String category = "";
    public String nahiya = "";
    public String qadaa = "";
    public String governorate = "";
    public double lat;
    public double lon;
}
