package iq.gis.poiexporter.core.geo;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.GeomCodec;
import iq.gis.poiexporter.core.Jts;
import iq.gis.poiexporter.core.crs.Crs;

import org.locationtech.jts.geom.CoordinateSequence;
import org.locationtech.jts.geom.CoordinateSequenceFilter;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.util.GeometryFixer;

import java.util.Collection;
import java.util.Locale;

/** A local azimuthal-equidistant metric CRS around a centre; geometries are moved in and out of it. Not thread safe. */
final class Local {
    final double lon, lat;
    private final Crs.Tx fwd, inv;

    Local(double lon, double lat) {
        this.lon = lon;
        this.lat = lat;
        Crs local = Crs.fromProj4("local", String.format(Locale.US,
                "+proj=aeqd +lat_0=%.8f +lon_0=%.8f +datum=WGS84 +units=m +no_defs", lat, lon));
        fwd = Crs.wgs84().to(local);
        inv = local.to(Crs.wgs84());
    }

    static Local around(Collection<Feature> fs) {
        double[] r = {1e9, 1e9, -1e9, -1e9};
        for (Feature f : fs) {
            double[] b = GeomCodec.bbox(f);
            if (b[0] > b[2]) continue;
            r[0] = Math.min(r[0], b[0]);
            r[1] = Math.min(r[1], b[1]);
            r[2] = Math.max(r[2], b[2]);
            r[3] = Math.max(r[3], b[3]);
        }
        if (r[0] > r[2]) return new Local(0, 0);
        return new Local((r[0] + r[2]) / 2, (r[1] + r[3]) / 2);
    }

    private static Geometry map(Geometry g, final Crs.Tx tx) {
        Geometry c = g.copy();
        final double[] o = new double[2];
        c.apply(new CoordinateSequenceFilter() {
            public void filter(CoordinateSequence s, int i) {
                tx.apply(s.getX(i), s.getY(i), o);
                s.setOrdinate(i, 0, o[0]);
                s.setOrdinate(i, 1, o[1]);
            }

            public boolean isDone() {
                return false;
            }

            public boolean isGeometryChanged() {
                return true;
            }
        });
        c.geometryChanged();
        return c;
    }

    Geometry to(Geometry lonlat) {
        return map(lonlat, fwd);
    }

    Geometry from(Geometry metric) {
        return map(metric, inv);
    }

    /** Local metric geometry of a feature, repaired when invalid; null when empty. */
    Geometry geom(Feature f) {
        Geometry g = Jts.toGeometry(f);
        if (g == null) return null;
        Geometry m = to(g);
        return fix(m);
    }

    static Geometry fix(Geometry m) {
        if (m != null && !m.isValid()) m = GeometryFixer.fix(m);
        return m;
    }
}
