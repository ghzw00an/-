package iq.gis.poiexporter;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Programmatic widgets with modern look and press / focus effects. */
public final class Ui {
    private Ui() {
    }

    public static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    public static GradientDrawable round(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable stroke(int fill, int strokeColor, float radiusDp, Context c) {
        GradientDrawable g = round(fill, radiusDp, c);
        g.setStroke(dp(c, 1.5f), strokeColor);
        return g;
    }

    /** Scale-down press effect plus ripple. */
    public static void pressable(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(0.95f).scaleY(0.95f).alpha(0.88f).setDuration(80).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    private static android.graphics.drawable.Drawable withRipple(int fill, int rippleColor, float r, Context c) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), round(fill, r, c), round(Color.WHITE, r, c));
    }

    /** Lighter (f > 1) or darker (f < 1) version of a colour, for gradients. */
    static int shade(int color, float f) {
        int r = Math.min(255, Math.round(Color.red(color) * f)), g = Math.min(255, Math.round(Color.green(color) * f)), bl = Math.min(255, Math.round(Color.blue(color) * f));
        return Color.rgb(r, g, bl);
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView button(Context c, String label, boolean filled, final Runnable action) {
        TextView b = new TextView(c);
        b.setText(label);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12));
        b.setMinHeight(dp(c, 46));
        b.setClickable(true);
        if (filled) {
            b.setTextColor(Theme.onPrimary);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Theme.primary, shade(Theme.primary, 1.18f)});
            g.setCornerRadius(dp(c, 14));
            b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55FFFFFF), g, round(Color.WHITE, 14, c)));
            b.setElevation(dp(c, 3));
            b.setStateListAnimator(null);
        } else {
            b.setTextColor(Theme.primary);
            RippleDrawable rd = new RippleDrawable(ColorStateList.valueOf((Theme.primary & 0x00FFFFFF) | 0x33000000),
                    stroke(Color.TRANSPARENT, Theme.primary, 14, c), round(Color.WHITE, 14, c));
            b.setBackground(rd);
        }
        pressable(b);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (action != null) action.run();
            }
        });
        return b;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        l.setBackground(stroke(Theme.card, Theme.line, 16, c));
        l.setElevation(dp(c, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(c, 6), 0, dp(c, 6));
        l.setLayoutParams(lp);
        return l;
    }

    /** Input with an animated border that lights up on focus. */
    public static EditText field(Context c, String hint, int inputType) {
        final EditText e = new EditText(c);
        e.setHint(hint);
        e.setInputType(inputType);
        e.setSingleLine(inputType != (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE));
        e.setTextColor(Theme.text);
        e.setHintTextColor(Theme.sub);
        e.setTextSize(15);
        e.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        final GradientDrawable bg = round(Theme.field, 12, c);
        bg.setStroke(dp(c, 1.5f), Theme.line);
        e.setBackground(bg);
        final int from = Theme.line, to = Theme.primary;
        final Context ctx = c;
        e.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean focus) {
                ValueAnimator a = ValueAnimator.ofObject(new android.animation.ArgbEvaluator(),
                        focus ? from : to, focus ? to : from);
                a.setDuration(180);
                a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator va) {
                        bg.setStroke(dp(ctx, focus_w(va)), (Integer) va.getAnimatedValue());
                    }
                });
                a.start();
                v.animate().scaleX(focus ? 1.01f : 1f).scaleY(focus ? 1.01f : 1f).setDuration(180).start();
            }
        });
        return e;
    }

    private static float focus_w(ValueAnimator va) {
        return 1.5f + 0.5f * va.getAnimatedFraction();
    }

    /** Toggle chip (single select within a group handled by caller). */
    public static TextView chip(Context c, String label) {
        TextView t = new TextView(c);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(14);
        t.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
        t.setClickable(true);
        pressable(t);
        setChip(t, false);
        return t;
    }

    public static void setChip(TextView t, boolean on) {
        Context c = t.getContext();
        if (on) {
            t.setTextColor(Theme.onPrimary);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setBackground(round(Theme.primary, 20, c));
        } else {
            t.setTextColor(Theme.text);
            t.setTypeface(Typeface.DEFAULT);
            t.setBackground(stroke(Theme.card, Theme.line, 20, c));
        }
    }

    public static LinearLayout.LayoutParams lp(int w, int h, float weight, Context c, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    public static View space(Context c, int h) {
        View v = new View(c);
        v.setLayoutParams(new ViewGroup.LayoutParams(1, dp(c, h)));
        return v;
    }

    /** A segmented group of chips; returns the container. */
    public interface OnPick {
        void pick(int index);
    }

    public static LinearLayout chips(Context c, String[] labels, int selected, final OnPick cb) {
        final LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.HORIZONTAL);
        final TextView[] cs = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            cs[i] = chip(c, labels[i]);
            Ui.setChip(cs[i], i == selected);
            cs[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int k = 0; k < cs.length; k++) Ui.setChip(cs[k], k == idx);
                    cb.pick(idx);
                }
            });
            box.addView(cs[i], lp(0, -2, 1f, c, 3, 3, 3, 3));
        }
        return box;
    }
}
