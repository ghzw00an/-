package iq.gis.poiexporter;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Programmatic widgets with modern look and press / focus effects. */
public final class Ui {
    private Ui() {
    }

    public static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    public static GradientDrawable round(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable stroke(int fill, int strokeColor, float radiusDp, Context c) {
        GradientDrawable g = round(fill, radiusDp, c);
        g.setStroke(dp(c, 1.5f), strokeColor);
        return g;
    }

    /** Scale-down press effect plus ripple. */
    public static void pressable(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(0.95f).scaleY(0.95f).alpha(0.88f).setDuration(80).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).start();
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    private static android.graphics.drawable.Drawable withRipple(int fill, int rippleColor, float r, Context c) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), round(fill, r, c), round(Color.WHITE, r, c));
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView button(Context c, String label, boolean filled, final Runnable action) {
        return button(c, label, filled, Theme.primary, Theme.onPrimary, action);
    }

    /** Button with explicit colours: filled uses color as background, outlined uses it for text and border. */
    public static TextView button(Context c, String label, boolean filled, int color, int onColor, final Runnable action) {
        TextView b = new TextView(c);
        b.setText(label);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12));
        b.setMinHeight(dp(c, 46));
        b.setClickable(true);
        if (filled) {
            b.setTextColor(onColor);
            b.setBackground(withRipple(color, 0x55FFFFFF, 14, c));
        } else {
            b.setTextColor(color);
            RippleDrawable rd = new RippleDrawable(ColorStateList.valueOf((color & 0x00FFFFFF) | 0x33000000),
                    stroke(Color.TRANSPARENT, color, 14, c), round(Color.WHITE, 14, c));
            b.setBackground(rd);
        }
        pressable(b);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (action != null) action.run();
            }
        });
        return b;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        l.setBackground(stroke(Theme.card, Theme.line, 16, c));
        l.setElevation(dp(c, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(c, 6), 0, dp(c, 6));
        l.setLayoutParams(lp);
        return l;
    }

    /** Input with an animated border that lights up on focus. */
    public static EditText field(Context c, String hint, int inputType) {
        final EditText e = new EditText(c);
        e.setHint(hint);
        e.setInputType(inputType);
        e.setSingleLine(inputType != (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE));
        e.setTextColor(Theme.text);
        e.setHintTextColor(Theme.sub);
        e.setTextSize(15);
        e.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        final GradientDrawable bg = round(Theme.field, 12, c);
        bg.setStroke(dp(c, 1.5f), Theme.line);
        e.setBackground(bg);
        final int from = Theme.line, to = Theme.primary;
        final Context ctx = c;
        e.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean focus) {
                ValueAnimator a = ValueAnimator.ofObject(new android.animation.ArgbEvaluator(),
                        focus ? from : to, focus ? to : from);
                a.setDuration(180);
                a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator va) {
                        bg.setStroke(dp(ctx, focus_w(va)), (Integer) va.getAnimatedValue());
                    }
                });
                a.start();
                v.animate().scaleX(focus ? 1.01f : 1f).scaleY(focus ? 1.01f : 1f).setDuration(180).start();
            }
        });
        return e;
    }

    private static float focus_w(ValueAnimator va) {
        return 1.5f + 0.5f * va.getAnimatedFraction();
    }

    /** Toggle chip (single select within a group handled by caller). */
    public static TextView chip(Context c, String label) {
        TextView t = new TextView(c);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(14);
        t.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
        t.setClickable(true);
        pressable(t);
        setChip(t, false);
        return t;
    }

    public static void setChip(TextView t, boolean on) {
        Context c = t.getContext();
        if (on) {
            t.setTextColor(Theme.onPrimary);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setBackground(round(Theme.primary, 20, c));
        } else {
            t.setTextColor(Theme.text);
            t.setTypeface(Typeface.DEFAULT);
            t.setBackground(stroke(Theme.card, Theme.line, 20, c));
        }
    }

    public static LinearLayout.LayoutParams lp(int w, int h, float weight, Context c, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    public static View space(Context c, int h) {
        View v = new View(c);
        v.setLayoutParams(new ViewGroup.LayoutParams(1, dp(c, h)));
        return v;
    }

    /** A segmented group of chips; returns the container. */
    public interface OnPick {
        void pick(int index);
    }

    public static LinearLayout chips(Context c, String[] labels, int selected, final OnPick cb) {
        final LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.HORIZONTAL);
        final TextView[] cs = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            cs[i] = chip(c, labels[i]);
            Ui.setChip(cs[i], i == selected);
            cs[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int k = 0; k < cs.length; k++) Ui.setChip(cs[k], k == idx);
                    cb.pick(idx);
                }
            });
            box.addView(cs[i], lp(0, -2, 1f, c, 3, 3, 3, 3));
        }
        return box;
    }

    // ------------------------------------------------------------------ popups, sheets, tiles

    /** Filled circle used as a colour swatch / marker. */
    public static View dot(Context c, int color, int sizeDp) {
        View v = new View(c);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        v.setBackground(g);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return v;
    }

    /** Small menu that pops up above an anchor view (long-press menus of the bottom toolbar). */
    public static android.widget.PopupWindow popupAbove(final Context c, View anchor, String[] icons, String[] labels,
                                                        final Runnable[] actions) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        box.setBackground(stroke(Theme.card, Theme.line, 16, c));
        box.setPadding(dp(c, 6), dp(c, 6), dp(c, 6), dp(c, 6));
        final android.widget.PopupWindow pw = new android.widget.PopupWindow(box,
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setMinimumHeight(dp(c, 46));
            row.setPadding(dp(c, 12), dp(c, 6), dp(c, 16), dp(c, 6));
            row.setClickable(true);
            row.setBackground(new RippleDrawable(ColorStateList.valueOf(0x333DB8A5), null, round(Color.WHITE, 12, c)));
            TextView ic = text(c, icons[i], 19, Theme.primary, true);
            ic.setGravity(Gravity.CENTER);
            row.addView(ic, new LinearLayout.LayoutParams(dp(c, 32), -2));
            TextView tv = text(c, labels[i], 14.5f, Theme.text, false);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
            tl.setMargins(dp(c, 8), 0, 0, 0);
            row.addView(tv, tl);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pw.dismiss();
                    if (actions[idx] != null) actions[idx].run();
                }
            });
            box.addView(row, new LinearLayout.LayoutParams(-2, -2));
        }
        pw.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        pw.setOutsideTouchable(true);
        pw.setElevation(dp(c, 12));
        box.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int pwW = box.getMeasuredWidth(), pwH = box.getMeasuredHeight();
        int[] loc = new int[2];
        anchor.getLocationOnScreen(loc);
        int sw = c.getResources().getDisplayMetrics().widthPixels;
        int x = loc[0] + anchor.getWidth() / 2 - pwW / 2;
        x = Math.max(dp(c, 8), Math.min(sw - pwW - dp(c, 8), x));
        int y = loc[1] - pwH - dp(c, 10);
        box.setAlpha(0f);
        box.setTranslationY(dp(c, 10));
        pw.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y);
        box.animate().alpha(1f).translationY(0).setDuration(140).start();
        return pw;
    }

    /** Bottom sheet dialog with rounded top corners; content may be filled after creation. */
    public static android.app.Dialog sheet(final Context c, final LinearLayout content) {
        final android.app.Dialog d = new android.app.Dialog(c);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        final LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Theme.card);
        float r = dp(c, 24);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        box.setBackground(bg);
        box.setPadding(dp(c, 18), dp(c, 10), dp(c, 18), dp(c, 18));
        View handle = new View(c);
        handle.setBackground(round(Theme.line, 3, c));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(c, 42), dp(c, 5));
        hp.gravity = Gravity.CENTER_HORIZONTAL;
        hp.bottomMargin = dp(c, 12);
        box.addView(handle, hp);
        android.widget.ScrollView sv = new android.widget.ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(content, new ViewGroup.LayoutParams(-1, -2));
        box.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(box);
        android.view.Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            int sw = c.getResources().getDisplayMetrics().widthPixels;
            w.setLayout(Math.min(sw, dp(c, 560)), ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
            w.setDimAmount(0.45f);
        }
        box.setTranslationY(dp(c, 420));
        d.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            public void onShow(android.content.DialogInterface di) {
                box.animate().translationY(0).setDuration(240)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            }
        });
        return d;
    }

    /** Square action tile: round icon over a short label. */
    public static View tile(Context c, String icon, String label, int tint, final Runnable action) {
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 4), dp(c, 10), dp(c, 4), dp(c, 8));
        t.setClickable(true);
        t.setBackground(new RippleDrawable(ColorStateList.valueOf((tint & 0x00FFFFFF) | 0x22000000),
                stroke(Theme.field, Theme.line, 16, c), round(Color.WHITE, 16, c)));
        TextView ic = text(c, icon, 20, tint, true);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round((tint & 0x00FFFFFF) | 0x22000000, 20, c));
        t.addView(ic, new LinearLayout.LayoutParams(dp(c, 42), dp(c, 42)));
        TextView lb = text(c, label, 11.5f, Theme.text, false);
        lb.setGravity(Gravity.CENTER);
        lb.setMaxLines(2);
        lb.setPadding(0, dp(c, 6), 0, 0);
        t.addView(lb, new LinearLayout.LayoutParams(-1, -2));
        pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (action != null) action.run();
            }
        });
        return t;
    }

    /** Lays tiles out in rows of cols equal columns. */
    public static LinearLayout grid(Context c, java.util.List<View> tiles, int cols) {
        LinearLayout g = new LinearLayout(c);
        g.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < tiles.size(); i += cols) {
            LinearLayout r = new LinearLayout(c);
            r.setOrientation(LinearLayout.HORIZONTAL);
            for (int k = 0; k < cols; k++) {
                View v = i + k < tiles.size() ? tiles.get(i + k) : new View(c);
                r.addView(v, lp(0, dp(c, 92), 1f, c, 4, 4, 4, 4));
            }
            g.addView(r, new LinearLayout.LayoutParams(-1, -2));
        }
        return g;
    }

    /** Styled on/off switch. */
    public static android.widget.Switch toggleSwitch(Context c, boolean on, final java.util.function.Consumer<Boolean> cb) {
        android.widget.Switch s = new android.widget.Switch(c);
        s.setChecked(on);
        s.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{Theme.primary, Theme.sub}));
        s.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{(Theme.primary & 0x00FFFFFF) | 0x66000000, Theme.line}));
        s.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                cb.accept(checked);
            }
        });
        return s;
    }

    /** Single-select chips that keep their natural width and scroll sideways when they do not fit. */
    public static android.widget.HorizontalScrollView chipScroller(Context c, String[] labels, int selected, final OnPick cb) {
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final TextView[] cs = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            cs[i] = chip(c, labels[i]);
            setChip(cs[i], i == selected);
            cs[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int k = 0; k < cs.length; k++) setChip(cs[k], k == idx);
                    cb.pick(idx);
                }
            });
            row.addView(cs[i], lp(-2, -2, 0, c, 3, 3, 3, 3));
        }
        hs.addView(row);
        return hs;
    }
}
