package iq.gis.poiexporter.core;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryCollection;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.LineString;
import org.locationtech.jts.geom.LinearRing;
import org.locationtech.jts.geom.MultiPolygon;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.PrecisionModel;

import java.util.ArrayList;
import java.util.List;

/** Conversion between app features (lon,lat arrays) and JTS geometries. */
public final class Jts {
    public static final GeometryFactory GF = new GeometryFactory(new PrecisionModel(), 4326);

    private Jts() {
    }

    private static Coordinate[] coords(double[] p, boolean close) {
        int n = p.length / 2;
        boolean needClose = close && n > 0 && (p[0] != p[2 * n - 2] || p[1] != p[2 * n - 1]);
        Coordinate[] c = new Coordinate[n + (needClose ? 1 : 0)];
        for (int i = 0; i < n; i++) c[i] = new Coordinate(p[2 * i], p[2 * i + 1]);
        if (needClose) c[n] = new Coordinate(p[0], p[1]);
        return c;
    }

    /** Geometry of the feature, or null when it has no usable coordinates. */
    public static Geometry toGeometry(Feature f) {
        if (f.parts.isEmpty()) return null;
        if (f.geom == Feature.POINT) {
            double[] p = f.parts.get(0);
            return p.length < 2 ? null : GF.createPoint(new Coordinate(p[0], p[1]));
        }
        if (f.geom == Feature.LINE) {
            List<LineString> ls = new ArrayList<>();
            for (double[] p : f.parts) if (p.length >= 4) ls.add(GF.createLineString(coords(p, false)));
            if (ls.isEmpty()) return null;
            return ls.size() == 1 ? ls.get(0) : GF.createMultiLineString(ls.toArray(new LineString[0]));
        }
        List<LinearRing> outers = new ArrayList<>();
        List<LinearRing> holes = new ArrayList<>();
        for (int i = 0; i < f.parts.size(); i++) {
            double[] p = f.parts.get(i);
            if (p.length < 6) continue;
            Coordinate[] c = coords(p, true);
            if (c.length < 4) continue;
            LinearRing r = GF.createLinearRing(c);
            (f.isHole(i) ? holes : outers).add(r);
        }
        if (outers.isEmpty()) return null;
        List<List<LinearRing>> own = new ArrayList<>();
        for (int i = 0; i < outers.size(); i++) own.add(new ArrayList<LinearRing>());
        for (LinearRing h : holes) {
            Point probe = GF.createPoint(h.getCoordinateN(0));
            int best = -1;
            double bestArea = Double.MAX_VALUE;
            for (int i = 0; i < outers.size(); i++) {
                Polygon pg = GF.createPolygon(outers.get(i));
                if (pg.covers(probe) && pg.getArea() < bestArea) {
                    best = i;
                    bestArea = pg.getArea();
                }
            }
            if (best >= 0) own.get(best).add(h);
        }
        Polygon[] pgs = new Polygon[outers.size()];
        for (int i = 0; i < pgs.length; i++) pgs[i] = GF.createPolygon(outers.get(i), own.get(i).toArray(new LinearRing[0]));
        return pgs.length == 1 ? pgs[0] : GF.createMultiPolygon(pgs);
    }

    private static double[] arr(Coordinate[] c) {
        double[] r = new double[c.length * 2];
        for (int i = 0; i < c.length; i++) {
            r[2 * i] = c[i].x;
            r[2 * i + 1] = c[i].y;
        }
        return r;
    }

    /**
     * Features for a geometry: one per point of a MultiPoint, one for each line or polygon (multi-part kept as one
     * feature). Attributes are copied from the template (may be null).
     */
    public static List<Feature> toFeatures(Geometry g, Feature template) {
        List<Feature> out = new ArrayList<>();
        add(g, template, out);
        return out;
    }

    private static Feature base(Feature t, int geom) {
        Feature f = t == null ? new Feature() : t.copy();
        f.parts.clear();
        f.holes.clear();
        f.geom = geom;
        if (t == null || f.id.isEmpty()) f.id = Feature.newId();
        return f;
    }

    private static void add(Geometry g, Feature t, List<Feature> out) {
        if (g == null || g.isEmpty()) return;
        if (g instanceof Point) {
            Feature f = base(t, Feature.POINT);
            Coordinate c = ((Point) g).getCoordinate();
            f.parts.add(new double[]{c.x, c.y});
            f.holes.add(Boolean.FALSE);
            Geo.setRepresentative(f);
            out.add(f);
        } else if (g instanceof LineString) {
            Feature f = base(t, Feature.LINE);
            f.addPart(arr(g.getCoordinates()), false);
            Geo.setRepresentative(f);
            out.add(f);
        } else if (g instanceof Polygon) {
            Feature f = base(t, Feature.POLYGON);
            addPolygon((Polygon) g, f);
            Geo.setRepresentative(f);
            out.add(f);
        } else if (g instanceof MultiPolygon) {
            Feature f = base(t, Feature.POLYGON);
            for (int i = 0; i < g.getNumGeometries(); i++) addPolygon((Polygon) g.getGeometryN(i), f);
            Geo.setRepresentative(f);
            out.add(f);
        } else if (g instanceof org.locationtech.jts.geom.MultiLineString) {
            Feature f = base(t, Feature.LINE);
            for (int i = 0; i < g.getNumGeometries(); i++) f.addPart(arr(g.getGeometryN(i).getCoordinates()), false);
            Geo.setRepresentative(f);
            out.add(f);
        } else if (g instanceof GeometryCollection) {
            for (int i = 0; i < g.getNumGeometries(); i++) {
                Feature tt = t == null ? null : t.copy();
                if (tt != null && i > 0) tt.id = "";
                add(g.getGeometryN(i), tt, out);
            }
        }
    }

    private static void addPolygon(Polygon p, Feature f) {
        f.addPart(Geo.oriented(arr(p.getExteriorRing().getCoordinates()), true), false);
        for (int i = 0; i < p.getNumInteriorRing(); i++)
            f.addPart(Geo.oriented(arr(p.getInteriorRingN(i).getCoordinates()), false), true);
    }
}
