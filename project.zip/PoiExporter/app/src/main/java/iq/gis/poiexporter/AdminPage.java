package iq.gis.poiexporter;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.admin.AdminRef;

/**
 * Iraqi administrative boundaries (bundled, unofficial): show on the map, browse governorate → district,
 * find what contains a point, and save boundary layers into the project (for clipping and analysis).
 */
final class AdminPage {
    private final MainActivity a;
    private String openGov;

    AdminPage(MainActivity a) {
        this.a = a;
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        final AdminRef r = AdminRef.get();
        if (r == null) {
            p.addView(UiKit.note(a, S.t("بيانات الحدود غير موجودة في هذا الإصدار.", "Boundary data is missing in this build.")));
            return p;
        }
        p.addView(info(r));
        p.addView(show(r));
        p.addView(lookup(r));
        p.addView(browse(r));
        return p;
    }

    private View info(AdminRef r) {
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("الحدود الإدارية المرجعية — غير رسمية", "Reference boundaries — unofficial")));
        c.addView(UiKit.note(a, S.t(
                "• المحافظات (" + r.units(1).size() + "): " + r.source(1) + " — " + r.year(1) + " — " + r.license(1)
                        + "\n• الأقضية (" + r.units(2).size() + "): " + r.source(2) + " — " + r.year(2) + " — " + r.license(2)
                        + "\n\n" + r.accuracyNote(true)
                        + "\nلا تشمل النواحي (Nahia) ولا محافظة حلبجة منفصلة (ضمن السليمانية). الأسماء العربية وربط القضاء بالمحافظة أُضيفا يدوياً ولم يردا في المصدر؛ يُرجى مراجعتهما.\nالنواحي تُملأ من OpenStreetMap عند توفر الإنترنت.",
                "• Governorates (" + r.units(1).size() + "): " + r.source(1) + " — " + r.year(1) + " — " + r.license(1)
                        + "\n• Districts (" + r.units(2).size() + "): " + r.source(2) + " — " + r.year(2) + " — " + r.license(2)
                        + "\n\n" + r.accuracyNote(false)
                        + "\nNo sub-districts (Nahia) and no separate Halabja governorate. Arabic names and the district→governorate link were added by hand, not by the source; please review.\nNahia is filled from OpenStreetMap when online.")));
        return c;
    }

    private View show(final AdminRef r) {
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("عرض على الخريطة", "Show on map")));
        c.addView(UiKit.check(a, S.t("حدود المحافظات", "Governorate boundaries"), visible(1), v -> toggle(r, 1, v)));
        c.addView(UiKit.check(a, S.t("حدود الأقضية", "District boundaries"), visible(2), v -> toggle(r, 2, v)));
        c.addView(UiKit.note(a, S.t("المس حداً على الخريطة لمعرفة اسمه.", "Tap a boundary on the map to see its name.")));
        LinearLayout row = Ui.row(a);
        row.addView(Ui.button(a, S.t("حفظ المحافظات في المشروع", "Save governorates to project"), false, () -> save(r, 1)),
                Ui.lp(0, -2, 1f, a, 0, 8, 4, 0));
        row.addView(Ui.button(a, S.t("حفظ الأقضية في المشروع", "Save districts to project"), false, () -> save(r, 2)),
                Ui.lp(0, -2, 1f, a, 4, 8, 0, 0));
        c.addView(row);
        return c;
    }

    private boolean visible(int level) {
        for (LayerData l : MainActivity.REF) if (l.id.equals("ref_adm" + level)) return true;
        return false;
    }

    private void toggle(AdminRef r, int level, boolean on) {
        LayerData ex = null;
        for (LayerData l : MainActivity.REF) if (l.id.equals("ref_adm" + level)) ex = l;
        if (ex != null) MainActivity.REF.remove(ex);
        if (on) MainActivity.REF.add(r.layer(level, S.ar, null));
        a.rebuild();
    }

    private void save(AdminRef r, int level) {
        LayerData l = r.layer(level, S.ar, null);
        MainActivity.WS.addLayerWithFeatures(l);
        a.rebuild();
        a.toast(S.t("حُفظت كطبقة في المشروع (مصدر: geoBoundaries، غير رسمية)", "Saved as a project layer (source: geoBoundaries, unofficial)"));
    }

    private View lookup(final AdminRef r) {
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("ما تتبعه نقطة؟", "Where is a point?")));
        final TextView out = Ui.text(a, "", 14, Theme.text, false);
        out.setPadding(0, Ui.dp(a, 8), 0, 0);
        c.addView(Ui.button(a, S.t("عند مركز الخريطة", "At map centre"), true, () -> {
            org.osmdroid.api.IGeoPoint g = a.map.getMapCenter();
            AdminRef.Hit h = r.locate(g.getLatitude(), g.getLongitude());
            if (!h.found()) {
                out.setText(S.t("خارج حدود العراق المرجعية.", "Outside the reference boundaries of Iraq."));
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("mohafadha: ").append(h.governorate(S.ar)).append('\n').append("gathaa: ").append(h.qadaa(S.ar).isEmpty() ? "—" : h.qadaa(S.ar));
            if (h.boundaryM >= 0 && h.boundaryM < 3000)
                sb.append('\n').append(S.t("⚠ قريبة من حد إداري (نحو " + Math.round(h.boundaryM) + " م): قد تكون النتيجة للجار.",
                        "⚠ Near an administrative border (about " + Math.round(h.boundaryM) + " m): the answer may be the neighbour."));
            out.setText(sb.toString());
        }), Ui.lp(-1, -2, 0, a, 0, 6, 0, 0));
        c.addView(out);
        return c;
    }

    private View browse(final AdminRef r) {
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("تصفح: محافظة ← قضاء", "Browse: governorate → district")));
        List<AdminRef.Unit> govs = new ArrayList<>(r.units(1));
        java.util.Collections.sort(govs, (x, y) -> x.name(S.ar).compareTo(y.name(S.ar)));
        for (final AdminRef.Unit g : govs) {
            LinearLayout row = Ui.row(a);
            boolean open = g.nameEn.equals(openGov);
            TextView t = Ui.text(a, (open ? "▾ " : "▸ ") + g.name(S.ar) + "  (" + g.nameEn + ")", 15, Theme.text, true);
            t.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
            t.setClickable(true);
            t.setOnClickListener(v -> {
                openGov = g.nameEn.equals(openGov) ? null : g.nameEn;
                a.showPage("admin");
            });
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(Ui.button(a, S.t("عرض", "Zoom"), false, () -> zoom(g.poly)), new LinearLayout.LayoutParams(Ui.dp(a, 84), -2));
            c.addView(row);
            if (!open) continue;
            List<AdminRef.Unit> ds = new ArrayList<>();
            for (AdminRef.Unit d : r.units(2)) if (d.parentEn.equals(g.nameEn)) ds.add(d);
            java.util.Collections.sort(ds, (x, y) -> x.name(S.ar).compareTo(y.name(S.ar)));
            for (final AdminRef.Unit d : ds) {
                LinearLayout dr = Ui.row(a);
                dr.setPadding(Ui.dp(a, 18), 0, 0, 0);
                TextView dt = Ui.text(a, d.name(S.ar) + "  (" + d.nameEn + ")", 14, Theme.sub, false);
                dt.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
                dr.addView(dt, new LinearLayout.LayoutParams(0, -2, 1f));
                dr.addView(Ui.button(a, S.t("عرض", "Zoom"), false, () -> zoom(d.poly)), new LinearLayout.LayoutParams(Ui.dp(a, 84), -2));
                c.addView(dr);
            }
            if (ds.isEmpty()) c.addView(UiKit.note(a, S.t("لا أقضية مسجلة لهذه المحافظة في المصدر.", "No districts for this governorate in the source.")));
            c.addView(Ui.button(a, S.t("حفظ أقضية " + g.name(true) + " في المشروع", "Save districts of " + g.nameEn + " to project"), false, () -> {
                MainActivity.WS.addLayerWithFeatures(r.layer(2, S.ar, g.nameEn));
                a.rebuild();
                a.toast(S.t("حُفظت في المشروع", "Saved to the project"));
            }), Ui.lp(-1, -2, 0, a, 18, 4, 0, 6));
        }
        return c;
    }

    private void zoom(Feature f) {
        LayerData tmp = new LayerData("tmp", f.name, Feature.POLYGON);
        tmp.features.add(f);
        a.showMap();
        a.zoomToLayer(tmp);
    }
}
