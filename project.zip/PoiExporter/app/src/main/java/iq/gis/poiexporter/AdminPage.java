package iq.gis.poiexporter;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.admin.AdminRef;

/**
 * Iraqi administrative boundaries (bundled, unofficial): show on the map, browse governorate → district,
 * find what contains a point, and save boundary layers into the project (for clipping and analysis).
 */
final class AdminPage {
    private final MainActivity a;
    private String openGov;

    AdminPage(MainActivity a) {
        this.a = a;
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        final AdminRef r = AdminRef.get();
        if (r == null) {
            p.addView(UiKit.note(a, S.t("بيانات الحدود غير موجودة في هذا الإصدار.", "Boundary data is missing in this build.")));
            return p;
        }
        p.addView(info(r));
        p.addView(show(r));
        p.addView(lookup(r));
        p.addView(fetchCard(r));
        p.addView(browse(r));
        return p;
    }

    private int fetchLevel = 1;

    /** Adds districts missing from the bundled set, fetched from OpenStreetMap by name or for the selected area. */
    private View fetchCard(final AdminRef r) {
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("إضافة أقضية ناقصة من OpenStreetMap", "Add missing districts from OpenStreetMap")));
        c.addView(UiKit.note(a, S.t(
                "المجموعة المدمجة لا تضم أقضية مثل أبو غريب والكرمة والشعب والحبانية. هذا الجلب يتم من هاتفك عبر الإنترنت، ويحفظ الحدود التي تختارها مع الحدود المدمجة فتُستخدم في ملء gathaa وفي القص. الحدود هي ما رسمه متطوعو OSM وليست رسمية؛ راجع النتيجة قبل اعتمادها. " + AdminFetch.CREDIT,
                "The bundled set lacks districts such as Abu Ghraib, Al-Karma, Al-Shu'ab and Al-Habbaniyah. This fetch runs on your phone over the internet and keeps the boundaries you pick next to the bundled ones, so they are used for filling gathaa and for clipping. They are what OSM volunteers mapped, not official; review before relying on them. " + AdminFetch.CREDIT)));
        final android.widget.EditText q = Ui.field(a, S.t("اسم القضاء (مثال: أبو غريب)", "District name (e.g. Abu Ghraib)"), android.text.InputType.TYPE_CLASS_TEXT);
        c.addView(q);
        c.addView(Ui.button(a, S.t("بحث بالاسم", "Search by name"), true, () -> {
            final String name = q.getText().toString().trim();
            if (name.isEmpty()) {
                a.toast(S.t("اكتب اسماً", "Type a name"));
                return;
            }
            fetch(r, () -> AdminFetch.byName(name));
        }), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        c.addView(UiKit.label(a, S.t("أو: كل ما داخل مستطيل التحديد الحالي", "Or: everything inside the current selection rectangle")));
        c.addView(Ui.chips(a, new String[]{S.t("مستوى OSM 5", "OSM level 5"), S.t("مستوى OSM 6", "OSM level 6"), S.t("مستوى OSM 4", "OSM level 4")},
                fetchLevel == 5 ? 0 : fetchLevel == 6 ? 1 : fetchLevel == 4 ? 2 : 0, i -> fetchLevel = i == 0 ? 5 : i == 1 ? 6 : 4));
        c.addView(Ui.button(a, S.t("جلب حدود المنطقة المحددة", "Fetch boundaries of the selected area"), false, () -> {
            final int lv = fetchLevel == 1 ? 5 : fetchLevel;
            final iq.gis.poiexporter.core.AreaSpec area = a.area();
            fetch(r, () -> AdminFetch.inArea(area, lv));
        }), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        c.addView(UiKit.note(a, S.t("الأقضية الناقصة في البيانات المدمجة (مثل أبو غريب والكرمة والشعب والحبانية) تُجلب من OpenStreetMap بزر واحد لكل المحافظات، وتُحفظ على الجهاز للعمل دون إنترنت. حدودها حدود OSM وليست رسمية.",
                "Districts missing from the bundled data (e.g. Abu Ghraib, Al-Karma, Al-Shu'ab, Al-Habbaniyah) are fetched from OpenStreetMap for all governorates with one button and saved on the device for offline use. Their outlines are OSM's, not official.")));
        c.addView(Ui.button(a, S.t("جلب كل الأقضية الناقصة (كل المحافظات)", "Fetch all missing districts (all governorates)"), true, () -> fetchAllMissing(r)),
                Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        int n = r.extras().size();
        if (n > 0) {
            c.addView(UiKit.note(a, S.t("أقضية مضافة من OSM: " + n, "Districts added from OSM: " + n)));
            c.addView(Ui.button(a, S.t("حذف الأقضية المضافة", "Remove added districts"), false, () -> a.messageConfirm(
                    S.t("حذف", "Remove"), S.t("تُحذف الأقضية المضافة فقط؛ المدمجة تبقى.", "Only the added districts are removed; the bundled ones stay."),
                    S.t("حذف", "Remove"), () -> {
                        r.loadExtras("");
                        AdminFetch.save(a);
                        a.showPage("admin");
                    })));
        }
        return c;
    }

    private interface Source {
        List<AdminFetch.Found> get() throws java.io.IOException;
    }

    private void fetch(final AdminRef r, final Source src) {
        a.toast(S.t("جارٍ الجلب من الإنترنت…", "Fetching online…"));
        new Thread(() -> {
            try {
                final List<AdminFetch.Found> found = src.get();
                a.runOnUiThread(() -> choose(r, found));
            } catch (final Throwable t) {
                ErrorLog.add("admin-fetch", t);
                a.runOnUiThread(() -> a.message(S.t("تعذّر الجلب", "Fetch failed"),
                        S.t("تحقق من الإنترنت ثم أعد المحاولة.\n", "Check the internet and try again.\n") + t.getMessage(), null, null));
            }
        }).start();
    }

    private void fetchAllMissing(final AdminRef r) {
        final LinearLayout bx = UiKit.col(a);
        bx.addView(UiKit.head(a, S.t("جلب الأقضية الناقصة", "Fetching missing districts")));
        final TextView msg = Ui.text(a, S.t("جارٍ البدء…", "Starting…"), 14, Theme.sub, false);
        bx.addView(msg);
        final boolean[] cancel = {false};
        bx.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, () -> cancel[0] = true), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        final android.app.Dialog dlg = a.card(bx);
        dlg.setCancelable(false);
        dlg.show();
        final List<AdminRef.Unit> govs = new ArrayList<>(r.units(1));
        new Thread(() -> {
            final List<AdminFetch.Found> all = new ArrayList<>();
            final java.util.Set<String> seen = new java.util.HashSet<>();
            int failed = 0;
            for (int i = 0; i < govs.size() && !cancel[0]; i++) {
                final AdminRef.Unit g = govs.get(i);
                final int idx = i;
                a.runOnUiThread(() -> msg.setText(g.name(S.ar) + "  (" + (idx + 1) + "/" + govs.size() + ")  •  " + S.t("وُجد ", "found ") + all.size()));
                try {
                    double[] bb = g.bbox;
                    double cLat = (bb[1] + bb[3]) / 2, cLon = (bb[0] + bb[2]) / 2;
                    double w = (bb[2] - bb[0]) * 111320.0 * Math.cos(Math.toRadians(cLat)), h = (bb[3] - bb[1]) * 111320.0;
                    for (AdminFetch.Found f : AdminFetch.inArea(iq.gis.poiexporter.core.AreaSpec.rotated(cLat, cLon, w, h, 0), 5)) {
                        if (r.knowsDistrict(f.nameAr, f.nameEn)) continue;
                        String key = iq.gis.poiexporter.core.io.DupFinder.normName(f.nameAr.isEmpty() ? f.nameEn : f.nameAr);
                        if (key.isEmpty() || !seen.add(key)) continue;
                        all.add(f);
                    }
                } catch (Throwable t) {
                    failed++;
                    ErrorLog.add("admin-fetch-all", t);
                }
            }
            final int fails = failed;
            a.runOnUiThread(() -> {
                dlg.dismiss();
                if (all.isEmpty()) {
                    a.message(S.t("لا أقضية جديدة", "No new districts"), fails > 0
                            ? S.t("تعذّر الجلب لـ " + fails + " محافظة (الإنترنت أو خادم OSM مشغول). أعد المحاولة لاحقاً.", fails + " governorates failed (network or busy OSM server). Try again later.")
                            : S.t("لم يُعثر على أقضية غير موجودة أصلاً.", "No district that is not already present was found."), null, null);
                } else {
                    if (fails > 0) a.toast(S.t("تعذّر الجلب لـ " + fails + " محافظة", fails + " governorates failed"));
                    choose(r, all, true);
                }
            });
        }).start();
    }

    private void choose(final AdminRef r, final List<AdminFetch.Found> found) {
        choose(r, found, false);
    }

    private void choose(final AdminRef r, final List<AdminFetch.Found> found, final boolean allOn) {
        if (found.isEmpty()) {
            a.message(S.t("لا نتائج", "No results"), S.t("لم يُعثر على حدود مطابقة. جرّب اسماً آخر أو مستوى OSM آخر.", "No matching boundary. Try another name or OSM level."), null, null);
            return;
        }
        final LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(a, S.t("اختر ما تريد إضافته (" + found.size() + ")", "Pick what to add (" + found.size() + ")"), 18, Theme.text, true));
        final boolean[] on = new boolean[found.size()];
        LinearLayout list = new LinearLayout(a);
        list.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < found.size(); i++) {
            final int idx = i;
            AdminFetch.Found f = found.get(i);
            String t = (f.nameAr.isEmpty() ? f.nameEn : f.nameAr) + (f.nameEn.isEmpty() || f.nameEn.equals(f.nameAr) ? "" : "  (" + f.nameEn + ")") + "\n" + f.detail;
            on[i] = allOn || found.size() <= 12; // small result sets (or a deliberate "fetch all") are ticked by default
            list.addView(UiKit.check(a, t, on[i], v -> on[idx] = v));
        }
        android.widget.ScrollView sv = new android.widget.ScrollView(a);
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(-1, Ui.dp(a, 380)));
        final android.app.Dialog d = a.card(box);
        box.addView(Ui.button(a, S.t("إضافة المحدد", "Add selected"), true, () -> {
            int added = 0;
            for (int i = 0; i < found.size(); i++) {
                if (!on[i]) continue;
                AdminFetch.Found f = found.get(i);
                if (r.addExtra(f.nameEn, f.nameAr, f.poly, AdminFetch.CREDIT) != null) added++;
            }
            d.dismiss();
            AdminFetch.save(a);
            a.toast(S.t("أُضيف " + added + " قضاء", added + " added"));
            a.showPage("admin");
        }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        d.show();
    }

    private View info(AdminRef r) {
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("الحدود الإدارية المرجعية — غير رسمية", "Reference boundaries — unofficial")));
        c.addView(UiKit.note(a, S.t(
                "• المحافظات (" + r.units(1).size() + "): " + r.source(1) + " — " + r.year(1) + " — " + r.license(1)
                        + "\n• الأقضية (" + r.units(2).size() + "): " + r.source(2) + " — " + r.year(2) + " — " + r.license(2)
                        + "\n\n" + r.accuracyNote(true)
                        + "\nلا تشمل النواحي (Nahia) ولا محافظة حلبجة منفصلة (ضمن السليمانية). الأسماء العربية وربط القضاء بالمحافظة أُضيفا يدوياً ولم يردا في المصدر؛ يُرجى مراجعتهما.\nالنواحي تُملأ من OpenStreetMap عند توفر الإنترنت.",
                "• Governorates (" + r.units(1).size() + "): " + r.source(1) + " — " + r.year(1) + " — " + r.license(1)
                        + "\n• Districts (" + r.units(2).size() + "): " + r.source(2) + " — " + r.year(2) + " — " + r.license(2)
                        + "\n\n" + r.accuracyNote(false)
                        + "\nNo sub-districts (Nahia) and no separate Halabja governorate. Arabic names and the district→governorate link were added by hand, not by the source; please review.\nNahia is filled from OpenStreetMap when online.")));
        return c;
    }

    private View show(final AdminRef r) {
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("عرض على الخريطة", "Show on map")));
        c.addView(UiKit.check(a, S.t("حدود المحافظات", "Governorate boundaries"), visible(1), v -> toggle(r, 1, v)));
        c.addView(UiKit.check(a, S.t("حدود الأقضية", "District boundaries"), visible(2), v -> toggle(r, 2, v)));
        c.addView(UiKit.note(a, S.t("المس حداً على الخريطة لمعرفة اسمه.", "Tap a boundary on the map to see its name.")));
        LinearLayout row = Ui.row(a);
        row.addView(Ui.button(a, S.t("حفظ المحافظات في المشروع", "Save governorates to project"), false, () -> save(r, 1)),
                Ui.lp(0, -2, 1f, a, 0, 8, 4, 0));
        row.addView(Ui.button(a, S.t("حفظ الأقضية في المشروع", "Save districts to project"), false, () -> save(r, 2)),
                Ui.lp(0, -2, 1f, a, 4, 8, 0, 0));
        c.addView(row);
        return c;
    }

    private boolean visible(int level) {
        for (LayerData l : MainActivity.REF) if (l.id.equals("ref_adm" + level)) return true;
        return false;
    }

    private void toggle(AdminRef r, int level, boolean on) {
        LayerData ex = null;
        for (LayerData l : MainActivity.REF) if (l.id.equals("ref_adm" + level)) ex = l;
        if (ex != null) MainActivity.REF.remove(ex);
        if (on) MainActivity.REF.add(r.layer(level, S.ar, null));
        a.rebuild();
    }

    private void save(AdminRef r, int level) {
        LayerData l = r.layer(level, S.ar, null);
        MainActivity.WS.addLayerWithFeatures(l);
        a.rebuild();
        a.toast(S.t("حُفظت كطبقة في المشروع (مصدر: geoBoundaries، غير رسمية)", "Saved as a project layer (source: geoBoundaries, unofficial)"));
    }

    private View lookup(final AdminRef r) {
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("ما تتبعه نقطة؟", "Where is a point?")));
        final TextView out = Ui.text(a, "", 14, Theme.text, false);
        out.setPadding(0, Ui.dp(a, 8), 0, 0);
        c.addView(Ui.button(a, S.t("عند مركز الخريطة", "At map centre"), true, () -> {
            org.osmdroid.api.IGeoPoint g = a.map.getMapCenter();
            AdminRef.Hit h = r.locate(g.getLatitude(), g.getLongitude());
            if (!h.found()) {
                out.setText(S.t("خارج حدود العراق المرجعية.", "Outside the reference boundaries of Iraq."));
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("mohafadha: ").append(h.governorate(S.ar)).append('\n').append("gathaa: ").append(h.qadaa(S.ar).isEmpty() ? "—" : h.qadaa(S.ar));
            if (h.boundaryM >= 0 && h.boundaryM < 3000)
                sb.append('\n').append(S.t("⚠ قريبة من حد إداري (نحو " + Math.round(h.boundaryM) + " م): قد تكون النتيجة للجار.",
                        "⚠ Near an administrative border (about " + Math.round(h.boundaryM) + " m): the answer may be the neighbour."));
            out.setText(sb.toString());
        }), Ui.lp(-1, -2, 0, a, 0, 6, 0, 0));
        c.addView(out);
        return c;
    }

    private View browse(final AdminRef r) {
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("تصفح: محافظة ← قضاء", "Browse: governorate → district")));
        List<AdminRef.Unit> govs = new ArrayList<>(r.units(1));
        java.util.Collections.sort(govs, (x, y) -> x.name(S.ar).compareTo(y.name(S.ar)));
        for (final AdminRef.Unit g : govs) {
            LinearLayout row = Ui.row(a);
            boolean open = g.nameEn.equals(openGov);
            TextView t = Ui.text(a, (open ? "▾ " : "▸ ") + g.name(S.ar) + "  (" + g.nameEn + ")", 15, Theme.text, true);
            t.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
            t.setClickable(true);
            t.setOnClickListener(v -> {
                openGov = g.nameEn.equals(openGov) ? null : g.nameEn;
                a.showPage("admin");
            });
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(Ui.button(a, S.t("عرض", "Zoom"), false, () -> zoom(g.poly)), new LinearLayout.LayoutParams(Ui.dp(a, 84), -2));
            c.addView(row);
            if (!open) continue;
            List<AdminRef.Unit> ds = new ArrayList<>();
            for (AdminRef.Unit d : r.units(2)) if (d.parentEn.equals(g.nameEn)) ds.add(d);
            java.util.Collections.sort(ds, (x, y) -> x.name(S.ar).compareTo(y.name(S.ar)));
            for (final AdminRef.Unit d : ds) {
                LinearLayout dr = Ui.row(a);
                dr.setPadding(Ui.dp(a, 18), 0, 0, 0);
                TextView dt = Ui.text(a, d.name(S.ar) + "  (" + d.nameEn + ")", 14, Theme.sub, false);
                dt.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
                dr.addView(dt, new LinearLayout.LayoutParams(0, -2, 1f));
                dr.addView(Ui.button(a, S.t("عرض", "Zoom"), false, () -> zoom(d.poly)), new LinearLayout.LayoutParams(Ui.dp(a, 84), -2));
                c.addView(dr);
            }
            if (ds.isEmpty()) c.addView(UiKit.note(a, S.t("لا أقضية مسجلة لهذه المحافظة في المصدر.", "No districts for this governorate in the source.")));
            c.addView(Ui.button(a, S.t("حفظ أقضية " + g.name(true) + " في المشروع", "Save districts of " + g.nameEn + " to project"), false, () -> {
                MainActivity.WS.addLayerWithFeatures(r.layer(2, S.ar, g.nameEn));
                a.rebuild();
                a.toast(S.t("حُفظت في المشروع", "Saved to the project"));
            }), Ui.lp(-1, -2, 0, a, 18, 4, 0, 6));
        }
        return c;
    }

    private void zoom(Feature f) {
        LayerData tmp = new LayerData("tmp", f.name, Feature.POLYGON);
        tmp.features.add(f);
        a.showMap();
        a.zoomToLayer(tmp);
    }
}
