package iq.gis.poiexporter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import iq.gis.poiexporter.core.Catalog;
import iq.gis.poiexporter.core.Feature;

/** Google Maps place extraction through an Apify actor (start run, poll, read dataset). */
public final class GMaps {
    public static final String DEFAULT_ACTOR = "AabCualFIriz3X6Fs";
    private static final String API = "https://api.apify.com/v2/";

    /** {Arabic label, Google Maps search term, index into Catalog.SECTORS}. */
    public static final String[][] CATS = {
            // 0 transport
            {"محطة وقود", "gas station", "0"}, {"موقف سيارات", "parking", "0"}, {"محطة حافلات", "bus station", "0"},
            {"محطة قطار", "train station", "0"}, {"مطار", "airport", "0"}, {"تأجير سيارات", "car rental", "0"},
            {"تصليح سيارات", "car repair", "0"}, {"محطة تاكسي", "taxi stand", "0"}, {"مغسلة سيارات", "car wash", "0"},
            {"معرض سيارات", "car dealer", "0"}, {"ميناء", "port", "0"},
            // 1 tourism
            {"فندق", "hotel", "1"}, {"نزل", "guest house", "1"}, {"منتجع", "resort", "1"},
            {"معلم سياحي", "tourist attraction", "1"}, {"وكالة سفر", "travel agency", "1"}, {"شقق فندقية", "apartment hotel", "1"},
            // 2 political
            {"مقر حزب سياسي", "political party office", "2"}, {"سفارة", "embassy", "2"}, {"قنصلية", "consulate", "2"},
            // 3 administrative
            {"دائرة حكومية", "government office", "3"}, {"مركز شرطة", "police station", "3"}, {"محكمة", "courthouse", "3"},
            {"مكتب بريد", "post office", "3"}, {"كاتب عدل", "notary public", "3"}, {"محامي", "lawyer", "3"},
            {"بلدية", "city government office", "3"},
            // 4 civil
            {"منظمة غير حكومية", "non-profit organization", "4"}, {"جمعية خيرية", "charity", "4"},
            {"الدفاع المدني", "fire station", "4"}, {"مقبرة", "cemetery", "4"}, {"مركز مجتمعي", "community center", "4"},
            // 5 financial
            {"مصرف", "bank", "5"}, {"صراف آلي", "ATM", "5"}, {"صرافة", "currency exchange service", "5"},
            {"شركة تأمين", "insurance agency", "5"}, {"محاسب", "accountant", "5"}, {"تحويل أموال", "money transfer service", "5"},
            // 6 commercial
            {"سوبرماركت", "supermarket", "6"}, {"مول", "shopping mall", "6"}, {"سوق", "market", "6"},
            {"مطعم", "restaurant", "6"}, {"مقهى", "cafe", "6"}, {"مخبز", "bakery", "6"}, {"وجبات سريعة", "fast food restaurant", "6"},
            {"حلويات", "dessert shop", "6"}, {"محل ملابس", "clothing store", "6"}, {"مجوهرات", "jewelry store", "6"},
            {"إلكترونيات", "electronics store", "6"}, {"أثاث", "furniture store", "6"}, {"مواد بناء", "building materials store", "6"},
            {"محل هواتف", "mobile phone store", "6"}, {"حلاق", "barber shop", "6"}, {"محل مواد إنشائية", "hardware store", "6"},
            {"جزار", "butcher shop", "6"}, {"محل خضار وفواكه", "fruit and vegetable store", "6"},
            // 7 education
            {"مدرسة", "school", "7"}, {"مدرسة ابتدائية", "primary school", "7"}, {"مدرسة ثانوية", "high school", "7"},
            {"روضة أطفال", "kindergarten", "7"}, {"جامعة", "university", "7"}, {"كلية", "college", "7"},
            {"مدرسة مهنية", "vocational school", "7"}, {"مركز تدريب", "training center", "7"}, {"مدرسة لغات", "language school", "7"},
            // 8 entertainment
            {"سينما", "movie theater", "8"}, {"مدينة ألعاب", "amusement park", "8"}, {"حديقة عامة", "park", "8"},
            {"قاعة مناسبات", "wedding venue", "8"}, {"مسبح", "swimming pool", "8"}, {"حديقة حيوان", "zoo", "8"},
            {"مقهى إنترنت", "internet cafe", "8"}, {"صالة بولينغ", "bowling alley", "8"}, {"ملعب أطفال", "playground", "8"},
            // 9 sports
            {"نادي رياضي", "gym", "9"}, {"ملعب", "stadium", "9"}, {"ملعب كرة قدم", "soccer field", "9"},
            {"مجمع رياضي", "sports complex", "9"}, {"نادٍ رياضي", "sports club", "9"},
            // 10 services
            {"مغسلة ملابس", "laundry", "10"}, {"مكتب عقاري", "real estate agency", "10"}, {"شركة كهرباء", "electric utility company", "10"},
            {"سباك", "plumber", "10"}, {"كهربائي", "electrician", "10"}, {"شركة شحن وتوصيل", "courier service", "10"},
            {"شركة نقل أثاث", "moving company", "10"}, {"شركة اتصالات", "telecommunications service provider", "10"},
            // 11 religious
            {"مسجد", "mosque", "11"}, {"كنيسة", "church", "11"}, {"مركز إسلامي", "islamic center", "11"},
            {"مزار / ضريح", "shrine", "11"}, {"مدرسة دينية", "islamic school", "11"}, {"منظمة دينية", "religious organization", "11"},
            // 12 agricultural
            {"مزرعة", "farm", "12"}, {"مشتل", "plant nursery", "12"}, {"أعلاف", "animal feed store", "12"},
            {"مركز زراعي", "agricultural service", "12"}, {"طبيب بيطري", "veterinarian", "12"}, {"مركز حدائق", "garden center", "12"},
            // 13 health
            {"مستشفى", "hospital", "13"}, {"عيادة", "clinic", "13"}, {"صيدلية", "pharmacy", "13"}, {"طبيب أسنان", "dentist", "13"},
            {"مختبر طبي", "medical laboratory", "13"}, {"طبيب", "doctor", "13"}, {"مركز صحي", "community health center", "13"},
            {"علاج طبيعي", "physiotherapist", "13"}, {"محل نظارات", "optician", "13"},
            // 14 industrial
            {"مصنع", "factory", "14"}, {"مصنّع", "manufacturer", "14"}, {"ورشة حدادة", "metal fabricator", "14"},
            {"شركة مقاولات", "construction company", "14"}, {"محطة توليد كهرباء", "power station", "14"}, {"مخزن", "warehouse", "14"},
            // 15 cultural
            {"مكتبة عامة", "library", "15"}, {"متحف", "museum", "15"}, {"معرض فني", "art gallery", "15"},
            {"مسرح", "theater", "15"}, {"مركز ثقافي", "cultural center", "15"}, {"مكتبة (بيع الكتب)", "book store", "15"},
            {"معلم تاريخي", "historical landmark", "15"}
    };

    public interface Progress {
        void update(String status);

        boolean cancelled();
    }

    private GMaps() {
    }

    public static String sectorOf(String term) {
        if (term == null) return "";
        for (String[] c : CATS) {
            if (c[1].equalsIgnoreCase(term.trim())) return Catalog.SECTORS[Integer.parseInt(c[2])];
        }
        return "";
    }

    /** Runs the actor and returns the extracted places as point features. */
    public static List<Feature> run(String token, String actor, List<String> terms, String location, int maxPerSearch,
                                    String gov, String qadaa, String nahia, boolean arabic, Progress p) throws Exception {
        JSONObject in = new JSONObject();
        JSONArray st = new JSONArray();
        for (String t : terms) st.put(t);
        in.put("searchStringsArray", st);
        in.put("locationQueries", new JSONArray().put(location));
        in.put("maxCrawledPlacesPerSearch", maxPerSearch);
        in.put("languages", new JSONArray().put(arabic ? "ar" : "en"));
        in.put("geoStrictMatch", true);
        in.put("skipClosedPlaces", true);

        p.update(S.t("جارٍ بدء المهمة…", "Starting run…"));
        JSONObject started = new JSONObject(http("POST", API + "actors/" + actor + "/runs", token, in.toString()));
        JSONObject data = started.getJSONObject("data");
        String runId = data.getString("id");
        String dataset = data.getString("defaultDatasetId");

        long t0 = System.currentTimeMillis();
        String status = "READY";
        while (true) {
            if (p.cancelled()) {
                try {
                    http("POST", API + "actor-runs/" + runId + "/abort", token, "{}");
                } catch (Exception ignored) {
                    // best effort
                }
                throw new IOException("cancelled");
            }
            JSONObject r = new JSONObject(http("GET", API + "actor-runs/" + runId, token, null)).getJSONObject("data");
            status = r.optString("status", "");
            p.update(S.t("الحالة: ", "Status: ") + status + " — " + ((System.currentTimeMillis() - t0) / 1000) + "s");
            if (status.equals("SUCCEEDED")) break;
            if (status.equals("FAILED") || status.equals("ABORTED") || status.equals("TIMED-OUT")) {
                throw new IOException(S.t("فشلت المهمة: ", "Run failed: ") + status);
            }
            if (System.currentTimeMillis() - t0 > 40L * 60 * 1000) throw new IOException("timeout");
            Thread.sleep(4000);
        }

        p.update(S.t("جارٍ تنزيل النتائج…", "Downloading results…"));
        String items = http("GET", API + "datasets/" + dataset + "/items?format=json&clean=true&limit=5000"
                + "&fields=title,categoryName,state,city,neighborhood,location,placeId,searchString,permanentlyClosed", token, null);
        JSONArray arr = new JSONArray(items);
        List<Feature> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        Map<String, String> sectorCache = new HashMap<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            JSONObject loc = o.optJSONObject("location");
            if (loc == null) continue;
            double lat = loc.optDouble("lat", Double.NaN), lng = loc.optDouble("lng", Double.NaN);
            if (Double.isNaN(lat) || Double.isNaN(lng)) continue;
            if (o.optBoolean("permanentlyClosed", false)) continue;
            String name = str(o, "title");
            String key = str(o, "placeId");
            if (key.isEmpty()) key = name + "|" + lat + "|" + lng;
            if (!seen.add(key)) continue;
            Feature f = Feature.point(lat, lng);
            f.name = name;
            String term = str(o, "searchString");
            String cn = str(o, "categoryName");
            f.type = cn.isEmpty() ? term : cn;
            String sec = sectorCache.get(term);
            if (sec == null) {
                sec = sectorOf(term);
                sectorCache.put(term, sec);
            }
            f.category = sec;
            f.governorate = gov.isEmpty() ? str(o, "state") : gov;
            f.qadaa = qadaa.isEmpty() ? str(o, "city") : qadaa;
            f.nahiya = nahia.isEmpty() ? str(o, "neighborhood") : nahia;
            out.add(f);
        }
        return out;
    }

    private static String str(JSONObject o, String k) {
        if (o.isNull(k)) return "";
        return o.optString(k, "").trim();
    }

    static String http(String method, String url, String token, String body) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(20000);
            c.setReadTimeout(120000);
            c.setRequestMethod(method);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("User-Agent", "PoiExporter/2.8 (Android; iq.gis.poiexporter)");
            if (body != null) {
                byte[] b = body.getBytes("UTF-8");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setFixedLengthStreamingMode(b.length);
                OutputStream os = c.getOutputStream();
                os.write(b);
                os.close();
            }
            int code = c.getResponseCode();
            InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String s = read(is);
            if (code >= 400) {
                String msg = s;
                try {
                    msg = new JSONObject(s).getJSONObject("error").optString("message", s);
                } catch (Exception ignored) {
                    // keep raw body
                }
                if (code == 401) msg = S.t("مفتاح API غير صحيح", "Invalid API token") + " (" + msg + ")";
                throw new IOException("HTTP " + code + ": " + msg);
            }
            return s;
        } finally {
            c.disconnect();
        }
    }

    private static String read(InputStream is) throws IOException {
        if (is == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();
        return new String(bo.toByteArray(), "UTF-8");
    }
}
