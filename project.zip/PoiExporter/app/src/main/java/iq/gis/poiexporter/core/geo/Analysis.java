package iq.gis.poiexporter.core.geo;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.Jts;
import iq.gis.poiexporter.core.LandmarkFields;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.io.DupFinder;

import org.locationtech.jts.algorithm.MinimumDiameter;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Envelope;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.index.strtree.STRtree;
import org.locationtech.jts.triangulate.VoronoiDiagramBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Extra analysis tools that work on whole layers: filter, summary, proximity, centroids, density grid, Thiessen
 * polygons, clusters, nearest-neighbour index, minimum bounding rectangle, point path, simplify, merge.
 * Metric work uses a local equirectangular plane centred on the data (error well under 0.5% for regions up to
 * about 100 km; the results are for analysis, not for surveying).
 */
public final class Analysis {
    private Analysis() {
    }

    private static IllegalArgumentException bad(String ar, String en) {
        return new IllegalArgumentException(S.t(ar, en));
    }

    // ---------------------------------------------------------------------------------------------- local plane

    public static final class Plane {
        final double lat0, lon0, kx, ky = 111320.0;

        Plane(double lat0, double lon0) {
            this.lat0 = lat0;
            this.lon0 = lon0;
            this.kx = 111320.0 * Math.cos(Math.toRadians(lat0));
        }

        public double x(double lon) {
            return (lon - lon0) * kx;
        }

        public double y(double lat) {
            return (lat - lat0) * ky;
        }

        public double lon(double x) {
            return lon0 + x / kx;
        }

        public double lat(double y) {
            return lat0 + y / ky;
        }

        public static Plane around(List<Feature> pts) {
            double sl = 0, so = 0;
            int n = 0;
            for (Feature f : pts) {
                sl += f.lat;
                so += f.lon;
                n++;
            }
            return n == 0 ? new Plane(33, 44) : new Plane(sl / n, so / n);
        }
    }

    private static List<Feature> points(LayerData l) {
        List<Feature> r = new ArrayList<>();
        for (Feature f : l.features) {
            if (f.geom == Feature.POINT && !(Double.isNaN(f.lat) || Double.isNaN(f.lon))) r.add(f);
        }
        return r;
    }

    private static LayerData result(LayerData src, String label, int geom) {
        LayerData r = new LayerData("an_" + Feature.newId(), label, geom);
        r.color = src.color;
        r.width = src.width;
        r.opacity = src.opacity;
        r.kind = "result";
        return r;
    }

    private static Feature cloneAttrs(Feature from, Feature to) {
        to.name = from.name;
        to.type = from.type;
        to.category = from.category;
        to.qadaa = from.qadaa;
        to.nahiya = from.nahiya;
        to.governorate = from.governorate;
        to.attrs.putAll(from.attrs);
        return to;
    }

    private static Feature polygonFeature(double[] ring) {
        Feature f = new Feature();
        f.geom = Feature.POLYGON;
        f.id = Feature.newId();
        f.parts.add(ring);
        Geo.setRepresentative(f);
        return f;
    }

    // ---------------------------------------------------------------------------------------------- 1 filter

    public static final String[] FIELD_NAMES = {"name", "type", "Gategory", "gathaa", "Nahia", "mohafadha"};

    public enum Match {CONTAINS, EQUALS, EMPTY, NOT_EMPTY}

    public static String field(Feature f, int idx) {
        return LandmarkFields.text(f)[idx];
    }

    /** Features whose field matches. Text matching ignores Arabic diacritics, hamza/yaa variants, case and spaces. */
    public static LayerData filter(LayerData src, int fieldIdx, String text, Match mode) {
        if (fieldIdx < 0 || fieldIdx > 5) throw bad("حقل غير صالح", "Invalid field");
        String q = DupFinder.normName(text);
        if ((mode == Match.CONTAINS || mode == Match.EQUALS) && q.isEmpty()) throw bad("اكتب نصاً للبحث", "Enter text to search");
        LayerData r = result(src, src.label + " [" + FIELD_NAMES[fieldIdx] + "]", src.geom);
        for (Feature f : src.features) {
            String v = field(f, fieldIdx);
            String nv = DupFinder.normName(v);
            boolean ok;
            switch (mode) {
                case CONTAINS:
                    ok = nv.contains(q);
                    break;
                case EQUALS:
                    ok = nv.equals(q);
                    break;
                case EMPTY:
                    ok = v.trim().isEmpty();
                    break;
                default:
                    ok = !v.trim().isEmpty();
            }
            if (ok) {
                Feature c = f.copy();
                c.id = Feature.newId();
                r.features.add(c);
            }
        }
        return r;
    }

    // ---------------------------------------------------------------------------------------------- 2 summary

    /** Count of features per value of the field, largest first; empty values are grouped under "". */
    public static LinkedHashMap<String, Integer> summarize(LayerData src, int fieldIdx) {
        if (fieldIdx < 0 || fieldIdx > 5) throw bad("حقل غير صالح", "Invalid field");
        Map<String, Integer> m = new LinkedHashMap<>();
        Map<String, String> shown = new LinkedHashMap<>();
        for (Feature f : src.features) {
            String v = field(f, fieldIdx).trim();
            String k = DupFinder.normName(v);
            if (!shown.containsKey(k)) shown.put(k, v);
            Integer c = m.get(k);
            m.put(k, c == null ? 1 : c + 1);
        }
        List<Map.Entry<String, Integer>> es = new ArrayList<>(m.entrySet());
        Collections.sort(es, (a, b) -> b.getValue() != a.getValue().intValue() ? b.getValue() - a.getValue() : shown.get(a.getKey()).compareTo(shown.get(b.getKey())));
        LinkedHashMap<String, Integer> out = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> e : es) out.put(shown.get(e.getKey()), e.getValue());
        return out;
    }

    public static String summaryText(LayerData src, int fieldIdx, boolean ar) {
        LinkedHashMap<String, Integer> m = summarize(src, fieldIdx);
        StringBuilder b = new StringBuilder();
        int total = src.features.size();
        for (Map.Entry<String, Integer> e : m.entrySet()) {
            String k = e.getKey().isEmpty() ? (ar ? "(فارغ)" : "(empty)") : e.getKey();
            b.append(k).append(" — ").append(e.getValue()).append(String.format(java.util.Locale.US, "  (%.1f%%)", total == 0 ? 0 : 100.0 * e.getValue() / total)).append('\n');
        }
        return b.toString().trim();
    }

    // ---------------------------------------------------------------------------------------------- 3 proximity

    /** Features within radiusM of the position (points by position, other geometry by its centre of mass). Sorted by distance; attrs dist_m. */
    public static LayerData withinRadius(LayerData src, double lat, double lon, double radiusM) {
        if (!(radiusM > 0)) throw bad("نصف القطر يجب أن يكون موجباً", "Radius must be positive");
        List<Object[]> hits = new ArrayList<>();
        for (Feature f : src.features) {
            double flat = f.lat, flon = f.lon;
            if (f.geom != Feature.POINT) {
                try {
                    double[] c = GeoOps.centroid(f);
                    flon = c[0];
                    flat = c[1];
                } catch (RuntimeException e) {
                    continue;
                }
            }
            double d = Geodesy.distance(lat, lon, flat, flon);
            if (d <= radiusM) hits.add(new Object[]{f, d});
        }
        Collections.sort(hits, (a, b) -> Double.compare((Double) a[1], (Double) b[1]));
        LayerData r = result(src, src.label + S.t(" (ضمن ", " (within ") + Math.round(radiusM) + " m)", src.geom);
        for (Object[] h : hits) {
            Feature c = ((Feature) h[0]).copy();
            c.id = Feature.newId();
            c.attrs.put("dist_m", String.valueOf(Math.round((Double) h[1])));
            r.features.add(c);
        }
        return r;
    }

    // ---------------------------------------------------------------------------------------------- 4 centroids

    public static LayerData centroids(LayerData src) {
        LayerData r = result(src, src.label + S.t(" (مراكز)", " (centroids)"), Feature.POINT);
        for (Feature f : src.features) {
            double[] c;
            if (f.geom == Feature.POINT) c = new double[]{f.lon, f.lat};
            else {
                try {
                    c = GeoOps.centroid(f);
                } catch (RuntimeException e) {
                    continue;
                }
            }
            r.features.add(cloneAttrs(f, Feature.point(c[1], c[0])));
        }
        return r;
    }

    // ---------------------------------------------------------------------------------------------- 5 density grid

    /** Square cells of cellM metres over the layer's extent holding the number of points inside (name = count). Empty cells dropped unless keepEmpty. */
    public static LayerData densityGrid(LayerData src, double cellM, boolean keepEmpty) {
        List<Feature> pts = points(src);
        if (pts.isEmpty()) throw bad("لا توجد نقاط في الطبقة", "The layer has no points");
        if (!(cellM > 0)) throw bad("حجم الخلية يجب أن يكون موجباً", "Cell size must be positive");
        Plane pl = Plane.around(pts);
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (Feature f : pts) {
            double x = pl.x(f.lon), y = pl.y(f.lat);
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
        }
        int cols = (int) Math.floor((maxX - minX) / cellM) + 1, rows = (int) Math.floor((maxY - minY) / cellM) + 1;
        if ((long) cols * rows > 500_000L) throw bad("الشبكة كبيرة جداً (" + (long) cols * rows + " خلية)، زد الحجم", "Grid too large (" + (long) cols * rows + " cells); increase the cell size");
        int[] count = new int[cols * rows];
        for (Feature f : pts) {
            int c = Math.min(cols - 1, (int) Math.floor((pl.x(f.lon) - minX) / cellM));
            int rw = Math.min(rows - 1, (int) Math.floor((pl.y(f.lat) - minY) / cellM));
            count[rw * cols + c]++;
        }
        LayerData r = result(src, src.label + S.t(" (كثافة ", " (density ") + Math.round(cellM) + " m)", Feature.POLYGON);
        for (int rw = 0; rw < rows; rw++) {
            for (int c = 0; c < cols; c++) {
                int n = count[rw * cols + c];
                if (n == 0 && !keepEmpty) continue;
                double x0 = minX + c * cellM, y0 = minY + rw * cellM;
                double[] ring = {pl.lon(x0), pl.lat(y0), pl.lon(x0 + cellM), pl.lat(y0), pl.lon(x0 + cellM), pl.lat(y0 + cellM),
                        pl.lon(x0), pl.lat(y0 + cellM), pl.lon(x0), pl.lat(y0)};
                Feature f = polygonFeature(ring);
                f.name = String.valueOf(n);
                f.attrs.put("count", String.valueOf(n));
                f.attrs.put("row", String.valueOf(rw));
                f.attrs.put("col", String.valueOf(c));
                r.features.add(f);
            }
        }
        return r;
    }

    // ---------------------------------------------------------------------------------------------- 6 thiessen

    /** Thiessen (Voronoi) polygons around the points, limited to the layer extent grown by 10%. Each cell takes its point's attributes. */
    public static LayerData thiessen(LayerData src) {
        List<Feature> pts = points(src);
        if (pts.size() < 3) throw bad("يلزم 3 نقاط على الأقل", "At least 3 points are needed");
        if (pts.size() > 20000) throw bad("أكثر من 20000 نقطة: صفّ الطبقة أولاً", "More than 20000 points: filter the layer first");
        Plane pl = Plane.around(pts);
        List<Coordinate> cs = new ArrayList<>();
        STRtree sites = new STRtree();
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (Feature f : pts) {
            Coordinate c = new Coordinate(pl.x(f.lon), pl.y(f.lat));
            cs.add(c);
            sites.insert(new Envelope(c), new Object[]{c, f});
            minX = Math.min(minX, c.x);
            maxX = Math.max(maxX, c.x);
            minY = Math.min(minY, c.y);
            maxY = Math.max(maxY, c.y);
        }
        double padX = Math.max(50, (maxX - minX) * 0.1), padY = Math.max(50, (maxY - minY) * 0.1);
        Envelope clip = new Envelope(minX - padX, maxX + padX, minY - padY, maxY + padY);
        VoronoiDiagramBuilder vb = new VoronoiDiagramBuilder();
        vb.setSites(cs);
        vb.setTolerance(0.01);
        Geometry diagram = vb.getDiagram(Jts.GF);
        Geometry clipBox = Jts.GF.toGeometry(clip);
        LayerData r = result(src, src.label + S.t(" (ثيسن)", " (Thiessen)"), Feature.POLYGON);
        for (int i = 0; i < diagram.getNumGeometries(); i++) {
            Geometry cell = diagram.getGeometryN(i);
            if (cell.isEmpty()) continue;
            // robust overlay: cocircular sites (e.g. a regular grid) make the plain intersection throw a noding error
            cell = org.locationtech.jts.operation.overlayng.OverlayNGRobust.overlay(cell, clipBox, org.locationtech.jts.operation.overlayng.OverlayNG.INTERSECTION);
            if (cell.isEmpty() || !(cell instanceof org.locationtech.jts.geom.Polygon)) {
                if (cell.getNumGeometries() == 0) continue;
                cell = cell.getGeometryN(0);
            }
            Feature owner = null;
            for (Object o : sites.query(cell.getEnvelopeInternal())) {
                Object[] s = (Object[]) o;
                if (cell.intersects(Jts.GF.createPoint((Coordinate) s[0]))) {
                    owner = (Feature) s[1];
                    break;
                }
            }
            Coordinate[] ring = cell.getCoordinates();
            double[] ll = new double[ring.length * 2];
            for (int k = 0; k < ring.length; k++) {
                ll[2 * k] = pl.lon(ring[k].x);
                ll[2 * k + 1] = pl.lat(ring[k].y);
            }
            Feature f = polygonFeature(ll);
            if (owner != null) cloneAttrs(owner, f);
            r.features.add(f);
        }
        return r;
    }

    // ---------------------------------------------------------------------------------------------- 7 clusters

    public static final class Cluster {
        public final List<Feature> members = new ArrayList<>();
        public double lat, lon;
    }

    /** DBSCAN: points with at least minPts neighbours within epsM (the point itself counts) form clusters; the rest is noise. */
    public static List<Cluster> clusters(LayerData src, double epsM, int minPts) {
        List<Feature> pts = points(src);
        if (!(epsM > 0)) throw bad("المسافة يجب أن تكون موجبة", "Distance must be positive");
        if (minPts < 2) throw bad("أقل عدد نقاط 2", "Minimum points is 2");
        if (pts.size() > 50000) throw bad("أكثر من 50000 نقطة: صفّ الطبقة أولاً", "More than 50000 points: filter the layer first");
        Plane pl = Plane.around(pts);
        int n = pts.size();
        double[] x = new double[n], y = new double[n];
        Map<Long, List<Integer>> grid = new java.util.HashMap<>();
        for (int i = 0; i < n; i++) {
            x[i] = pl.x(pts.get(i).lon);
            y[i] = pl.y(pts.get(i).lat);
            long key = cell(x[i], y[i], epsM);
            List<Integer> l = grid.get(key);
            if (l == null) grid.put(key, l = new ArrayList<>());
            l.add(i);
        }
        int[] label = new int[n]; // 0 unvisited, -1 noise, >0 cluster id
        int id = 0;
        List<Cluster> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (label[i] != 0) continue;
            List<Integer> nb = neighbours(i, x, y, grid, epsM);
            if (nb.size() < minPts) {
                label[i] = -1;
                continue;
            }
            id++;
            Cluster cl = new Cluster();
            out.add(cl);
            label[i] = id;
            List<Integer> queue = new ArrayList<>(nb);
            for (int qi = 0; qi < queue.size(); qi++) {
                int j = queue.get(qi);
                if (label[j] == -1) label[j] = id;
                if (label[j] != 0) continue;
                label[j] = id;
                List<Integer> nb2 = neighbours(j, x, y, grid, epsM);
                if (nb2.size() >= minPts) queue.addAll(nb2);
            }
        }
        for (int i = 0; i < n; i++) if (label[i] > 0) out.get(label[i] - 1).members.add(pts.get(i));
        for (Cluster c : out) {
            double sl = 0, so = 0;
            for (Feature f : c.members) {
                sl += f.lat;
                so += f.lon;
            }
            c.lat = sl / c.members.size();
            c.lon = so / c.members.size();
        }
        Collections.sort(out, (a, b) -> b.members.size() - a.members.size());
        return out;
    }

    private static long cell(double x, double y, double eps) {
        return ((long) Math.floor(x / eps)) * 4000037L + (long) Math.floor(y / eps);
    }

    private static List<Integer> neighbours(int i, double[] x, double[] y, Map<Long, List<Integer>> grid, double eps) {
        List<Integer> r = new ArrayList<>();
        long cx = (long) Math.floor(x[i] / eps), cy = (long) Math.floor(y[i] / eps);
        for (long dx = -1; dx <= 1; dx++) {
            for (long dy = -1; dy <= 1; dy++) {
                List<Integer> l = grid.get((cx + dx) * 4000037L + (cy + dy));
                if (l == null) continue;
                for (int j : l) {
                    double ddx = x[i] - x[j], ddy = y[i] - y[j];
                    if (ddx * ddx + ddy * ddy <= eps * eps) r.add(j);
                }
            }
        }
        return r;
    }

    /** Point layer of cluster centres (name "تجمع k — n", attrs count) and, optionally, a polygon layer of their convex hulls. */
    public static List<LayerData> clusterLayers(LayerData src, double epsM, int minPts, boolean hulls) {
        List<Cluster> cl = clusters(src, epsM, minPts);
        LayerData pts = result(src, src.label + S.t(" (تجمعات)", " (clusters)"), Feature.POINT);
        LayerData hl = result(src, src.label + S.t(" (حدود التجمعات)", " (cluster hulls)"), Feature.POLYGON);
        int k = 0;
        for (Cluster c : cl) {
            k++;
            Feature p = Feature.point(c.lat, c.lon);
            p.name = S.t("تجمع ", "Cluster ") + k + " — " + c.members.size();
            p.attrs.put("count", String.valueOf(c.members.size()));
            pts.features.add(p);
            if (hulls) {
                Feature h = GeoOps.convexHull(c.members);
                if (h != null && h.geom == Feature.POLYGON) {
                    h.id = Feature.newId();
                    h.name = p.name;
                    h.attrs.put("count", String.valueOf(c.members.size()));
                    hl.features.add(h);
                }
            }
        }
        List<LayerData> r = new ArrayList<>();
        r.add(pts);
        if (hulls && !hl.features.isEmpty()) r.add(hl);
        return r;
    }

    // ---------------------------------------------------------------------------------------------- 8 nearest neighbour

    public static final class NN {
        public int n;
        public double observedM, expectedM, ratio, z, areaKm2;

        public String verdict(boolean ar) {
            if (Math.abs(z) < 1.96) return ar ? "عشوائي (لا فرق معنوي عن التوزيع العشوائي)" : "Random (not significantly different)";
            return ratio < 1 ? (ar ? "متجمّع" : "Clustered") : (ar ? "متباعد" : "Dispersed");
        }

        public String toText(boolean ar) {
            return (ar ? "عدد النقاط: " : "Points: ") + n
                    + "\n" + (ar ? "متوسط أقرب جار (ملاحظ): " : "Mean nearest-neighbour distance (observed): ") + String.format(java.util.Locale.US, "%.1f m", observedM)
                    + "\n" + (ar ? "المتوقع عشوائياً: " : "Expected for random: ") + String.format(java.util.Locale.US, "%.1f m", expectedM)
                    + "\n" + (ar ? "مؤشر أقرب جار R: " : "Nearest-neighbour ratio R: ") + String.format(java.util.Locale.US, "%.2f", ratio)
                    + "\nz = " + String.format(java.util.Locale.US, "%.2f", z)
                    + "\n" + (ar ? "المساحة المرجعية (الغلاف المحدب): " : "Reference area (convex hull): ") + String.format(java.util.Locale.US, "%.3f km²", areaKm2)
                    + "\n" + (ar ? "النمط: " : "Pattern: ") + verdict(ar)
                    + "\n\n" + (ar ? "ملاحظة: يتأثر المؤشر بحدود المنطقة المختارة؛ استخدمه كمؤشر وليس كإثبات." : "Note: the index depends on the study-area boundary (here the convex hull); treat it as an indicator, not proof.");
        }
    }

    /** Clark-Evans nearest-neighbour index in the local plane; study area = convex hull of the points. */
    public static NN nearestNeighbour(LayerData src) {
        List<Feature> pts = points(src);
        if (pts.size() < 4) throw bad("يلزم 4 نقاط على الأقل", "At least 4 points are needed");
        if (pts.size() > 20000) throw bad("أكثر من 20000 نقطة: صفّ الطبقة أولاً", "More than 20000 points: filter the layer first");
        Plane pl = Plane.around(pts);
        int n = pts.size();
        STRtree tree = new STRtree();
        Coordinate[] cs = new Coordinate[n];
        for (int i = 0; i < n; i++) {
            cs[i] = new Coordinate(pl.x(pts.get(i).lon), pl.y(pts.get(i).lat));
            tree.insert(new Envelope(cs[i]), cs[i]);
        }
        double sum = 0;
        for (int i = 0; i < n; i++) {
            double best = Double.MAX_VALUE;
            // nearest other point: ask for 2 nearest and take the one that is not itself (duplicates give 0)
            Object[] nn = tree.nearestNeighbour(new Envelope(cs[i]), cs[i], (a, b) -> ((Coordinate) a.getItem()).distance((Coordinate) b.getItem()), 2);
            for (Object o : nn) {
                if (o == cs[i]) continue;
                best = Math.min(best, cs[i].distance((Coordinate) o));
            }
            if (best == Double.MAX_VALUE) best = 0;
            sum += best;
        }
        Geometry hull = Jts.GF.createMultiPointFromCoords(cs).convexHull();
        double area = hull.getArea();
        if (area <= 0) throw bad("النقاط على خط واحد: لا يمكن حساب المساحة", "Points are collinear: no area");
        NN r = new NN();
        r.n = n;
        r.observedM = sum / n;
        r.expectedM = 0.5 / Math.sqrt(n / area);
        r.ratio = r.observedM / r.expectedM;
        double se = 0.26136 / Math.sqrt(n * n / area);
        r.z = (r.observedM - r.expectedM) / se;
        r.areaKm2 = area / 1e6;
        return r;
    }

    // ---------------------------------------------------------------------------------------------- 9 min bounding rectangle

    /** Smallest rotated rectangle around every feature (perFeature) or around the whole layer. */
    public static LayerData boundingRectangles(LayerData src, boolean perFeature) {
        List<Feature> fs = new ArrayList<>();
        for (Feature f : src.features) if (!f.parts.isEmpty()) fs.add(f);
        if (fs.isEmpty()) throw bad("الطبقة فارغة", "The layer is empty");
        Plane pl = Plane.around(allPointsOf(fs));
        LayerData r = result(src, src.label + S.t(" (أصغر مستطيل)", " (min. bounding rectangle)"), Feature.POLYGON);
        if (perFeature) {
            for (Feature f : fs) {
                if (f.geom == Feature.POINT) continue;
                Feature rect = rect(Collections.singletonList(f), pl);
                if (rect != null) r.features.add(cloneAttrs(f, rect));
            }
        } else {
            Feature rect = rect(fs, pl);
            if (rect != null) {
                rect.name = src.label;
                r.features.add(rect);
            }
        }
        return r;
    }

    private static List<Feature> allPointsOf(List<Feature> fs) {
        List<Feature> r = new ArrayList<>();
        for (Feature f : fs) {
            double[] p = f.parts.get(0);
            r.add(Feature.point(p[1], p[0]));
        }
        return r;
    }

    private static Feature rect(List<Feature> fs, Plane pl) {
        List<Coordinate> cs = new ArrayList<>();
        for (Feature f : fs) for (double[] p : f.parts) for (int i = 0; i + 1 < p.length; i += 2) cs.add(new Coordinate(pl.x(p[i]), pl.y(p[i + 1])));
        if (cs.size() < 2) return null;
        Geometry g = Jts.GF.createMultiPointFromCoords(cs.toArray(new Coordinate[0]));
        Geometry rect = new MinimumDiameter(g).getMinimumRectangle();
        if (!(rect instanceof org.locationtech.jts.geom.Polygon) || rect.getArea() <= 0) return null;
        Coordinate[] c = rect.getCoordinates();
        double[] ll = new double[c.length * 2];
        for (int i = 0; i < c.length; i++) {
            ll[2 * i] = pl.lon(c[i].x);
            ll[2 * i + 1] = pl.lat(c[i].y);
        }
        Feature f = polygonFeature(ll);
        f.attrs.put("area_m2", String.valueOf(Math.round(rect.getArea())));
        return f;
    }

    // ---------------------------------------------------------------------------------------------- 10 path

    /** One line (or polygon) through the layer's points in layer order, or sorted by name. */
    public static LayerData pointPath(LayerData src, boolean polygon, boolean sortByName) {
        List<Feature> pts = points(src);
        if (pts.size() < (polygon ? 3 : 2)) throw bad(polygon ? "يلزم 3 نقاط على الأقل" : "يلزم نقطتان على الأقل", polygon ? "At least 3 points are needed" : "At least 2 points are needed");
        if (sortByName) {
            pts = new ArrayList<>(pts);
            Collections.sort(pts, (a, b) -> a.name.compareToIgnoreCase(b.name));
        }
        int n = pts.size();
        double[] p = new double[(n + (polygon ? 1 : 0)) * 2];
        for (int i = 0; i < n; i++) {
            p[2 * i] = pts.get(i).lon;
            p[2 * i + 1] = pts.get(i).lat;
        }
        if (polygon) {
            p[2 * n] = p[0];
            p[2 * n + 1] = p[1];
        }
        Feature f = new Feature();
        f.geom = polygon ? Feature.POLYGON : Feature.LINE;
        f.id = Feature.newId();
        f.parts.add(p);
        Geo.setRepresentative(f);
        f.name = src.label;
        LayerData r = result(src, src.label + (polygon ? S.t(" (مضلع من النقاط)", " (polygon from points)") : S.t(" (خط من النقاط)", " (line from points)")), f.geom);
        r.features.add(f);
        if (!polygon) f.attrs.put("length_m", String.valueOf(Math.round(Geodesy.length(f))));
        return r;
    }

    // ---------------------------------------------------------------------------------------------- 11 simplify / 12 merge

    public static LayerData simplifyLayer(LayerData src, double toleranceM) {
        if (src.geom == Feature.POINT) throw bad("التبسيط للخطوط والمضلعات فقط", "Simplify works on lines and polygons only");
        if (toleranceM < 0) throw bad("التسامح لا يكون سالباً", "Tolerance cannot be negative");
        LayerData r = result(src, src.label + S.t(" (مبسّطة ", " (simplified ") + Math.round(toleranceM) + " m)", src.geom);
        for (Feature f : src.features) {
            Feature s;
            try {
                s = GeoOps.simplify(f, toleranceM);
            } catch (RuntimeException e) {
                s = null;
            }
            if (s != null) {
                s.id = Feature.newId();
                r.features.add(s);
            }
        }
        return r;
    }

    /** Layers of the same geometry type joined into one. */
    public static LayerData merge(List<LayerData> layers, String label) {
        if (layers.size() < 2) throw bad("اختر طبقتين على الأقل", "Pick at least two layers");
        int geom = layers.get(0).geom;
        for (LayerData l : layers) if (l.geom != geom) throw bad("الطبقات من أنواع هندسية مختلفة", "The layers have different geometry types");
        LayerData r = result(layers.get(0), label, geom);
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                Feature c = f.copy();
                c.id = Feature.newId();
                r.features.add(c);
            }
        }
        return r;
    }

    /** Extent polygon helper used by tests and the UI: bbox of the layer as {w,s,e,n}, or null. */
    public static double[] extent(LayerData l) {
        double[] r = null;
        for (Feature f : l.features) {
            double[] b = f.geom == Feature.POINT ? new double[]{f.lon, f.lat, f.lon, f.lat} : Geo.bbox(f);
            if (r == null) r = b.clone();
            else {
                r[0] = Math.min(r[0], b[0]);
                r[1] = Math.min(r[1], b[1]);
                r[2] = Math.max(r[2], b[2]);
                r[3] = Math.max(r[3], b[3]);
            }
        }
        return r;
    }
}
