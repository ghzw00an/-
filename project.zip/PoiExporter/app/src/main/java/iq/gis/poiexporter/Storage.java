package iq.gis.poiexporter;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import java.io.IOException;
import java.io.OutputStream;

/** Saves exported files either to the chosen folder (SAF) or to Downloads/PoiExporter. */
public final class Storage {
    public interface Writer {
        void write(OutputStream os) throws IOException;
    }

    public static final class Saved {
        public final Uri uri;
        public final String where;

        Saved(Uri uri, String where) {
            this.uri = uri;
            this.where = where;
        }
    }

    private Storage() {
    }

    public static Saved save(Context ctx, Prefs prefs, String name, String mime, Writer w) throws IOException {
        ContentResolver cr = ctx.getContentResolver();
        String folder = prefs.folder();
        if (folder != null) {
            try {
                Uri tree = Uri.parse(folder);
                Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
                Uri doc = DocumentsContract.createDocument(cr, parent, mime, name);
                if (doc != null) {
                    OutputStream os = cr.openOutputStream(doc);
                    if (os != null) {
                        try {
                            w.write(os);
                        } finally {
                            os.close();
                        }
                        return new Saved(doc, S.t("المجلد المحدد", "Selected folder") + " / " + name);
                    }
                }
            } catch (IOException e) {
                throw e;
            } catch (Exception e) {
                // folder permission lost: fall back to Downloads
            }
        }
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PoiExporter");
        Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new IOException("cannot create file");
        OutputStream os = cr.openOutputStream(u);
        if (os == null) throw new IOException("cannot open file");
        try {
            w.write(os);
        } finally {
            os.close();
        }
        return new Saved(u, "Downloads/PoiExporter/" + name);
    }

    public static void share(Context ctx, Uri uri, String mime) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        ctx.startActivity(Intent.createChooser(i, S.t("مشاركة / فتح بتطبيق", "Share / open with")));
    }

    /** Opens the saved file in a viewer app (PDF reader, gallery…). */
    public static boolean open(Context ctx, Uri uri, String mime) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(i);
            return true;
        } catch (android.content.ActivityNotFoundException e) {
            return false;
        }
    }
}
