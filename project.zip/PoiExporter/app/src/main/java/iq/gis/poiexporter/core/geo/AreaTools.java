package iq.gis.poiexporter.core.geo;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;

import java.util.ArrayList;
import java.util.List;

/** Operations that use the selected area (rectangle / square / circle, rotated) as a polygon. */
public final class AreaTools {
    private AreaTools() {
    }

    /** The area as a polygon feature in lon/lat (closed ring). */
    public static Feature polygon(AreaSpec a) {
        double[] ring;
        if (a.circle) {
            ring = Geo.circleRing(a.clat, a.clon, a.radius, 96);
        } else if (a.corners != null) {
            double[] c = a.corners;
            ring = new double[]{c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7], c[0], c[1]};
        } else {
            ring = new double[]{a.west, a.south, a.east, a.south, a.east, a.north, a.west, a.north, a.west, a.south};
        }
        Feature f = new Feature();
        f.geom = Feature.POLYGON;
        f.id = Feature.newId();
        f.addPart(ring, false);
        Geo.setRepresentative(f);
        return f;
    }

    /** New layer with copies of the features of {@code src} selected by the area. */
    public static LayerData extract(LayerData src, AreaSpec a, GeoOps.Mode mode, String label) {
        LayerData res = new LayerData("ext_" + Feature.newId(), label, src.geom);
        res.kind = "user";
        res.color = src.color;
        res.width = src.width;
        res.source = src.source;
        res.sourceDate = src.sourceDate;
        for (Feature f : GeoOps.select(src, polygon(a), mode)) {
            Feature c = f.copy();
            c.id = Feature.newId();
            res.features.add(c);
        }
        return res;
    }

    /** All point features of several layers selected by the area, in one new layer. */
    public static List<Feature> selectFrom(List<LayerData> layers, AreaSpec a, GeoOps.Mode mode) {
        Feature p = polygon(a);
        List<Feature> r = new ArrayList<>();
        for (LayerData l : layers) r.addAll(GeoOps.select(l, p, mode));
        return r;
    }
}
