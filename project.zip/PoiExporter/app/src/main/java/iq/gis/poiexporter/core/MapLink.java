package iq.gis.poiexporter.core;

import java.net.URLDecoder;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads a position out of the text of a map link (geo:, Google Maps, OpenStreetMap, Apple, Waze, plain "lat, lon"). */
public final class MapLink {
    private MapLink() {
    }

    public static final class Pos {
        public final double lat, lon;
        public final String label;

        Pos(double lat, double lon, String label) {
            this.lat = lat;
            this.lon = lon;
            this.label = label == null ? "" : label;
        }
    }

    private static final String NUM = "(-?\\d{1,3}(?:\\.\\d+)?)";
    private static final Pattern[] PATTERNS = {
            Pattern.compile("!3d" + NUM + "!4d" + NUM),
            Pattern.compile("@" + NUM + "," + NUM),
            Pattern.compile("[?&;](?:q|ll|sll|query|center|daddr|destination|saddr|coordinate)=" + NUM + "[, ]+\\s*" + NUM),
            Pattern.compile("mlat=" + NUM + "&(?:amp;)?mlon=" + NUM),
            Pattern.compile("[#?&]map=\\d+(?:\\.\\d+)?/" + NUM + "/" + NUM),
            Pattern.compile("/(?:place|dir|search)/(?:[^/]*/)?" + NUM + "[, ]+" + NUM + "(?:[/?]|$)"),
            Pattern.compile("^geo:" + NUM + "," + NUM),
            Pattern.compile("^\\s*" + NUM + "\\s*[,;\\s]\\s*" + NUM + "\\s*$"),
    };

    /** True when the link is a shortened map link whose position is only known after following its redirect. */
    public static boolean isShort(String s) {
        if (s == null) return false;
        String t = s.toLowerCase(Locale.ROOT);
        return t.contains("maps.app.goo.gl") || t.contains("goo.gl/maps") || t.contains("g.co/kgs") || t.contains("share.google")
                || t.contains("maps.apple.com/p/") || t.contains("waze.com/ul/");
    }

    /** A shared Google "saved places" list: its link holds only a list id, never coordinates. */
    public static boolean isList(String s) {
        if (s == null) return false;
        String t = s.toLowerCase(Locale.ROOT);
        return t.contains("/maps/@/data=") || t.contains("placelists") || t.contains("/maps/@/");
    }

    /** consent.google.com wrapper: the page the user wanted is in its continue= parameter. */
    public static String unwrapConsent(String url) {
        if (url == null || !url.contains("consent.google.")) return url;
        Matcher m = Pattern.compile("[?&]continue=([^&]+)").matcher(url);
        if (!m.find()) return url;
        try {
            return URLDecoder.decode(m.group(1), "UTF-8");
        } catch (Exception e) {
            return url;
        }
    }

    /** Public KML export address of a shared Google My Maps map, or null. */
    public static String myMapsKmlUrl(String url) {
        if (url == null) return null;
        String t = url.toLowerCase(Locale.ROOT);
        if (!t.contains("google.") || !t.contains("/maps/d/")) return null;
        Matcher m = Pattern.compile("[?&]mid=([A-Za-z0-9_\\-]+)").matcher(url);
        return m.find() ? "https://www.google.com/maps/d/kml?mid=" + m.group(1) + "&forcekml=1" : null;
    }

    /** First valid position found, or null. */
    public static Pos parse(String text) {
        if (text == null) return null;
        String s = text.trim();
        if (s.isEmpty()) return null;
        String dec = s;
        try {
            dec = URLDecoder.decode(s.replace("+", "%2B"), "UTF-8");
        } catch (Exception ignored) {
            // keep the raw text
        }
        for (String cand : new String[]{dec, s}) {
            for (Pattern p : PATTERNS) {
                Matcher m = p.matcher(cand);
                while (m.find()) {
                    double lat, lon;
                    try {
                        lat = Double.parseDouble(m.group(1));
                        lon = Double.parseDouble(m.group(2));
                    } catch (NumberFormatException e) {
                        continue;
                    }
                    if (valid(lat, lon)) return new Pos(lat, lon, label(cand));
                }
            }
        }
        // Plus Codes: full codes always; short ones when the app has set a reference position
        String spaced = s;
        try {
            spaced = URLDecoder.decode(s, "UTF-8");
        } catch (Exception ignored) {
            // keep the raw text
        }
        for (String cand : new String[]{spaced, dec, s}) {
            String pc = PlusCode.find(cand);
            if (pc == null) continue;
            double[] ll = IraqPlaces.resolvePlusCode(cand);
            if (ll != null && valid(ll[0], ll[1])) return new Pos(ll[0], ll[1], PlusCode.localityAfter(cand, pc));
        }
        return null;
    }

    private static boolean valid(double lat, double lon) {
        return Math.abs(lat) <= 90 && Math.abs(lon) <= 180 && !(lat == 0 && lon == 0);
    }

    /** "(Label)" after a geo q= value, or the place name segment of a Google /place/ link. */
    private static String label(String s) {
        Matcher m = Pattern.compile("\\(([^)]{1,80})\\)").matcher(s);
        if (m.find()) return m.group(1).trim();
        m = Pattern.compile("/place/([^/@]+)/").matcher(s);
        if (m.find()) {
            String n = m.group(1).replace('+', ' ').trim();
            if (!n.matches("-?[\\d.]+[, ]+-?[\\d.]+")) return n;
        }
        return "";
    }

    /** First http(s) URL or geo: URI inside a shared text, or the text itself. */
    public static String extractLink(String text) {
        if (text == null) return "";
        Matcher m = Pattern.compile("(https?://\\S+|geo:\\S+)").matcher(text);
        return m.find() ? m.group(1) : text.trim();
    }
}
