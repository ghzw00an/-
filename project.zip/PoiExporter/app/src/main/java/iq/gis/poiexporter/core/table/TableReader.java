package iq.gis.poiexporter.core.table;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.CoordFmt;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Streaming reader for CSV / TXT / TSV and XLSX tables. Rows are returned as String arrays, one at a time, so the
 * file never has to fit in memory.
 */
public final class TableReader implements Closeable {
    private interface RowSrc {
        String[] next() throws IOException;

        void close() throws IOException;
    }

    private final File file;
    private final String display;
    private final boolean xlsx;
    private ZipFile zip;
    private List<String> sheetNames = new ArrayList<>();
    private List<String> sheetPaths = new ArrayList<>();
    private List<String> shared;
    private RowSrc src;
    private char delim;
    private Charset charset = Charset.forName("UTF-8");
    private String[] first;
    private boolean hasHeader;
    private List<String> header = new ArrayList<>();
    private boolean firstPending;
    private long rowNo;

    private TableReader(File f, String display, boolean xlsx) {
        this.file = f;
        this.display = display;
        this.xlsx = xlsx;
    }

    public static TableReader open(File f, String displayName) throws IOException {
        String nm = (displayName == null ? f.getName() : displayName).toLowerCase(Locale.US);
        byte[] head = new byte[8];
        int n;
        InputStream in = new FileInputStream(f);
        try {
            n = in.read(head);
        } finally {
            in.close();
        }
        boolean ole = n >= 4 && (head[0] & 0xFF) == 0xD0 && (head[1] & 0xFF) == 0xCF && (head[2] & 0xFF) == 0x11 && (head[3] & 0xFF) == 0xE0;
        if (ole || nm.endsWith(".xls")) {
            throw new IOException(S.t("ملف Excel القديم (.xls) غير مدعوم. افتحه في Excel واحفظه بصيغة .xlsx أو CSV ثم أعد المحاولة.",
                    "Legacy Excel (.xls) is not supported. Save it as .xlsx or CSV and try again."));
        }
        boolean zipMagic = n >= 2 && head[0] == 'P' && head[1] == 'K';
        boolean x = zipMagic && (nm.endsWith(".xlsx") || nm.endsWith(".xlsm") || !nm.endsWith(".csv") && !nm.endsWith(".txt"));
        TableReader r = new TableReader(f, displayName == null ? f.getName() : displayName, x);
        if (x) r.initXlsx();
        else r.initText();
        r.openSheet(0);
        return r;
    }

    // ------------------------------------------------------------------ public API

    public List<String> sheetNames() {
        return sheetNames;
    }

    public List<String> header() {
        return header;
    }

    public boolean hasHeader() {
        return hasHeader;
    }

    public int columns() {
        return header.size();
    }

    /** Row number (1-based, header counts as row 1) of the row last returned by next(). */
    public long rowNumber() {
        return rowNo;
    }

    public char delimiter() {
        return delim;
    }

    public String charsetName() {
        return charset.name();
    }

    public String displayName() {
        return display;
    }

    public void openSheet(int i) throws IOException {
        if (src != null) src.close();
        rowNo = 0;
        if (xlsx) {
            if (i < 0 || i >= sheetPaths.size()) throw new IOException("no such sheet");
            src = xlsxSheet(sheetPaths.get(i));
        } else {
            src = csvSource();
        }
        first = nextNonEmpty();
        header = new ArrayList<>();
        hasHeader = false;
        firstPending = false;
        if (first == null) return;
        hasHeader = looksLikeHeader(first);
        if (hasHeader) {
            for (int k = 0; k < first.length; k++) {
                String h = first[k] == null ? "" : first[k].trim();
                header.add(h.isEmpty() ? "col" + (k + 1) : h);
            }
        } else {
            for (int k = 0; k < first.length; k++) header.add("col" + (k + 1));
            firstPending = true;
        }
    }

    /** Next data row or null at the end. Rows may be shorter or longer than the header. */
    public String[] next() throws IOException {
        if (firstPending) {
            firstPending = false;
            rowNo = 1;
            return first;
        }
        if (src == null) return null;
        String[] r = nextNonEmpty();
        return r;
    }

    private String[] nextNonEmpty() throws IOException {
        while (true) {
            String[] r = src.next();
            if (r == null) return null;
            rowNo++;
            boolean empty = true;
            for (String s : r) if (s != null && !s.trim().isEmpty()) {
                empty = false;
                break;
            }
            if (!empty) return r;
        }
    }

    public static List<String[]> sample(File f, String name, int n) throws IOException {
        TableReader r = open(f, name);
        try {
            List<String[]> out = new ArrayList<>();
            String[] row;
            while (out.size() < n && (row = r.next()) != null) out.add(row);
            return out;
        } finally {
            r.close();
        }
    }

    public void close() throws IOException {
        if (src != null) src.close();
        src = null;
        if (zip != null) zip.close();
        zip = null;
    }

    private static boolean numericLike(String s) {
        if (s == null) return false;
        String t = s.trim();
        if (t.isEmpty()) return false;
        double v = PointTable.parseNum(t);
        return !Double.isNaN(v);
    }

    private static boolean looksLikeHeader(String[] row) {
        int numeric = 0, cells = 0;
        for (String s : row) {
            if (s == null || s.trim().isEmpty()) continue;
            cells++;
            if (numericLike(s)) numeric++;
            else if (hasDigit(s)) {
                try {
                    CoordFmt.parse(s);
                    return false; // a single cell holding a full coordinate
                } catch (RuntimeException ignored) {
                    // not a coordinate
                }
            }
        }
        if (cells == 0) return false;
        return numeric < 2 && !(cells == 1 && numeric == 1);
    }

    private static boolean hasDigit(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9' || c >= '٠' && c <= '٩') return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ text

    private void initText() throws IOException {
        sheetNames.add(display);
        byte[] buf = new byte[4 * 1024 * 1024];
        int n = 0;
        InputStream in = new FileInputStream(file);
        try {
            int r;
            while (n < buf.length && (r = in.read(buf, n, buf.length - n)) > 0) n += r;
        } finally {
            in.close();
        }
        boolean truncated = n == buf.length;
        int off = 0;
        if (n >= 3 && (buf[0] & 0xFF) == 0xEF && (buf[1] & 0xFF) == 0xBB && (buf[2] & 0xFF) == 0xBF) {
            off = 3;
        } else if (n >= 2 && (buf[0] & 0xFF) == 0xFF && (buf[1] & 0xFF) == 0xFE) {
            charset = Charset.forName("UTF-16LE");
            off = 2;
        } else if (n >= 2 && (buf[0] & 0xFF) == 0xFE && (buf[1] & 0xFF) == 0xFF) {
            charset = Charset.forName("UTF-16BE");
            off = 2;
        }
        if (charset.name().equals("UTF-8")) {
            int len = n - off;
            if (truncated) len -= 4; // do not judge a cut multi-byte sequence
            try {
                Charset.forName("UTF-8").newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                        .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(buf, off, Math.max(0, len)));
            } catch (CharacterCodingException e) {
                charset = Charset.forName("windows-1256");
            }
        }
        skipBytes = off;
        String sample = new String(buf, off, Math.min(n - off, 64 * 1024), charset);
        delim = detectDelimiter(sample);
    }

    private int skipBytes;

    static char detectDelimiter(String sample) {
        List<String> lines = new ArrayList<>();
        int st = 0;
        boolean q = false;
        for (int i = 0; i < sample.length() && lines.size() < 30; i++) {
            char c = sample.charAt(i);
            if (c == '"') q = !q;
            if ((c == '\n') && !q) {
                String l = sample.substring(st, i).replace("\r", "");
                if (!l.trim().isEmpty()) lines.add(l);
                st = i + 1;
            }
        }
        if (lines.size() < 2 && st < sample.length()) {
            String l = sample.substring(st).replace("\r", "");
            if (!l.trim().isEmpty()) lines.add(l);
        }
        char[] cands = {'\t', ';', '|', ',', ' '};
        char best = 0;
        double bestScore = 0;
        for (char d : cands) {
            int min = Integer.MAX_VALUE, max = 0;
            for (String l : lines) {
                int c = count(l, d);
                min = Math.min(min, c);
                max = Math.max(max, c);
            }
            if (lines.isEmpty() || min == 0) continue;
            double score = (min == max ? 1000 : 0) + Math.min(min, 50);
            if (d == ' ') score -= 500; // whitespace only as the last resort
            if (score > bestScore) {
                bestScore = score;
                best = d;
            }
        }
        return best;
    }

    private static int count(String l, char d) {
        int c = 0;
        boolean q = false;
        boolean prevSpace = true;
        for (int i = 0; i < l.length(); i++) {
            char ch = l.charAt(i);
            if (ch == '"') q = !q;
            else if (!q) {
                if (d == ' ') {
                    boolean sp = ch == ' ' || ch == '\t';
                    if (sp && !prevSpace) c++;
                    prevSpace = sp;
                    if (i == l.length() - 1 && sp) c--;
                } else if (ch == d) {
                    c++;
                }
            }
        }
        return c;
    }

    private RowSrc csvSource() throws IOException {
        final InputStream fin = new BufferedInputStream(new FileInputStream(file), 1 << 16);
        long skipped = 0;
        while (skipped < skipBytes) {
            long s = fin.skip(skipBytes - skipped);
            if (s <= 0) break;
            skipped += s;
        }
        final Reader rd = new BufferedReader(new InputStreamReader(fin, charset), 1 << 16);
        final char d = delim;
        return new RowSrc() {
            private int pk = -2;

            private int rd() throws IOException {
                if (pk != -2) {
                    int c = pk;
                    pk = -2;
                    return c;
                }
                return rd.read();
            }

            public String[] next() throws IOException {
                List<String> cells = new ArrayList<>();
                StringBuilder sb = new StringBuilder();
                boolean any = false, inQ = false, wasQuoted = false;
                int c;
                boolean lead = true; // skipping leading spaces in whitespace mode
                while ((c = rd()) >= 0) {
                    any = true;
                    if (inQ) {
                        if (c == '"') {
                            int n = rd();
                            if (n == '"') sb.append('"');
                            else {
                                inQ = false;
                                pk = n;
                            }
                        } else {
                            sb.append((char) c);
                        }
                        continue;
                    }
                    if (c == '\r') continue;
                    if (c == '\n') break;
                    if (c == '"' && sb.length() == 0 && !wasQuoted) {
                        inQ = true;
                        wasQuoted = true;
                        continue;
                    }
                    if (d == ' ') {
                        if (c == ' ' || c == '\t') {
                            if (!lead) {
                                cells.add(sb.toString());
                                sb.setLength(0);
                                wasQuoted = false;
                                lead = true;
                            }
                            continue;
                        }
                        lead = false;
                        sb.append((char) c);
                    } else if (d != 0 && c == d) {
                        cells.add(sb.toString());
                        sb.setLength(0);
                        wasQuoted = false;
                    } else {
                        sb.append((char) c);
                    }
                }
                if (!any) return null;
                if (d == ' ') {
                    if (sb.length() > 0) cells.add(sb.toString());
                } else {
                    cells.add(sb.toString());
                }
                return cells.toArray(new String[0]);
            }

            public void close() throws IOException {
                rd.close();
            }
        };
    }

    // ------------------------------------------------------------------ xlsx

    private ZipEntry entry(String path) {
        ZipEntry e = zip.getEntry(path);
        if (e != null) return e;
        Enumeration<? extends ZipEntry> en = zip.entries();
        while (en.hasMoreElements()) {
            ZipEntry z = en.nextElement();
            if (z.getName().equalsIgnoreCase(path)) return z;
        }
        return null;
    }

    private XmlPull xml(String path) throws IOException {
        ZipEntry e = entry(path);
        if (e == null) throw new IOException("missing part " + path);
        return new XmlPull(new BufferedReader(new InputStreamReader(zip.getInputStream(e), "UTF-8"), 1 << 16));
    }

    private void initXlsx() throws IOException {
        zip = new ZipFile(file);
        String wb = "xl/workbook.xml";
        Map<String, String> rels = new HashMap<>();
        if (entry("xl/_rels/workbook.xml.rels") != null) {
            XmlPull p = xml("xl/_rels/workbook.xml.rels");
            int t;
            while ((t = p.next()) != XmlPull.EOF) {
                if (t == XmlPull.START && p.name.equals("Relationship")) {
                    String target = p.attr("Target");
                    if (target == null) continue;
                    String full = target.startsWith("/") ? target.substring(1) : "xl/" + target;
                    rels.put(p.attr("Id"), full);
                }
            }
        }
        if (entry(wb) == null) throw new IOException(S.t("ملف Excel غير صالح", "Invalid Excel file"));
        XmlPull p = xml(wb);
        int t;
        while ((t = p.next()) != XmlPull.EOF) {
            if (t == XmlPull.START && p.name.equals("sheet")) {
                String nm = p.attr("name");
                String rid = p.attr("r:id");
                String path = rid == null ? null : rels.get(rid);
                if (path == null) path = "xl/worksheets/sheet" + (sheetPaths.size() + 1) + ".xml";
                sheetNames.add(nm == null ? "Sheet" + (sheetNames.size() + 1) : nm);
                sheetPaths.add(path);
            }
        }
        if (sheetPaths.isEmpty()) throw new IOException(S.t("لا توجد أوراق في الملف", "No sheets in workbook"));
        shared = new ArrayList<>();
        if (entry("xl/sharedStrings.xml") != null) {
            XmlPull sp = xml("xl/sharedStrings.xml");
            StringBuilder cur = null;
            boolean inT = false, inPh = false;
            while ((t = sp.next()) != XmlPull.EOF) {
                if (t == XmlPull.START) {
                    if (sp.name.equals("si")) cur = new StringBuilder();
                    else if (sp.name.equals("rPh")) inPh = true;
                    else if (sp.name.equals("t")) inT = true;
                } else if (t == XmlPull.END) {
                    if (sp.name.equals("si")) {
                        shared.add(cur == null ? "" : cur.toString());
                        cur = null;
                    } else if (sp.name.equals("rPh")) inPh = false;
                    else if (sp.name.equals("t")) inT = false;
                } else if (t == XmlPull.TEXT && inT && !inPh && cur != null) {
                    cur.append(sp.text);
                }
            }
        }
    }

    private static int colIndex(String ref) {
        int c = 0;
        for (int i = 0; i < ref.length(); i++) {
            char ch = ref.charAt(i);
            if (ch >= 'A' && ch <= 'Z') c = c * 26 + (ch - 'A' + 1);
            else if (ch >= 'a' && ch <= 'z') c = c * 26 + (ch - 'a' + 1);
            else break;
        }
        return c - 1;
    }

    private RowSrc xlsxSheet(String path) throws IOException {
        final XmlPull p = xml(path);
        final List<String> sst = shared;
        return new RowSrc() {
            public String[] next() throws IOException {
                int t;
                List<String> row = null;
                int col = 0;
                String type = null;
                StringBuilder val = null;
                boolean inV = false, inIs = false, inT = false, inCell = false;
                while ((t = p.next()) != XmlPull.EOF) {
                    if (t == XmlPull.START) {
                        switch (p.name) {
                            case "row":
                                row = new ArrayList<>();
                                col = 0;
                                break;
                            case "c":
                                inCell = true;
                                String r = p.attr("r");
                                if (r != null) col = colIndex(r);
                                type = p.attr("t");
                                val = new StringBuilder();
                                break;
                            case "v":
                                inV = true;
                                break;
                            case "is":
                                inIs = true;
                                break;
                            case "t":
                                inT = inIs;
                                break;
                            default:
                        }
                    } else if (t == XmlPull.TEXT) {
                        if (inCell && (inV || inT) && val != null) val.append(p.text);
                    } else if (t == XmlPull.END) {
                        switch (p.name) {
                            case "v":
                                inV = false;
                                break;
                            case "is":
                                inIs = false;
                                break;
                            case "t":
                                inT = false;
                                break;
                            case "c":
                                if (row != null && val != null) {
                                    while (row.size() < col) row.add("");
                                    String s = val.toString();
                                    if ("s".equals(type)) {
                                        try {
                                            s = sst.get(Integer.parseInt(s.trim()));
                                        } catch (RuntimeException e) {
                                            s = "";
                                        }
                                    } else if ("b".equals(type)) {
                                        s = "1".equals(s.trim()) ? "TRUE" : "FALSE";
                                    }
                                    if (row.size() == col) row.add(s);
                                    else row.set(col, s);
                                }
                                inCell = false;
                                val = null;
                                break;
                            case "row":
                                if (row != null) return row.toArray(new String[0]);
                                break;
                            default:
                        }
                    }
                }
                return null;
            }

            public void close() {
            }
        };
    }
}
