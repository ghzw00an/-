package iq.gis.poiexporter;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.Quality;
import iq.gis.poiexporter.core.admin.AdminRef;

/** Data-quality screen: checks one project layer and offers safe, undoable fixes. All logic lives in core.Quality. */
final class QualityPage {
    private final MainActivity a;
    private int layerIdx;
    private boolean makeValid;
    private Quality.Report report;
    private LayerData reportLayer;
    private LinearLayout out;

    QualityPage(MainActivity a) {
        this.a = a;
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        final List<LayerData> ls = new ArrayList<>(MainActivity.LIB);
        LinearLayout pick = Ui.card(a);
        pick.addView(UiKit.head(a, S.t("فحص جودة الطبقة", "Layer quality check")));
        if (ls.isEmpty()) {
            pick.addView(UiKit.note(a, S.t("لا توجد طبقات في المشروع. أضف معالم أو استورد بيانات أولاً.", "No layers in the project yet.")));
            p.addView(pick);
            return p;
        }
        List<String> names = new ArrayList<>();
        for (LayerData l : ls) names.add(l.label + "  (" + l.features.size() + ")");
        if (layerIdx >= ls.size()) layerIdx = 0;
        Spinner sp = ConverterPage.spinner(a, names, layerIdx);
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> parent, View v, int pos, long id) {
                if (pos != layerIdx) {
                    layerIdx = pos;
                    report = null;
                    if (out != null) out.removeAllViews();
                }
            }

            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });
        pick.addView(sp);
        pick.addView(UiKit.note(a, S.t("المسافة التي يُعدّ عندها المعلمان المتشابهان بالاسم مكرّرين: 25 متراً. المعالم في نفس الموضع تماماً تُعدّ مكررة دائماً.",
                "Same-name landmarks closer than 25 m count as duplicates; identical positions always do.")));
        pick.addView(Ui.button(a, S.t("افحص", "Run check"), true, () -> run(ls.get(layerIdx))));
        p.addView(pick);
        out = UiKit.col(a);
        p.addView(out);
        if (report != null && reportLayer != null && ls.contains(reportLayer)) show(reportLayer);
        return p;
    }

    private void run(final LayerData l) {
        out.removeAllViews();
        out.addView(UiKit.note(a, S.t("جارٍ الفحص…", "Checking…")));
        final List<Feature> snapshot = new ArrayList<>(l.features);
        new Thread(() -> {
            try {
                final LayerData copy = new LayerData(l.id, l.label, l.geom);
                copy.features.addAll(snapshot);
                final Quality.Report r = Quality.analyze(copy, 25, AdminRef.get());
                a.runOnUiThread(() -> {
                    report = r;
                    reportLayer = l;
                    show(l);
                });
            } catch (Throwable t) {
                ErrorLog.add("quality", t);
                a.runOnUiThread(() -> a.message(S.t("تعذّر الفحص", "Check failed"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }

    private void show(final LayerData l) {
        if (out == null) return;
        out.removeAllViews();
        final Quality.Report r = report;
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("النتيجة: ", "Result: ") + l.label));
        TextView t = UiKit.note(a, r.toText(S.ar));
        t.setTextIsSelectable(true);
        c.addView(t);
        if (r.problems() == 0 && r.missingAdmin.isEmpty())
            c.addView(UiKit.note(a, S.t("لا مشاكل هندسية أو تكرار. راجع الحقول الفارغة أعلاه.", "No geometry or duplicate problems. Review the empty fields above.")));
        out.addView(c);

        LinearLayout fx = Ui.card(a);
        fx.addView(UiKit.head(a, S.t("إصلاحات (يمكن التراجع عنها)", "Fixes (undoable)")));
        if (!r.invalidGeometry.isEmpty()) {
            fx.addView(UiKit.check(a, S.t("إصلاح التقاطعات الذاتية أيضاً (قد يغيّر الشكل قليلاً)", "Also repair self-intersections (may change the shape slightly)"),
                    makeValid, v -> makeValid = v));
            fx.addView(Ui.button(a, S.t("إصلاح الهندسة (" + r.invalidGeometry.size() + ")", "Repair geometry (" + r.invalidGeometry.size() + ")"), false, () -> repair(l, r)));
        }
        if (!r.missingAdmin.isEmpty())
            fx.addView(Ui.button(a, S.t("ملء القضاء والمحافظة (" + r.missingAdmin.size() + ")", "Fill qadaa/governorate (" + r.missingAdmin.size() + ")"), false, () -> fill(l, r)));
        if (r.duplicateExtra > 0)
            fx.addView(Ui.button(a, S.t("حذف المكرّر (" + r.duplicateExtra + ")", "Remove duplicates (" + r.duplicateExtra + ")"), false, () -> dedupe(l, r)));
        if (r.problems() > 0)
            fx.addView(Ui.button(a, S.t("إنشاء طبقة بالعناصر الإشكالية", "Create a layer of problem features"), false, () -> problemLayer(l, r)));
        if (fx.getChildCount() == 1) fx.addView(UiKit.note(a, S.t("لا إصلاحات متاحة.", "Nothing to fix.")));
        out.addView(fx);
    }

    private void repair(final LayerData l, final Quality.Report r) {
        List<Feature[]> ch = Quality.repairGeometry(r.invalidGeometry, makeValid);
        if (ch.isEmpty()) {
            a.toast(S.t("لا يوجد ما يُصلح تلقائياً. العناصر الفارغة أو قليلة النقاط تحتاج حذفاً أو إعادة رسم.", "Nothing repairable automatically."));
            return;
        }
        apply(l, ch, S.t("إصلاح الهندسة", "Repair geometry"));
    }

    private void fill(final LayerData l, final Quality.Report r) {
        AdminRef ar = AdminRef.get();
        if (ar == null) return;
        List<Feature[]> ch = Quality.fillAdmin(r.missingAdmin, ar);
        if (ch.isEmpty()) {
            a.toast(S.t("لا شيء للملء.", "Nothing to fill."));
            return;
        }
        apply(l, ch, S.t("ملء الحدود الإدارية", "Fill admin units"));
    }

    private void apply(LayerData l, List<Feature[]> ch, String label) {
        List<Feature> before = new ArrayList<>(), after = new ArrayList<>();
        for (Feature[] c : ch) {
            before.add(c[0]);
            after.add(c[1]);
        }
        MainActivity.WS.updateFeatures(l.id, before, after, label);
        a.rebuild();
        a.toast(S.t("تم تعديل " + ch.size() + " عنصراً — يمكن التراجع", ch.size() + " changed — undo available"));
        report = null;
        run(l);
    }

    private void dedupe(final LayerData l, final Quality.Report r) {
        final List<String> ids = Quality.duplicateIdsToRemove(r.duplicates);
        a.messageConfirm(S.t("حذف المكرّر", "Remove duplicates"),
                S.t("سيُحذف " + ids.size() + " عنصراً ويُبقى الأول من كل مجموعة. يمكن التراجع.", ids.size() + " features will be removed, keeping the first of each group. Undo is available."),
                S.t("حذف", "Remove"), () -> {
                    MainActivity.WS.deleteFeatures(l.id, ids, S.t("حذف المكرّر", "Remove duplicates"));
                    a.rebuild();
                    report = null;
                    run(l);
                });
    }

    private void problemLayer(LayerData l, Quality.Report r) {
        LayerData n = new LayerData("", l.label + " — " + S.t("مشاكل", "problems"), l.geom);
        java.util.LinkedHashSet<Feature> set = new java.util.LinkedHashSet<>();
        set.addAll(r.invalidGeometry);
        set.addAll(r.outsideIraq);
        for (iq.gis.poiexporter.core.io.DupFinder.Group g : r.duplicates) set.addAll(g.members);
        for (Feature f : set) n.features.add(f.copy());
        n.kind = l.kind;
        MainActivity.WS.addLayerWithFeatures(n);
        a.rebuild();
        a.toast(S.t("أُنشئت طبقة بـ " + n.features.size() + " عنصراً", "Layer created with " + n.features.size() + " features"));
    }
}
