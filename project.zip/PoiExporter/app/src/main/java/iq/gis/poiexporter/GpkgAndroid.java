package iq.gis.poiexporter;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import iq.gis.poiexporter.core.io.Gpkg;
import iq.gis.poiexporter.core.io.ImportHub;

/** GeoPackage files through Android's SQLite (the format logic lives in core.io.Gpkg). */
public final class GpkgAndroid {
    private GpkgAndroid() {
    }

    /** Call once at start-up so ImportHub can open .gpkg files. */
    public static void install() {
        ImportHub.gpkgOpener = new ImportHub.GpkgOpener() {
            @Override
            public Gpkg.Source open(File f) throws IOException {
                return new Reader(f);
            }
        };
    }

    private static void bind(SQLiteStatement st, Object[] args) {
        st.clearBindings();
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            int k = i + 1;
            if (a == null) st.bindNull(k);
            else if (a instanceof byte[]) st.bindBlob(k, (byte[]) a);
            else if (a instanceof Double || a instanceof Float) st.bindDouble(k, ((Number) a).doubleValue());
            else if (a instanceof Number) st.bindLong(k, ((Number) a).longValue());
            else if (a instanceof Boolean) st.bindLong(k, ((Boolean) a) ? 1 : 0);
            else st.bindString(k, String.valueOf(a));
        }
    }

    /** Writer: creates (or replaces) the file and runs the statements Gpkg produces. */
    public static final class Writer implements Gpkg.SqlExec, java.io.Closeable {
        private final SQLiteDatabase db;
        private final Map<String, SQLiteStatement> cache = new HashMap<>();

        public Writer(File f) throws IOException {
            if (f.exists() && !f.delete()) throw new IOException("cannot replace " + f.getName());
            try {
                db = SQLiteDatabase.openDatabase(f.getAbsolutePath(), null, SQLiteDatabase.CREATE_IF_NECESSARY);
            } catch (RuntimeException e) {
                throw new IOException(e);
            }
        }

        @Override
        public void begin() throws IOException {
            try {
                db.beginTransaction();
            } catch (RuntimeException e) {
                throw new IOException(e);
            }
        }

        @Override
        public void exec(String sql, Object... args) throws IOException {
            try {
                if (args == null || args.length == 0) {
                    db.execSQL(sql);
                    return;
                }
                SQLiteStatement st = cache.get(sql);
                if (st == null) {
                    st = db.compileStatement(sql);
                    cache.put(sql, st);
                }
                bind(st, args);
                st.execute();
            } catch (RuntimeException e) {
                throw new IOException(e);
            }
        }

        @Override
        public void commit() throws IOException {
            try {
                db.setTransactionSuccessful();
                db.endTransaction();
            } catch (RuntimeException e) {
                throw new IOException(e);
            }
        }

        @Override
        public void close() {
            for (SQLiteStatement s : cache.values()) s.close();
            cache.clear();
            if (db.inTransaction()) db.endTransaction();
            db.close();
        }
    }

    /** Reader over a .gpkg file (read-only). */
    public static final class Reader implements Gpkg.Source, java.io.Closeable {
        private final SQLiteDatabase db;

        public Reader(File f) throws IOException {
            try {
                db = SQLiteDatabase.openDatabase(f.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            } catch (RuntimeException e) {
                throw new IOException("not a database: " + e.getMessage());
            }
        }

        private static Object val(Cursor c, int i) {
            switch (c.getType(i)) {
                case Cursor.FIELD_TYPE_NULL:
                    return null;
                case Cursor.FIELD_TYPE_INTEGER:
                    return c.getLong(i);
                case Cursor.FIELD_TYPE_FLOAT:
                    return c.getDouble(i);
                case Cursor.FIELD_TYPE_BLOB:
                    return c.getBlob(i);
                default:
                    return c.getString(i);
            }
        }

        private List<Object[]> query(String sql, String... args) throws IOException {
            List<Object[]> out = new ArrayList<>();
            try (Cursor c = db.rawQuery(sql, args)) {
                int n = c.getColumnCount();
                while (c.moveToNext()) {
                    Object[] r = new Object[n];
                    for (int i = 0; i < n; i++) r[i] = val(c, i);
                    out.add(r);
                }
            } catch (RuntimeException e) {
                throw new IOException(e);
            }
            return out;
        }

        private static String q(String id) {
            return "\"" + id.replace("\"", "\"\"") + "\"";
        }

        @Override
        public List<Object[]> featureTables() throws IOException {
            return query("SELECT table_name, identifier, srs_id FROM gpkg_contents WHERE data_type = 'features'");
        }

        @Override
        public String geometryColumn(String table) throws IOException {
            List<Object[]> r = query("SELECT column_name FROM gpkg_geometry_columns WHERE table_name = ?", table);
            return r.isEmpty() ? null : (String) r.get(0)[0];
        }

        @Override
        public Object[] srs(long srsId) throws IOException {
            List<Object[]> r = query("SELECT organization, organization_coordsys_id FROM gpkg_spatial_ref_sys WHERE srs_id = ?", String.valueOf(srsId));
            return r.isEmpty() ? null : r.get(0);
        }

        @Override
        public List<String> columns(String table) throws IOException {
            List<String> cols = new ArrayList<>();
            for (Object[] r : query("PRAGMA table_info(" + q(table) + ")")) cols.add((String) r[1]);
            return cols;
        }

        @Override
        public long count(String table) throws IOException {
            List<Object[]> r = query("SELECT COUNT(*) FROM " + q(table));
            return r.isEmpty() ? 0 : (Long) r.get(0)[0];
        }

        @Override
        public List<Object[]> rows(String table, List<String> cols, long offset, int limit) throws IOException {
            StringBuilder b = new StringBuilder("SELECT ");
            for (int i = 0; i < cols.size(); i++) {
                if (i > 0) b.append(',');
                b.append(q(cols.get(i)));
            }
            b.append(" FROM ").append(q(table)).append(" ORDER BY rowid LIMIT ").append(limit).append(" OFFSET ").append(offset);
            return query(b.toString());
        }

        @Override
        public void close() {
            db.close();
        }
    }
}
