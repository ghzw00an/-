package iq.gis.poiexporter;

import android.net.Uri;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.db.ProjectArchive;
import iq.gis.poiexporter.core.db.ProjectInfo;
import iq.gis.poiexporter.core.db.Workspace;

/** Layer manager (visibility, style, order, undo/redo) and project list (open, rename, delete, backup, restore). */
final class ManagePages {
    private final MainActivity a;
    private static final int[] PALETTE = {0, 0xFFE03131, 0xFFF76707, 0xFFF59F00, 0xFF2F9E44, 0xFF1C7ED6, 0xFF7048E8, 0xFFC2255C, 0xFF343A40};

    ManagePages(MainActivity a) {
        this.a = a;
    }

    private Workspace ws() {
        return MainActivity.WS;
    }

    private void refresh() {
        a.rebuild();
        a.showPage(a.page);
    }

    // ---------------------------------------------------------------- layers

    View layers() {
        final Workspace w = ws();
        LinearLayout p = UiKit.col(a);
        LinearLayout bar = Ui.card(a);
        bar.addView(UiKit.head(a, S.t("التراجع والإعادة", "Undo & redo")));
        LinearLayout r = Ui.row(a);
        String ul = w.undoLabel(), rl = w.redoLabel();
        r.addView(Ui.button(a, "↶ " + S.t("تراجع", "Undo") + (ul == null ? "" : ": " + shorten(ul)), false, () -> {
            if (w.canUndo()) {
                w.undo();
                refresh();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 4, 4, 0));
        r.addView(Ui.button(a, "↷ " + S.t("إعادة", "Redo") + (rl == null ? "" : ": " + shorten(rl)), false, () -> {
            if (w.canRedo()) {
                w.redo();
                refresh();
            }
        }), Ui.lp(0, -2, 1f, a, 4, 4, 0, 0));
        bar.addView(r);
        bar.addView(UiKit.note(a, S.t("المشروع: ", "Project: ") + w.project().name + "  •  " + w.featureCount() + S.t(" عنصر", " features")
                + "\n" + S.t("تُحفظ كل التعديلات تلقائياً.", "Every change is saved automatically.")));
        p.addView(bar);

        if (w.layers().isEmpty()) {
            p.addView(UiKit.note(a, S.t("لا توجد طبقات في هذا المشروع.", "No layers in this project.")));
            p.addView(Ui.button(a, S.t("+ طبقة جديدة", "+ New layer"), true, this::newLayerDialog), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
            return p;
        }
        List<LayerData> ls = new ArrayList<>(w.layers());
        for (int i = 0; i < ls.size(); i++) p.addView(layerCard(ls.get(i), i, ls.size()));
        p.addView(Ui.button(a, S.t("+ طبقة جديدة", "+ New layer"), true, this::newLayerDialog), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        return p;
    }

    private static String shorten(String s) {
        return s.length() > 18 ? s.substring(0, 17) + "…" : s;
    }

    private void newLayerDialog() {
        LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, S.t("طبقة جديدة", "New layer")));
        final EditText f = Ui.field(a, S.t("الاسم", "Name"), InputType.TYPE_CLASS_TEXT);
        box.addView(f);
        final int[] g = {iq.gis.poiexporter.core.Feature.POINT};
        box.addView(Ui.chips(a, new String[]{S.t("نقاط", "Points"), S.t("خطوط", "Lines"), S.t("مضلعات", "Polygons")}, 0, i ->
                g[0] = i == 0 ? iq.gis.poiexporter.core.Feature.POINT : i == 1 ? iq.gis.poiexporter.core.Feature.LINE : iq.gis.poiexporter.core.Feature.POLYGON),
                Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        final android.app.Dialog d = a.card(box);
        box.addView(Ui.button(a, S.t("إنشاء", "Create"), true, () -> {
            String n = f.getText().toString().trim();
            if (n.isEmpty()) return;
            ws().addLayer(n, g[0], "user");
            d.dismiss();
            refresh();
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        d.show();
    }

    private View layerCard(final LayerData l, final int idx, int total) {
        LinearLayout c = Ui.card(a);
        LinearLayout top = Ui.row(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        final boolean vis = l.visible && !MainActivity.HIDDEN.contains(l.id);
        TextView eye = Ui.text(a, vis ? "👁" : "🚫", 22, Theme.text, false);
        eye.setPadding(0, 0, Ui.dp(a, 12), 0);
        eye.setClickable(true);
        eye.setOnClickListener(v -> {
            MainActivity.HIDDEN.remove(l.id);
            a.saveCsv("hidden", MainActivity.HIDDEN);
            ws().setVisible(l.id, !vis);
            refresh();
        });
        top.addView(eye);
        LinearLayout names = UiKit.col(a);
        names.addView(Ui.text(a, l.label, 16, Theme.text, true));
        String kind = "official".equals(l.kind) ? "" : l.kind;
        String sub = l.features.size() + S.t(" عنصر", " features") + (kind.isEmpty() ? "" : "  •  " + kind)
                + (l.official ? "" : (l.kind.equals("reference") ? S.t("  •  غير رسمي", "  •  unofficial") : ""));
        names.addView(Ui.text(a, sub, 12, Theme.sub, false));
        if (!l.source.isEmpty())
            names.addView(Ui.text(a, S.t("المصدر: ", "Source: ") + l.source + (l.sourceDate.isEmpty() ? "" : " (" + l.sourceDate + ")"), 11.5f, Theme.sub, false));
        if (!l.accuracyNote.isEmpty()) names.addView(Ui.text(a, l.accuracyNote, 11.5f, Theme.sub, false));
        top.addView(names, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView up = Ui.text(a, "▲", 18, idx > 0 ? Theme.primary : Theme.sub, true);
        TextView dn = Ui.text(a, "▼", 18, idx < total - 1 ? Theme.primary : Theme.sub, true);
        up.setPadding(Ui.dp(a, 10), 0, Ui.dp(a, 10), 0);
        dn.setPadding(Ui.dp(a, 10), 0, Ui.dp(a, 10), 0);
        up.setOnClickListener(v -> move(l, -1));
        dn.setOnClickListener(v -> move(l, 1));
        top.addView(up);
        top.addView(dn);
        c.addView(top);

        // colour
        LinearLayout colors = new LinearLayout(a);
        for (final int col : PALETTE) {
            TextView sw = new TextView(a);
            sw.setText(col == 0 ? "A" : "");
            sw.setGravity(Gravity.CENTER);
            sw.setTextColor(Theme.text);
            boolean on = l.color == col;
            sw.setBackground(Ui.stroke(col == 0 ? Theme.card : col, on ? Theme.text : Theme.sub, 8, a));
            sw.setOnClickListener(v -> {
                ws().updateLayerStyle(l.id, x -> x.color = col, S.t("لون ", "Colour ") + l.label);
                refresh();
            });
            colors.addView(sw, Ui.lp(Ui.dp(a, 30), Ui.dp(a, 30), 0, a, 3, 8, 3, 0));
        }
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(colors);
        c.addView(hs);

        final float[] ops = {1f, 0.7f, 0.4f};
        int oi = l.opacity > 0.85f ? 0 : l.opacity > 0.55f ? 1 : 2;
        c.addView(UiKit.label(a, S.t("الشفافية / السُّمك", "Opacity / width")));
        LinearLayout st = Ui.row(a);
        st.addView(Ui.chips(a, new String[]{"100%", "70%", "40%"}, oi, i -> {
            ws().updateLayerStyle(l.id, x -> x.opacity = ops[i], S.t("شفافية ", "Opacity ") + l.label);
            a.rebuild();
        }), new LinearLayout.LayoutParams(0, -2, 1f));
        final float[] ws = {0f, 2f, 4f, 6f};
        int wi = l.width <= 0 ? 0 : l.width <= 2f ? 1 : l.width <= 4f ? 2 : 3;
        st.addView(Ui.chips(a, new String[]{"A", "2", "4", "6"}, wi, i -> {
            ws().updateLayerStyle(l.id, x -> x.width = ws[i], S.t("سُمك ", "Width ") + l.label);
            a.rebuild();
        }), new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(st);

        LinearLayout acts = Ui.row(a);
        acts.addView(Ui.button(a, S.t("عرض", "Zoom"), false, () -> {
            a.showMap();
            a.zoomToLayer(l);
        }), Ui.lp(0, -2, 1f, a, 0, 8, 2, 0));
        acts.addView(Ui.button(a, S.t("اسم", "Rename"), false, () -> renameDialog(l)), Ui.lp(0, -2, 1f, a, 2, 8, 2, 0));
        acts.addView(Ui.button(a, S.t("مشاركة", "Share"), false, () -> a.shareDialog(l)), Ui.lp(0, -2, 1f, a, 2, 8, 2, 0));
        acts.addView(Ui.button(a, S.t("حذف", "Delete"), false, () -> a.deleteLayer(l)), Ui.lp(0, -2, 1f, a, 2, 8, 0, 0));
        c.addView(acts);
        return c;
    }

    private void move(LayerData l, int dir) {
        List<LayerData> ls = ws().layers();
        int i = ls.indexOf(l), j = i + dir;
        if (i < 0 || j < 0 || j >= ls.size()) return;
        final LayerData o = ls.get(j);
        final int a1 = l.order, a2 = o.order;
        // layers keep their list position; order values are swapped so the order survives a restart
        ws().updateLayerStyle(l.id, x -> x.order = a2 == a1 ? a2 + dir : a2, S.t("ترتيب ", "Order ") + l.label);
        ws().updateLayerStyle(o.id, x -> x.order = a1, S.t("ترتيب ", "Order ") + o.label);
        java.util.Collections.swap(ls, i, j);
        refresh();
    }

    private void renameDialog(final LayerData l) {
        LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, S.t("تغيير الاسم", "Rename")));
        final EditText f = Ui.field(a, S.t("الاسم", "Name"), InputType.TYPE_CLASS_TEXT);
        f.setText(l.label);
        box.addView(f);
        final android.app.Dialog d = a.card(box);
        box.addView(Ui.button(a, S.t("حفظ", "Save"), true, () -> {
            String n = f.getText().toString().trim();
            if (n.isEmpty()) return;
            ws().renameLayer(l.id, n);
            d.dismiss();
            refresh();
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        d.show();
    }

    // ---------------------------------------------------------------- projects

    View projects() {
        final Workspace w = ws();
        w.flush();
        LinearLayout p = UiKit.col(a);
        for (final ProjectInfo pi : w.repo().projects()) {
            LinearLayout c = Ui.card(a);
            boolean open = pi.id.equals(w.project().id);
            c.addView(Ui.text(a, (open ? "● " : "") + pi.name, 16, Theme.text, true));
            c.addView(UiKit.note(a, pi.layers + S.t(" طبقة • ", " layers • ") + pi.features + S.t(" عنصر", " features")
                    + (pi.updated == null ? "" : "\n" + pi.updated.replace('T', ' ').replaceAll("\\..*", ""))));
            LinearLayout r = Ui.row(a);
            if (!open) r.addView(Ui.button(a, S.t("فتح", "Open"), true, () -> {
                w.open(pi.id);
                MainActivity.ACTIVE = null;
                a.rebuild();
                a.showPage("projects");
            }), Ui.lp(0, -2, 1f, a, 0, 8, 2, 0));
            r.addView(Ui.button(a, S.t("اسم", "Rename"), false, () -> renameProject(pi)), Ui.lp(0, -2, 1f, a, 2, 8, 2, 0));
            r.addView(Ui.button(a, S.t("نسخة احتياطية", "Backup"), false, () -> backup(pi)), Ui.lp(0, -2, 1f, a, 2, 8, 2, 0));
            if (!open) r.addView(Ui.button(a, S.t("حذف", "Delete"), false, () -> a.messageConfirm(S.t("حذف المشروع", "Delete project"),
                    S.t("سيُحذف «", "Delete “") + pi.name + S.t("» نهائياً بكل طبقاته. لا يمكن التراجع.", "” and all its layers permanently. This cannot be undone."),
                    S.t("حذف", "Delete"), () -> {
                        w.repo().deleteProject(pi.id);
                        a.showPage("projects");
                    })), Ui.lp(0, -2, 1f, a, 2, 8, 0, 0));
            c.addView(r);
            p.addView(c);
        }
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("+ مشروع جديد", "+ New project"), true, this::newProject), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("استرجاع نسخة", "Restore backup"), false, a::pickRestore), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        p.addView(r);
        p.addView(UiKit.note(a, S.t("المزامنة مع خادم غير متوفرة: تحتاج خدمة خارجية. استخدم «نسخة احتياطية» لنقل المشروع بين الأجهزة.",
                "Server sync is not available (needs an external service). Use Backup to move a project between devices.")));
        return p;
    }

    private void newProject() {
        LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, S.t("مشروع جديد", "New project")));
        final EditText f = Ui.field(a, S.t("الاسم", "Name"), InputType.TYPE_CLASS_TEXT);
        box.addView(f);
        final android.app.Dialog d = a.card(box);
        box.addView(Ui.button(a, S.t("إنشاء وفتح", "Create & open"), true, () -> {
            String n = f.getText().toString().trim();
            if (n.isEmpty()) return;
            ws().flush();
            ProjectInfo pi = ws().repo().createProject(n);
            ws().open(pi.id);
            MainActivity.ACTIVE = null;
            a.rebuild();
            d.dismiss();
            a.showPage("projects");
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        d.show();
    }

    private void renameProject(final ProjectInfo pi) {
        LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, S.t("تغيير الاسم", "Rename")));
        final EditText f = Ui.field(a, S.t("الاسم", "Name"), InputType.TYPE_CLASS_TEXT);
        f.setText(pi.name);
        box.addView(f);
        final android.app.Dialog d = a.card(box);
        box.addView(Ui.button(a, S.t("حفظ", "Save"), true, () -> {
            String n = f.getText().toString().trim();
            if (n.isEmpty()) return;
            ws().repo().renameProject(pi.id, n);
            d.dismiss();
            a.showPage("projects");
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        d.show();
    }

    private void backup(final ProjectInfo pi) {
        final Workspace w = ws();
        w.flush();
        final List<LayerData> layers = w.repo().loadLayers(pi.id);
        final String name = "backup_" + iq.gis.poiexporter.core.ShapeWriter.safeName(pi.name) + "_"
                + new java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.US).format(new java.util.Date()) + ".poiproj.zip";
        new Thread(() -> {
            try {
                final Storage.Saved sv = Storage.save(a, a.prefs, name, "application/zip", os -> ProjectArchive.write(pi.name, layers, os));
                a.runOnUiThread(() -> a.message(S.t("تم حفظ النسخة الاحتياطية ✔", "Backup saved ✔"), sv.where, S.t("مشاركة", "Share"),
                        () -> Storage.share(a, sv.uri, "application/zip")));
            } catch (final Throwable t) {
                a.runOnUiThread(() -> a.message(S.t("فشل الحفظ", "Backup failed"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }

    void restorePicked(final Uri u) {
        new Thread(() -> {
            try {
                final ProjectArchive.Restored rs;
                try (java.io.InputStream in = UriIO.open(a, u)) {
                    if (in == null) throw new java.io.IOException("cannot open");
                    rs = ProjectArchive.read(in);
                }
                a.runOnUiThread(() -> {
                    Workspace w = ws();
                    w.flush();
                    ProjectInfo pi = w.repo().createProject(rs.name + S.t(" (مسترجع)", " (restored)"));
                    w.open(pi.id);
                    for (LayerData l : rs.layers) w.addLayerWithFeatures(l);
                    w.clearHistory();
                    MainActivity.ACTIVE = null;
                    a.rebuild();
                    a.showPage("projects");
                    a.toast(S.t("تم الاسترجاع كمشروع جديد", "Restored as a new project"));
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> a.message(S.t("ملف غير صالح", "Invalid file"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }
}
