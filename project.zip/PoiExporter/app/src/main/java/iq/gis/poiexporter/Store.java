package iq.gis.poiexporter;

import android.content.Context;

import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.db.Workspace;

/** Owns the project database and the open workspace for the whole process. */
public final class Store {
    private Store() {
    }

    private static Workspace ws;
    private static SqliteRepo repo;
    private static ExecutorService io;

    public static synchronized Workspace open(Context c) {
        if (ws != null) return ws;
        Context app = c.getApplicationContext();
        repo = new SqliteRepo(app);
        io = Executors.newSingleThreadExecutor();
        ws = new Workspace(repo, io);
        ws.openDefault(S.t("مشروعي", "My project"));
        migrateLibrary(app);
        return ws;
    }

    public static Workspace ws() {
        return ws;
    }

    public static SqliteRepo repo() {
        return repo;
    }

    /** Old v2.x groups (one KML file each) become layers of the default project. The KML files stay untouched as a backup. */
    private static void migrateLibrary(Context c) {
        if ("1".equals(repo.getMeta("migrated_library", "0"))) return;
        try {
            List<LayerData> old = Library.loadAll(c);
            for (LayerData g : old) {
                if (g.features.isEmpty() && g.label.isEmpty()) continue;
                ws.addLayerWithFeatures(g);
            }
            ws.flush();
            ws.clearHistory();
            ws.flush();
            repo.setMeta("migrated_library", "1");
        } catch (RuntimeException e) {
            // keep the flag unset: migration is retried at the next start and layers already added are skipped by id
        }
    }

    /** Waits for pending writes (call from onPause). */
    public static void flush() {
        if (ws != null) ws.flush();
    }

    public static File dbFile(Context c) {
        return SqliteRepo.file(c);
    }
}
