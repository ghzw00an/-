package iq.gis.poiexporter;

import android.app.Dialog;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.EntryTemplates;
import iq.gis.poiexporter.core.EntryTemplates.Template;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;

/** One-tap landmark entry at the GPS position, entry templates, and the short "undo" chip shown after a quick add. */
final class QuickEntry {
    private final MainActivity a;
    private final Handler h = new Handler(Looper.getMainLooper());
    private View chip;

    QuickEntry(MainActivity a) {
        this.a = a;
    }

    // ------------------------------------------------------------------ templates storage

    List<Template> templates() {
        return EntryTemplates.fromJson(a.prefs.get("templates", ""));
    }

    private void saveTemplates(List<Template> l) {
        a.prefs.put("templates", EntryTemplates.toJson(l));
    }

    /** Master switch: when off, no template is applied anywhere (quick add or the normal add form). */
    boolean templatesOn() {
        return a.prefs.flag("tplOn", true);
    }

    /** True when templates also pre-fill the normal add form. */
    boolean inAddForm() {
        return a.prefs.flag("tplInForm", true);
    }

    Template active() {
        if (!templatesOn()) return null;
        String n = a.prefs.get("tplActive", "");
        if (n.isEmpty()) return null;
        for (Template t : templates()) if (t.name.equals(n)) return t;
        return null;
    }

    /** Remembers the last sector and item typed in the add form, used when no template is active. */
    void remember(Feature f) {
        a.prefs.put("lastCat", f.category);
        a.prefs.put("lastType", f.type);
    }

    // ------------------------------------------------------------------ quick add

    void quickAdd() {
        if (a.map == null) return;
        org.osmdroid.api.IGeoPoint mc = a.map.getMapCenter();
        Feature f = Feature.point(mc.getLatitude(), mc.getLongitude());

        Template t = active();
        if (t != null) {
            t.applyTo(f);
        } else {
            f.category = a.prefs.get("lastCat", "");
            f.type = a.prefs.get("lastType", "");
        }
        try {
            iq.gis.poiexporter.core.admin.AdminRef ar = iq.gis.poiexporter.core.admin.AdminRef.get();
            iq.gis.poiexporter.core.admin.AdminRef.Hit hit = ar == null ? null : ar.locate(f.lat, f.lon);
            if (hit != null && hit.found()) {
                if (f.qadaa.isEmpty()) f.qadaa = hit.qadaa(true);
                if (f.governorate.isEmpty()) f.governorate = hit.governorate(true);
            }
        } catch (RuntimeException ignored) {
            // no offline boundaries: the online fill still runs in addToGroup
        }
        f.updated = java.time.LocalDate.now().toString();
        String g = S.t("معالمي", "My landmarks");
        for (LayerData l : MainActivity.LIB) if (l.id.equals(MainActivity.ACTIVE)) g = l.label;
        a.addToGroup(f, g);
        if (a.prefs.flag("haptic", true) && a.mapRoot != null) a.mapRoot.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        showUndo(S.t("أُضيف معلم", "Landmark added") + (t != null ? " • " + t.name : ""));
    }

    private void showUndo(String text) {
        hideChip();
        final FrameLayout root = a.mapRoot;
        if (root == null) return;
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.round(0xE6202B36, 22, a));
        row.setElevation(Ui.dp(a, 8));
        row.setPadding(Ui.dp(a, 16), Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6));
        row.addView(Ui.text(a, text, 14, 0xFFFFFFFF, false));
        TextView undo = Ui.text(a, "↩ " + S.t("تراجع", "Undo"), 14, 0xFFFFD54F, true);
        undo.setPadding(Ui.dp(a, 14), Ui.dp(a, 8), Ui.dp(a, 14), Ui.dp(a, 8));
        undo.setClickable(true);
        Ui.pressable(undo);
        undo.setOnClickListener(v -> {
            hideChip();
            if (Store.ws().canUndo()) {
                Store.ws().undo();
                a.rebuild();
                a.toast(S.t("تم التراجع", "Undone"));
            }
        });
        row.addView(undo);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = Ui.dp(a, 76);
        row.setAlpha(0f);
        row.setTranslationY(-Ui.dp(a, 16));
        root.addView(row, lp);
        row.animate().alpha(1f).translationY(0).setDuration(180).start();
        chip = row;
        h.postDelayed(this::hideChip, 5000);
    }

    private void hideChip() {
        h.removeCallbacksAndMessages(null);
        final View c = chip;
        chip = null;
        if (c == null) return;
        c.animate().alpha(0f).setDuration(160).withEndAction(() -> {
            if (c.getParent() instanceof FrameLayout) ((FrameLayout) c.getParent()).removeView(c);
        }).start();
    }


    // ------------------------------------------------------------------ add by template (name only)

    /** Add at the map centre (the + mark). */
    void addByTemplate() {
        if (a.map == null) return;
        org.osmdroid.api.IGeoPoint mc = a.map.getMapCenter();
        addByTemplate(mc.getLatitude(), mc.getLongitude(), "");
    }

    /** Pick a template, type only the name; sector, type, district, sub-district and governorate are filled from the template and the boundaries. */
    void addByTemplate(final double lat, final double lon, final String suggestedName) {
        final List<Template> ts = templates();
        if (ts.isEmpty()) {
            a.messageConfirm(S.t("لا توجد قوالب", "No templates"),
                    S.t("أنشئ قالباً أولاً (القطاع والنوع والمنطقة)، ثم اختره عند الإضافة.", "Create a template first (sector, type, area), then pick it when adding."),
                    S.t("إنشاء قالب", "Create template"), () -> templatesDialog());
            return;
        }
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, "📋 " + S.t("اختر قالباً", "Pick a template")));
        box.addView(UiKit.note(a, S.t("بعد الاختيار تكتب اسم المعلم فقط، وتُملأ بقية الحقول تلقائياً.", "After picking, type only the name; the other fields fill automatically.")));
        final Dialog d = a.card(wrapScroll(box));
        for (final Template t : ts) {
            LinearLayout c = Ui.card(a);
            int col = iq.gis.poiexporter.core.SectorColors.colorOf(t.category);
            c.addView(UiKit.headerRow(a, col, t.name, null, summary(t), false));
            c.setClickable(true);
            Ui.pressable(c);
            c.setOnClickListener(v -> {
                d.dismiss();
                nameStep(t, lat, lon, suggestedName);
            });
            box.addView(c);
        }
        d.show();
    }

    private void nameStep(final Template t, final double lat, final double lon, String suggested) {
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, t.name));
        box.addView(UiKit.note(a, summary(t)));
        final EditText name = Ui.field(a, S.t("اسم المعلم", "Landmark name"), InputType.TYPE_CLASS_TEXT);
        name.setText(suggested == null ? "" : suggested);
        name.setSelection(name.getText().length());
        box.addView(name, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        final Dialog d = a.card(box);
        box.addView(Ui.button(a, S.t("حفظ", "Save"), true, () -> {
            Feature f = Feature.point(lat, lon);
            t.applyTo(f);
            f.name = name.getText().toString().trim();
            try {
                iq.gis.poiexporter.core.admin.AdminRef ar = iq.gis.poiexporter.core.admin.AdminRef.get();
                iq.gis.poiexporter.core.admin.AdminRef.Hit hit = ar == null ? null : ar.locate(f.lat, f.lon);
                if (hit != null && hit.found()) {
                    if (f.qadaa.isEmpty()) f.qadaa = hit.qadaa(true);
                    if (f.governorate.isEmpty()) f.governorate = hit.governorate(true);
                }
            } catch (RuntimeException ignored) {
                // no offline boundaries: the online fill still runs in addToGroup
            }
            f.updated = java.time.LocalDate.now().toString();
            String g = S.t("معالمي", "My landmarks");
            for (LayerData l : MainActivity.LIB) if (l.id.equals(MainActivity.ACTIVE)) g = l.label;
            a.addToGroup(f, g);
            remember(f);
            d.dismiss();
            showUndo(S.t("أُضيف: ", "Added: ") + (f.name.isEmpty() ? t.name : f.name));
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        d.show();
        name.requestFocus();
        d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    // ------------------------------------------------------------------ templates dialog

    void templatesDialog() {
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, S.t("قوالب الإدخال", "Entry templates")));
        box.addView(UiKit.note(a, S.t("القالب يملأ القطاع والنوع والقضاء والناحية والمحافظة تلقائياً في «الإضافة السريعة ⚡». اختر قالباً واحداً نشطاً أو أطفئه.",
                "A template fills sector, type, district, sub-district and governorate in ⚡ quick add. Pick one active template or turn it off.")));
        box.addView(UiKit.check(a, S.t("تشغيل القوالب", "Templates on"), templatesOn(), v -> a.prefs.setFlag("tplOn", v)));
        box.addView(UiKit.check(a, S.t("تطبيق القالب النشط أيضاً في نافذة «إضافة معلم»", "Also pre-fill the normal «Add landmark» form"),
                inAddForm(), v -> a.prefs.setFlag("tplInForm", v)));
        final Dialog d = a.card(wrapScroll(box));
        refreshList(box, d);
        d.show();
    }

    private View wrapScroll(LinearLayout box) {
        ScrollView sv = new ScrollView(a);
        sv.addView(box);
        LinearLayout o = new LinearLayout(a);
        o.setOrientation(LinearLayout.VERTICAL);
        o.addView(sv, new LinearLayout.LayoutParams(-1, Ui.dp(a, 460)));
        return o;
    }

    private void refreshList(final LinearLayout box, final Dialog d) {
        while (box.getChildCount() > 4) box.removeViewAt(4);
        final List<Template> ts = templates();
        String act = a.prefs.get("tplActive", "");
        if (ts.isEmpty()) {
            box.addView(UiKit.note(a, S.t("لا توجد قوالب بعد.", "No templates yet.")));
        }
        for (final Template t : ts) {
            LinearLayout c = Ui.card(a);
            boolean on = t.name.equals(act);
            c.addView(Ui.text(a, (on ? "● " : "") + t.name, 16, on ? Theme.primary : Theme.text, true));
            c.addView(UiKit.note(a, summary(t)));
            LinearLayout r = Ui.row(a);
            r.addView(Ui.button(a, on ? S.t("إيقاف", "Turn off") : S.t("تفعيل", "Use"), !on, () -> {
                a.prefs.put("tplActive", on ? "" : t.name);
                refreshList(box, d);
                a.toast(on ? S.t("لا يوجد قالب نشط", "No active template") : S.t("القالب النشط: ", "Active template: ") + t.name);
            }), Ui.lp(0, -2, 1f, a, 0, 8, 2, 0));
            r.addView(Ui.button(a, S.t("تعديل", "Edit"), false, () -> edit(t, box, d)), Ui.lp(0, -2, 1f, a, 2, 8, 2, 0));
            r.addView(Ui.button(a, S.t("حذف", "Delete"), false, () -> {
                List<Template> l = templates();
                for (int i = 0; i < l.size(); i++) if (l.get(i).name.equals(t.name)) l.remove(i--);
                saveTemplates(l);
                if (t.name.equals(a.prefs.get("tplActive", ""))) a.prefs.put("tplActive", "");
                refreshList(box, d);
            }), Ui.lp(0, -2, 1f, a, 2, 8, 0, 0));
            c.addView(r);
            box.addView(c);
        }
        box.addView(Ui.button(a, S.t("+ قالب جديد", "+ New template"), true, () -> edit(null, box, d)), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
    }

    private static String summary(Template t) {
        List<String> p = new ArrayList<>();
        if (!t.category.isEmpty()) p.add(t.category);
        if (!t.type.isEmpty()) p.add(t.type);
        if (!t.qadaa.isEmpty()) p.add(t.qadaa);
        if (!t.nahiya.isEmpty()) p.add(t.nahiya);
        if (!t.governorate.isEmpty()) p.add(t.governorate);
        return p.isEmpty() ? "—" : android.text.TextUtils.join(" • ", p);
    }

    private void edit(final Template old, final LinearLayout listBox, final Dialog listDlg) {
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, old == null ? S.t("قالب جديد", "New template") : S.t("تعديل القالب", "Edit template")));
        final EditText name = Ui.field(a, S.t("اسم القالب", "Template name"), InputType.TYPE_CLASS_TEXT);
        final EditText cat = Ui.field(a, "Gategory", InputType.TYPE_CLASS_TEXT);
        final EditText type = Ui.field(a, "type", InputType.TYPE_CLASS_TEXT);
        final EditText qadaa = Ui.field(a, "gathaa", InputType.TYPE_CLASS_TEXT);
        final EditText nahia = Ui.field(a, "Nahia", InputType.TYPE_CLASS_TEXT);
        final EditText gov = Ui.field(a, "mohafadha", InputType.TYPE_CLASS_TEXT);
        if (old != null) {
            name.setText(old.name);
            cat.setText(old.category);
            type.setText(old.type);
            qadaa.setText(old.qadaa);
            nahia.setText(old.nahiya);
            gov.setText(old.governorate);
        } else {
            cat.setText(a.prefs.get("lastCat", ""));
            type.setText(a.prefs.get("lastType", ""));
        }
        box.addView(name, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        box.addView(cat, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        box.addView(SectorPicker.build(a, cat, type));
        box.addView(type, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        box.addView(qadaa, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        box.addView(nahia, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        box.addView(gov, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        final Dialog d = a.card(wrapScroll(box));
        box.addView(Ui.button(a, S.t("حفظ القالب", "Save template"), true, () -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) {
                a.toast(S.t("اكتب اسم القالب", "Enter a template name"));
                return;
            }
            Template t = new Template();
            t.name = n;
            t.category = cat.getText().toString().trim();
            t.type = type.getText().toString().trim();
            t.qadaa = qadaa.getText().toString().trim();
            t.nahiya = nahia.getText().toString().trim();
            t.governorate = gov.getText().toString().trim();
            List<Template> l = templates();
            for (int i = 0; i < l.size(); i++) if (old != null && l.get(i).name.equals(old.name)) l.remove(i--);
            for (int i = 0; i < l.size(); i++) if (l.get(i).name.equals(n)) l.remove(i--);
            l.add(t);
            saveTemplates(l);
            if (old != null && old.name.equals(a.prefs.get("tplActive", ""))) a.prefs.put("tplActive", n);
            d.dismiss();
            refreshList(listBox, listDlg);
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        d.show();
    }
}
