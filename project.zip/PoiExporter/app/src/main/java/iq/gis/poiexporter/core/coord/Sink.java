package iq.gis.poiexporter.core.coord;

import java.io.IOException;
import java.util.List;

/** Receives converted rows. Cells are String or Number (numbers keep their value in Excel/GeoJSON). */
public interface Sink {
    /** columns: names; isLonLat marks nothing, sinks that need the position receive it in row(). */
    void begin(List<String> columns) throws IOException;

    void row(Object[] cells, double lon, double lat) throws IOException;

    /** Finishes the output (flushes and closes the underlying stream). */
    void end() throws IOException;
}
