package iq.gis.poiexporter.core.table;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.crs.Crs;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

/** Turns a table (CSV/TXT/XLSX) with coordinate columns into a point layer. */
public final class PointTable {
    private PointTable() {
    }

    public static final class Guess {
        public int x = -1, y = -1, name = -1, combined = -1;
        public boolean latFirst;
    }

    /** Column indices (-1 = none). For geographic sources x = longitude, y = latitude unless latFirst swaps them. */
    public static final class Mapping {
        public int x = -1, y = -1, name = -1, combined = -1;
        public boolean latFirst;
        /** Combined column holding plain decimal numbers without N/S/E/W: true = "lon, lat" (default "lat, lon"). */
        public boolean combinedLonFirst;

        public Mapping() {
        }

        public Mapping(Guess g) {
            x = g.x;
            y = g.y;
            name = g.name;
            combined = g.combined;
            latFirst = g.latFirst;
        }
    }

    /** Parses a number: Arabic digits, decimal comma, spaces. NaN when not numeric. */
    public static double parseNum(String s) {
        if (s == null) return Double.NaN;
        StringBuilder b = new StringBuilder(s.length());
        boolean dot = s.indexOf('.') >= 0 || s.indexOf('٫') >= 0;
        int commas = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == ',' || s.charAt(i) == '،') commas++;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '٠' && c <= '٩') b.append((char) ('0' + (c - '٠')));
            else if (c >= '۰' && c <= '۹') b.append((char) ('0' + (c - '۰')));
            else if (c == '٫') b.append('.');
            else if ((c == ',' || c == '،') && !dot && commas == 1) b.append('.');
            else if (c == ',' || c == '،' || c == '٬' || c == ' ' || c == ' ') continue;
            else if (c == '−' || c == '–') b.append('-');
            else b.append(c);
        }
        String t = b.toString().trim();
        if (t.isEmpty()) return Double.NaN;
        char c0 = t.charAt(0);
        if (!(c0 == '-' || c0 == '+' || c0 == '.' || c0 >= '0' && c0 <= '9')) return Double.NaN;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (!(c >= '0' && c <= '9' || c == '.' || c == '-' || c == '+' || c == 'e' || c == 'E')) return Double.NaN;
        }
        try {
            double v = Double.parseDouble(t);
            return Double.isInfinite(v) ? Double.NaN : v;
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    private static String norm(String h) {
        return h.toLowerCase(Locale.ROOT).replaceAll("[\\s_\\-.()]", "");
    }

    private static boolean any(String h, String... names) {
        for (String n : names) if (h.equals(n)) return true;
        return false;
    }

    public static Guess guess(List<String> header) {
        Guess g = new Guess();
        int lat = -1, lon = -1, east = -1, north = -1, x = -1, y = -1;
        for (int i = 0; i < header.size(); i++) {
            String h = norm(header.get(i));
            if (any(h, "lat", "latitude", "خطالعرض", "دائرةالعرض", "عرض", "lat_dd", "latdd", "ycoord", "wgs84lat")) lat = lat < 0 ? i : lat;
            else if (any(h, "lon", "lng", "long", "longitude", "خطالطول", "طول", "londd", "lon_dd", "xcoord", "wgs84lon")) lon = lon < 0 ? i : lon;
            else if (any(h, "easting", "east", "e", "شرقي", "إحداثيشرقي", "شرق")) east = east < 0 ? i : east;
            else if (any(h, "northing", "north", "n", "شمالي", "إحداثيشمالي", "شمال")) north = north < 0 ? i : north;
            else if (any(h, "x")) x = x < 0 ? i : x;
            else if (any(h, "y")) y = y < 0 ? i : y;
            else if (g.name < 0 && (any(h, "name", "اسم", "الاسم", "title", "label", "اسمالمعلم", "المعلم", "namear", "nameen") || h.startsWith("name")))
                g.name = i;
            else if (g.combined < 0 && any(h, "coord", "coords", "coordinates", "coordinate", "الاحداثيات", "الإحداثيات", "احداثيات", "إحداثيات",
                    "location", "الموقع", "position", "mgrs", "utm", "latlon", "latlng"))
                g.combined = i;
        }
        if (lat >= 0 && lon >= 0) {
            g.x = lon;
            g.y = lat;
            g.latFirst = lat < lon;
        } else if (east >= 0 && north >= 0) {
            g.x = east;
            g.y = north;
        } else if (x >= 0 && y >= 0) {
            g.x = x;
            g.y = y;
        }
        if (g.x >= 0 && g.y >= 0) g.combined = -1;
        return g;
    }

    /** Rejected row: carries a bilingual reason (use {@link #reason()}). */
    public static final class BadRow extends Exception {
        final String ar, en;

        BadRow(String ar, String en) {
            super(en);
            this.ar = ar;
            this.en = en;
        }

        public String reason() {
            return S.t(ar, en);
        }
    }

    /** Parses one table row into WGS84 lon/lat according to a mapping. Not thread safe. */
    public static final class RowParser {
        private final Mapping m;
        private final boolean geo, useCombined;
        private final Crs.Tx tx;
        private final double[] out = new double[2];

        public RowParser(Mapping m, Crs src) throws IOException {
            this.m = m;
            this.geo = src == null || src.geographic;
            this.tx = src == null || src.epsg == 4326 ? null : src.to(Crs.wgs84());
            this.useCombined = m.combined >= 0 && (m.x < 0 || m.y < 0);
            if (!useCombined && (m.x < 0 || m.y < 0))
                throw new IOException(S.t("حدّد عمودي X وY أو عموداً واحداً للإحداثيات", "Choose the X and Y columns or one coordinate column"));
            if (useCombined && src != null && !src.geographic)
                throw new IOException(S.t("عمود الإحداثيات المدمج يجب أن يكون نصاً جغرافياً (DD/DMS/UTM/MGRS) بنظام WGS84",
                        "A combined coordinate column must be geographic text (DD/DMS/UTM/MGRS) in WGS84"));
        }

        /** Returns {lon, lat} (a fresh array). */
        public double[] parse(String[] row) throws BadRow {
            double lon, lat;
            if (useCombined) {
                String s = cell(row, m.combined);
                CoordFmt.Parsed p;
                try {
                    p = CoordFmt.parse(s);
                } catch (IllegalArgumentException e) {
                    throw new BadRow("إحداثيات غير مفهومة: «" + safe(s) + "»", "unrecognised coordinates: \"" + safe(s) + "\"");
                }
                lat = p.lat;
                lon = p.lon;
                if (m.combinedLonFirst && p.fmt == CoordFmt.Fmt.DD && !s.toUpperCase(Locale.ROOT).matches(".*[NSEW].*")) {
                    double t = lat;
                    lat = lon;
                    lon = t;
                    if (Math.abs(lat) > 90) throw new BadRow("خط العرض خارج ±90", "latitude outside ±90");
                }
            } else {
                String sa = cell(row, m.x), sb = cell(row, m.y);
                double a = parseNum(sa), b = parseNum(sb);
                if (Double.isNaN(a) || Double.isNaN(b))
                    throw new BadRow("قيمة إحداثي غير رقمية أو فارغة (" + safe(sa) + " / " + safe(sb) + ")",
                            "empty or non-numeric coordinate (" + safe(sa) + " / " + safe(sb) + ")");
                if (geo) {
                    if (Math.abs(b) > 90)
                        throw new BadRow("خط العرض " + sb + " خارج المدى ±90 (هل عمودا الطول والعرض معكوسان؟)",
                                "latitude " + sb + " outside ±90 (are lon/lat columns swapped?)");
                    if (Math.abs(a) > 180)
                        throw new BadRow("خط الطول " + sa + " خارج المدى ±180", "longitude " + sa + " outside ±180");
                    lon = a;
                    lat = b;
                    if (tx != null) {
                        try {
                            tx.apply(a, b, out);
                        } catch (IllegalArgumentException e) {
                            throw new BadRow("تعذّر تحويل المرجعية: " + e.getMessage(), "datum transform failed: " + e.getMessage());
                        }
                        lon = out[0];
                        lat = out[1];
                    }
                } else {
                    try {
                        tx.apply(a, b, out);
                    } catch (IllegalArgumentException e) {
                        throw new BadRow("الإحداثيات (" + sa + ", " + sb + ") خارج مجال النظام المرجعي؛ تحقق من النظام ومن ترتيب X وY",
                                "coordinates (" + sa + ", " + sb + ") outside the CRS area; check the CRS and the X/Y order");
                    }
                    lon = out[0];
                    lat = out[1];
                }
            }
            if (Double.isNaN(lat) || Double.isNaN(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180)
                throw new BadRow("الإحداثيات الناتجة خارج النطاق الجغرافي", "result outside geographic range");
            return new double[]{lon, lat};
        }

        /** Resolution in metres of the typed values of this row (for honest output digits). */
        public double resolutionMetres(String[] row, double lat) {
            if (useCombined) return iq.gis.poiexporter.core.coord.Precision.resolutionMetres(cell(row, m.combined));
            int d = Math.max(iq.gis.poiexporter.core.coord.Precision.decimals(cell(row, m.x)),
                    iq.gis.poiexporter.core.coord.Precision.decimals(cell(row, m.y)));
            double r = Math.pow(10, -d);
            return Math.max(geo ? r * 111320.0 : r, 0.001);
        }
    }

    /** Builds the layer. Geographic sources: x = longitude, y = latitude. */
    public static LayerData toLayer(File f, String name, Mapping m, Crs src, RowReport rep) throws IOException {
        if (rep == null) rep = new RowReport();
        String label = name == null ? f.getName() : name.replaceAll("\\.[A-Za-z0-9]+$", "");
        LayerData layer = new LayerData("imp_" + System.currentTimeMillis(), label, Feature.POINT);
        layer.kind = "import";
        layer.source = name == null ? f.getName() : name;
        RowParser parser = new RowParser(m, src);
        TableReader r = TableReader.open(f, name);
        try {
            List<String> header = r.header();
            String[] row;
            while ((row = r.next()) != null) {
                rep.read++;
                double[] ll;
                try {
                    ll = parser.parse(row);
                } catch (BadRow e) {
                    rep.bad(r.rowNumber(), e.ar, e.en);
                    continue;
                }
                Feature ft = Feature.point(ll[1], ll[0]);
                ft.id = Feature.newId();
                if (m.name >= 0) ft.name = cell(row, m.name).trim();
                java.util.LinkedHashMap<String, String> props = new java.util.LinkedHashMap<>();
                for (int c = 0; c < row.length && c < header.size(); c++) {
                    if (c == m.x || c == m.y || c == m.name || c == m.combined) continue;
                    String v = row[c];
                    if (v != null && !v.isEmpty()) props.put(header.get(c), v);
                }
                String nameCol = ft.name;
                iq.gis.poiexporter.core.io.Mapper.apply(ft, props);
                if (!nameCol.isEmpty()) ft.name = nameCol;
                Geo.setRepresentative(ft);
                layer.features.add(ft);
                rep.ok++;
            }
        } finally {
            r.close();
        }
        return layer;
    }

    private static String safe(String s) {
        return s.length() > 40 ? s.substring(0, 40) + "…" : s;
    }

    static String cell(String[] row, int i) {
        return i >= 0 && i < row.length && row[i] != null ? row[i] : "";
    }
}
