package iq.gis.poiexporter;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Opening screen: the emblem fades and grows in over a navy gradient with a thin gold progress line, then dissolves into the map. */
final class Splash {
    private Splash() {
    }

    static void show(final Activity a, String version) {
        final ViewGroup root = a.findViewById(android.R.id.content);
        if (root == null) return;
        final FrameLayout v = new FrameLayout(a);
        v.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF0B1A33, 0xFF050B16}));
        v.setClickable(true);
        float d = a.getResources().getDisplayMetrics().density;

        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);

        ImageView logo = new ImageView(a);
        int id = a.getResources().getIdentifier("logo", "drawable", a.getPackageName());
        if (id != 0) logo.setImageResource(id);
        logo.setAdjustViewBounds(true);
        logo.setScaleX(0.82f);
        logo.setScaleY(0.82f);
        logo.setAlpha(0f);
        int sz = Math.min(Math.round(a.getResources().getDisplayMetrics().widthPixels * 0.62f), Math.round(300 * d));
        col.addView(logo, new LinearLayout.LayoutParams(sz, sz));

        TextView title = new TextView(a);
        title.setText(S.t("مصدّر المعالم", "POI Exporter"));
        title.setTextColor(0xFFE8C877);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setAlpha(0f);
        col.addView(title, new LinearLayout.LayoutParams(-2, -2));

        TextView sub = new TextView(a);
        sub.setText("GIS  •  v" + version);
        sub.setTextColor(0xFF9FB3D1);
        sub.setTextSize(13);
        sub.setGravity(Gravity.CENTER);
        sub.setAlpha(0f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.topMargin = Math.round(4 * d);
        col.addView(sub, sp);

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        v.addView(col, cp);

        final View bar = new View(a);
        bar.setBackgroundColor(0xFFD9B25A);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(0, Math.round(3 * d), Gravity.BOTTOM | Gravity.LEFT);
        bp.bottomMargin = Math.round(48 * d);
        v.addView(bar, bp);
        root.addView(v, new ViewGroup.LayoutParams(-1, -1));
        v.setElevation(1000f);

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).start();
        title.animate().alpha(1f).setStartDelay(250).setDuration(500).start();
        sub.animate().alpha(1f).setStartDelay(400).setDuration(500).start();
        final int full = a.getResources().getDisplayMetrics().widthPixels;
        android.animation.ValueAnimator va = android.animation.ValueAnimator.ofInt(0, full);
        va.setDuration(1300);
        va.addUpdateListener(x -> {
            ViewGroup.LayoutParams l = bar.getLayoutParams();
            l.width = (int) x.getAnimatedValue();
            bar.setLayoutParams(l);
        });
        va.start();
        v.postDelayed(() -> v.animate().alpha(0f).setDuration(380).withEndAction(() -> root.removeView(v)).start(), 1500);
    }
}
