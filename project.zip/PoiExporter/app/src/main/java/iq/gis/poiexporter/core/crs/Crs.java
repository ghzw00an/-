package iq.gis.poiexporter.core.crs;

import org.locationtech.proj4j.BasicCoordinateTransform;
import org.locationtech.proj4j.CRSFactory;
import org.locationtech.proj4j.CoordinateReferenceSystem;
import org.locationtech.proj4j.ProjCoordinate;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Coordinate reference system backed by Proj4J (real projection maths, EPSG parameter file bundled in the app).
 *
 * <p>Axis convention of this class: x = easting or longitude, y = northing or latitude (always, for every CRS, so
 * the order never depends on how EPSG defines the axes). The UI labels the values explicitly.
 */
public final class Crs {
    public static final class Entry {
        public final int code;
        public final String name;
        public final String proj;

        Entry(int code, String name, String proj) {
            this.code = code;
            this.name = name;
            this.proj = proj;
        }

        public boolean geographic() {
            return proj.contains("+proj=longlat");
        }
    }

    private static final CRSFactory FACTORY = new CRSFactory();
    private static final Map<String, Crs> CACHE = new HashMap<>();
    private static List<Entry> catalog;
    private static Map<Integer, Entry> byCode;

    public final int epsg;
    public final String name;
    public final boolean geographic;
    final CoordinateReferenceSystem crs;
    private final String proj;

    private Crs(int epsg, String name, CoordinateReferenceSystem crs, String proj) {
        this.epsg = epsg;
        this.name = name;
        this.crs = crs;
        this.proj = proj;
        this.geographic = proj.contains("+proj=longlat");
    }

    /** "EPSG:32638". */
    public String code() {
        return epsg == 0 ? "CUSTOM" : "EPSG:" + epsg;
    }

    public String proj4() {
        return proj;
    }

    public String toString() {
        return code() + " - " + name;
    }

    public static synchronized Crs wgs84() {
        return of(4326);
    }

    public static Crs of(String text) {
        String t = text.trim().toUpperCase(Locale.US);
        if (t.startsWith("EPSG:")) t = t.substring(5);
        try {
            return of(Integer.parseInt(t.trim()));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Bad CRS code: " + text);
        }
    }

    public static synchronized Crs of(int epsg) {
        String key = "EPSG:" + epsg;
        Crs c = CACHE.get(key);
        if (c != null) return c;
        Entry e = entries().get(epsg);
        if (e == null) throw new IllegalArgumentException("Unknown EPSG code: " + epsg);
        CoordinateReferenceSystem p = FACTORY.createFromParameters(key, e.proj);
        c = new Crs(epsg, e.name, p, e.proj);
        CACHE.put(key, c);
        return c;
    }

    /** True when the bundled EPSG file can be read (false would mean a packaging problem). */
    public static boolean available() {
        try {
            return of(4326) != null && of(32638) != null;
        } catch (Throwable t) {
            return false;
        }
    }

    public static Crs utm(int zone, boolean north) {
        return of((north ? 32600 : 32700) + zone);
    }

    private static int customCounter;

    /** A CRS from a Proj4 parameter string, e.g. "+proj=laea +lat_0=33 +lon_0=44 +datum=WGS84 +units=m" (epsg = 0). */
    public static synchronized Crs fromProj4(String name, String proj) {
        String key = "CUSTOM:" + (customCounter++);
        return new Crs(0, name, FACTORY.createFromParameters(key, proj), proj);
    }

    /** UTM zone (WGS84) that contains the longitude. */
    public static int utmZone(double lon) {
        return Math.max(1, Math.min(60, (int) Math.floor((lon + 180) / 6) + 1));
    }

    // ------------------------------------------------------------------ catalog

    private static synchronized Map<Integer, Entry> entries() {
        if (byCode == null) loadCatalog();
        return byCode;
    }

    /** All CRS of the bundled EPSG file (about 5800 entries), in file order. */
    public static synchronized List<Entry> catalog() {
        if (catalog == null) loadCatalog();
        return catalog;
    }

    private static final Pattern LINE = Pattern.compile("^<(\\d+)>\\s+(.*?)\\s*<>\\s*$");

    private static void loadCatalog() {
        List<Entry> list = new ArrayList<>();
        Map<Integer, Entry> map = new HashMap<>();
        InputStream in = Crs.class.getClassLoader().getResourceAsStream("proj4/nad/epsg");
        if (in == null) throw new IllegalStateException("EPSG parameter file is missing from the app");
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String name = "";
            String l;
            while ((l = r.readLine()) != null) {
                if (l.startsWith("#")) {
                    name = l.substring(1).trim();
                    continue;
                }
                Matcher m = LINE.matcher(l);
                if (!m.matches()) continue;
                int code = Integer.parseInt(m.group(1));
                String proj = m.group(2);
                if (!proj.contains("+proj=") || proj.contains("+nadgrids=") && !proj.contains("@null")) {
                    if (!proj.contains("+proj=")) continue;
                }
                Entry e = new Entry(code, name, proj);
                if (!map.containsKey(code)) {
                    list.add(e);
                    map.put(code, e);
                }
            }
            r.close();
        } catch (Exception ex) {
            throw new IllegalStateException("Cannot read EPSG file: " + ex.getMessage());
        }
        catalog = list;
        byCode = map;
    }

    /** Case-insensitive search by code or name. */
    public static List<Entry> search(String q, int max) {
        String s = q.trim().toLowerCase(Locale.US);
        List<Entry> out = new ArrayList<>();
        for (Entry e : catalog()) {
            if (s.isEmpty() || String.valueOf(e.code).startsWith(s.replace("epsg:", "")) || e.name.toLowerCase(Locale.US).contains(s)) {
                out.add(e);
                if (out.size() >= max) break;
            }
        }
        return out;
    }

    /** Curated shortlist for Iraq and the region, shown first in the pickers. */
    public static int[] favourites() {
        return new int[]{4326, 32638, 32637, 32639, 32636, 3857, 4230, 23038, 23037, 23039, 4204, 20438, 20437, 20439,
                4270, 3893, 3891, 3892};
    }

    // ------------------------------------------------------------------ transform

    /** Not thread safe: make one per thread. */
    public static final class Tx {
        private final BasicCoordinateTransform t;
        private final ProjCoordinate in = new ProjCoordinate(), out = new ProjCoordinate();

        Tx(Crs from, Crs to) {
            t = new BasicCoordinateTransform(from.crs, to.crs);
        }

        /** Returns {x, y} of the target CRS. Throws IllegalArgumentException for impossible coordinates. */
        public double[] apply(double x, double y) {
            double[] r = new double[2];
            apply(x, y, r);
            return r;
        }

        public void apply(double x, double y, double[] res) {
            if (Double.isNaN(x) || Double.isNaN(y) || Double.isInfinite(x) || Double.isInfinite(y))
                throw new IllegalArgumentException("not a number");
            in.x = x;
            in.y = y;
            in.z = 0;
            try {
                t.transform(in, out);
            } catch (RuntimeException e) {
                throw new IllegalArgumentException("transform failed: " + e.getMessage());
            }
            if (Double.isNaN(out.x) || Double.isNaN(out.y) || Double.isInfinite(out.x) || Double.isInfinite(out.y))
                throw new IllegalArgumentException("result outside the valid area of the projection");
            res[0] = out.x;
            res[1] = out.y;
        }
    }

    public Tx to(Crs target) {
        return new Tx(this, target);
    }

    /** Datum parameter set (towgs84 text) or "" when none (WGS84-equivalent). */
    public String datumShift() {
        Matcher m = Pattern.compile("\\+towgs84=([^\\s]+)").matcher(proj);
        return m.find() ? m.group(1) : "";
    }

    /** True when the datum shift between the two systems is a 3/7-parameter approximation (metre-level error). */
    public static boolean approximateShift(Crs a, Crs b) {
        String sa = a.datumShift(), sb = b.datumShift();
        if (sa.equals(sb)) return false;
        return !isZero(sa) || !isZero(sb);
    }

    private static boolean isZero(String s) {
        if (s.isEmpty()) return true;
        for (String p : s.split(",")) if (Math.abs(Double.parseDouble(p)) > 1e-9) return false;
        return true;
    }

    /** {semi-major axis a, inverse flattening 1/f (0 for a sphere), semi-minor b} of the CRS ellipsoid. */
    public double[] ellipsoidAB() {
        org.locationtech.proj4j.datum.Ellipsoid e = crs.getDatum().getEllipsoid();
        double a = e.equatorRadius, b = e.poleRadius;
        double invF = a == b ? 0 : a / (a - b);
        return new double[]{a, invF, b};
    }

    public String ellipsoid() {
        Matcher m = Pattern.compile("\\+(?:ellps|datum)=([^\\s]+)").matcher(proj);
        return m.find() ? m.group(1) : "";
    }

    /** UTM zone and hemisphere if this is a UTM system. */
    public int[] utmZoneOf() {
        Matcher m = Pattern.compile("\\+proj=utm \\+zone=(\\d+)(\\s+\\+south)?").matcher(proj);
        if (!m.find()) return null;
        return new int[]{Integer.parseInt(m.group(1)), m.group(2) != null ? 0 : 1};
    }
}
