package iq.gis.poiexporter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.SectorColors;
import iq.gis.poiexporter.core.Sectors;

/** Start page: totals, a pie of the sectors, quick actions and the most recent landmarks. */
final class DashboardPage {
    private final MainActivity a;

    DashboardPage(MainActivity a) {
        this.a = a;
    }

    /** Donut chart drawn with the sector colours; the centre shows the total. */
    private static final class Donut extends View {
        private final int[] counts;
        private final int total;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private float grow = 0f;

        Donut(Context c, int[] counts, int total) {
            super(c);
            this.counts = counts;
            this.total = total;
            p.setStyle(Paint.Style.STROKE);
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setFakeBoldText(true);
            animate().setDuration(0);
            android.animation.ValueAnimator va = android.animation.ValueAnimator.ofFloat(0f, 1f);
            va.setDuration(650);
            va.addUpdateListener(v -> {
                grow = (float) v.getAnimatedValue();
                invalidate();
            });
            va.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float d = getResources().getDisplayMetrics().density;
            float s = Math.min(getWidth(), getHeight());
            float sw = s * 0.17f;
            p.setStrokeWidth(sw);
            r.set((getWidth() - s) / 2f + sw / 2, (getHeight() - s) / 2f + sw / 2, (getWidth() + s) / 2f - sw / 2, (getHeight() + s) / 2f - sw / 2);
            if (total == 0) {
                p.setColor(Theme.line);
                c.drawArc(r, 0, 360, false, p);
            } else {
                float start = -90f;
                for (int i = 0; i < counts.length; i++) {
                    if (counts[i] == 0) continue;
                    float sweep = 360f * counts[i] / total * grow;
                    p.setColor(i < SectorColors.count() ? SectorColors.colorAt(i) : Theme.sub);
                    c.drawArc(r, start, Math.max(0.5f, sweep - 1.5f), false, p);
                    start += sweep;
                }
            }
            tp.setColor(Theme.text);
            tp.setTextSize(s * 0.22f);
            c.drawText(String.valueOf((int) (total * grow)), getWidth() / 2f, getHeight() / 2f + s * 0.05f, tp);
            tp.setColor(Theme.sub);
            tp.setFakeBoldText(false);
            tp.setTextSize(11f * d);
            c.drawText(S.t("معلم", "landmarks"), getWidth() / 2f, getHeight() / 2f + s * 0.05f + 15f * d, tp);
            tp.setFakeBoldText(true);
        }
    }

    View build() {
        LinearLayout p = UiKit.col(a);
        List<LayerData> layers = MainActivity.WS.layers();
        int n = Sectors.ALL.length + 1; // last slot: no / other sector
        int[] cnt = new int[n];
        int total = 0, points = 0, lines = 0, polys = 0, noName = 0;
        Feature[] recent = new Feature[5];
        int rc = 0;
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                total++;
                if (f.geom == Feature.POINT) points++;
                else if (f.geom == Feature.LINE) lines++;
                else polys++;
                if (f.name == null || f.name.trim().isEmpty()) noName++;
                int si = SectorColors.indexOf(f.category);
                cnt[si < 0 ? n - 1 : si]++;
                recent[rc++ % 5] = f;
            }
        }

        // greeting + totals
        LinearLayout hero = Ui.card(a);
        hero.addView(Ui.text(a, S.t("لوحة المعلومات", "Dashboard"), 20, Theme.text, true));
        hero.addView(UiKit.note(a, S.t("المشروع: ", "Project: ") + MainActivity.WS.project().name));
        LinearLayout stats = Ui.row(a);
        stats.addView(stat(String.valueOf(layers.size()), S.t("طبقة", "layers")), Ui.lp(0, -2, 1f, a, 0, 8, 3, 0));
        stats.addView(stat(String.valueOf(points), S.t("نقطة", "points")), Ui.lp(0, -2, 1f, a, 3, 8, 3, 0));
        stats.addView(stat(lines + "/" + polys, S.t("خط/مضلع", "line/poly")), Ui.lp(0, -2, 1f, a, 3, 8, 0, 0));
        hero.addView(stats);
        p.addView(hero);

        if (total == 0) {
            p.addView(UiKit.empty(a, "📍", S.t("ابدأ أول معلم", "Add your first landmark"),
                    S.t("اضغط الزر لوضع معلم في مركز الخريطة، أو استورد ملفاً أو حمّل بيانات المنطقة.", "Tap to place a landmark at the map centre, import a file, or download the area."),
                    S.t("⚑ إضافة معلم", "⚑ Add landmark"), () -> {
                        a.showMap();
                        a.addAtCenter();
                    }));
        } else {
            LinearLayout pie = Ui.card(a);
            pie.addView(UiKit.head(a, S.t("توزيع القطاعات", "Sectors")));
            LinearLayout row = Ui.row(a);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(new Donut(a, cnt, total), new LinearLayout.LayoutParams(Ui.dp(a, 150), Ui.dp(a, 150)));
            LinearLayout leg = UiKit.col(a);
            for (int k = 0; k < n; k++) {
                if (cnt[k] == 0) continue;
                LinearLayout lr = Ui.row(a);
                lr.setGravity(Gravity.CENTER_VERTICAL);
                View dot = new View(a);
                dot.setBackground(Ui.round(k < SectorColors.count() ? SectorColors.colorAt(k) : Theme.sub, 5, a));
                lr.addView(dot, Ui.lp(Ui.dp(a, 10), Ui.dp(a, 10), 0, a, 0, 0, 6, 0));
                String nm = k < Sectors.ALL.length ? Sectors.ALL[k].name : S.t("بدون قطاع", "No sector");
                lr.addView(Ui.text(a, nm, 12.5f, Theme.text, false), new LinearLayout.LayoutParams(0, -2, 1f));
                lr.addView(Ui.text(a, String.valueOf(cnt[k]), 12.5f, Theme.sub, true));
                leg.addView(lr, Ui.lp(-1, -2, 0, a, 0, 3, 0, 3));
            }
            android.widget.ScrollView sv = new android.widget.ScrollView(a);
            sv.addView(leg);
            row.addView(sv, Ui.lp(0, Ui.dp(a, 150), 1f, a, 12, 0, 0, 0));
            pie.addView(row);
            p.addView(pie);

            if (noName > 0) {
                LinearLayout w = Ui.card(a);
                w.addView(Ui.text(a, "⚠ " + noName + S.t(" معلم بلا اسم", " landmark(s) without a name"), 14, Theme.danger, true));
                w.addView(UiKit.note(a, S.t("افتح «جودة البيانات» لمراجعتها وإصلاحها.", "Open “Data quality” to review and fix them.")));
                w.addView(Ui.button(a, S.t("فحص الجودة", "Check quality"), false, () -> a.showPage("quality")), Ui.lp(-1, -2, 0, a, 0, 6, 0, 0));
                p.addView(w);
            }
        }

        // quick actions
        LinearLayout act = Ui.card(a);
        act.addView(UiKit.head(a, S.t("إجراءات سريعة", "Quick actions")));
        act.addView(UiKit.tiles(a,
                UiKit.tile(a, "🗺", S.t("الخريطة", "Map"), false, a::showMap),
                UiKit.tile(a, "⚡", S.t("إضافة سريعة", "Quick add"), false, () -> {
                    a.showMap();
                    a.quick.quickAdd();
                }),
                UiKit.tile(a, "⬇", S.t("تحميل", "Download"), false, () -> a.showPage("layers")),
                UiKit.tile(a, "🖨", S.t("تقرير", "Report"), false, () -> a.showPage("report"))));
        act.addView(UiKit.tiles(a,
                UiKit.tile(a, "▦", S.t("الجدول", "Table"), false, () -> a.showPage("attrs")),
                UiKit.tile(a, "✔", S.t("الجودة", "Quality"), false, () -> a.showPage("quality")),
                UiKit.tile(a, "⇵", S.t("استيراد/تصدير", "Import/export"), false, () -> a.showPage("hub")),
                UiKit.tile(a, "💾", S.t("نسخ احتياطي", "Backup"), false, () -> a.showPage("backups"))));
        p.addView(act);

        // recent
        if (rc > 0) {
            LinearLayout rec = Ui.card(a);
            rec.addView(UiKit.head(a, S.t("آخر المعالم", "Latest landmarks")));
            int shown = Math.min(rc, 5);
            for (int i = 0; i < shown; i++) {
                final Feature f = recent[((rc - 1 - i) % 5 + 5) % 5];
                LayerData owner = null;
                for (LayerData l : layers) if (l.features.contains(f)) owner = l;
                final LayerData lay = owner;
                int col = SectorColors.colorOf(f.category);
                LinearLayout r = UiKit.headerRow(a, col, f.name.isEmpty() ? S.t("(بلا اسم)", "(unnamed)") : f.name, null,
                        (f.category.isEmpty() ? "" : f.category) + (f.type.isEmpty() ? "" : "  •  " + f.type), false);
                r.setClickable(true);
                Ui.pressable(r);
                r.setOnClickListener(v -> {
                    a.showMap();
                    a.flashTo(f);
                });
                rec.addView(r, Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
            }
            p.addView(rec);
        }
        return p;
    }

    private View stat(String big, String small) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10));
        c.setBackground(Ui.round(Theme.field, 14, a));
        TextView b = Ui.text(a, big, 22, Theme.primary, true);
        b.setGravity(Gravity.CENTER);
        TextView s = Ui.text(a, small, 11.5f, Theme.sub, false);
        s.setGravity(Gravity.CENTER);
        c.addView(b, new LinearLayout.LayoutParams(-1, -2));
        c.addView(s, new LinearLayout.LayoutParams(-1, -2));
        return c;
    }
}
