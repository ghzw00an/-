package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.Jts;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.crs.Crs;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ByteOrderValues;
import org.locationtech.jts.io.WKBReader;
import org.locationtech.jts.io.WKBWriter;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * GeoPackage (OGC 12-128r15) feature tables. The database access is abstracted ({@link SqlExec}, {@link Source}) so the
 * encoding logic is testable on the JVM; Android implementations are in {@code iq.gis.poiexporter.GpkgAndroid}.
 */
public final class Gpkg {
    private Gpkg() {
    }

    public static final int APPLICATION_ID = 0x47504B47, USER_VERSION = 10300;

    public interface SqlExec {
        void begin() throws IOException;

        void exec(String sql, Object... args) throws IOException;

        void commit() throws IOException;
    }

    /** Read access: rows are Object[] of String / Long / Double / byte[] / null. */
    public interface Source {
        /** Rows (table_name, identifier, srs_id) of gpkg_contents with data_type = 'features'. */
        List<Object[]> featureTables() throws IOException;

        /** Name of the geometry column of the table, or null. */
        String geometryColumn(String table) throws IOException;

        /** {organization, organization_coordsys_id} of the srs row, or null. */
        Object[] srs(long srsId) throws IOException;

        List<String> columns(String table) throws IOException;

        long count(String table) throws IOException;

        /** Rows in chunks: select the given columns of the table in rowid order. */
        List<Object[]> rows(String table, List<String> cols, long offset, int limit) throws IOException;
    }

    // ------------------------------------------------------------------ geometry blobs

    private static final WKBWriter WRITER = new WKBWriter(2, ByteOrderValues.LITTLE_ENDIAN);

    /** GP binary: header (little endian, XY envelope) + WKB. Lines and polygons are written as Multi* geometries. */
    public static byte[] encode(Feature f, int srsId) {
        Geometry g = Jts.toGeometry(f);
        if (g == null) return null;
        if (g instanceof org.locationtech.jts.geom.LineString) g = Jts.GF.createMultiLineString(new org.locationtech.jts.geom.LineString[]{(org.locationtech.jts.geom.LineString) g});
        else if (g instanceof org.locationtech.jts.geom.Polygon) g = Jts.GF.createMultiPolygon(new org.locationtech.jts.geom.Polygon[]{(org.locationtech.jts.geom.Polygon) g});
        byte[] wkb = WRITER.write(g);
        org.locationtech.jts.geom.Envelope e = g.getEnvelopeInternal();
        ByteBuffer b = ByteBuffer.allocate(8 + 32 + wkb.length).order(ByteOrder.LITTLE_ENDIAN);
        b.put((byte) 'G').put((byte) 'P').put((byte) 0).put((byte) 0x03);
        b.putInt(srsId);
        b.putDouble(e.getMinX()).putDouble(e.getMaxX()).putDouble(e.getMinY()).putDouble(e.getMaxY());
        b.put(wkb);
        return b.array();
    }

    /** Geometry of a GP blob (empty blobs give null). */
    public static Geometry decodeGeometry(byte[] blob) throws IOException {
        if (blob == null || blob.length < 8 || blob[0] != 'G' || blob[1] != 'P') throw new IOException("not a GeoPackage geometry");
        int flags = blob[3] & 0xFF;
        boolean le = (flags & 1) == 1;
        if ((flags & 0x10) != 0) return null; // empty geometry
        int env = (flags >> 1) & 7;
        int[] envBytes = {0, 32, 48, 48, 64, 0, 0, 0};
        int off = 8 + envBytes[env];
        if (off > blob.length) throw new IOException("truncated geometry header");
        try {
            byte[] wkb = java.util.Arrays.copyOfRange(blob, off, blob.length);
            return new WKBReader(Jts.GF).read(wkb);
        } catch (org.locationtech.jts.io.ParseException e) {
            throw new IOException("bad WKB: " + e.getMessage());
        }
    }

    public static int srsOf(byte[] blob) {
        if (blob == null || blob.length < 8) return 0;
        ByteBuffer b = ByteBuffer.wrap(blob, 4, 4).order((blob[3] & 1) == 1 ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN);
        return b.getInt();
    }

    // ------------------------------------------------------------------ writing

    private static final String WGS84_WKT = "GEOGCS[\"WGS 84\",DATUM[\"WGS_1984\",SPHEROID[\"WGS 84\",6378137,298.257223563,"
            + "AUTHORITY[\"EPSG\",\"7030\"]],AUTHORITY[\"EPSG\",\"6326\"]],PRIMEM[\"Greenwich\",0,AUTHORITY[\"EPSG\",\"8901\"]],"
            + "UNIT[\"degree\",0.0174532925199433,AUTHORITY[\"EPSG\",\"9122\"]],AUTHORITY[\"EPSG\",\"4326\"]]";

    private static final String[] STD = {"name", "name_en", "type", "category", "governorat", "qadaa", "nahiya", "status", "source",
            "updated", "descr", "notes"};

    private static String ident(String s) {
        String t = s.replaceAll("[^A-Za-z0-9_]", "_").replaceAll("_+", "_");
        if (t.isEmpty() || t.equals("_")) t = "layer";
        if (Character.isDigit(t.charAt(0))) t = "t_" + t;
        return t;
    }

    /** Writes layers (WGS84 only) as feature tables. One table per layer and geometry type. */
    public static ExportResult write(List<LayerData> layers, SqlExec db, boolean attributes) throws IOException {
        ExportResult res = new ExportResult();
        db.begin();
        db.exec("PRAGMA application_id = " + APPLICATION_ID);
        db.exec("PRAGMA user_version = " + USER_VERSION);
        db.exec("CREATE TABLE gpkg_spatial_ref_sys (srs_name TEXT NOT NULL, srs_id INTEGER PRIMARY KEY, organization TEXT NOT NULL, "
                + "organization_coordsys_id INTEGER NOT NULL, definition TEXT NOT NULL, description TEXT)");
        db.exec("INSERT INTO gpkg_spatial_ref_sys VALUES (?,?,?,?,?,?)", "WGS 84 geodetic", 4326L, "EPSG", 4326L, WGS84_WKT, "longitude/latitude coordinates in decimal degrees on the WGS 84 spheroid");
        db.exec("INSERT INTO gpkg_spatial_ref_sys VALUES (?,?,?,?,?,?)", "Undefined Cartesian SRS", -1L, "NONE", -1L, "undefined", "undefined Cartesian coordinate reference system");
        db.exec("INSERT INTO gpkg_spatial_ref_sys VALUES (?,?,?,?,?,?)", "Undefined geographic SRS", 0L, "NONE", 0L, "undefined", "undefined geographic coordinate reference system");
        db.exec("CREATE TABLE gpkg_contents (table_name TEXT NOT NULL PRIMARY KEY, data_type TEXT NOT NULL, identifier TEXT UNIQUE, "
                + "description TEXT DEFAULT '', last_change DATETIME NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), "
                + "min_x DOUBLE, min_y DOUBLE, max_x DOUBLE, max_y DOUBLE, srs_id INTEGER, "
                + "CONSTRAINT fk_gc_r_srs_id FOREIGN KEY (srs_id) REFERENCES gpkg_spatial_ref_sys(srs_id))");
        db.exec("CREATE TABLE gpkg_geometry_columns (table_name TEXT NOT NULL, column_name TEXT NOT NULL, geometry_type_name TEXT NOT NULL, "
                + "srs_id INTEGER NOT NULL, z TINYINT NOT NULL, m TINYINT NOT NULL, CONSTRAINT pk_geom_cols PRIMARY KEY (table_name, column_name), "
                + "CONSTRAINT fk_gc_tn FOREIGN KEY (table_name) REFERENCES gpkg_contents(table_name), "
                + "CONSTRAINT fk_gc_srs FOREIGN KEY (srs_id) REFERENCES gpkg_spatial_ref_sys (srs_id))");
        Set<String> usedTables = new HashSet<>();
        for (LayerData l : layers) {
            for (int geom : new int[]{Feature.POINT, Feature.LINE, Feature.POLYGON}) {
                List<Feature> fs = new ArrayList<>();
                for (Feature f : l.features) if (f.geom == geom && !f.parts.isEmpty()) fs.add(f);
                if (fs.isEmpty()) continue;
                String suffix = geom == Feature.POINT ? "_points" : geom == Feature.LINE ? "_lines" : "_polygons";
                String base = ident(l.label.isEmpty() ? l.id : l.label);
                String table = base;
                int k = 2;
                boolean mixed = false;
                for (Feature f : l.features) if (f.geom != geom) mixed = true;
                if (mixed) table = base + suffix;
                while (!usedTables.add(table.toLowerCase(Locale.ROOT))) table = (mixed ? base + suffix : base) + "_" + k++;
                // custom attribute columns
                Map<String, String> cols = new LinkedHashMap<>();
                Set<String> taken = new HashSet<>();
                taken.add("fid");
                taken.add("geom");
                taken.add("uid");
                taken.add("acc_m");
                for (String s : STD) taken.add(s);
                if (attributes) {
                    for (Feature f : fs) {
                        for (String key : f.attrs.keySet()) {
                            if (cols.containsKey(key) || cols.size() >= 200) continue;
                            String c = ident(key.replaceAll("[^A-Za-z0-9_]", "").isEmpty() ? "field" : key).toLowerCase(Locale.ROOT);
                            String c0 = c;
                            int n = 2;
                            while (!taken.add(c)) c = c0 + "_" + n++;
                            cols.put(key, c);
                        }
                    }
                }
                StringBuilder ddl = new StringBuilder("CREATE TABLE \"" + table + "\" (fid INTEGER PRIMARY KEY AUTOINCREMENT, geom BLOB, uid TEXT");
                if (attributes) {
                    for (String s : STD) ddl.append(", ").append(s).append(" TEXT");
                    ddl.append(", acc_m REAL");
                    for (String c : cols.values()) ddl.append(", \"").append(c).append("\" TEXT");
                }
                ddl.append(")");
                db.exec(ddl.toString());
                StringBuilder ins = new StringBuilder("INSERT INTO \"" + table + "\" (geom, uid");
                int nargs = 2;
                if (attributes) {
                    for (String s : STD) {
                        ins.append(", ").append(s);
                        nargs++;
                    }
                    ins.append(", acc_m");
                    nargs++;
                    for (String c : cols.values()) {
                        ins.append(", \"").append(c).append("\"");
                        nargs++;
                    }
                }
                ins.append(") VALUES (");
                for (int i = 0; i < nargs; i++) ins.append(i == 0 ? "?" : ",?");
                ins.append(")");
                double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
                for (Feature f : fs) {
                    byte[] blob = encode(f, 4326);
                    if (blob == null) {
                        res.skipped++;
                        continue;
                    }
                    double[] bb = iq.gis.poiexporter.core.GeomCodec.bbox(f);
                    minX = Math.min(minX, bb[0]);
                    minY = Math.min(minY, bb[1]);
                    maxX = Math.max(maxX, bb[2]);
                    maxY = Math.max(maxY, bb[3]);
                    Object[] a = new Object[nargs];
                    int i = 0;
                    a[i++] = blob;
                    a[i++] = f.id;
                    if (attributes) {
                        a[i++] = f.name;
                        a[i++] = f.nameEn;
                        a[i++] = f.type;
                        a[i++] = f.category;
                        a[i++] = f.governorate;
                        a[i++] = f.qadaa;
                        a[i++] = f.nahiya;
                        a[i++] = Mapper.statusText(f.status);
                        a[i++] = f.source;
                        a[i++] = f.updated;
                        a[i++] = f.description;
                        a[i++] = f.notes;
                        a[i++] = Double.isNaN(f.accuracy) ? null : (Object) Double.valueOf(f.accuracy);
                        for (String key : cols.keySet()) a[i++] = f.attrs.get(key);
                    }
                    db.exec(ins.toString(), a);
                    res.written++;
                }
                String gt = geom == Feature.POINT ? "POINT" : geom == Feature.LINE ? "MULTILINESTRING" : "MULTIPOLYGON";
                db.exec("INSERT INTO gpkg_contents (table_name, data_type, identifier, description, min_x, min_y, max_x, max_y, srs_id) VALUES (?,?,?,?,?,?,?,?,?)",
                        table, "features", table, l.label, minX, minY, maxX, maxY, 4326L);
                db.exec("INSERT INTO gpkg_geometry_columns VALUES (?,?,?,?,?,?)", table, "geom", gt, 4326L, 0L, 0L);
            }
        }
        db.commit();
        return res;
    }

    public static final class ExportResult {
        public int written, skipped;
    }

    // ------------------------------------------------------------------ reading

    public static final class TableInfo {
        public String table, identifier;
        public long srsId, count;
        public Crs crs;
        public String geomColumn;
        public int geom;
    }

    public static List<TableInfo> tables(Source src) throws IOException {
        List<TableInfo> out = new ArrayList<>();
        for (Object[] r : src.featureTables()) {
            TableInfo t = new TableInfo();
            t.table = String.valueOf(r[0]);
            t.identifier = r[1] == null ? t.table : String.valueOf(r[1]);
            t.srsId = r[2] instanceof Number ? ((Number) r[2]).longValue() : 4326;
            t.geomColumn = src.geometryColumn(t.table);
            if (t.geomColumn == null) continue;
            t.count = src.count(t.table);
            Object[] s = src.srs(t.srsId);
            if (s != null && s[0] != null && String.valueOf(s[0]).equalsIgnoreCase("EPSG") && s[1] instanceof Number) {
                try {
                    t.crs = Crs.of(((Number) s[1]).intValue());
                } catch (RuntimeException ignored) {
                    t.crs = null;
                }
            } else if (t.srsId == 4326) {
                t.crs = Crs.wgs84();
            }
            out.add(t);
        }
        return out;
    }

    /** Visits all features of one table (coordinates in the table CRS). */
    public static void read(Source src, TableInfo t, Visitor v, ReadInfo info) throws IOException {
        List<String> all = src.columns(t.table);
        List<String> cols = new ArrayList<>();
        cols.add(t.geomColumn);
        for (String c : all) if (!c.equals(t.geomColumn) && !c.equalsIgnoreCase("fid")) cols.add(c);
        long off = 0;
        int chunk = 2000;
        while (!info.cancel) {
            List<Object[]> rows = src.rows(t.table, cols, off, chunk);
            if (rows.isEmpty()) break;
            for (Object[] r : rows) {
                Feature f;
                try {
                    Geometry g = decodeGeometry(r[0] instanceof byte[] ? (byte[]) r[0] : null);
                    if (g == null) {
                        info.unreadable++;
                        continue;
                    }
                    List<Feature> fs = Jts.toFeatures(g, null);
                    if (fs.isEmpty()) {
                        info.unreadable++;
                        continue;
                    }
                    f = fs.get(0);
                    for (int i = 1; i < fs.size(); i++) {
                        Feature x = fs.get(i);
                        if (x.geom == f.geom) for (int p = 0; p < x.parts.size(); p++) f.addPart(x.parts.get(p), x.isHole(p));
                    }
                } catch (IOException | RuntimeException e) {
                    info.unreadable++;
                    if (info.messages.size() < 200) info.messages.add(S.t("هندسة تالفة في الجدول " + t.table, "Damaged geometry in table " + t.table));
                    continue;
                }
                Map<String, String> props = new LinkedHashMap<>();
                for (int i = 1; i < cols.size(); i++) {
                    Object o = r[i];
                    if (o == null || o instanceof byte[]) continue;
                    String sv = o instanceof Double && ((Double) o) == Math.rint((Double) o) && Math.abs((Double) o) < 1e15 && false
                            ? String.valueOf(((Double) o).longValue()) : String.valueOf(o);
                    props.put(cols.get(i), sv);
                }
                if (props.containsKey("uid")) {
                    props.put("id", props.remove("uid"));
                }
                Mapper.apply(f, props);
                Geo.setRepresentative(f);
                if (f.id.isEmpty()) f.id = Feature.newId();
                if (!v.feature(t.identifier, f)) return;
            }
            off += rows.size();
            if (rows.size() < chunk) break;
        }
    }
}
