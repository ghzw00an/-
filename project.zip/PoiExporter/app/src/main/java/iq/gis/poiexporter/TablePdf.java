package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/** Prints any table (the columns and rows the user selected) to a multi-page A4 PDF. Device-only code. */
final class TablePdf {
    private TablePdf() {
    }

    static int write(OutputStream os, String title, String[] header, List<String[]> rows, boolean landscape) throws IOException {
        final int pw = landscape ? 842 : 595, ph = landscape ? 595 : 842, m = 28;
        Paint head = new Paint(Paint.ANTI_ALIAS_FLAG), cell = new Paint(Paint.ANTI_ALIAS_FLAG), ttl = new Paint(Paint.ANTI_ALIAS_FLAG),
                line = new Paint(Paint.ANTI_ALIAS_FLAG), band = new Paint();
        head.setTextSize(8.5f);
        head.setFakeBoldText(true);
        cell.setTextSize(8f);
        ttl.setTextSize(13f);
        ttl.setFakeBoldText(true);
        line.setColor(0xFF888888);
        line.setStrokeWidth(0.5f);
        band.setColor(0xFFF0F3F6);
        int n = header.length;
        // column widths proportional to the longest of header and the first 200 values (clamped)
        float[] w = new float[n];
        float tot = 0;
        for (int c = 0; c < n; c++) {
            float mw = head.measureText(header[c]);
            for (int r = 0; r < Math.min(rows.size(), 200); r++) mw = Math.max(mw, cell.measureText(rows.get(r)[c]));
            w[c] = Math.max(34, Math.min(mw + 8, 220));
            tot += w[c];
        }
        float usable = pw - 2 * m, k = usable / tot;
        for (int c = 0; c < n; c++) w[c] *= k;
        float rowH = 15;
        int per = (int) ((ph - 2 * m - 40) / rowH) - 1;
        int pages = Math.max(1, (rows.size() + per - 1) / per);
        PdfDocument doc = new PdfDocument();
        try {
            for (int p = 0; p < pages; p++) {
                PdfDocument.Page pg = doc.startPage(new PdfDocument.PageInfo.Builder(pw, ph, p + 1).create());
                Canvas c = pg.getCanvas();
                c.drawColor(Color.WHITE);
                float y = m + 12;
                c.drawText(title + "  (" + (p + 1) + "/" + pages + ")", m, y, ttl);
                y += 20;
                float x = m;
                for (int i = 0; i < n; i++) {
                    c.drawText(clip(header[i], head, w[i] - 4), x + 2, y, head);
                    x += w[i];
                }
                c.drawLine(m, y + 3, pw - m, y + 3, line);
                for (int r = p * per; r < Math.min(rows.size(), (p + 1) * per); r++) {
                    y += rowH;
                    if (((r - p * per) & 1) == 1) c.drawRect(m, y - rowH + 4, pw - m, y + 4, band);
                    x = m;
                    String[] row = rows.get(r);
                    for (int i = 0; i < n; i++) {
                        c.drawText(clip(row[i], cell, w[i] - 4), x + 2, y, cell);
                        x += w[i];
                    }
                }
                doc.finishPage(pg);
            }
            doc.writeTo(os);
        } finally {
            doc.close();
        }
        return pages;
    }

    private static String clip(String s, Paint p, float maxW) {
        if (s == null) return "";
        if (p.measureText(s) <= maxW) return s;
        int n = p.breakText(s, true, Math.max(1, maxW - p.measureText("…")), null);
        return s.substring(0, Math.max(0, n)) + "…";
    }
}
