package iq.gis.poiexporter.core;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Plus Codes (Open Location Code): encode, decode, validate, shorten and recover short codes.
 * Pure Java port of the public algorithm (Apache-2.0 reference by Google); no network, works offline.
 */
public final class PlusCode {
    private PlusCode() {
    }

    public static final String ALPHABET = "23456789CFGHJMPQRVWX";
    private static final char SEP = '+', PAD = '0';
    private static final int SEP_POS = 8, PAIR_LEN = 10, MAX_LEN = 15, BASE = 20, GRID_COLS = 4, GRID_ROWS = 5, GRID_LEN = 5;
    private static final long PAIR_PREC = 8000L;              // 1/8000 degree
    private static final long FINAL_LAT_PREC = PAIR_PREC * 3125L;  // 5^5
    private static final long FINAL_LON_PREC = PAIR_PREC * 1024L;  // 4^5
    private static final double[] PAIR_RES = {20.0, 1.0, 0.05, 0.0025, 0.000125};

    /** Position of the code: the rectangle it names and its centre. */
    public static final class Area {
        public final double latLo, lonLo, latHi, lonHi;
        public final int length;

        Area(double latLo, double lonLo, double latHi, double lonHi, int length) {
            this.latLo = latLo;
            this.lonLo = lonLo;
            this.latHi = latHi;
            this.lonHi = lonHi;
            this.length = length;
        }

        public double centerLat() {
            return Math.min(latLo + (latHi - latLo) / 2, 90);
        }

        public double centerLon() {
            return Math.min(lonLo + (lonHi - lonLo) / 2, 180);
        }

        /** Approximate size of the rectangle in metres (height, width at the centre latitude). */
        public double[] sizeMetres() {
            double h = (latHi - latLo) * 111320.0;
            double w = (lonHi - lonLo) * 111320.0 * Math.cos(Math.toRadians(centerLat()));
            return new double[]{h, w};
        }
    }

    // ------------------------------------------------------------------ validation

    private static int idx(char c) {
        return ALPHABET.indexOf(Character.toUpperCase(c));
    }

    /** Valid full or short code (padding allowed in full codes). */
    public static boolean isValid(String code) {
        if (code == null || code.isEmpty()) return false;
        int sep = code.indexOf(SEP);
        if (sep < 0 || sep != code.lastIndexOf(SEP)) return false;
        if (code.length() == 1) return false;
        if (sep > SEP_POS || sep % 2 == 1) return false;
        int pad = code.indexOf(PAD);
        if (pad != -1) {
            if (sep < SEP_POS) return false;           // short codes are never padded
            if (pad == 0) return false;
            String p = code.substring(pad, sep);
            if (!p.matches("0+") || p.length() % 2 == 1 || sep != SEP_POS) return false;
            if (code.length() > sep + 1) return false; // nothing after the separator in a padded code
        }
        if (code.length() - sep - 1 == 1) return false;  // one digit after the separator is not allowed
        for (int i = 0; i < code.length(); i++) {
            char c = code.charAt(i);
            if (c == SEP || c == PAD) continue;
            if (idx(c) < 0) return false;
        }
        if (sep == SEP_POS) {                              // full code: first pair must be on the globe
            if (idx(code.charAt(0)) > 8) return false;
            if (code.length() > 1 && idx(code.charAt(1)) > 17) return false;
        }
        return true;
    }

    public static boolean isShort(String code) {
        return isValid(code) && code.indexOf(SEP) >= 0 && code.indexOf(SEP) < SEP_POS;
    }

    public static boolean isFull(String code) {
        return isValid(code) && code.indexOf(SEP) == SEP_POS;
    }

    // ------------------------------------------------------------------ encode

    private static double clipLat(double v) {
        return Math.min(90, Math.max(-90, v));
    }

    private static double normLon(double v) {
        while (v < -180) v += 360;
        while (v >= 180) v -= 360;
        return v;
    }

    private static double latPrecision(int len) {
        if (len <= PAIR_LEN) return Math.pow(BASE, Math.floor(len / -2.0 + 2));
        return Math.pow(BASE, -3) / Math.pow(GRID_ROWS, len - PAIR_LEN);
    }

    /** Standard 10-digit code (about 14 m). */
    public static String encode(double lat, double lon) {
        return encode(lat, lon, PAIR_LEN);
    }

    /** @param length digits without the "+": even number 2..10, or 11..15 (grid refinement). */
    public static String encode(double lat, double lon, int length) {
        if (length < 2 || (length < SEP_POS && length % 2 == 1) || length > MAX_LEN)
            throw new IllegalArgumentException("invalid Plus Code length " + length);
        lat = clipLat(lat);
        lon = normLon(lon);
        if (lat == 90) lat -= latPrecision(length);
        long latVal = (long) Math.floor(Math.round((lat + 90) * FINAL_LAT_PREC * 1e6) / 1e6);
        long lonVal = (long) Math.floor(Math.round((lon + 180) * FINAL_LON_PREC * 1e6) / 1e6);
        if (latVal < 0) latVal = 0;
        if (lonVal < 0) lonVal = 0;
        StringBuilder code = new StringBuilder();
        if (length > PAIR_LEN) {
            for (int i = 0; i < GRID_LEN; i++) {
                int ld = (int) (latVal % GRID_ROWS), od = (int) (lonVal % GRID_COLS);
                code.insert(0, ALPHABET.charAt(ld * GRID_COLS + od));
                latVal /= GRID_ROWS;
                lonVal /= GRID_COLS;
            }
        } else {
            latVal /= 3125L;
            lonVal /= 1024L;
        }
        for (int i = 0; i < PAIR_LEN / 2; i++) {
            code.insert(0, ALPHABET.charAt((int) (lonVal % BASE)));
            code.insert(0, ALPHABET.charAt((int) (latVal % BASE)));
            latVal /= BASE;
            lonVal /= BASE;
        }
        code.insert(SEP_POS, SEP);
        if (length >= SEP_POS) return code.substring(0, length + 1);
        StringBuilder pad = new StringBuilder(code.substring(0, length));
        while (pad.length() < SEP_POS) pad.append(PAD);
        return pad.append(SEP).toString();
    }

    // ------------------------------------------------------------------ decode

    /** @throws IllegalArgumentException when the code is not a valid full code */
    public static Area decode(String code) {
        if (!isFull(code)) throw new IllegalArgumentException("not a valid full Plus Code: " + code);
        String c = code.replace("+", "").replace("0", "").toUpperCase(Locale.ROOT);
        if (c.length() > MAX_LEN) c = c.substring(0, MAX_LEN);
        long normLat = -90L * PAIR_PREC, normLon = -180L * PAIR_PREC;
        long gridLat = 0, gridLon = 0;
        int digits = Math.min(c.length(), PAIR_LEN);
        long pv = 160000L; // 20^4
        for (int i = 0; i < digits; i += 2) {
            normLat += idx(c.charAt(i)) * pv;
            normLon += idx(c.charAt(i + 1)) * pv;
            if (i < digits - 2) pv /= BASE;
        }
        double latP = pv / (double) PAIR_PREC, lonP = latP;
        if (c.length() > PAIR_LEN) {
            long rowPv = 625L, colPv = 256L; // 5^4, 4^4
            int dg = Math.min(c.length(), MAX_LEN);
            for (int i = PAIR_LEN; i < dg; i++) {
                int d = idx(c.charAt(i));
                gridLat += (d / GRID_COLS) * rowPv;
                gridLon += (d % GRID_COLS) * colPv;
                if (i < dg - 1) {
                    rowPv /= GRID_ROWS;
                    colPv /= GRID_COLS;
                }
            }
            latP = rowPv / (double) FINAL_LAT_PREC;
            lonP = colPv / (double) FINAL_LON_PREC;
        }
        double lat = normLat / (double) PAIR_PREC + gridLat / (double) FINAL_LAT_PREC;
        double lon = normLon / (double) PAIR_PREC + gridLon / (double) FINAL_LON_PREC;
        return new Area(lat, lon, Math.min(90, lat + latP), Math.min(180, lon + lonP), c.length());
    }

    // ------------------------------------------------------------------ short codes

    /** Rebuilds the full code of a short one using a reference position (the nearest match wins). */
    public static String recoverNearest(String shortCode, double refLat, double refLon) {
        if (!isShort(shortCode)) {
            if (isFull(shortCode)) return shortCode.toUpperCase(Locale.ROOT);
            throw new IllegalArgumentException("not a valid short Plus Code: " + shortCode);
        }
        refLat = clipLat(refLat);
        refLon = normLon(refLon);
        int pad = SEP_POS - shortCode.indexOf(SEP);
        double res = Math.pow(BASE, 2 - pad / 2.0), half = res / 2;
        String prefix = encode(refLat, refLon).substring(0, pad);
        Area a = decode(prefix + shortCode.toUpperCase(Locale.ROOT));
        double cLat = a.centerLat(), cLon = a.centerLon();
        double dLat = cLat - refLat;
        if (dLat > half && cLat - res >= -90) cLat -= res;
        else if (dLat < -half && cLat + res <= 90) cLat += res;
        double dLon = cLon - refLon;
        if (dLon > half) cLon -= res;
        else if (dLon < -half) cLon += res;
        return encode(cLat, cLon, a.length);
    }

    /** Drops leading digits that the reference position makes redundant (4, 6 or 8). Returns the code unchanged if none can go. */
    public static String shorten(String code, double refLat, double refLon) {
        if (!isFull(code) || code.indexOf(PAD) >= 0) return code;
        code = code.toUpperCase(Locale.ROOT);
        Area a = decode(code);
        double range = Math.max(Math.abs(a.centerLat() - clipLat(refLat)), Math.abs(a.centerLon() - normLon(refLon)));
        for (int i = PAIR_RES.length - 2; i >= 1; i--) {
            if (range < PAIR_RES[i] * 0.3) return code.substring((i + 1) * 2);
        }
        return code;
    }

    /** Height of the cell a code names, in metres (short codes count the dropped leading digits). */
    public static double cellMetres(String code) {
        if (code == null) return 0;
        int sep = code.indexOf(SEP);
        int digits = code.replace("+", "").replace("0", "").length() + (sep >= 0 && sep < SEP_POS ? SEP_POS - sep : 0);
        double deg = digits <= PAIR_LEN ? Math.pow(BASE, Math.floor(2 - digits / 2.0)) : Math.pow(BASE, -3) / Math.pow(GRID_ROWS, digits - PAIR_LEN);
        return deg * 111320.0;
    }

    // ------------------------------------------------------------------ finding a code inside text

    private static final Pattern TOKEN = Pattern.compile("(?<![A-Za-z0-9+])([2-9CFGHJMPQRVWXcfghjmpqrvwx0]{2,8}\\+[2-9CFGHJMPQRVWXcfghjmpqrvwx]{0,7})(?![A-Za-z0-9+])");

    /** First valid code (full or short) found in free text such as "8HJ7+2F Baghdad", or null. */
    public static String find(String text) {
        if (text == null) return null;
        Matcher m = TOKEN.matcher(text);
        while (m.find()) {
            String c = m.group(1).toUpperCase(Locale.ROOT);
            if (isValid(c)) return c;
        }
        return null;
    }

    /** Text after the code (the "locality" of a short code such as "8HJ7+2F Baghdad, Iraq"); empty when none. */
    public static String localityAfter(String text, String code) {
        if (text == null || code == null) return "";
        int i = text.toUpperCase(Locale.ROOT).indexOf(code);
        if (i < 0) return "";
        return text.substring(i + code.length()).replaceAll("^[\\s,،:;\\-–]+", "").trim();
    }

    // ------------------------------------------------------------------ reference position for short codes

    private static volatile double refLat = Double.NaN, refLon = Double.NaN;

    /** The app sets this to the map centre; short codes are resolved to the nearest match to it. */
    public static void setReference(double lat, double lon) {
        refLat = lat;
        refLon = lon;
    }

    public static boolean hasReference() {
        return !Double.isNaN(refLat) && !Double.isNaN(refLon);
    }

    /** Position of a full or short code (short ones need {@link #setReference}); throws IllegalArgumentException otherwise. */
    public static double[] toLatLon(String code) {
        String c = code.trim().toUpperCase(Locale.ROOT);
        if (isShort(c)) {
            if (!hasReference()) throw new IllegalArgumentException("short Plus Code needs a reference position");
            c = recoverNearest(c, refLat, refLon);
        }
        Area a = decode(c);
        return new double[]{a.centerLat(), a.centerLon()};
    }
}
