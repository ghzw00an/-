package iq.gis.poiexporter.core;

/** One fixed colour per sector (ARGB, opaque) so maps, legends and reports agree. */
public final class SectorColors {
    private SectorColors() {
    }

    /** Same order as {@link Sectors#ALL}; chosen to stay distinguishable on satellite and plain maps. */
    private static final int[] COLORS = {
            0xFFE8590C, // المواصلات
            0xFF862E9C, // السياسي
            0xFF495057, // الإداري
            0xFF0CA678, // المدني
            0xFFF59F00, // التجاري
            0xFF2B8A3E, // المالي
            0xFF1C7ED6, // التربوي
            0xFFE64980, // الترفيهي
            0xFF74B816, // الرياضي
            0xFF15AABF, // الخدماتي
            0xFF5F3DC4, // الديني
            0xFF66A80F, // الزراعي
            0xFFE03131, // الصحي
            0xFF7B5E57, // الصناعي
            0xFFD6336C, // الثقافي
    };

    /** Index into {@link Sectors#ALL} for a Gategory text, or -1. */
    public static int indexOf(String category) {
        Sectors.Sector s = Sectors.find(category);
        if (s == null) return -1;
        for (int i = 0; i < Sectors.ALL.length; i++) if (Sectors.ALL[i] == s) return i;
        return -1;
    }

    /** Colour for a Gategory text; 0 when the text is not one of the sectors. */
    public static int colorOf(String category) {
        int i = indexOf(category);
        return i < 0 ? 0 : COLORS[i];
    }

    public static int colorAt(int index) {
        return COLORS[index];
    }

    public static int count() {
        return COLORS.length;
    }
}
