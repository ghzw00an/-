package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.geo.Geodesy;
import iq.gis.poiexporter.core.geo.Measure;

/**
 * Measure on the map: tap points to get the running length, close the shape to get area and perimeter,
 * and save the drawn line or polygon as a project layer. Accuracy is ellipsoidal (see Geodesy); the tap precision
 * is whatever your finger and the zoom level allow.
 */
final class MeasureTool {
    private final MainActivity a;
    private final List<double[]> pts = new ArrayList<>(); // lon, lat
    private boolean on, polygon;
    private LinearLayout panel;
    private TextView info;
    private final Layer layer = new Layer();
    private boolean added;

    MeasureTool(MainActivity a) {
        this.a = a;
    }

    boolean isOn() {
        return on;
    }

    void start(FrameLayout root) {
        if (!added) {
            a.map.getOverlays().add(layer);
            added = true;
        }
        pts.clear();
        polygon = false;
        on = true;
        a.showMap();
        if (panel == null) buildPanel(root);
        panel.setVisibility(View.VISIBLE);
        refresh();
        a.map.invalidate();
    }

    void stop() {
        on = false;
        pts.clear();
        if (panel != null) panel.setVisibility(View.GONE);
        a.map.invalidate();
    }

    private void buildPanel(FrameLayout root) {
        panel = new LinearLayout(a);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(Ui.round(0xE6202428, 12, a));
        panel.setPadding(Ui.dp(a, 10), Ui.dp(a, 8), Ui.dp(a, 10), Ui.dp(a, 8));
        panel.setElevation(Ui.dp(a, 8));
        info = Ui.text(a, "", 14, 0xFFFFFFFF, false);
        panel.addView(info);
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        row.addView(btn("↶", () -> {
            if (!pts.isEmpty()) pts.remove(pts.size() - 1);
            refresh();
        }));
        row.addView(btn("⬡", () -> {
            polygon = !polygon;
            refresh();
        }));
        row.addView(btn("🗑", () -> {
            pts.clear();
            refresh();
        }));
        row.addView(btn("💾", this::save));
        row.addView(btn("✖", this::stop));
        panel.addView(row);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = Ui.dp(a, 150);
        root.addView(panel, lp);
    }

    private TextView btn(String g, Runnable r) {
        TextView t = Ui.text(a, g, 20, 0xFFFFFFFF, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(a, 14), Ui.dp(a, 6), Ui.dp(a, 14), Ui.dp(a, 6));
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private Feature shape() {
        Feature f = new Feature();
        f.geom = polygon ? Feature.POLYGON : Feature.LINE;
        f.id = Feature.newId();
        int n = pts.size();
        double[] p = new double[(n + (polygon ? 1 : 0)) * 2];
        for (int i = 0; i < n; i++) {
            p[2 * i] = pts.get(i)[0];
            p[2 * i + 1] = pts.get(i)[1];
        }
        if (polygon) {
            p[2 * n] = p[0];
            p[2 * n + 1] = p[1];
        }
        f.parts.add(p);
        Geo.setRepresentative(f);
        return f;
    }

    private void refresh() {
        if (info == null) return;
        StringBuilder b = new StringBuilder();
        b.append(S.t("قياس — ", "Measure — ")).append(pts.size()).append(S.t(" نقطة", " points"));
        if (pts.size() >= 2) {
            Feature l = shape();
            if (!polygon) b.append("\n").append(S.t("الطول: ", "Length: ")).append(Measure.length(Geodesy.length(l), S.ar));
            else if (pts.size() >= 3) {
                try {
                    b.append("\n").append(S.t("المساحة: ", "Area: ")).append(Measure.area(Geodesy.area(l), S.ar).all());
                    b.append("\n").append(S.t("المحيط: ", "Perimeter: ")).append(Measure.length(Geodesy.perimeter(l), S.ar));
                } catch (RuntimeException e) {
                    b.append("\n").append(S.t("شكل غير صالح", "Invalid shape"));
                }
            } else b.append("\n").append(S.t("أضف نقطة ثالثة", "Add a third point"));
        } else b.append("\n").append(S.t("المس الخريطة لإضافة نقاط", "Tap the map to add points"));
        b.append("\n").append(polygon ? S.t("الوضع: مضلع (⬡ للتبديل إلى خط)", "Mode: polygon (⬡ switches to line)") : S.t("الوضع: خط (⬡ للتبديل إلى مضلع)", "Mode: line (⬡ switches to polygon)"));
        info.setText(b.toString());
        a.map.invalidate();
    }

    private void save() {
        if (pts.size() < (polygon ? 3 : 2)) {
            a.toast(S.t("أضف نقاطاً أكثر", "Add more points"));
            return;
        }
        Feature f = shape();
        f.name = polygon ? S.t("مضلع مقاس", "Measured polygon") : S.t("خط مقاس", "Measured line");
        try {
            if (polygon) {
                f.attrs.put("area_m2", String.valueOf(Math.round(Geodesy.area(f))));
                f.attrs.put("perimeter_m", String.valueOf(Math.round(Geodesy.perimeter(f))));
            } else f.attrs.put("length_m", String.valueOf(Math.round(Geodesy.length(f))));
        } catch (RuntimeException e) {
            a.toast(S.t("شكل غير صالح", "Invalid shape"));
            return;
        }
        LayerData l = new LayerData("", f.name, f.geom);
        l.features.add(f);
        LayerData added2 = MainActivity.WS.addLayerWithFeatures(l);
        a.rebuild();
        a.toast(S.t("حُفظ كطبقة: ", "Saved as layer: ") + added2.label);
        pts.clear();
        refresh();
    }

    private final class Layer extends Overlay {
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), dot = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG);

        Layer() {
            line.setStyle(Paint.Style.STROKE);
            line.setColor(0xFFFF6D00);
            line.setStrokeWidth(5f);
            fill.setColor(0x33FF6D00);
            dot.setColor(0xFFFFFFFF);
        }

        @Override
        public void draw(Canvas c, MapView map, boolean shadow) {
            if (shadow || !on || pts.isEmpty()) return;
            Path p = new Path();
            Point q = new Point();
            for (int i = 0; i < pts.size(); i++) {
                map.getProjection().toPixels(new GeoPoint(pts.get(i)[1], pts.get(i)[0]), q);
                if (i == 0) p.moveTo(q.x, q.y);
                else p.lineTo(q.x, q.y);
            }
            if (polygon && pts.size() >= 3) {
                p.close();
                c.drawPath(p, fill);
            }
            c.drawPath(p, line);
            for (double[] d : pts) {
                map.getProjection().toPixels(new GeoPoint(d[1], d[0]), q);
                c.drawCircle(q.x, q.y, 9f, dot);
                c.drawCircle(q.x, q.y, 6f, line);
            }
        }

        @Override
        public boolean onSingleTapConfirmed(MotionEvent e, MapView map) {
            if (!on) return false;
            org.osmdroid.api.IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
            pts.add(new double[]{g.getLongitude(), g.getLatitude()});
            refresh();
            return true;
        }
    }
}
