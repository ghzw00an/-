package iq.gis.poiexporter;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

/**
 * Opens a content Uri robustly. Some file managers and share targets return media-store Uris
 * (content://media/external_primary/file/…) that the app has no grant for, which throws
 * "has no access to content://media/…". We try the equivalent document Uri and a file descriptor before giving up,
 * and then explain how to pick the file so a grant is issued.
 */
final class UriIO {
    private UriIO() {
    }

    static final class NoAccess extends IOException {
        /** True when the file is on shared storage and "All files access" would let the app read it by path. */
        final boolean allFilesWouldHelp;

        NoAccess(String m, Throwable c, boolean allFiles) {
            super(m, c);
            allFilesWouldHelp = allFiles;
        }
    }

    /** "primary:Download/222.kmz" document id of the external-storage provider as a file path, or null. */
    static String pathOfDocument(Uri u) {
        if (u == null || !"com.android.externalstorage.documents".equals(u.getAuthority())) return null;
        try {
            String id = android.provider.DocumentsContract.getDocumentId(u);
            int c = id.indexOf(':');
            if (c < 0) return null;
            String vol = id.substring(0, c), rel = id.substring(c + 1);
            if (rel.contains("..")) return null;
            return ("primary".equalsIgnoreCase(vol) ? android.os.Environment.getExternalStorageDirectory().getPath() : "/storage/" + vol) + "/" + rel;
        } catch (RuntimeException e) {
            return null;
        }
    }

    static boolean allFilesGranted() {
        return android.os.Build.VERSION.SDK_INT >= 30 && android.os.Environment.isExternalStorageManager();
    }

    static InputStream open(Context ctx, Uri u) throws IOException {
        Throwable first = null;
        try {
            InputStream in = ctx.getContentResolver().openInputStream(u);
            if (in != null) return in;
        } catch (SecurityException | FileNotFoundException e) {
            first = e;
        }
        // 1) media-store Uri → the document Uri of the same file
        if ("media".equals(u.getAuthority())) {
            try {
                Uri doc = MediaStore.getDocumentUri(ctx, u);
                if (doc != null) {
                    InputStream in = ctx.getContentResolver().openInputStream(doc);
                    if (in != null) return in;
                }
            } catch (RuntimeException | FileNotFoundException e) {
                // keep going
            }
        }
        // 2) file descriptor route
        try {
            ParcelFileDescriptor pfd = ctx.getContentResolver().openFileDescriptor(u, "r");
            if (pfd != null) return new ParcelFileDescriptor.AutoCloseInputStream(pfd);
        } catch (RuntimeException | FileNotFoundException e) {
            // keep going
        }
        // 3) a Uri that is really a file path
        if ("file".equals(u.getScheme()) && u.getPath() != null) {
            try {
                return new FileInputStream(u.getPath());
            } catch (IOException | RuntimeException e) {
                // keep going
            }
        }
        // 4) shared-storage document Uri without a grant: read by path when the user allowed "All files access"
        String path = pathOfDocument(u);
        boolean help = false;
        if (path != null) {
            if (allFilesGranted()) {
                try {
                    return new FileInputStream(path);
                } catch (IOException | RuntimeException e) {
                    // fall through
                }
            } else {
                help = true;
            }
        }
        String why = first == null ? "" : "\n\n" + S.t("السبب التقني: ", "Technical cause: ") + first.getClass().getSimpleName() + " — "
                + String.valueOf(first.getMessage()).replaceAll("content://\\S+", "…");
        throw new NoAccess(S.t(
                "لم يمنح النظام التطبيق إذن قراءة هذا الملف. هذا يحدث عادةً عند «فتح بواسطة» من مدير الملفات (لا يمنح إذناً). الحلول:\n"
                        + "• زر «اختيار الملف» ثم التنزيلات (يمنح الإذن).\n• من مدير الملفات اختر «مشاركة» ثم هذا التطبيق.\n"
                        + (help ? "• أو امنح التطبيق «الوصول إلى كل الملفات» ليقرأ الملف مباشرة." : "") + why,
                "Android did not give the app permission to read this file. This usually happens with \"Open with\" from a file manager (it grants nothing). Options:\n"
                        + "• Tap \"Choose file\", then Downloads (this grants access).\n• In the file manager use \"Share\" and pick this app.\n"
                        + (help ? "• Or grant the app \"All files access\" so it can read the file directly." : "") + why), first, help);
    }
}
