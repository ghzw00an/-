package iq.gis.poiexporter;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

/**
 * Opens a content Uri robustly. Some file managers and share targets return media-store Uris
 * (content://media/external_primary/file/…) that the app has no grant for, which throws
 * "has no access to content://media/…". We try the equivalent document Uri and a file descriptor before giving up,
 * and then explain how to pick the file so a grant is issued.
 */
final class UriIO {
    private UriIO() {
    }

    static final class NoAccess extends IOException {
        NoAccess(String m, Throwable c) {
            super(m, c);
        }
    }

    static InputStream open(Context ctx, Uri u) throws IOException {
        Throwable first = null;
        try {
            InputStream in = ctx.getContentResolver().openInputStream(u);
            if (in != null) return in;
        } catch (SecurityException | FileNotFoundException e) {
            first = e;
        }
        // 1) media-store Uri → the document Uri of the same file
        if ("media".equals(u.getAuthority())) {
            try {
                Uri doc = MediaStore.getDocumentUri(ctx, u);
                if (doc != null) {
                    InputStream in = ctx.getContentResolver().openInputStream(doc);
                    if (in != null) return in;
                }
            } catch (RuntimeException | FileNotFoundException e) {
                // keep going
            }
        }
        // 2) file descriptor route
        try {
            ParcelFileDescriptor pfd = ctx.getContentResolver().openFileDescriptor(u, "r");
            if (pfd != null) return new ParcelFileDescriptor.AutoCloseInputStream(pfd);
        } catch (RuntimeException | FileNotFoundException e) {
            // keep going
        }
        // 3) a Uri that is really a file path
        if ("file".equals(u.getScheme()) && u.getPath() != null) {
            try {
                return new FileInputStream(u.getPath());
            } catch (IOException | RuntimeException e) {
                // keep going
            }
        }
        throw new NoAccess(S.t(
                "لا يملك التطبيق صلاحية قراءة هذا الملف (" + u + "). اختر الملف من داخل التطبيق: زر «اختيار ملف» ثم تصفّح ← التخزين الداخلي أو التنزيلات، ولا تستخدم «فتح بواسطة» من مدير الملفات.",
                "The app has no permission to read this file (" + u + "). Pick it from inside the app: tap \"Choose file\", then Browse → Internal storage or Downloads, rather than \"Open with\" from a file manager."), first);
    }
}
