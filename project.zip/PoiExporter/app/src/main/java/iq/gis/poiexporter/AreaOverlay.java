package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.view.MotionEvent;

import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.Projection;
import org.osmdroid.views.overlay.Overlay;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Geo;

/** Draws the selected area; drag it to move, drag a handle to resize, long-press to re-centre. */
public final class AreaOverlay extends Overlay {
    public interface Edited {
        /** circle: wM = radius, hM = radius. */
        void changed(double clat, double clon, double wM, double hM, boolean circle);
    }

    public interface Moved {
        void to(double lat, double lon);
    }

    private AreaSpec area;
    private Moved moved;
    private Edited edited;
    private boolean editable = true;
    private boolean squareMode;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG),
            cross = new Paint(Paint.ANTI_ALIAS_FLAG), handle = new Paint(Paint.ANTI_ALIAS_FLAG),
            handleRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Point tmp = new Point();
    private final GeoPoint gp = new GeoPoint(0.0, 0.0);
    private final float density;

    // drag state
    private int mode; // 0 none, 1 move, 2 resize rect corner, 3 resize circle
    private double fixLat, fixLon; // opposite corner
    private double grabDLat, grabDLon; // centre minus touch
    private float[] hx = new float[4], hy = new float[4]; // handles NW, NE, SE, SW (circle: east at 0)

    public AreaOverlay(float density) {
        this.density = density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f * density);
        stroke.setColor(0xFFE03131);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x22E03131);
        cross.setStyle(Paint.Style.STROKE);
        cross.setStrokeWidth(2f * density);
        cross.setColor(0xFFE03131);
        handle.setStyle(Paint.Style.FILL);
        handle.setColor(0xFFE03131);
        handleRing.setStyle(Paint.Style.STROKE);
        handleRing.setStrokeWidth(2.5f * density);
        handleRing.setColor(0xFFFFFFFF);
    }

    public void set(AreaSpec s) {
        area = s;
    }

    public void onMoved(Moved m) {
        moved = m;
    }

    public void onEdited(Edited e) {
        edited = e;
    }

    public void setEditable(boolean b) {
        editable = b;
    }

    public boolean isEditable() {
        return editable;
    }

    public void setSquare(boolean sq) {
        squareMode = sq;
    }

    private Point px(Projection pj, double lat, double lon) {
        gp.setCoords(lat, lon);
        Point p = new Point();
        pj.toPixels(gp, p);
        return p;
    }

    @Override
    public void draw(Canvas c, MapView map, boolean shadow) {
        if (shadow || area == null) return;
        Projection pj = map.getProjection();
        Path path = new Path();
        if (area.circle) {
            double[] ring = Geo.circleRing(area.clat, area.clon, area.radius, 72);
            for (int i = 0; i < ring.length / 2; i++) {
                gp.setCoords(ring[2 * i + 1], ring[2 * i]);
                pj.toPixels(gp, tmp);
                if (i == 0) path.moveTo(tmp.x, tmp.y);
                else path.lineTo(tmp.x, tmp.y);
            }
            Point e = px(pj, area.clat, area.east);
            hx[0] = e.x;
            hy[0] = e.y;
        } else {
            Point nw = px(pj, area.north, area.west), ne = px(pj, area.north, area.east),
                    se = px(pj, area.south, area.east), sw = px(pj, area.south, area.west);
            path.moveTo(nw.x, nw.y);
            path.lineTo(ne.x, ne.y);
            path.lineTo(se.x, se.y);
            path.lineTo(sw.x, sw.y);
            hx = new float[]{nw.x, ne.x, se.x, sw.x};
            hy = new float[]{nw.y, ne.y, se.y, sw.y};
        }
        path.close();
        c.drawPath(path, fill);
        c.drawPath(path, stroke);
        Point m = px(pj, area.clat, area.clon);
        float r = 8 * density;
        c.drawLine(m.x - r, m.y, m.x + r, m.y, cross);
        c.drawLine(m.x, m.y - r, m.x, m.y + r, cross);
        if (editable) {
            int n = area.circle ? 1 : 4;
            for (int i = 0; i < n; i++) {
                c.drawCircle(hx[i], hy[i], 9 * density, handle);
                c.drawCircle(hx[i], hy[i], 9 * density, handleRing);
            }
        }
    }

    private boolean inside(MapView map, float x, float y) {
        IGeoPoint g = map.getProjection().fromPixels((int) x, (int) y);
        if (area.circle) return Geo.haversine(area.clat, area.clon, g.getLatitude(), g.getLongitude()) <= area.radius;
        return g.getLatitude() >= area.south && g.getLatitude() <= area.north && g.getLongitude() >= area.west
                && g.getLongitude() <= area.east;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e, MapView map) {
        if (!editable || area == null || edited == null) return false;
        if (e.getPointerCount() > 1) {
            if (mode != 0) mode = 0;
            return false;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                mode = 0;
                float tol = 30 * density;
                int n = area.circle ? 1 : 4;
                for (int i = 0; i < n; i++) {
                    if (Math.hypot(hx[i] - e.getX(), hy[i] - e.getY()) <= tol) {
                        if (area.circle) mode = 3;
                        else {
                            mode = 2;
                            int o = (i + 2) % 4; // opposite corner
                            fixLat = (o == 0 || o == 1) ? area.north : area.south;
                            fixLon = (o == 0 || o == 3) ? area.west : area.east;
                        }
                        break;
                    }
                }
                if (mode == 0 && inside(map, e.getX(), e.getY())) {
                    mode = 1;
                    IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
                    grabDLat = area.clat - g.getLatitude();
                    grabDLon = area.clon - g.getLongitude();
                }
                return mode != 0;
            }
            case MotionEvent.ACTION_MOVE: {
                if (mode == 0) return false;
                IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
                double lat = g.getLatitude(), lon = g.getLongitude();
                if (mode == 1) {
                    double w = area.circle ? area.radius : area.widthM(), h = area.circle ? area.radius : area.heightM();
                    edited.changed(lat + grabDLat, lon + grabDLon, w, h, area.circle);
                } else if (mode == 3) {
                    double rad = Math.max(10, Geo.haversine(area.clat, area.clon, lat, lon));
                    edited.changed(area.clat, area.clon, rad, rad, true);
                } else {
                    double s = Math.min(fixLat, lat), nn = Math.max(fixLat, lat);
                    double w = Math.min(fixLon, lon), ee = Math.max(fixLon, lon);
                    double wM = Math.max(10, Geo.haversine((s + nn) / 2, w, (s + nn) / 2, ee));
                    double hM = Math.max(10, Geo.haversine(s, w, nn, w));
                    if (squareMode) {
                        double side = Math.max(wM, hM);
                        double sx = lon >= fixLon ? 1 : -1, sy = lat >= fixLat ? 1 : -1;
                        double dLat = sy * side / 111320.0;
                        double dLon = sx * side / (111320.0 * Math.max(0.05, Math.cos(Math.toRadians(fixLat))));
                        edited.changed(fixLat + dLat / 2, fixLon + dLon / 2, side, side, false);
                    } else {
                        edited.changed((s + nn) / 2, (w + ee) / 2, wM, hM, false);
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                boolean was = mode != 0;
                mode = 0;
                return was;
            }
            default:
                return mode != 0;
        }
    }

    @Override
    public boolean onLongPress(MotionEvent e, MapView map) {
        if (moved == null) return false;
        IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
        moved.to(g.getLatitude(), g.getLongitude());
        return true;
    }
}
