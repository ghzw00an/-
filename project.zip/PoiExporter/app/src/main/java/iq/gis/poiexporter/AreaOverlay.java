package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.Projection;
import org.osmdroid.views.overlay.Overlay;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Geo;

/** Draws the selected area; long-press moves its centre. */
public final class AreaOverlay extends Overlay {
    public interface Moved {
        void to(double lat, double lon);
    }

    private AreaSpec area;
    private Moved moved;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG),
            cross = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Point a = new Point(), b = new Point();
    private final float density;

    public AreaOverlay(float density) {
        this.density = density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f * density);
        stroke.setColor(0xFFE03131);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x22E03131);
        cross.setStyle(Paint.Style.STROKE);
        cross.setStrokeWidth(2f * density);
        cross.setColor(0xFFE03131);
    }

    public void set(AreaSpec s) {
        area = s;
    }

    public void onMoved(Moved m) {
        moved = m;
    }

    @Override
    public void draw(Canvas c, MapView map, boolean shadow) {
        if (shadow || area == null) return;
        Projection pj = map.getProjection();
        if (area.circle) {
            pj.toPixels(new GeoPoint(area.clat, area.clon), a);
            double[] ring = Geo.circleRing(area.clat, area.clon, area.radius, 72);
            android.graphics.Path p = new android.graphics.Path();
            for (int i = 0; i < ring.length / 2; i++) {
                pj.toPixels(new GeoPoint(ring[2 * i + 1], ring[2 * i]), b);
                if (i == 0) p.moveTo(b.x, b.y);
                else p.lineTo(b.x, b.y);
            }
            p.close();
            c.drawPath(p, fill);
            c.drawPath(p, stroke);
        } else {
            pj.toPixels(new GeoPoint(area.north, area.west), a);
            pj.toPixels(new GeoPoint(area.south, area.east), b);
            c.drawRect(a.x, a.y, b.x, b.y, fill);
            c.drawRect(a.x, a.y, b.x, b.y, stroke);
        }
        pj.toPixels(new GeoPoint(area.clat, area.clon), a);
        float r = 8 * density;
        c.drawLine(a.x - r, a.y, a.x + r, a.y, cross);
        c.drawLine(a.x, a.y - r, a.x, a.y + r, cross);
    }

    @Override
    public boolean onLongPress(MotionEvent e, MapView map) {
        if (moved == null) return false;
        org.osmdroid.api.IGeoPoint g = map.getProjection().fromPixels((int) e.getX(), (int) e.getY());
        moved.to(g.getLatitude(), g.getLongitude());
        return true;
    }
}
