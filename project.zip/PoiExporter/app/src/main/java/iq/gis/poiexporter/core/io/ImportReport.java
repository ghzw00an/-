package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.S;

import java.util.ArrayList;
import java.util.List;

/** What happened during an import: counts and the first problems found. Never thrown away silently. */
public final class ImportReport {
    public static final int MAX_MESSAGES = 200;

    public long read, imported, skippedNoGeometry, invalidFixed, invalidKept, duplicatesSkipped, badCoordinates;
    public final List<String> messages = new ArrayList<>();
    public int droppedMessages;

    public void add(String msg) {
        if (messages.size() < MAX_MESSAGES) messages.add(msg);
        else droppedMessages++;
    }

    public long problems() {
        return skippedNoGeometry + invalidKept + duplicatesSkipped + badCoordinates;
    }

    public String toText(boolean ar) {
        StringBuilder b = new StringBuilder();
        b.append(ar ? "تقرير الاستيراد\n" : "Import report\n");
        b.append(ar ? "• السجلات المقروءة: " : "• Records read: ").append(read).append('\n');
        b.append(ar ? "• المستوردة: " : "• Imported: ").append(imported).append('\n');
        if (skippedNoGeometry > 0) b.append(ar ? "• متجاهلة (بلا هندسة): " : "• Skipped (no geometry): ").append(skippedNoGeometry).append('\n');
        if (badCoordinates > 0) b.append(ar ? "• إحداثيات غير صحيحة: " : "• Bad coordinates: ").append(badCoordinates).append('\n');
        if (invalidFixed > 0) b.append(ar ? "• هندسة تم إصلاحها: " : "• Geometry repaired: ").append(invalidFixed).append('\n');
        if (invalidKept > 0) b.append(ar ? "• هندسة غير سليمة (أُبقيت للمراجعة): " : "• Invalid geometry (kept for review): ").append(invalidKept).append('\n');
        if (duplicatesSkipped > 0) b.append(ar ? "• مكررات تم تجاهلها: " : "• Duplicates skipped: ").append(duplicatesSkipped).append('\n');
        if (!messages.isEmpty()) {
            b.append(ar ? "\nالتفاصيل:\n" : "\nDetails:\n");
            for (String m : messages) b.append("- ").append(m).append('\n');
            if (droppedMessages > 0)
                b.append(S.t("… و ", "… and ")).append(droppedMessages).append(S.t(" ملاحظة أخرى", " more")).append('\n');
        }
        return b.toString();
    }
}
