package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.crs.Crs;

import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** ESRI style WKT for .prj files: writing from a Crs and detecting a Crs from existing .prj text. */
public final class Wkt {
    private Wkt() {
    }

    private static String clean(String n) {
        return n.replaceAll("[^A-Za-z0-9]+", "_").replaceAll("^_+|_+$", "");
    }

    private static String num(double v) {
        String s = String.format(Locale.US, "%.12f", v);
        int e = s.length();
        while (e > 1 && s.charAt(e - 1) == '0') e--;
        if (s.charAt(e - 1) == '.') e++;
        return s.substring(0, Math.min(e, s.length()));
    }

    private static String geogcs(Crs c) {
        if (c.epsg == 4326)
            return "GEOGCS[\"GCS_WGS_1984\",DATUM[\"D_WGS_1984\",SPHEROID[\"WGS_1984\",6378137.0,298.257223563]],"
                    + "PRIMEM[\"Greenwich\",0.0],UNIT[\"Degree\",0.0174532925199433]]";
        double[] e = c.ellipsoidAB();
        String nm = c.geographic ? clean(c.name) : clean(c.name.split("/")[0].trim());
        String ell = clean(c.ellipsoid().isEmpty() ? "Ellipsoid" : c.ellipsoid());
        return "GEOGCS[\"GCS_" + nm + "\",DATUM[\"D_" + nm + "\",SPHEROID[\"" + ell + "\"," + num(e[0]) + "," + num(e[1])
                + "]],PRIMEM[\"Greenwich\",0.0],UNIT[\"Degree\",0.0174532925199433]]";
    }

    private static double param(String proj, String key, double def) {
        Matcher m = Pattern.compile("\\+" + key + "=([-+0-9.eE]+)").matcher(proj);
        return m.find() ? Double.parseDouble(m.group(1)) : def;
    }

    /** ESRI WKT of the CRS. Throws IllegalArgumentException for systems this app cannot describe. */
    public static String of(Crs c) {
        if (c.geographic) return geogcs(c);
        String p = c.proj4();
        if (c.epsg == 3857 || (p.contains("+proj=merc") && p.contains("+a=6378137") && p.contains("+b=6378137")))
            return "PROJCS[\"WGS_1984_Web_Mercator_Auxiliary_Sphere\",GEOGCS[\"GCS_WGS_1984\",DATUM[\"D_WGS_1984\","
                    + "SPHEROID[\"WGS_1984\",6378137.0,298.257223563]],PRIMEM[\"Greenwich\",0.0],UNIT[\"Degree\",0.0174532925199433]],"
                    + "PROJECTION[\"Mercator_Auxiliary_Sphere\"],PARAMETER[\"False_Easting\",0.0],PARAMETER[\"False_Northing\",0.0],"
                    + "PARAMETER[\"Central_Meridian\",0.0],PARAMETER[\"Standard_Parallel_1\",0.0],PARAMETER[\"Auxiliary_Sphere_Type\",0.0],UNIT[\"Meter\",1.0]]";
        double lat0, lon0, k, fe, fn;
        int[] z = c.utmZoneOf();
        if (z != null) {
            lat0 = 0;
            lon0 = z[0] * 6 - 183;
            k = 0.9996;
            fe = 500000;
            fn = z[1] == 1 ? 0 : 10000000;
        } else if (p.contains("+proj=tmerc")) {
            lat0 = param(p, "lat_0", 0);
            lon0 = param(p, "lon_0", 0);
            k = param(p, "k", param(p, "k_0", 1));
            fe = param(p, "x_0", 0);
            fn = param(p, "y_0", 0);
        } else {
            throw new IllegalArgumentException(S.t(
                    "لا يمكن كتابة ملف .prj لهذا النظام (" + c.code() + "). اختر WGS84 أو نظام UTM أو Transverse Mercator.",
                    "Cannot write a .prj for " + c.code() + ". Choose WGS84, a UTM zone or a Transverse Mercator system."));
        }
        if (p.contains("+units=") && !p.contains("+units=m"))
            throw new IllegalArgumentException(S.t("وحدات غير مدعومة في " + c.code(), "Unsupported units in " + c.code()));
        String name = c.epsg == 32600 + (z == null ? 0 : z[0]) && z != null ? "WGS_1984_UTM_Zone_" + z[0] + "N"
                : c.epsg == 32700 + (z == null ? 0 : z[0]) && z != null ? "WGS_1984_UTM_Zone_" + z[0] + "S" : clean(c.name);
        return "PROJCS[\"" + name + "\"," + geogcs(c) + ",PROJECTION[\"Transverse_Mercator\"],PARAMETER[\"False_Easting\","
                + num(fe) + "],PARAMETER[\"False_Northing\"," + num(fn) + "],PARAMETER[\"Central_Meridian\"," + num(lon0)
                + "],PARAMETER[\"Scale_Factor\"," + num(k) + "],PARAMETER[\"Latitude_Of_Origin\"," + num(lat0) + "],UNIT[\"Meter\",1.0]]";
    }

    private static String norm(String s) {
        String t = s.toLowerCase(Locale.ROOT).replace("wgs_1984", "wgs84").replace("wgs 1984", "wgs84")
                .replace("european_datum_1950", "ed50").replace("ed_1950", "ed50").replace("d_", "").replace("gcs_", "");
        return t.replaceAll("[^a-z0-9]", "");
    }

    /** Detects the CRS of a .prj text; null when it cannot be matched to a known EPSG entry (the UI then asks). */
    public static Crs detect(String prj) {
        if (prj == null || prj.trim().isEmpty()) return null;
        String t = prj.trim();
        // the last AUTHORITY at the end belongs to the whole CRS
        Matcher am = Pattern.compile("AUTHORITY\\[\"EPSG\",\\s*\"?(\\d+)\"?\\]\\s*\\]\\s*$").matcher(t);
        if (am.find()) {
            try {
                return Crs.of(Integer.parseInt(am.group(1)));
            } catch (Exception ignored) {
                // fall through to the name match
            }
        }
        Matcher nm = Pattern.compile("^(PROJCS|GEOGCS)\\[\"([^\"]+)\"").matcher(t);
        if (!nm.find()) return null;
        String want = norm(nm.group(2));
        boolean proj = nm.group(1).equals("PROJCS");
        if (!proj && (want.equals("wgs84") || want.equals("wgs84geographic"))) return Crs.wgs84();
        List<Crs.Entry> all = Crs.catalog();
        for (Crs.Entry e : all) {
            if (e.geographic() == proj) continue;
            if (norm(e.name).equals(want)) return Crs.of(e.code);
        }
        return null;
    }
}
