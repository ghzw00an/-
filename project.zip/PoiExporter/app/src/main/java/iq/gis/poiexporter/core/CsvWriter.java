package iq.gis.poiexporter.core;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;
import java.util.Locale;

/** Simple UTF-8 CSV (with BOM, opens correctly in Excel) of every feature with WGS84 and UTM columns. */
public final class CsvWriter {
    private CsvWriter() {
    }

    private static String q(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    public static void write(List<LayerData> layers, OutputStream os) throws IOException {
        Writer w = new OutputStreamWriter(os, "UTF-8");
        w.write('﻿');
        w.write("name,type,Gategory,gather,Nahia,mohafadha,x,y,link\r\n");
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                Utm.Result u = Utm.fromLatLon(f.lat, f.lon);
                w.write(q(f.name) + "," + q(f.type) + "," + q(f.category) + "," + q(f.qadaa) + "," + q(f.nahiya) + ","
                        + q(f.governorate) + ","
                        + String.format(Locale.US, "%.2f,%.2f", u.easting, u.northing) + ","
                        + q(CoordFmt.link(f.lat, f.lon)) + "\r\n");
            }
        }
        w.flush();
    }
}
