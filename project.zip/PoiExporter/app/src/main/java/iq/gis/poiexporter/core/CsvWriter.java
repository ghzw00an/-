package iq.gis.poiexporter.core;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;
import java.util.Locale;

/** Simple UTF-8 CSV (with BOM, opens correctly in Excel) of every feature with WGS84 and UTM columns. */
public final class CsvWriter {
    private CsvWriter() {
    }

    private static String q(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    public static void write(List<LayerData> layers, OutputStream os) throws IOException {
        Writer w = new OutputStreamWriter(os, "UTF-8");
        w.write('﻿');
        w.write("name,type,Gategory,gathaa,Nahia,mohafadha,x,y,link\r\n");
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                String[] t = LandmarkFields.text(f);
                double[] xy = LandmarkFields.xy(f, null);
                StringBuilder row = new StringBuilder();
                for (String s : t) row.append(q(s)).append(',');
                row.append(LandmarkFields.num(xy[0], 2)).append(',').append(LandmarkFields.num(xy[1], 2)).append(',').append(q(LandmarkFields.link(f)));
                w.write(row.append("\r\n").toString());
            }
        }
        w.flush();
    }
}
