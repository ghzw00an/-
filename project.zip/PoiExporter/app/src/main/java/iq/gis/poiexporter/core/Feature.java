package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;

/** One geometry with its attributes. Coordinates are WGS84, interleaved lon,lat. */
public final class Feature {
    public static final int POINT = 1, LINE = 3, POLYGON = 5;

    public int geom;
    public static final int STATUS_NEW = 0, STATUS_REVIEW = 1, STATUS_VERIFIED = 2;

    public String id = "", name = "", type = "", category = "", nahiya = "", qadaa = "", governorate = "";
    /** English name, free description and field notes (landmark form). */
    public String nameEn = "", description = "", notes = "";
    /** Where the data came from and when it was last changed (ISO date-time text). */
    public String source = "", updated = "";
    /** Horizontal position accuracy in metres, NaN when unknown. */
    public double accuracy = Double.NaN;
    /** STATUS_NEW, STATUS_REVIEW or STATUS_VERIFIED. */
    public int status = STATUS_NEW;
    /** Absolute paths of photos attached to the feature (app private storage). */
    public final List<String> photos = new ArrayList<>();
    /** Extra attributes kept from imported files (original field names are preserved). */
    public final java.util.LinkedHashMap<String, String> attrs = new java.util.LinkedHashMap<>();
    /** Parts of the geometry. A point has one part with one coordinate pair. */
    public final List<double[]> parts = new ArrayList<>();
    /** Parallel to parts for polygons: true if the ring is a hole. */
    public final List<Boolean> holes = new ArrayList<>();
    /** Representative point (on the line, inside the polygon where possible). */
    public double lat, lon;

    public static Feature point(double lat, double lon) {
        Feature f = new Feature();
        f.geom = POINT;
        f.parts.add(new double[]{lon, lat});
        f.holes.add(Boolean.FALSE);
        f.lat = lat;
        f.lon = lon;
        return f;
    }

    public void addPart(double[] coords, boolean hole) {
        parts.add(coords);
        holes.add(hole);
    }

    public static String newId() {
        return java.util.UUID.randomUUID().toString();
    }

    /** Deep copy (history snapshots and duplicate). The id is kept. */
    public Feature copy() {
        Feature c = new Feature();
        c.geom = geom;
        c.id = id;
        c.name = name;
        c.type = type;
        c.category = category;
        c.nahiya = nahiya;
        c.qadaa = qadaa;
        c.governorate = governorate;
        c.nameEn = nameEn;
        c.description = description;
        c.notes = notes;
        c.source = source;
        c.updated = updated;
        c.accuracy = accuracy;
        c.status = status;
        c.photos.addAll(photos);
        c.attrs.putAll(attrs);
        for (double[] p : parts) c.parts.add(p.clone());
        c.holes.addAll(holes);
        c.lat = lat;
        c.lon = lon;
        return c;
    }

    public boolean isHole(int i) {
        return i < holes.size() && holes.get(i);
    }
}
