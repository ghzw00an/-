package iq.gis.poiexporter;

import android.net.Uri;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.coord.BatchConverter;
import iq.gis.poiexporter.core.coord.CoordService;
import iq.gis.poiexporter.core.coord.CsvSink;
import iq.gis.poiexporter.core.coord.Sink;
import iq.gis.poiexporter.core.coord.XlsxSink;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.io.ImportHub;
import iq.gis.poiexporter.core.table.PointTable;

/** Coordinate converter v2: any format and CRS, precision notes, and batch conversion of CSV / Excel files. */
final class ConverterPage {
    private final MainActivity a;
    private Crs src, target;
    private boolean latFirst = true;

    ConverterPage(MainActivity a) {
        this.a = a;
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        LinearLayout in = Ui.card(a);
        in.addView(UiKit.head(a, S.t("أدخل إحداثيات بأي صيغة", "Enter coordinates in any format")));
        in.addView(UiKit.note(a, "33.3152, 44.3661\n33°18'54.7\"N 44°21'58.0\"E\n33°18.912'N 44°21.966'E\n38S 444000 3688000\n38SMB4400088000"));
        final EditText f = Ui.field(a, S.t("الصق أو اكتب هنا", "Paste or type here"), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        f.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        f.setGravity(Gravity.START);
        in.addView(f, new LinearLayout.LayoutParams(-1, -2));
        final TextView status = Ui.text(a, "", 13, Theme.sub, false);
        status.setPadding(0, Ui.dp(a, 8), 0, 0);
        in.addView(status);

        final TextView srcBtn = Ui.button(a, "", false, null);
        final TextView tgtBtn = Ui.button(a, "", false, null);
        in.addView(UiKit.label(a, S.t("نظام الإدخال", "Input system")));
        in.addView(srcBtn, new LinearLayout.LayoutParams(-1, -2));
        in.addView(UiKit.label(a, S.t("نظام إضافي للإخراج (X/Y)", "Extra output system (X/Y)")));
        in.addView(tgtBtn, new LinearLayout.LayoutParams(-1, -2));
        in.addView(UiKit.check(a, S.t("الأرقام العادية: خط العرض أولاً (lat, lon)", "Plain numbers: latitude first (lat, lon)"), latFirst, v -> {
            latFirst = v;
            f.setText(f.getText());
        }));
        p.addView(in);

        final LinearLayout out = Ui.card(a);
        out.addView(UiKit.head(a, S.t("النتائج", "Results")));
        final LinearLayout res = UiKit.col(a);
        out.addView(res);
        p.addView(out);

        final CoordService.Result[] cur = new CoordService.Result[1];
        final Runnable recompute = new Runnable() {
            public void run() {
                res.removeAllViews();
                cur[0] = null;
                String t = f.getText().toString();
                srcBtn.setText(UiKit.crsText(src, S.t("تلقائي (WGS84 / UTM / MGRS)", "Auto (WGS84 / UTM / MGRS)")));
                tgtBtn.setText(UiKit.crsText(target, S.t("لا شيء", "None")));
                if (t.trim().isEmpty()) {
                    status.setText("");
                    return;
                }
                try {
                    CoordService.Result r = CoordService.convert(t, src, latFirst, target);
                    cur[0] = r;
                    status.setTextColor(Theme.ok);
                    status.setText("✔ " + S.t("النوع المكتشف: ", "Detected: ") + r.detectedFormat);
                    addRow(res, "DD", r.dd);
                    addRow(res, "DMS", r.dms);
                    addRow(res, "DDM", r.ddm);
                    addRow(res, "UTM", r.utm);
                    if (r.mgrs != null) addRow(res, "MGRS", r.mgrs);
                    if (r.target != null && r.target.epsg != 4326) addRow(res, r.target.code(), r.targetText);
                    if (!r.precisionNote.isEmpty()) res.addView(UiKit.note(a, r.precisionNote));
                    for (String w : r.warnings) {
                        TextView wt = UiKit.note(a, "⚠ " + w);
                        wt.setTextColor(Theme.danger);
                        res.addView(wt);
                    }
                    LinearLayout ar = Ui.row(a);
                    ar.addView(Ui.button(a, S.t("إظهار على الخريطة", "Show on map"), true, () -> {
                        a.setCenter(cur[0].lat, cur[0].lon);
                        a.showMap();
                        a.map.getController().setZoom(15.0);
                        a.map.getController().animateTo(new org.osmdroid.util.GeoPoint(cur[0].lat, cur[0].lon));
                    }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
                    ar.addView(Ui.button(a, S.t("نسخ الكل", "Copy all"), false, () -> a.copy(cur[0].copyText(S.ar))),
                            Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
                    res.addView(ar);
                } catch (RuntimeException e) {
                    status.setTextColor(Theme.danger);
                    status.setText("✖ " + e.getMessage());
                }
            }
        };
        srcBtn.setOnClickListener(v -> UiKit.pickCrs(a, S.t("تلقائي", "Auto"), c -> {
            src = c;
            recompute.run();
        }));
        tgtBtn.setOnClickListener(v -> UiKit.pickCrs(a, S.t("لا شيء (WGS84 فقط)", "None (WGS84 only)"), c -> {
            target = c;
            recompute.run();
        }));
        f.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                recompute.run();
            }
        });
        recompute.run();

        LinearLayout batch = Ui.card(a);
        batch.addView(UiKit.head(a, S.t("تحويل ملف كامل (دفعة)", "Convert a whole file (batch)")));
        batch.addView(UiKit.note(a, S.t("CSV أو TXT أو Excel: اختر الأعمدة ونظام الإدخال ثم الصيغ المطلوبة. الصفوف الخاطئة تُسجَّل في ملف أخطاء ولا تُخفى.",
                "CSV, TXT or Excel: choose the columns and input system, then the output formats. Bad rows are logged in an errors file, never hidden.")));
        batch.addView(Ui.button(a, S.t("اختيار ملف…", "Choose file…"), true, a::pickBatch), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(batch);
        return p;
    }

    private void addRow(LinearLayout parent, String name, final String value) {
        parent.addView(UiKit.label(a, name));
        LinearLayout r = Ui.row(a);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        TextView v = Ui.text(a, value, 15, Theme.text, true);
        v.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        v.setTextIsSelectable(true);
        r.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(Ui.button(a, S.t("نسخ", "Copy"), false, () -> a.copy(value)), new LinearLayout.LayoutParams(Ui.dp(a, 84), -2));
        parent.addView(r);
    }

    // ---------------------------------------------------------------- batch

    static File copyToCache(MainActivity a, Uri u, String name) throws java.io.IOException {
        File dir = new File(a.getCacheDir(), "incoming");
        if (!dir.exists()) dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File o : old) if (System.currentTimeMillis() - o.lastModified() > 3600_000L) o.delete();
        File f = new File(dir, System.currentTimeMillis() + "_" + name.replaceAll("[^A-Za-z0-9._-]", "_"));
        try (InputStream in = a.getContentResolver().openInputStream(u); FileOutputStream os = new FileOutputStream(f)) {
            if (in == null) throw new java.io.IOException("cannot open");
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        }
        return f;
    }

    void batchPicked(final Uri u, final String name) {
        a.toast(S.t("جارٍ قراءة الملف…", "Reading file…"));
        new Thread(() -> {
            try {
                final File f = copyToCache(a, u, name);
                final ImportHub.Preview pv = ImportHub.preview(f, name);
                a.runOnUiThread(() -> {
                    if (pv.header == null) {
                        a.message(S.t("ملف غير مناسب", "Unsuitable file"),
                                S.t("اختر CSV أو TXT أو Excel يحتوي أعمدة إحداثيات.", "Choose a CSV, TXT or Excel file with coordinate columns."), null, null);
                        return;
                    }
                    batchDialog(f, name, pv);
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> a.message(S.t("تعذّرت القراءة", "Cannot read"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }

    static android.widget.Spinner spinner(MainActivity a, List<String> items, int sel) {
        android.widget.Spinner sp = new android.widget.Spinner(a);
        android.widget.ArrayAdapter<String> ad = new android.widget.ArrayAdapter<>(a, android.R.layout.simple_spinner_dropdown_item, items);
        sp.setAdapter(ad);
        sp.setSelection(Math.max(0, sel));
        return sp;
    }

    static List<String> columnChoices(List<String> header) {
        List<String> r = new ArrayList<>();
        r.add(S.t("— لا شيء —", "— none —"));
        for (int i = 0; i < header.size(); i++) r.add((i + 1) + ": " + header.get(i));
        return r;
    }

    private void batchDialog(final File f, final String name, final ImportHub.Preview pv) {
        final PointTable.Mapping m = new PointTable.Mapping(pv.guess);
        final BatchConverter.Options o = new BatchConverter.Options();
        final Crs[] srcCrs = {null};
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, name));
        box.addView(UiKit.note(a, pv.layers.get(0).count + S.t(" صف", " rows")));
        List<String> ch = columnChoices(pv.header);
        final android.widget.Spinner sx = spinner(a, ch, m.x + 1), sy = spinner(a, ch, m.y + 1), sc = spinner(a, ch, m.combined + 1);
        box.addView(UiKit.label(a, S.t("عمود X / خط الطول / Easting", "X / longitude / easting column")));
        box.addView(sx);
        box.addView(UiKit.label(a, S.t("عمود Y / دائرة العرض / Northing", "Y / latitude / northing column")));
        box.addView(sy);
        box.addView(UiKit.label(a, S.t("أو عمود واحد يجمع الاثنين", "or one combined column")));
        box.addView(sc);
        box.addView(UiKit.check(a, S.t("العمود الأول هو خط العرض (Y قبل X)", "First column is latitude"), m.latFirst, v -> m.latFirst = v));
        final TextView sb = Ui.button(a, UiKit.crsText(null, S.t("نظام الإدخال: تلقائي", "Input system: auto")), false, null);
        sb.setOnClickListener(v -> UiKit.pickCrs(a, S.t("تلقائي / WGS84", "Auto / WGS84"), c -> {
            srcCrs[0] = c;
            sb.setText(S.t("نظام الإدخال: ", "Input system: ") + UiKit.crsText(c, S.t("تلقائي", "auto")));
        }));
        box.addView(sb, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        final TextView tb = Ui.button(a, S.t("نظام إضافي: لا شيء", "Extra system: none"), false, null);
        tb.setOnClickListener(v -> UiKit.pickCrs(a, S.t("لا شيء", "None"), c -> {
            o.target = c;
            tb.setText(S.t("نظام إضافي: ", "Extra system: ") + UiKit.crsText(c, S.t("لا شيء", "none")));
        }));
        box.addView(tb, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        box.addView(UiKit.check(a, "DD", true, v -> o.outDD = v));
        o.outDD = true;
        box.addView(UiKit.check(a, "DMS", false, v -> o.outDMS = v));
        box.addView(UiKit.check(a, "DDM", false, v -> o.outDDM = v));
        box.addView(UiKit.check(a, "UTM", true, v -> o.outUTM = v));
        o.outUTM = true;
        box.addView(UiKit.check(a, "MGRS", false, v -> o.outMGRS = v));
        box.addView(UiKit.check(a, S.t("إبقاء الأعمدة الأصلية", "Keep original columns"), true, v -> o.keepOriginal = v));
        final boolean[] xlsx = {false};
        box.addView(Ui.chips(a, new String[]{"CSV", "Excel"}, 0, i -> xlsx[0] = i == 1), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        final android.app.Dialog d = a.card(scroll(box));
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, d::dismiss), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("تحويل وحفظ", "Convert & save"), true, () -> {
            m.x = sx.getSelectedItemPosition() - 1;
            m.y = sy.getSelectedItemPosition() - 1;
            m.combined = sc.getSelectedItemPosition() - 1;
            if (m.combined < 0 && (m.x < 0 || m.y < 0)) {
                a.toast(S.t("حدّد عمودَي الإحداثيات", "Choose the coordinate columns"));
                return;
            }
            o.mapping = m;
            o.src = srcCrs[0];
            d.dismiss();
            runBatch(f, name, o, xlsx[0]);
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    static View scroll(View v) {
        android.widget.ScrollView sv = new android.widget.ScrollView(v.getContext());
        sv.addView(v);
        LinearLayout w = new LinearLayout(v.getContext());
        w.setOrientation(LinearLayout.VERTICAL);
        w.addView(sv, new LinearLayout.LayoutParams(-1, Ui.dp(v.getContext(), 460)));
        return w;
    }

    private void runBatch(final File f, final String name, final BatchConverter.Options o, final boolean xlsx) {
        final LinearLayout box = UiKit.col(a);
        final TextView msg = Ui.text(a, S.t("جارٍ التحويل…", "Converting…"), 16, Theme.text, true);
        box.addView(msg);
        final android.app.Dialog busy = a.card(box);
        busy.setCancelable(false);
        busy.show();
        final boolean[] cancel = {false};
        box.addView(Ui.button(a, S.t("إيقاف", "Stop"), false, () -> cancel[0] = true));
        new Thread(() -> {
            try {
                String base = name.replaceAll("\\.[^.]*$", "") + "_converted";
                final File errs = new File(a.getCacheDir(), "errors_" + System.currentTimeMillis() + ".csv");
                o.errorsFile = errs;
                final BatchConverter.Summary[] sum = new BatchConverter.Summary[1];
                final String mime = xlsx ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "text/csv";
                final Storage.Saved sv = Storage.save(a, a.prefs, base + (xlsx ? ".xlsx" : ".csv"), mime, os -> {
                    Sink sink = xlsx ? new XlsxSink(os, S.ar) : new CsvSink(os);
                    sum[0] = BatchConverter.run(f, name, o, sink, new BatchConverter.Progress() {
                        long last;

                        public void update(long rows) {
                            if (rows - last >= 5000) {
                                last = rows;
                                a.runOnUiThread(() -> msg.setText(S.t("جارٍ التحويل… ", "Converting… ") + rows));
                            }
                        }

                        public boolean cancelled() {
                            return cancel[0];
                        }
                    });
                });
                final String text = sum[0].toText(S.ar);
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("اكتمل التحويل", "Conversion finished"), text + "\n\n" + sv.where, S.t("مشاركة / فتح", "Share / open"),
                            () -> Storage.share(a, sv.uri, mime));
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("فشل التحويل", "Conversion failed"), String.valueOf(t.getMessage()), null, null);
                });
            }
        }).start();
    }
}
