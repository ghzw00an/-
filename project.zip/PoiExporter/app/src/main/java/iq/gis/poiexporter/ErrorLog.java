package iq.gis.poiexporter;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** In-memory ring buffer of recent errors for the error-log page. Never leaves the device unless the user shares it. */
public final class ErrorLog {
    private ErrorLog() {
    }

    private static final int MAX = 100;
    private static final List<String> LINES = new ArrayList<>();

    public static synchronized void add(String where, Throwable t) {
        StringWriter sw = new StringWriter();
        if (t != null) t.printStackTrace(new PrintWriter(sw));
        String head = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new Date()) + "  [" + where + "]  "
                + (t == null ? "" : t.getClass().getSimpleName() + ": " + t.getMessage());
        String[] st = sw.toString().split("\n");
        StringBuilder b = new StringBuilder(head);
        for (int i = 1; i < st.length && i < 8; i++) b.append('\n').append(st[i]);
        LINES.add(b.toString());
        while (LINES.size() > MAX) LINES.remove(0);
    }

    public static synchronized String text() {
        StringBuilder b = new StringBuilder();
        for (int i = LINES.size() - 1; i >= 0; i--) b.append(LINES.get(i)).append("\n\n");
        return b.toString();
    }

    public static synchronized int size() {
        return LINES.size();
    }

    public static synchronized void clear() {
        LINES.clear();
    }
}
