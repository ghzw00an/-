package iq.gis.poiexporter.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Writes Shapefiles (point, polyline, polygon) in WGS84 lon/lat.
 * Attribute table: NAME TYPE CATEGORY NAHIYA QADAA GOVERNORAT UTM_ZONE X Y LON LAT COORD
 * where X, Y are UTM easting and northing of the representative point.
 */
public final class ShapeWriter {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final String PRJ =
            "GEOGCS[\"GCS_WGS_1984\",DATUM[\"D_WGS_1984\",SPHEROID[\"WGS_1984\",6378137.0,298.257223563]],"
                    + "PRIMEM[\"Greenwich\",0.0],UNIT[\"Degree\",0.0174532925199433]]";

    static final String[] F_NAME = LandmarkFields.NAMES;
    static final char[] F_TYPE = {'C', 'C', 'C', 'C', 'C', 'C', 'N', 'N', 'C'};
    static final int[] F_LEN = {200, 80, 100, 100, 100, 100, 14, 14, 254};
    static final int[] F_DEC = {0, 0, 0, 0, 0, 0, 2, 2, 0};

    private ShapeWriter() {}

    public static String safeName(String s) {
        String r = s.replaceAll("[^A-Za-z0-9_\\-]", "_");
        return r.isEmpty() ? "layer" : r;
    }

    /** Parts keyed by extension: shp, shx, dbf, prj, cpg (in memory; used by tests and small exports). */
    public static Map<String, byte[]> build(List<Feature> feats, int geom, CoordFmt.Fmt fmt) throws IOException {
        Prepared p = new Prepared(feats, geom);
        Map<String, byte[]> out = new LinkedHashMap<>();
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        writeShp(b, p);
        out.put("shp", b.toByteArray());
        b = new ByteArrayOutputStream();
        writeShx(b, p);
        out.put("shx", b.toByteArray());
        b = new ByteArrayOutputStream();
        writeDbf(b, p.feats, fmt);
        out.put("dbf", b.toByteArray());
        out.put("prj", PRJ.getBytes(UTF8));
        out.put("cpg", "UTF-8".getBytes(UTF8));
        return out;
    }

    private static double[][] clean(Feature f, int geom) {
        List<double[]> res = new ArrayList<>();
        boolean haveOuter = false;
        for (int i = 0; i < f.parts.size(); i++) {
            double[] p = f.parts.get(i);
            if (p == null || p.length < 2) continue;
            if (geom == Feature.POINT) {
                res.add(new double[]{p[0], p[1]});
                break;
            } else if (geom == Feature.LINE) {
                if (p.length >= 4) res.add(p);
            } else {
                if (p.length < 6) continue;
                double[] r = p;
                int n = r.length;
                if (r[0] != r[n - 2] || r[1] != r[n - 1]) {
                    r = java.util.Arrays.copyOf(r, n + 2);
                    r[n] = r[0];
                    r[n + 1] = r[1];
                }
                if (r.length < 8) continue;
                boolean hole = f.isHole(i);
                r = Geo.oriented(r, !hole); // outer rings clockwise, holes counter-clockwise
                if (!hole) haveOuter = true;
                res.add(r);
            }
        }
        if (res.isEmpty()) return null;
        if (geom == Feature.POLYGON && !haveOuter) return null;
        return res.toArray(new double[0][]);
    }

    /** Buffered little/big endian writer on top of a stream; never closes the stream it wraps. */
    private static final class Bin {
        private final OutputStream os;
        private final byte[] buf = new byte[1 << 16];
        private int n;

        Bin(OutputStream os) {
            this.os = os;
        }

        private void room(int k) throws IOException {
            if (n + k > buf.length) flush();
        }

        void flush() throws IOException {
            if (n > 0) {
                os.write(buf, 0, n);
                n = 0;
            }
        }

        void be32(int v) throws IOException {
            room(4);
            buf[n++] = (byte) (v >>> 24);
            buf[n++] = (byte) (v >>> 16);
            buf[n++] = (byte) (v >>> 8);
            buf[n++] = (byte) v;
        }

        void le32(int v) throws IOException {
            room(4);
            buf[n++] = (byte) v;
            buf[n++] = (byte) (v >>> 8);
            buf[n++] = (byte) (v >>> 16);
            buf[n++] = (byte) (v >>> 24);
        }

        void le16(int v) throws IOException {
            room(2);
            buf[n++] = (byte) v;
            buf[n++] = (byte) (v >>> 8);
        }

        void leDouble(double d) throws IOException {
            long v = Double.doubleToRawLongBits(d);
            room(8);
            for (int i = 0; i < 8; i++) buf[n++] = (byte) (v >>> (8 * i));
        }

        void put(int b) throws IOException {
            room(1);
            buf[n++] = (byte) b;
        }

        void put(byte[] b, int len) throws IOException {
            if (len > buf.length) {
                flush();
                os.write(b, 0, len);
                return;
            }
            room(len);
            System.arraycopy(b, 0, buf, n, len);
            n += len;
        }
    }

    /** Features that can be written, with their cleaned geometry. */
    private static final class Prepared {
        final List<Feature> feats = new ArrayList<>();
        final List<double[][]> geo = new ArrayList<>();
        final int geom;
        double minX, minY, maxX, maxY;
        long shpBytes = 100;

        Prepared(List<Feature> all, int geom) {
            this.geom = geom;
            boolean first = true;
            for (Feature f : all) {
                double[][] parts = clean(f, geom);
                if (parts == null) continue;
                feats.add(f);
                geo.add(parts);
                int pts = 0;
                for (double[] p : parts) {
                    pts += p.length / 2;
                    for (int i = 0; i < p.length; i += 2) {
                        if (first) {
                            minX = maxX = p[i];
                            minY = maxY = p[i + 1];
                            first = false;
                        } else {
                            minX = Math.min(minX, p[i]);
                            maxX = Math.max(maxX, p[i]);
                            minY = Math.min(minY, p[i + 1]);
                            maxY = Math.max(maxY, p[i + 1]);
                        }
                    }
                }
                shpBytes += 8 + contentLen(geom, parts.length, pts);
            }
        }
    }

    private static int contentLen(int geom, int nParts, int nPts) {
        if (geom == Feature.POINT) return 20;
        return 44 + 4 * nParts + 16 * nPts;
    }

    private static void header(Bin o, long bytes, Prepared p) throws IOException {
        o.be32(9994);
        for (int i = 0; i < 5; i++) o.be32(0);
        o.be32((int) (bytes / 2));
        o.le32(1000);
        o.le32(p.geom);
        o.leDouble(p.minX);
        o.leDouble(p.minY);
        o.leDouble(p.maxX);
        o.leDouble(p.maxY);
        for (int i = 0; i < 4; i++) o.leDouble(0);
    }

    private static void writeShp(OutputStream os, Prepared p) throws IOException {
        Bin o = new Bin(os);
        header(o, p.shpBytes, p);
        for (int r = 0; r < p.geo.size(); r++) {
            double[][] parts = p.geo.get(r);
            int pts = 0;
            for (double[] q : parts) pts += q.length / 2;
            o.be32(r + 1);
            o.be32(contentLen(p.geom, parts.length, pts) / 2);
            o.le32(p.geom);
            if (p.geom == Feature.POINT) {
                o.leDouble(parts[0][0]);
                o.leDouble(parts[0][1]);
            } else {
                double bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9;
                for (double[] q : parts) {
                    for (int i = 0; i < q.length; i += 2) {
                        bx0 = Math.min(bx0, q[i]);
                        bx1 = Math.max(bx1, q[i]);
                        by0 = Math.min(by0, q[i + 1]);
                        by1 = Math.max(by1, q[i + 1]);
                    }
                }
                o.leDouble(bx0);
                o.leDouble(by0);
                o.leDouble(bx1);
                o.leDouble(by1);
                o.le32(parts.length);
                o.le32(pts);
                int idx = 0;
                for (double[] q : parts) {
                    o.le32(idx);
                    idx += q.length / 2;
                }
                for (double[] q : parts) for (double v : q) o.leDouble(v);
            }
        }
        o.flush();
    }

    private static void writeShx(OutputStream os, Prepared p) throws IOException {
        Bin o = new Bin(os);
        header(o, 100L + 8L * p.geo.size(), p);
        long offset = 100;
        for (double[][] parts : p.geo) {
            int pts = 0;
            for (double[] q : parts) pts += q.length / 2;
            int len = contentLen(p.geom, parts.length, pts);
            o.be32((int) (offset / 2));
            o.be32(len / 2);
            offset += 8 + len;
        }
        o.flush();
    }

    static byte[] fit(String s, int max) {
        if (s == null) s = "";
        byte[] raw = s.getBytes(UTF8);
        if (raw.length <= max) return raw;
        int end = max;
        while (end > 0 && (raw[end] & 0xC0) == 0x80) end--;
        return java.util.Arrays.copyOf(raw, end);
    }

    private static void writeDbf(OutputStream os, List<Feature> feats, CoordFmt.Fmt fmt) throws IOException {
        Bin o = new Bin(os);
        int nf = F_NAME.length;
        int recLen = 1;
        for (int l : F_LEN) recLen += l;
        int headerLen = 32 + 32 * nf + 1;
        Calendar c = Calendar.getInstance();
        o.put(0x03);
        o.put(c.get(Calendar.YEAR) - 1900);
        o.put(c.get(Calendar.MONTH) + 1);
        o.put(c.get(Calendar.DAY_OF_MONTH));
        o.le32(feats.size());
        o.le16(headerLen);
        o.le16(recLen);
        for (int i = 0; i < 20; i++) o.put(0);
        for (int i = 0; i < nf; i++) {
            byte[] d = new byte[32];
            byte[] nm = F_NAME[i].getBytes(UTF8);
            System.arraycopy(nm, 0, d, 0, Math.min(10, nm.length));
            d[11] = (byte) F_TYPE[i];
            d[16] = (byte) F_LEN[i];
            d[17] = (byte) F_DEC[i];
            o.put(d, 32);
        }
        o.put(0x0D);
        byte[] rec = new byte[recLen];
        for (Feature f : feats) {
            java.util.Arrays.fill(rec, (byte) 0x20);
            String[] text = LandmarkFields.text(f);
            int pos = 1;
            for (int i = 0; i < text.length; i++) {
                byte[] b = fit(text[i], F_LEN[i]);
                System.arraycopy(b, 0, rec, pos, b.length);
                pos += F_LEN[i];
            }
            double[] xy = LandmarkFields.xy(f, null);
            for (int k = 0; k < 2; k++) {
                int col = 6 + k;
                byte[] b = LandmarkFields.num(xy[k], F_DEC[col]).getBytes(UTF8);
                int len = Math.min(b.length, F_LEN[col]);
                System.arraycopy(b, 0, rec, pos + F_LEN[col] - len, len);
                pos += F_LEN[col];
            }
            byte[] lb = fit(LandmarkFields.link(f), F_LEN[8]);
            System.arraycopy(lb, 0, rec, pos, lb.length);
            o.put(rec, recLen);
        }
        o.put(0x1A);
        o.flush();
    }

    /** All parts of one layer written into an open zip under the given base name. */
    private static void zipLayer(ZipOutputStream zos, String base, List<Feature> feats, int geom, CoordFmt.Fmt fmt)
            throws IOException {
        Prepared p = new Prepared(feats, geom);
        zos.putNextEntry(new ZipEntry(base + ".shp"));
        writeShp(zos, p);
        zos.closeEntry();
        zos.putNextEntry(new ZipEntry(base + ".shx"));
        writeShx(zos, p);
        zos.closeEntry();
        zos.putNextEntry(new ZipEntry(base + ".dbf"));
        writeDbf(zos, p.feats, fmt);
        zos.closeEntry();
        zos.putNextEntry(new ZipEntry(base + ".prj"));
        zos.write(PRJ.getBytes(UTF8));
        zos.closeEntry();
        zos.putNextEntry(new ZipEntry(base + ".cpg"));
        zos.write("UTF-8".getBytes(UTF8));
        zos.closeEntry();
    }

    /** All layers into one zip stream, streaming so memory stays small. File names come from the layer ids. */
    public static void writeZip(List<LayerData> layers, CoordFmt.Fmt fmt, OutputStream os) throws IOException {
        ZipOutputStream zos = new ZipOutputStream(os);
        zos.setLevel(1);
        java.util.HashSet<String> used = new java.util.HashSet<>();
        for (LayerData l : layers) {
            String base = safeName(l.id);
            String b = base;
            int k = 2;
            while (!used.add(b)) b = base + "_" + k++;
            zipLayer(zos, b, l.features, l.geom, fmt);
        }
        zos.finish();
        zos.flush();
    }

    // ------------------------------------------------------------------ generic export (any CRS, all attributes)

    private static final int[] G_LEN = {200, 80, 100, 100, 100, 100};

    /** Result of a generic export: features that could not be written. */
    public static final class GenericResult {
        public int written, skipped;
        public final List<String> notes = new ArrayList<>();
    }

    private static String dbfName(String raw, java.util.Set<String> used) {
        String n = raw.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9_]", "_");
        if (n.isEmpty() || Character.isDigit(n.charAt(0))) n = "F_" + n;
        if (n.length() > 10) n = n.substring(0, 10);
        String b = n;
        int k = 1;
        while (!used.add(b)) {
            String suf = "_" + k++;
            b = n.substring(0, Math.min(n.length(), 10 - suf.length())) + suf;
        }
        return b;
    }

    private static Feature project(Feature f, iq.gis.poiexporter.core.crs.Crs.Tx tx) {
        Feature c = f.copy();
        double[] o = new double[2];
        for (int i = 0; i < c.parts.size(); i++) {
            double[] p = c.parts.get(i);
            for (int k = 0; k + 1 < p.length; k += 2) {
                tx.apply(p[k], p[k + 1], o);
                p[k] = o[0];
                p[k + 1] = o[1];
            }
        }
        double[] r = new double[2];
        tx.apply(f.lon, f.lat, r);
        c.lon = r[0];
        c.lat = r[1];
        return c;
    }

    /**
     * One shapefile per layer and geometry type inside a ZIP: landmark fields + imported attributes + X/Y in the
     * target CRS. The .prj is written from the CRS; unsupported systems throw IllegalArgumentException before any
     * byte is written.
     */
    public static GenericResult writeZipGeneric(List<LayerData> layers, iq.gis.poiexporter.core.crs.Crs target,
                                                boolean attributes, OutputStream os) throws IOException {
        final boolean utmXY = target == null; // default: geometry in WGS84, x/y = UTM of each point
        if (target == null) target = iq.gis.poiexporter.core.crs.Crs.wgs84();
        String prj = iq.gis.poiexporter.core.io.Wkt.of(target);
        boolean wgs = target.epsg == 4326;
        iq.gis.poiexporter.core.crs.Crs.Tx tx = wgs ? null : iq.gis.poiexporter.core.crs.Crs.wgs84().to(target);
        GenericResult res = new GenericResult();
        ZipOutputStream zos = new ZipOutputStream(os);
        zos.setLevel(1);
        java.util.HashSet<String> usedFiles = new java.util.HashSet<>();
        for (LayerData l : layers) {
            for (int geom : new int[]{Feature.POINT, Feature.LINE, Feature.POLYGON}) {
                List<Feature> feats = new ArrayList<>();
                for (Feature f : l.features) {
                    if (f.geom != geom || f.parts.isEmpty()) continue;
                    if (tx == null) {
                        feats.add(f);
                    } else {
                        try {
                            feats.add(project(f, tx));
                        } catch (IllegalArgumentException e) {
                            res.skipped++;
                            if (res.notes.size() < 50) res.notes.add(iq.gis.poiexporter.S.t("تعذّر إسقاط المعلم «" + f.name + "»", "Cannot project feature \"" + f.name + "\""));
                        }
                    }
                }
                if (feats.isEmpty()) continue;
                String suffix = geom == Feature.POINT ? "_points" : geom == Feature.LINE ? "_lines" : "_polygons";
                String baseName = safeName(l.label.isEmpty() ? l.id : l.label);
                if (baseName.replace("_", "").isEmpty()) baseName = safeName(l.id);
                String base = baseName + suffix;
                String b = base;
                int k = 2;
                while (!usedFiles.add(b)) b = base + "_" + k++;
                Prepared p = new Prepared(feats, geom);
                res.skipped += feats.size() - p.feats.size();
                res.written += p.feats.size();
                zos.putNextEntry(new ZipEntry(b + ".shp"));
                writeShp(zos, p);
                zos.closeEntry();
                zos.putNextEntry(new ZipEntry(b + ".shx"));
                writeShx(zos, p);
                zos.closeEntry();
                zos.putNextEntry(new ZipEntry(b + ".dbf"));
                writeDbfGeneric(zos, p.feats, attributes, !utmXY && target.geographic, utmXY);
                zos.closeEntry();
                zos.putNextEntry(new ZipEntry(b + ".prj"));
                zos.write(prj.getBytes(UTF8));
                zos.closeEntry();
                zos.putNextEntry(new ZipEntry(b + ".cpg"));
                zos.write("UTF-8".getBytes(UTF8));
                zos.closeEntry();
            }
        }
        zos.finish();
        zos.flush();
        return res;
    }

    private static void writeDbfGeneric(OutputStream os, List<Feature> feats, boolean attributes, boolean geographic, boolean utm)
            throws IOException {
        List<String> names = new ArrayList<>();
        List<Character> types = new ArrayList<>();
        List<Integer> lens = new ArrayList<>(), decs = new ArrayList<>();
        java.util.Set<String> used = new java.util.HashSet<>();
        List<String> attrKeys = new ArrayList<>();
        // fixed table: name, type, Gategory, gathaa, Nahia, mohafadha, x, y, link (exact spelling), then imported attributes
        for (int i = 0; i < LandmarkFields.NAMES.length; i++) {
            String n = LandmarkFields.NAMES[i];
            used.add(n.toUpperCase(Locale.ROOT));
            names.add(n);
            if (i < LandmarkFields.N_TEXT) {
                types.add('C');
                lens.add(G_LEN[i]);
                decs.add(0);
            } else if (i < 8) {
                types.add('N');
                lens.add(geographic ? 15 : 18);
                decs.add(geographic ? 9 : 3);
            } else {
                types.add('C');
                lens.add(254);
                decs.add(0);
            }
        }
        if (attributes) {
            java.util.LinkedHashSet<String> keys = new java.util.LinkedHashSet<>();
            for (Feature f : feats) {
                for (String k : f.attrs.keySet()) if (!LandmarkFields.isStd(k)) keys.add(k);
                if (keys.size() > 100) break;
            }
            for (String key : keys) {
                if (names.size() >= 250) break;
                attrKeys.add(key);
                names.add(dbfName(key, used));
                types.add('C');
                lens.add(254);
                decs.add(0);
            }
        }
        int nf = names.size();
        int recLen = 1;
        for (int l : lens) recLen += l;
        int headerLen = 32 + 32 * nf + 1;
        Bin o = new Bin(os);
        Calendar c = Calendar.getInstance();
        o.put(0x03);
        o.put(c.get(Calendar.YEAR) - 1900);
        o.put(c.get(Calendar.MONTH) + 1);
        o.put(c.get(Calendar.DAY_OF_MONTH));
        o.le32(feats.size());
        o.le16(headerLen);
        o.le16(recLen);
        for (int i = 0; i < 20; i++) o.put(0);
        for (int i = 0; i < nf; i++) {
            byte[] d = new byte[32];
            byte[] nm = names.get(i).getBytes(UTF8);
            System.arraycopy(nm, 0, d, 0, Math.min(10, nm.length));
            d[11] = (byte) types.get(i).charValue();
            d[16] = (byte) (int) lens.get(i);
            d[17] = (byte) (int) decs.get(i);
            o.put(d, 32);
        }
        o.put(0x0D);
        byte[] rec = new byte[recLen];
        for (Feature f : feats) {
            java.util.Arrays.fill(rec, (byte) 0x20);
            int pos = 1;
            int col = 0;
            String[] text = LandmarkFields.text(f);
            for (int i = 0; i < text.length; i++, col++) {
                int len = lens.get(col);
                byte[] b = fit(text[i], len);
                System.arraycopy(b, 0, rec, pos, b.length);
                pos += len;
            }
            double[] vals = utm ? LandmarkFields.xy(f, null) : new double[]{f.lon, f.lat};
            for (int k = 0; k < 2; k++, col++) {
                int len = lens.get(col);
                byte[] b = LandmarkFields.num(vals[k], decs.get(col)).getBytes(UTF8);
                int n2 = Math.min(b.length, len);
                System.arraycopy(b, 0, rec, pos + len - n2, n2);
                pos += len;
            }
            {
                int len = lens.get(col++);
                byte[] b = fit(LandmarkFields.link(f), len);
                System.arraycopy(b, 0, rec, pos, b.length);
                pos += len;
            }
            for (String key : attrKeys) {
                int len = lens.get(col++);
                String v = f.attrs.get(key);
                byte[] b = fit(v == null ? "" : v, len);
                System.arraycopy(b, 0, rec, pos, b.length);
                pos += len;
            }
            o.put(rec, recLen);
        }
        o.put(0x1A);
        o.flush();
    }

    /** Test helper: writes the parts as files. */
    public static void writeFiles(File dir, String base, List<Feature> feats, int geom, CoordFmt.Fmt fmt) throws IOException {
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("cannot create " + dir);
        for (Map.Entry<String, byte[]> e : build(feats, geom, fmt).entrySet()) {
            FileOutputStream o = new FileOutputStream(new File(dir, base + "." + e.getKey()));
            try {
                o.write(e.getValue());
            } finally {
                o.close();
            }
        }
    }
}
