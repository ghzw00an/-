package iq.gis.poiexporter.core.coord;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Mgrs;

import java.util.Locale;

/**
 * Keeps converted coordinates honest: the resolution of the typed input decides how many digits the results may
 * show, so 33.3152 (about 11 m) is never turned into a UTM value with millimetres.
 */
public final class Precision {
    private static final double M_PER_DEG = 111320.0;

    private Precision() {
    }

    private static String normalize(String raw) {
        StringBuilder sb = new StringBuilder();
        for (char c : raw.trim().toCharArray()) {
            if (c >= '٠' && c <= '٩') sb.append((char) ('0' + (c - '٠')));
            else if (c >= '۰' && c <= '۹') sb.append((char) ('0' + (c - '۰')));
            else if (c == '٫') sb.append('.');
            else sb.append(Character.toUpperCase(c));
        }
        return sb.toString();
    }

    /** Largest number of decimals found in any numeric token (the finest unit carries the decimals). */
    public static int decimals(String text) {
        String t = normalize(text);
        int best = 0;
        int i = 0, n = t.length();
        while (i < n) {
            char c = t.charAt(i);
            if (c >= '0' && c <= '9' || c == '.') {
                int j = i;
                int dot = -1;
                while (j < n && (t.charAt(j) >= '0' && t.charAt(j) <= '9' || t.charAt(j) == '.')) {
                    if (t.charAt(j) == '.' && dot < 0) dot = j;
                    j++;
                }
                if (dot >= 0) best = Math.max(best, j - dot - 1);
                i = j;
            } else {
                i++;
            }
        }
        return best;
    }

    /** Resolution in metres of coordinates typed in the given text (auto-detected format). Never below 1 mm. */
    public static double resolutionMetres(String input) {
        CoordFmt.Fmt fmt;
        try {
            fmt = CoordFmt.parse(input).fmt;
        } catch (RuntimeException e) {
            return projectedResolution(input);
        }
        return resolutionMetres(input, fmt);
    }

    public static double resolutionMetres(String input, CoordFmt.Fmt fmt) {
        int d = decimals(input);
        double r;
        switch (fmt) {
            case DMS:
                r = Math.pow(10, -d) / 3600.0 * M_PER_DEG;
                break;
            case DDM:
                r = Math.pow(10, -d) / 60.0 * M_PER_DEG;
                break;
            case MGRS: {
                String compact = normalize(input).replaceAll("[\\s,;]+", "");
                int digits = 0;
                for (int k = compact.length() - 1; k >= 0 && Character.isDigit(compact.charAt(k)); k--) digits++;
                digits = Math.min(digits, 10) / 2;
                // zone digits are consumed by the regex of Mgrs; only the trailing pair counts
                r = Math.pow(10, 5 - digits);
                break;
            }
            case UTM:
                r = Math.pow(10, -d);
                break;
            default:
                r = Math.pow(10, -d) * M_PER_DEG;
        }
        return Math.max(r, 0.001);
    }

    /** Resolution of plain projected numbers (x y in metres). */
    public static double projectedResolution(String input) {
        return Math.max(Math.pow(10, -decimals(input)), 0.001);
    }

    /** Digits after the point for projected (metre) output. 0..3. */
    public static int projectedDecimals(double resMetres) {
        int d = (int) Math.round(-Math.log10(resMetres));
        return Math.max(0, Math.min(3, d));
    }

    /** Decimal digits of degrees for geographic output. 0..9 (never more than the input justifies, at least 2). */
    public static int degreeDecimals(double resMetres) {
        double resDeg = resMetres / M_PER_DEG;
        int d = (int) Math.round(-Math.log10(resDeg));
        return Math.max(2, Math.min(9, d));
    }

    public static int outputDecimals(double resMetres, boolean targetIsGeographic, double lat) {
        return targetIsGeographic ? degreeDecimals(resMetres / Math.max(0.2, Math.cos(Math.toRadians(lat))) * 1.0) : projectedDecimals(resMetres);
    }

    /** Decimals of the seconds field for DMS output. */
    public static int dmsSecondDecimals(double resMetres) {
        int d = (int) Math.round(Math.log10(30.9 / resMetres));
        return Math.max(0, Math.min(5, d));
    }

    /** Decimals of the minutes field for DDM output. */
    public static int ddmMinuteDecimals(double resMetres) {
        int d = (int) Math.round(Math.log10(1855.0 / resMetres));
        return Math.max(0, Math.min(7, d));
    }

    /** MGRS digits per axis (1..5) matching the resolution. */
    public static int mgrsDigits(double resMetres) {
        int d = (int) Math.round(5 - Math.log10(resMetres));
        return Math.max(1, Math.min(5, d));
    }

    public static String describe(double resMetres, boolean ar) {
        String v;
        if (resMetres >= 1000) v = String.format(Locale.US, "%.0f", resMetres / 1000) + (ar ? " كم" : " km");
        else if (resMetres >= 1) v = String.format(Locale.US, "%.0f", resMetres) + (ar ? " م" : " m");
        else if (resMetres >= 0.01) v = String.format(Locale.US, "%.0f", resMetres * 100) + (ar ? " سم" : " cm");
        else v = String.format(Locale.US, "%.0f", resMetres * 1000) + (ar ? " ملم" : " mm");
        return (ar ? "دقة الإدخال ≈ ±" : "Input precision ≈ ±") + v;
    }

    public static String note(double resMetres, boolean ar) {
        return describe(resMetres, ar);
    }

    // ------------------------------------------------------------------ number text (fast, no String.format)

    private static final long[] POW10 = {1L, 10L, 100L, 1000L, 10000L, 100000L, 1000000L, 10000000L, 100000000L, 1000000000L};

    /** Fixed decimals without locale effects or scientific notation. */
    public static String fixed(double v, int decimals) {
        if (decimals < 0) decimals = 0;
        if (decimals > 9 || Math.abs(v) > 9.0e8) {
            return String.format(Locale.US, "%." + Math.min(decimals, 12) + "f", v);
        }
        boolean neg = v < 0;
        long scaled = Math.round(Math.abs(v) * POW10[decimals]);
        if (scaled == 0) neg = false;
        long ip = scaled / POW10[decimals];
        long fp = scaled % POW10[decimals];
        StringBuilder b = new StringBuilder(24);
        if (neg) b.append('-');
        b.append(ip);
        if (decimals > 0) {
            b.append('.');
            String f = Long.toString(fp);
            for (int i = f.length(); i < decimals; i++) b.append('0');
            b.append(f);
        }
        return b.toString();
    }

    /** True when the string is an MGRS text with at least the 100 km square letters. */
    public static boolean isMgrs(String s) {
        return Mgrs.looks(normalize(s).replaceAll("[\\s,;]+", ""));
    }

    static String msg(String ar, String en) {
        return S.t(ar, en);
    }
}
