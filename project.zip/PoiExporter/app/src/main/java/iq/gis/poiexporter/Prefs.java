package iq.gis.poiexporter;

import android.content.Context;
import android.content.SharedPreferences;

/** Persistent settings. */
public final class Prefs {
    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    public int theme() { // 0 system, 1 light, 2 dark
        return sp.getInt("theme", 0);
    }

    public void theme(int v) {
        sp.edit().putInt("theme", v).apply();
    }

    public boolean arabic() {
        return sp.getBoolean("ar", true);
    }

    public void arabic(boolean v) {
        sp.edit().putBoolean("ar", v).apply();
    }

    public String folder() {
        return sp.getString("folder", null);
    }

    public void folder(String v) {
        sp.edit().putString("folder", v).apply();
    }

    public int fmt() { // ordinal of CoordFmt.Fmt
        return sp.getInt("fmt", 2);
    }

    public void fmt(int v) {
        sp.edit().putInt("fmt", v).apply();
    }

    public int shape() { // 0 rect, 1 square, 2 circle
        return sp.getInt("shape", 0);
    }

    public void shape(int v) {
        sp.edit().putInt("shape", v).apply();
    }

    public double width() { // metres (circle: radius)
        return Double.longBitsToDouble(sp.getLong("w", Double.doubleToLongBits(2000)));
    }

    public double height() {
        return Double.longBitsToDouble(sp.getLong("h", Double.doubleToLongBits(2000)));
    }

    public void size(double w, double h) {
        sp.edit().putLong("w", Double.doubleToLongBits(w)).putLong("h", Double.doubleToLongBits(h)).apply();
    }

    public double rot() {
        return Double.longBitsToDouble(sp.getLong("rot", Double.doubleToLongBits(0)));
    }

    public void rot(double v) {
        sp.edit().putLong("rot", Double.doubleToLongBits(((v % 360) + 360) % 360)).apply();
    }

    public double[] center() {
        return new double[]{Double.longBitsToDouble(sp.getLong("clat", Double.doubleToLongBits(33.3152))),
                Double.longBitsToDouble(sp.getLong("clon", Double.doubleToLongBits(44.3661)))};
    }

    public void center(double lat, double lon) {
        sp.edit().putLong("clat", Double.doubleToLongBits(lat)).putLong("clon", Double.doubleToLongBits(lon)).apply();
    }

    public String get(String k, String def) {
        return sp.getString(k, def);
    }

    public void put(String k, String v) {
        sp.edit().putString(k, v).apply();
    }

    public boolean flag(String k, boolean def) {
        return sp.getBoolean(k, def);
    }

    public void setFlag(String k, boolean v) {
        sp.edit().putBoolean(k, v).apply();
    }
}
