package iq.gis.poiexporter.core.coord;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.List;

/** CSV (UTF-8 with BOM so Excel shows Arabic correctly) or tab separated text. */
public class CsvSink implements Sink {
    private final BufferedWriter w;
    private final char sep;
    private final boolean bom;
    private int[] decimals;

    public CsvSink(OutputStream os) throws IOException {
        this(os, ',', true);
    }

    protected CsvSink(OutputStream os, char sep, boolean bom) throws IOException {
        this.w = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"), 1 << 16);
        this.sep = sep;
        this.bom = bom;
    }

    public void begin(List<String> columns) throws IOException {
        if (bom) w.write('﻿');
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < columns.size(); i++) {
            if (i > 0) b.append(sep);
            quote(columns.get(i), b);
        }
        w.write(b.append("\r\n").toString());
    }

    public void row(Object[] cells, double lon, double lat) throws IOException {
        StringBuilder b = new StringBuilder(128);
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) b.append(sep);
            Object o = cells[i];
            if (o == null) continue;
            if (o instanceof BatchConverter.Num) b.append(((BatchConverter.Num) o).text());
            else if (o instanceof Number) b.append(o);
            else quote(String.valueOf(o), b);
        }
        w.write(b.append("\r\n").toString());
    }

    private void quote(String s, StringBuilder b) {
        boolean need = s.indexOf(sep) >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0;
        if (!need) {
            b.append(s);
            return;
        }
        b.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"') b.append('"');
            b.append(c);
        }
        b.append('"');
    }

    public void end() throws IOException {
        w.flush();
        w.close();
    }
}
