package iq.gis.poiexporter.core.db;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.MiniJson;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * The open project: layers and features in memory, every change written through to the Repo
 * (autosave) and recorded as an undoable step. All mutating methods must be called from one thread (the UI thread).
 */
public final class Workspace {
    public interface Listener {
        void changed();
    }

    private final Repo repo;
    private final ExecutorService io;      // single thread; null = write inline (tests)
    private ProjectInfo project;
    private final List<LayerData> layers = new ArrayList<>();
    private final Map<String, Feature> byId = new HashMap<>();
    private final Map<String, LayerData> layerOf = new HashMap<>();
    private final List<HistoryEntry> hist = new ArrayList<>();
    private Listener listener;
    private int maxHistory = 200;
    private volatile String lastError;

    public Workspace(Repo repo, ExecutorService io) {
        this.repo = repo;
        this.io = io;
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public void setMaxHistory(int n) {
        maxHistory = Math.max(10, n);
    }

    public String lastError() {
        return lastError;
    }

    public ProjectInfo project() {
        return project;
    }

    public List<LayerData> layers() {
        return layers;
    }

    public LayerData layer(String id) {
        for (LayerData l : layers) if (l.id.equals(id)) return l;
        return null;
    }

    public Feature feature(String id) {
        return byId.get(id);
    }

    public LayerData layerOfFeature(String id) {
        return layerOf.get(id);
    }

    public long featureCount() {
        long n = 0;
        for (LayerData l : layers) n += l.features.size();
        return n;
    }

    // ---------------------------------------------------------------- open

    public void open(String projectId) {
        flush();
        ProjectInfo found = null;
        for (ProjectInfo p : repo.projects()) if (p.id.equals(projectId)) found = p;
        if (found == null) throw new IllegalArgumentException("no such project");
        project = found;
        layers.clear();
        byId.clear();
        layerOf.clear();
        hist.clear();
        for (LayerData l : repo.loadLayers(projectId)) {
            layers.add(l);
            for (Feature f : l.features) {
                byId.put(f.id, f);
                layerOf.put(f.id, l);
            }
        }
        hist.addAll(repo.history(projectId));
        repo.setMeta("last_project", projectId);
    }

    /** Opens the last used project or creates the default one. */
    public void openDefault(String defaultName) {
        String last = repo.getMeta("last_project", "");
        for (ProjectInfo p : repo.projects()) {
            if (p.id.equals(last)) {
                open(last);
                return;
            }
        }
        List<ProjectInfo> all = repo.projects();
        if (!all.isEmpty()) {
            open(all.get(0).id);
            return;
        }
        open(repo.createProject(defaultName).id);
    }

    public Repo repo() {
        return repo;
    }

    // ---------------------------------------------------------------- write-behind

    private void write(Runnable r) {
        if (io == null) {
            run(r);
            return;
        }
        try {
            io.execute(() -> run(r));
        } catch (RuntimeException e) {
            run(r);
        }
    }

    private void run(Runnable r) {
        try {
            r.run();
        } catch (RuntimeException e) {
            lastError = String.valueOf(e);
        }
    }

    /** Waits until all pending writes reached the database (call from onPause and before backup). */
    public void flush() {
        if (io == null) return;
        try {
            io.submit(() -> {
            }).get(20, TimeUnit.SECONDS);
        } catch (Exception e) {
            lastError = String.valueOf(e);
        }
    }

    private void fire() {
        if (listener != null) listener.changed();
    }

    // ---------------------------------------------------------------- history

    private static String now() {
        return java.time.Instant.now().toString();
    }

    private void record(String label, String json) {
        // a new action discards the redo stack
        List<Long> drop = new ArrayList<>();
        List<HistoryEntry> dropped = new ArrayList<>();
        for (HistoryEntry e : hist) if (e.undone) {
            drop.add(e.seq);
            dropped.add(e);
        }
        if (!drop.isEmpty()) {
            hist.removeAll(dropped);
            final List<HistoryEntry> d = dropped;
            write(() -> {
                purgeAdds(d);
                repo.deleteHistory(drop);
            });
        }
        final HistoryEntry e = new HistoryEntry();
        e.ts = now();
        e.label = label;
        e.json = json;
        hist.add(e);
        write(() -> e.seq = repo.addHistory(project.id, e));
        while (hist.size() > maxHistory) {
            final HistoryEntry old = hist.remove(0);
            write(() -> {
                repo.deleteHistory(java.util.Collections.singletonList(old.seq));
            });
        }
    }

    /** Features that only exist because of an undone "add" can never come back: remove them for good. */
    @SuppressWarnings("unchecked")
    private void purgeAdds(List<HistoryEntry> es) {
        for (HistoryEntry e : es) {
            Object o = MiniJson.parse(e.json);
            if (!(o instanceof List)) continue;
            for (Object x : (List<Object>) o) {
                Map<String, Object> m = (Map<String, Object>) x;
                String op = MiniJson.str(m, "op", "");
                if (op.equals("addF")) {
                    List<String> ids = new ArrayList<>();
                    for (Object id : (List<Object>) m.get("ids")) ids.add(String.valueOf(id));
                    repo.purgeFeatures(ids);
                } else if (op.equals("addL")) {
                    repo.purgeLayer(MiniJson.str(m, "layer", ""));
                }
            }
        }
    }

    public boolean canUndo() {
        for (int i = hist.size() - 1; i >= 0; i--) if (!hist.get(i).undone) return true;
        return false;
    }

    public boolean canRedo() {
        for (HistoryEntry e : hist) if (e.undone) return true;
        return false;
    }

    public String undoLabel() {
        for (int i = hist.size() - 1; i >= 0; i--) if (!hist.get(i).undone) return hist.get(i).label;
        return null;
    }

    public String redoLabel() {
        for (HistoryEntry e : hist) if (e.undone) return e.label;
        return null;
    }

    public List<HistoryEntry> history() {
        return hist;
    }

    public String undo() {
        for (int i = hist.size() - 1; i >= 0; i--) {
            HistoryEntry e = hist.get(i);
            if (e.undone) continue;
            apply(e, true);
            e.undone = true;
            final HistoryEntry fe = e;
            write(() -> repo.setHistoryUndone(fe.seq, true));
            fire();
            return e.label;
        }
        return null;
    }

    public String redo() {
        for (HistoryEntry e : hist) {
            if (!e.undone) continue;
            apply(e, false);
            e.undone = false;
            final HistoryEntry fe = e;
            write(() -> repo.setHistoryUndone(fe.seq, false));
            fire();
            return e.label;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private void apply(HistoryEntry e, boolean undo) {
        List<Object> ops = (List<Object>) MiniJson.parse(e.json);
        if (undo) {
            for (int i = ops.size() - 1; i >= 0; i--) applyOp((Map<String, Object>) ops.get(i), true);
        } else {
            for (Object o : ops) applyOp((Map<String, Object>) o, false);
        }
    }

    @SuppressWarnings("unchecked")
    private void applyOp(Map<String, Object> m, boolean undo) {
        String op = MiniJson.str(m, "op", "");
        String layerId = MiniJson.str(m, "layer", "");
        switch (op) {
            case "addF":
            case "delF": {
                boolean add = op.equals("addF") != undo;   // true: make features present
                List<String> ids = new ArrayList<>();
                for (Object id : (List<Object>) m.get("ids")) ids.add(String.valueOf(id));
                if (add) restoreFeatures(layerId, ids, m);
                else removeFeatures(layerId, ids);
                break;
            }
            case "updF": {
                Map<String, Object> snap = (Map<String, Object>) m.get(undo ? "before" : "after");
                Feature f = FeatureJson.fromJson(snap);
                replaceFeature(layerId, f);
                break;
            }
            case "addL":
            case "delL": {
                boolean add = op.equals("addL") != undo;
                if (add) restoreLayer(layerId, m); else removeLayer(layerId);
                break;
            }
            case "styleL": {
                Map<String, Object> snap = (Map<String, Object>) m.get(undo ? "before" : "after");
                LayerData src = FeatureJson.layerFrom(snap);
                LayerData l = layer(layerId);
                if (l != null) {
                    copyStyle(src, l);
                    final LayerData fl = l;
                    write(() -> repo.saveLayerMeta(project.id, fl));
                }
                break;
            }
            default:
                break;
        }
    }

    // ---------------------------------------------------------------- low-level model changes (no history)

    private void removeFeatures(String layerId, List<String> ids) {
        LayerData l = layer(layerId);
        if (l == null) return;
        java.util.Set<String> set = new java.util.HashSet<>(ids);
        l.features.removeIf(f -> set.contains(f.id));
        for (String id : ids) {
            byId.remove(id);
            layerOf.remove(id);
        }
        write(() -> repo.setFeaturesDeleted(ids, true));
    }

    @SuppressWarnings("unchecked")
    private void restoreFeatures(String layerId, List<String> ids, Map<String, Object> m) {
        LayerData l = layer(layerId);
        if (l == null) return;
        flush();
        List<Feature> back = new ArrayList<>();
        for (String id : ids) {
            Feature f = repo.getFeatureAny(id);
            if (f == null) continue;
            back.add(f);
        }
        for (Feature f : back) {
            l.features.add(f);
            byId.put(f.id, f);
            layerOf.put(f.id, l);
        }
        write(() -> repo.setFeaturesDeleted(ids, false));
    }

    private void replaceFeature(String layerId, Feature f) {
        LayerData l = layer(layerId);
        if (l == null) return;
        for (int i = 0; i < l.features.size(); i++) {
            if (l.features.get(i).id.equals(f.id)) {
                l.features.set(i, f);
                break;
            }
        }
        byId.put(f.id, f);
        layerOf.put(f.id, l);
        final Feature c = f.copy();
        write(() -> repo.saveFeatures(layerId, java.util.Collections.singletonList(c)));
    }

    private void removeLayer(String layerId) {
        LayerData l = layer(layerId);
        if (l == null) return;
        layers.remove(l);
        for (Feature f : l.features) {
            byId.remove(f.id);
            layerOf.remove(f.id);
        }
        write(() -> repo.setLayerDeleted(layerId, true));
    }

    private void restoreLayer(String layerId, Map<String, Object> m) {
        if (layer(layerId) != null) return;
        write(() -> repo.setLayerDeleted(layerId, false));
        flush();
        LayerData l = repo.loadLayer(layerId);
        if (l == null) return;
        l.projectId = project.id;
        layers.add(l);
        layers.sort((a, b) -> Integer.compare(a.order, b.order));
        for (Feature f : l.features) {
            byId.put(f.id, f);
            layerOf.put(f.id, l);
        }
    }

    private static void copyStyle(LayerData s, LayerData d) {
        d.label = s.label;
        d.color = s.color;
        d.width = s.width;
        d.opacity = s.opacity;
        d.order = s.order;
        d.visible = s.visible;
    }

    // ---------------------------------------------------------------- public edits (each is one undo step)

    private static String idsJson(String op, String layer, List<String> ids) {
        StringBuilder b = new StringBuilder("{\"op\":\"").append(op).append("\",\"layer\":");
        MiniJson.quote(layer, b);
        b.append(",\"ids\":[");
        for (int i = 0; i < ids.size(); i++) {
            if (i > 0) b.append(',');
            MiniJson.quote(ids.get(i), b);
        }
        return b.append("]}").toString();
    }

    /** Creates an empty layer. */
    public LayerData addLayer(String label, int geom, String kind) {
        LayerData l = new LayerData(Feature.newId(), label, geom);
        l.kind = kind;
        l.projectId = project.id;
        l.order = layers.isEmpty() ? 0 : layers.get(layers.size() - 1).order + 1;
        layers.add(l);
        final LayerData c = l;
        write(() -> repo.saveLayerMeta(project.id, c));
        record("+ " + label, "[{\"op\":\"addL\",\"layer\":" + MiniJson.quote(l.id) + "}]");
        fire();
        return l;
    }

    /** Adds a ready-made layer (import, download). The features get new ids if they clash with existing ones. */
    public LayerData addLayerWithFeatures(LayerData src) {
        LayerData l = new LayerData(src.id == null || src.id.isEmpty() || layer(src.id) != null ? Feature.newId() : src.id, src.label, src.geom);
        copyStyle(src, l);
        l.kind = src.kind;
        l.source = src.source;
        l.sourceDate = src.sourceDate;
        l.accuracyNote = src.accuracyNote;
        l.official = src.official;
        l.projectId = project.id;
        l.order = layers.isEmpty() ? 0 : layers.get(layers.size() - 1).order + 1;
        for (Feature f : src.features) {
            if (f.id == null || f.id.isEmpty() || byId.containsKey(f.id)) f.id = Feature.newId();
            l.features.add(f);
            byId.put(f.id, f);
            layerOf.put(f.id, l);
        }
        layers.add(l);
        final LayerData c = l;
        final List<Feature> fs = new ArrayList<>(l.features);
        write(() -> {
            repo.saveLayerMeta(project.id, c);
            repo.saveFeatures(c.id, fs);
        });
        record("+ " + l.label, "[{\"op\":\"addL\",\"layer\":" + MiniJson.quote(l.id) + "}]");
        fire();
        return l;
    }

    public void renameLayer(String layerId, String label) {
        updateLayerStyle(layerId, l -> l.label = label, "rename");
    }

    public void updateLayerStyle(String layerId, java.util.function.Consumer<LayerData> change, String label) {
        LayerData l = layer(layerId);
        if (l == null) return;
        String before = FeatureJson.layerJson(l);
        change.accept(l);
        String after = FeatureJson.layerJson(l);
        final LayerData c = l;
        write(() -> repo.saveLayerMeta(project.id, c));
        record(label, "[{\"op\":\"styleL\",\"layer\":" + MiniJson.quote(layerId) + ",\"before\":" + before + ",\"after\":" + after + "}]");
        fire();
    }

    /** Visibility is a view setting: saved but not an undo step. */
    public void setVisible(String layerId, boolean v) {
        LayerData l = layer(layerId);
        if (l == null) return;
        l.visible = v;
        final LayerData c = l;
        write(() -> repo.saveLayerMeta(project.id, c));
        fire();
    }

    public void deleteLayer(String layerId) {
        LayerData l = layer(layerId);
        if (l == null) return;
        removeLayer(layerId);
        record("- " + l.label, "[{\"op\":\"delL\",\"layer\":" + MiniJson.quote(layerId) + "}]");
        fire();
    }

    public void addFeatures(String layerId, List<Feature> fs, String label) {
        LayerData l = layer(layerId);
        if (l == null || fs.isEmpty()) return;
        List<String> ids = new ArrayList<>(fs.size());
        for (Feature f : fs) {
            if (f.id == null || f.id.isEmpty() || byId.containsKey(f.id)) f.id = Feature.newId();
            l.features.add(f);
            byId.put(f.id, f);
            layerOf.put(f.id, l);
            ids.add(f.id);
        }
        final List<Feature> copy = new ArrayList<>(fs.size());
        for (Feature f : fs) copy.add(f.copy());
        write(() -> repo.saveFeatures(layerId, copy));
        record(label, "[" + idsJson("addF", layerId, ids) + "]");
        fire();
    }

    public void addFeature(String layerId, Feature f) {
        addFeatures(layerId, java.util.Collections.singletonList(f), "+ " + (f.name.isEmpty() ? f.type : f.name));
    }

    /** Deletes features of one layer (soft; undo brings them back). */
    public void deleteFeatures(String layerId, List<String> ids, String label) {
        if (ids.isEmpty()) return;
        removeFeatures(layerId, ids);
        record(label, "[" + idsJson("delF", layerId, ids) + "]");
        fire();
    }

    /** Deletes features that may live in different layers as ONE undo step. */
    public void deleteAnywhere(List<String> ids, String label) {
        Map<String, List<String>> per = new java.util.LinkedHashMap<>();
        for (String id : ids) {
            LayerData l = layerOf.get(id);
            if (l == null) continue;
            per.computeIfAbsent(l.id, k -> new ArrayList<>()).add(id);
        }
        if (per.isEmpty()) return;
        StringBuilder b = new StringBuilder("[");
        boolean first = true;
        for (Map.Entry<String, List<String>> e : per.entrySet()) {
            removeFeatures(e.getKey(), e.getValue());
            if (!first) b.append(',');
            first = false;
            b.append(idsJson("delF", e.getKey(), e.getValue()));
        }
        record(label, b.append(']').toString());
        fire();
    }

    /** Replaces the stored feature by the edited one (same id). {@code before} is the snapshot taken before editing. */
    public void updateFeature(Feature before, Feature after, String label) {
        LayerData l = layerOf.get(after.id);
        if (l == null) return;
        replaceFeature(l.id, after);
        record(label, "[{\"op\":\"updF\",\"layer\":" + MiniJson.quote(l.id) + ",\"before\":" + FeatureJson.toJson(before)
                + ",\"after\":" + FeatureJson.toJson(after) + "}]");
        fire();
    }

    /** Replaces several stored features at once as ONE undo step ({@code before} and {@code after} are parallel lists). */
    public void updateFeatures(List<Feature> before, List<Feature> after, String label) {
        if (before.isEmpty() || before.size() != after.size()) return;
        StringBuilder b = new StringBuilder("[");
        boolean first = true;
        for (int i = 0; i < after.size(); i++) {
            Feature nf = after.get(i);
            LayerData l = layerOf.get(nf.id);
            if (l == null) continue;
            replaceFeature(l.id, nf);
            if (!first) b.append(',');
            first = false;
            b.append("{\"op\":\"updF\",\"layer\":").append(MiniJson.quote(l.id)).append(",\"before\":").append(FeatureJson.toJson(before.get(i)))
                    .append(",\"after\":").append(FeatureJson.toJson(nf)).append('}');
        }
        if (first) return;
        record(label, b.append(']').toString());
        fire();
    }

    /** Replaces many features of one layer by edited versions as ONE undo step. before.get(i) and after.get(i) share the id. */
    public void updateFeatures(String layerId, List<Feature> before, List<Feature> after, String label) {
        LayerData l = layer(layerId);
        if (l == null || after.isEmpty() || before.size() != after.size()) return;
        StringBuilder ops = new StringBuilder("[");
        for (int i = 0; i < after.size(); i++) {
            replaceFeature(layerId, after.get(i));
            if (i > 0) ops.append(',');
            ops.append("{\"op\":\"updF\",\"layer\":").append(MiniJson.quote(layerId)).append(",\"before\":")
                    .append(FeatureJson.toJson(before.get(i))).append(",\"after\":").append(FeatureJson.toJson(after.get(i))).append('}');
        }
        record(label, ops.append(']').toString());
        fire();
    }

    /** Moves features to another layer of the same geometry type (copy + delete as one step). */
    public void moveFeatures(List<String> ids, String toLayer, String label) {
        LayerData to = layer(toLayer);
        if (to == null) return;
        List<Feature> moved = new ArrayList<>();
        List<String> del = new ArrayList<>();
        for (String id : ids) {
            Feature f = byId.get(id);
            LayerData from = layerOf.get(id);
            if (f == null || from == null || from == to || f.geom != to.geom) continue;
            del.add(id);
            Feature c = f.copy();
            c.id = Feature.newId();
            moved.add(c);
        }
        if (moved.isEmpty()) return;
        deleteAnywhere(del, label);
        addFeatures(toLayer, moved, label);
    }

    /** Saves the (already modified) feature without creating an undo step (e.g. admin names filled in later). */
    public void saveSilently(Feature f) {
        LayerData l = layerOf.get(f.id);
        if (l == null) return;
        final Feature c = f.copy();
        write(() -> repo.saveFeatures(l.id, java.util.Collections.singletonList(c)));
        fire();
    }

    /** Forgets the undo history (after migration or restore). */
    public void clearHistory() {
        List<Long> seqs = new ArrayList<>();
        for (HistoryEntry e : hist) seqs.add(e.seq);
        hist.clear();
        write(() -> repo.deleteHistory(seqs));
    }

    public List<Feature> search(String text, int limit) {
        flush();
        return repo.search(project.id, text, limit);
    }
}
