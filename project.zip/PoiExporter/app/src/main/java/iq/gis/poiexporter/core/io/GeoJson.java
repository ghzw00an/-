package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LandmarkFields;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.JsonStream;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.MiniJson;
import iq.gis.poiexporter.core.crs.Crs;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** GeoJSON reader (streaming) and writer. */
public final class GeoJson {
    private GeoJson() {
    }

    // ------------------------------------------------------------------ reading

    private static final class Node {
        String type;
        Object coords; // nested List / double[] tree
        List<Node> geoms;
    }

    /** Reads every feature; the layer name passed to the visitor is {@code layerName}. */
    public static void read(File f, String layerName, Visitor v, ReadInfo info) throws IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8), 1 << 16);
        try {
            r.mark(4);
            int c = r.read();
            if (c != 0xFEFF) {
                r.reset();
            }
            JsonStream js = new JsonStream(r);
            Ctx ctx = new Ctx(layerName, v, info);
            if (js.peekIsArray()) {
                // a bare array of features
                js.beginArray();
                while (js.hasNext() && !ctx.stop && !info.cancel) parseObject(js, ctx, false);
            } else {
                parseObject(js, ctx, true);
            }
        } finally {
            r.close();
        }
    }

    private static final class Ctx {
        final String layer;
        final Visitor v;
        final ReadInfo info;
        boolean stop;
        long n;

        Ctx(String layer, Visitor v, ReadInfo info) {
            this.layer = layer;
            this.v = v;
            this.info = info;
        }
    }

    private static void parseObject(JsonStream js, Ctx ctx, boolean top) throws IOException {
        String type = null, id = null;
        Node geom = null;
        Map<String, String> props = null;
        Node own = new Node();
        js.beginObject();
        while (js.hasNext()) {
            String k = js.nextName();
            switch (k) {
                case "type":
                    if (js.peekIsString()) type = js.nextString();
                    else js.skipValue();
                    own.type = type;
                    break;
                case "features":
                    if (!js.peekIsArray()) {
                        js.skipValue();
                        break;
                    }
                    js.beginArray();
                    while (js.hasNext()) {
                        if (ctx.stop || ctx.info.cancel) {
                            js.skipValue();
                            continue;
                        }
                        if (js.peekIsObject()) parseObject(js, ctx, false);
                        else js.skipValue();
                    }
                    break;
                case "geometry":
                    if (js.peekIsNull()) js.skipValue();
                    else geom = readGeometry(js);
                    break;
                case "properties":
                    if (js.peekIsObject()) props = readProps(js);
                    else js.skipValue();
                    break;
                case "id":
                    if (js.peekIsString()) id = js.nextString();
                    else if (js.peekIsNumber()) id = trim(js.nextDouble());
                    else js.skipValue();
                    break;
                case "coordinates":
                    own.coords = readTree(js);
                    break;
                case "geometries":
                    own.geoms = new ArrayList<>();
                    js.beginArray();
                    while (js.hasNext()) own.geoms.add(readGeometry(js));
                    break;
                case "crs":
                    if (top) readCrs(js, ctx.info);
                    else js.skipValue();
                    break;
                default:
                    js.skipValue();
            }
        }
        if ("Feature".equals(type)) {
            emit(ctx, geom, props, id);
        } else if (type != null && !type.equals("FeatureCollection")) {
            emit(ctx, own, null, null); // bare geometry
        }
    }

    private static Node readGeometry(JsonStream js) throws IOException {
        Node n = new Node();
        js.beginObject();
        while (js.hasNext()) {
            String k = js.nextName();
            if (k.equals("type") && js.peekIsString()) n.type = js.nextString();
            else if (k.equals("coordinates")) n.coords = readTree(js);
            else if (k.equals("geometries")) {
                n.geoms = new ArrayList<>();
                js.beginArray();
                while (js.hasNext()) n.geoms.add(readGeometry(js));
            } else js.skipValue();
        }
        return n;
    }

    /** Coordinate tree: positions become double[], everything else List. */
    private static Object readTree(JsonStream js) throws IOException {
        List<Object> list = new ArrayList<>();
        double[] pos = new double[4];
        int np = 0;
        js.beginArray();
        while (js.hasNext()) {
            if (js.peekIsNumber()) {
                if (np == pos.length) pos = java.util.Arrays.copyOf(pos, np * 2);
                pos[np++] = js.nextDouble();
            } else if (js.peekIsArray()) {
                list.add(readTree(js));
            } else {
                js.skipValue();
            }
        }
        if (np > 0 && list.isEmpty()) return java.util.Arrays.copyOf(pos, np);
        return list;
    }

    private static Map<String, String> readProps(JsonStream js) throws IOException {
        Map<String, String> m = new LinkedHashMap<>();
        js.beginObject();
        while (js.hasNext()) {
            String k = js.nextName();
            if (js.peekIsString()) m.put(k, js.nextString());
            else if (js.peekIsNumber()) m.put(k, trim(js.nextDouble()));
            else if (js.peekIsBoolean()) m.put(k, String.valueOf(js.nextBoolean()));
            else if (js.peekIsNull()) js.skipValue();
            else {
                StringBuilder sb = new StringBuilder();
                copyJson(js, sb);
                m.put(k, sb.toString());
            }
        }
        return m;
    }

    private static void copyJson(JsonStream js, StringBuilder sb) throws IOException {
        if (js.peekIsObject()) {
            sb.append('{');
            js.beginObject();
            boolean first = true;
            while (js.hasNext()) {
                if (!first) sb.append(',');
                first = false;
                MiniJson.quote(js.nextName(), sb);
                sb.append(':');
                copyJson(js, sb);
            }
            sb.append('}');
        } else if (js.peekIsArray()) {
            sb.append('[');
            js.beginArray();
            boolean first = true;
            while (js.hasNext()) {
                if (!first) sb.append(',');
                first = false;
                copyJson(js, sb);
            }
            sb.append(']');
        } else if (js.peekIsString()) MiniJson.quote(js.nextString(), sb);
        else if (js.peekIsNumber()) sb.append(trim(js.nextDouble()));
        else if (js.peekIsBoolean()) sb.append(js.nextBoolean());
        else {
            js.skipValue();
            sb.append("null");
        }
    }

    private static final Pattern EPSG = Pattern.compile("(?:EPSG)[:]{1,2}(\\d{3,6})", Pattern.CASE_INSENSITIVE);

    private static void readCrs(JsonStream js, ReadInfo info) throws IOException {
        if (js.peekIsNull() || !js.peekIsObject()) {
            js.skipValue();
            return;
        }
        StringBuilder sb = new StringBuilder();
        copyJson(js, sb);
        String text = sb.toString();
        try {
            Map<String, Object> m = MiniJson.obj(text);
            Object p = m.get("properties");
            String name = "";
            if (p instanceof Map) name = String.valueOf(((Map<?, ?>) p).get("name"));
            if (name.toUpperCase(Locale.ROOT).contains("CRS84")) {
                info.crs = Crs.wgs84();
                return;
            }
            Matcher mt = EPSG.matcher(name);
            if (mt.find()) {
                try {
                    info.crs = Crs.of(Integer.parseInt(mt.group(1)));
                } catch (IllegalArgumentException e) {
                    info.warnings.add(S.t("نظام الإحداثيات المعلن غير معروف: ", "Unknown declared CRS: ") + name);
                }
            } else if (!name.isEmpty() && !name.equals("null")) {
                info.warnings.add(S.t("نظام الإحداثيات المعلن غير معروف: ", "Unknown declared CRS: ") + name);
            }
        } catch (RuntimeException e) {
            // ignore a malformed crs member
        }
    }

    private static String trim(double d) {
        return d == Math.rint(d) && Math.abs(d) < 1e15 ? Long.toString((long) d) : Double.toString(d);
    }

    private static void emit(Ctx ctx, Node g, Map<String, String> props, String id) {
        ctx.n++;
        List<Feature> fs = new ArrayList<>();
        try {
            if (g != null) build(g, fs);
        } catch (RuntimeException e) {
            ctx.info.unreadable++;
            ctx.info.messages.add(S.t("سجل ", "Record ") + ctx.n + ": " + S.t("هندسة غير صالحة", "invalid geometry"));
            return;
        }
        if (fs.isEmpty()) {
            Feature none = new Feature();
            none.geom = 0;
            fs.add(none);
        }
        boolean firstF = true;
        for (Feature f : fs) {
            if (props != null) Mapper.apply(f, props);
            if (id != null && f.id.isEmpty()) f.id = id;
            if (!firstF && f.id.equals(id)) f.id = "";
            firstF = false;
            if (!ctx.v.feature(ctx.layer, f)) ctx.stop = true;
        }
    }

    private static void build(Node g, List<Feature> out) {
        if (g.type == null) return;
        switch (g.type) {
            case "Point": {
                double[] p = (double[]) g.coords;
                if (p == null || p.length < 2) return;
                out.add(pt(p));
                break;
            }
            case "MultiPoint":
                for (Object o : list(g.coords)) if (o instanceof double[] && ((double[]) o).length >= 2) out.add(pt((double[]) o));
                break;
            case "LineString": {
                Feature f = new Feature();
                f.geom = Feature.LINE;
                f.addPart(flat(g.coords), false);
                out.add(f);
                break;
            }
            case "MultiLineString": {
                Feature f = new Feature();
                f.geom = Feature.LINE;
                for (Object o : list(g.coords)) f.addPart(flat(o), false);
                out.add(f);
                break;
            }
            case "Polygon": {
                Feature f = new Feature();
                f.geom = Feature.POLYGON;
                polygon(g.coords, f);
                out.add(f);
                break;
            }
            case "MultiPolygon": {
                Feature f = new Feature();
                f.geom = Feature.POLYGON;
                for (Object o : list(g.coords)) polygon(o, f);
                out.add(f);
                break;
            }
            case "GeometryCollection":
                if (g.geoms != null) for (Node n : g.geoms) build(n, out);
                break;
            default:
                throw new IllegalArgumentException("type " + g.type);
        }
    }

    @SuppressWarnings("unchecked")
    private static List<Object> list(Object o) {
        if (o instanceof List) return (List<Object>) o;
        return new ArrayList<>();
    }

    private static Feature pt(double[] p) {
        Feature f = new Feature();
        f.geom = Feature.POINT;
        f.parts.add(new double[]{p[0], p[1]});
        f.holes.add(Boolean.FALSE);
        f.lon = p[0];
        f.lat = p[1];
        return f;
    }

    private static double[] flat(Object ring) {
        List<Object> l = list(ring);
        double[] r = new double[l.size() * 2];
        int n = 0;
        for (Object o : l) {
            if (o instanceof double[] && ((double[]) o).length >= 2) {
                r[n++] = ((double[]) o)[0];
                r[n++] = ((double[]) o)[1];
            }
        }
        return java.util.Arrays.copyOf(r, n);
    }

    private static void polygon(Object rings, Feature f) {
        List<Object> l = list(rings);
        for (int i = 0; i < l.size(); i++) {
            double[] r = flat(l.get(i));
            if (r.length < 6) continue;
            boolean hole = i > 0;
            f.addPart(close(r), hole);
        }
    }

    static double[] close(double[] r) {
        int n = r.length;
        if (n >= 2 && (r[0] != r[n - 2] || r[1] != r[n - 1])) {
            r = java.util.Arrays.copyOf(r, n + 2);
            r[n] = r[0];
            r[n + 1] = r[1];
        }
        return r;
    }

    // ------------------------------------------------------------------ writing

    /**
     * Writes one FeatureCollection with all features of all layers. Coordinates are reprojected to the target CRS
     * (RFC 7946 requires WGS84, so for any other CRS a legacy "crs" member is added; modern readers may ignore it).
     */
    public static void write(List<LayerData> layers, ExportOptions o, OutputStream os) throws IOException {
        Writer w = new BufferedWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8), 1 << 16);
        Crs target = o.target();
        Crs.Tx tx = target.epsg == 4326 ? null : Crs.wgs84().to(target);
        w.write("{\"type\":\"FeatureCollection\"");
        if (target.epsg != 4326)
            w.write(",\"crs\":{\"type\":\"name\",\"properties\":{\"name\":\"urn:ogc:def:crs:EPSG::" + target.epsg + "\"}}");
        w.write(",\"features\":[\n");
        boolean first = true;
        int dec = target.geographic ? 9 : 3;
        double[] tmp = new double[2];
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                if (f.parts.isEmpty()) continue;
                StringBuilder sb = new StringBuilder(256);
                if (!first) sb.append(",\n");
                first = false;
                sb.append("{\"type\":\"Feature\",");
                if (!f.id.isEmpty()) {
                    sb.append("\"id\":");
                    MiniJson.quote(f.id, sb);
                    sb.append(',');
                }
                sb.append("\"geometry\":");
                geometry(sb, f, tx, dec, tmp);
                sb.append(",\"properties\":{");
                if (o.attributes) props(sb, f, l);
                sb.append("}}");
                w.write(sb.toString());
            }
        }
        w.write("\n]}\n");
        w.flush();
    }

    static void props(StringBuilder sb, Feature f, LayerData l) {
        boolean[] first = {true};
        String[] t = LandmarkFields.text(f);
        for (int i = 0; i < t.length; i++) putAlways(sb, first, LandmarkFields.NAMES[i], t[i]);
        double[] xy = LandmarkFields.xy(f, null);
        for (int i = 0; i < 2; i++) {
            if (!first[0]) sb.append(',');
            first[0] = false;
            sb.append('"').append(LandmarkFields.NAMES[6 + i]).append("\":").append(Double.isNaN(xy[i]) ? "null" : LandmarkFields.num(xy[i], 2));
        }
        putAlways(sb, first, "link", LandmarkFields.link(f));
        for (Map.Entry<String, String> e : f.attrs.entrySet()) if (!LandmarkFields.isStd(e.getKey())) put(sb, first, e.getKey(), e.getValue());
    }

    private static void putAlways(StringBuilder sb, boolean[] first, String k, String v) {
        if (!first[0]) sb.append(',');
        first[0] = false;
        MiniJson.quote(k, sb);
        sb.append(':');
        MiniJson.quote(v == null ? "" : v, sb);
    }

    private static void put(StringBuilder sb, boolean[] first, String k, String v) {
        if (v == null || v.isEmpty()) return;
        if (!first[0]) sb.append(',');
        first[0] = false;
        MiniJson.quote(k, sb);
        sb.append(':');
        MiniJson.quote(v, sb);
    }

    private static void num(StringBuilder sb, double v, int dec) {
        if (dec == 9 || dec == 3) {
            String s = String.format(Locale.US, "%." + dec + "f", v);
            int e = s.length();
            while (e > 0 && s.charAt(e - 1) == '0') e--;
            if (e > 0 && s.charAt(e - 1) == '.') e--;
            sb.append(s, 0, e);
        } else sb.append(v);
    }

    private static void ring(StringBuilder sb, double[] p, Crs.Tx tx, int dec, double[] tmp) {
        sb.append('[');
        for (int i = 0; i + 1 < p.length; i += 2) {
            if (i > 0) sb.append(',');
            double x = p[i], y = p[i + 1];
            if (tx != null) {
                tx.apply(x, y, tmp);
                x = tmp[0];
                y = tmp[1];
            }
            sb.append('[');
            num(sb, x, dec);
            sb.append(',');
            num(sb, y, dec);
            sb.append(']');
        }
        sb.append(']');
    }

    private static void geometry(StringBuilder sb, Feature f, Crs.Tx tx, int dec, double[] tmp) {
        if (f.geom == Feature.POINT) {
            sb.append("{\"type\":\"Point\",\"coordinates\":");
            double[] p = f.parts.get(0);
            ring(sb, p, tx, dec, tmp);
            sb.setLength(sb.length() - 1); // drop ']' of ring wrapper -> need position, rebuild properly
            // ring() wrote [[x,y]]; convert to [x,y]
            String s = sb.toString();
            int cut = s.lastIndexOf("\"coordinates\":") + 14;
            String coords = s.substring(cut); // "[[x,y]"
            sb.setLength(cut);
            sb.append(coords.substring(1)).append('}');
            return;
        }
        if (f.geom == Feature.LINE) {
            boolean multi = f.parts.size() > 1;
            sb.append("{\"type\":\"").append(multi ? "MultiLineString" : "LineString").append("\",\"coordinates\":");
            if (multi) {
                sb.append('[');
                for (int i = 0; i < f.parts.size(); i++) {
                    if (i > 0) sb.append(',');
                    ring(sb, f.parts.get(i), tx, dec, tmp);
                }
                sb.append(']');
            } else {
                ring(sb, f.parts.get(0), tx, dec, tmp);
            }
            sb.append('}');
            return;
        }
        // polygon: group holes under the outer ring that contains them (RFC 7946: outer CCW, holes CW)
        List<double[]> outers = new ArrayList<>();
        List<List<double[]>> holes = new ArrayList<>();
        for (int i = 0; i < f.parts.size(); i++) {
            if (!f.isHole(i)) {
                outers.add(f.parts.get(i));
                holes.add(new ArrayList<double[]>());
            }
        }
        for (int i = 0; i < f.parts.size(); i++) {
            if (!f.isHole(i)) continue;
            double[] h = f.parts.get(i);
            int best = -1;
            double bestArea = Double.MAX_VALUE;
            for (int k = 0; k < outers.size(); k++) {
                if (Geo.pointInRing(h[0], h[1], outers.get(k))) {
                    double a = Math.abs(Geo.signedArea(outers.get(k)));
                    if (a < bestArea) {
                        bestArea = a;
                        best = k;
                    }
                }
            }
            if (best < 0 && !outers.isEmpty()) best = 0;
            if (best >= 0) holes.get(best).add(h);
        }
        boolean multi = outers.size() > 1;
        sb.append("{\"type\":\"").append(multi ? "MultiPolygon" : "Polygon").append("\",\"coordinates\":");
        if (multi) sb.append('[');
        for (int k = 0; k < outers.size(); k++) {
            if (k > 0) sb.append(',');
            sb.append('[');
            ring(sb, Geo.oriented(close(outers.get(k)), false), tx, dec, tmp);
            for (double[] h : holes.get(k)) {
                sb.append(',');
                ring(sb, Geo.oriented(close(h), true), tx, dec, tmp);
            }
            sb.append(']');
        }
        if (multi) sb.append(']');
        sb.append('}');
    }
}
