package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.Projection;
import org.osmdroid.views.overlay.Overlay;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;

/** Fast Canvas drawing of downloaded layers, with bbox culling and pixel decimation. */
public final class FeatureOverlay extends Overlay {
    public interface Tap {
        void onFeature(Feature f, LayerData layer);
    }

    private static final class Item {
        final Feature f;
        final LayerData layer;
        final double[] bb; // minLon,minLat,maxLon,maxLat

        Item(Feature f, LayerData l) {
            this.f = f;
            this.layer = l;
            this.bb = f.geom == Feature.POINT ? new double[]{f.lon, f.lat, f.lon, f.lat} : Geo.bbox(f);
        }
    }

    private final List<Item> items = new ArrayList<>();
    private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG), ln = new Paint(Paint.ANTI_ALIAS_FLAG),
            fill = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Point p1 = new Point();
    private Tap tap;
    private final java.util.Set<LayerData> hidden = new java.util.HashSet<>();
    private float density = 2f;
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG), halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<float[]> lpos = new ArrayList<>();
    private final List<String> ltxt = new ArrayList<>();
    private final List<Integer> lcol = new ArrayList<>();
    private final android.graphics.RectF rc = new android.graphics.RectF();
    private final List<android.graphics.RectF> used = new ArrayList<>();
    /** 0 = off, 1 = automatic (zoom 14+), 2 = from zoom 10. */
    public int labelMode = 1;
    /** Text size factor of the name labels (1 = 12 sp). */
    public float labelScale = 1.2f;
    /** Features without a name show their type (mosque, school…) instead of nothing. */
    public boolean typeFallback = true;

    private String labelOf(Feature f) {
        if (f.name != null && !f.name.isEmpty()) return f.name;
        return typeFallback && f.type != null ? f.type : "";
    }
    /** White labels with a dark halo: readable on satellite and hybrid maps. */
    public boolean lightLabels;
    /** Points take the colour of their sector (Gategory); a legend of the sectors in view is drawn. */
    public boolean colorBySector;
    private final boolean[] sectorSeen = new boolean[iq.gis.poiexporter.core.SectorColors.count()];
    private final Paint legendBg = new Paint(Paint.ANTI_ALIAS_FLAG), legendTx = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Feature flashFeature;
    private long flashStart;
    private static final long FLASH_MS = 2600;

    public FeatureOverlay() {
        ln.setStyle(Paint.Style.STROKE);
        ln.setStrokeJoin(Paint.Join.ROUND);
        ln.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(Color.WHITE);
        ring.setStrokeWidth(2f);
        txt.setStyle(Paint.Style.FILL);
        txt.setFakeBoldText(true);
        halo.setStyle(Paint.Style.STROKE);
        halo.setStrokeJoin(Paint.Join.ROUND);
        halo.setColor(Color.WHITE);
    }

    public void setTap(Tap t) {
        tap = t;
    }

    public void setData(List<LayerData> layers, float density) {
        this.density = density;
        items.clear();
        if (layers != null) {
            for (LayerData l : layers) for (Feature f : l.features) items.add(new Item(f, l));
        }
    }

    public void setHidden(LayerData l, boolean h) {
        if (h) hidden.add(l);
        else hidden.remove(l);
    }

    public boolean isHidden(LayerData l) {
        return hidden.contains(l);
    }

    public static double[] boundsOf(LayerData l) {
        double[] r = null;
        for (Feature f : l.features) {
            double[] b = f.geom == Feature.POINT ? new double[]{f.lon, f.lat, f.lon, f.lat} : Geo.bbox(f);
            if (r == null) r = b.clone();
            else {
                r[0] = Math.min(r[0], b[0]);
                r[1] = Math.min(r[1], b[1]);
                r[2] = Math.max(r[2], b[2]);
                r[3] = Math.max(r[3], b[3]);
            }
        }
        return r;
    }

    public int count() {
        return items.size();
    }

    /** minLon,minLat,maxLon,maxLat of all data or null. */
    public double[] bounds() {
        double[] r = null;
        for (Item it : items) {
            double[] b = it.bb;
            if (b == null) continue;
            if (r == null) r = b.clone();
            else {
                r[0] = Math.min(r[0], b[0]);
                r[1] = Math.min(r[1], b[1]);
                r[2] = Math.max(r[2], b[2]);
                r[3] = Math.max(r[3], b[3]);
            }
        }
        return r;
    }

    static int colorFor(String id) {
        switch (id) {
            case "roads_main": return Color.parseColor("#E8590C");
            case "roads_secondary": return Color.parseColor("#F59F00");
            case "rivers": return Color.parseColor("#1C7ED6");
            case "lakes": return Color.parseColor("#4DABF7");
            case "dams": return Color.parseColor("#7048E8");
            case "manual": return Color.parseColor("#FF8F00");
            case "tourism": return Color.parseColor("#D6336C");
            case "admin_gov": return Color.parseColor("#C2255C");
            case "admin_qadaa": return Color.parseColor("#9C36B5");
            case "admin_nahiya": return Color.parseColor("#2F9E44");
            default: return Color.parseColor("#0CA678");
        }
    }

    @Override
    public void draw(Canvas c, MapView map, boolean shadow) {
        if (shadow || items.isEmpty()) return;
        Projection pj = map.getProjection();
        org.osmdroid.util.BoundingBox vb = pj.getBoundingBox();
        double minLat = vb.getLatSouth(), maxLat = vb.getLatNorth(), minLon = vb.getLonWest(), maxLon = vb.getLonEast();
        float d = density;
        int visiblePts = 0;
        GeoPoint gp = new GeoPoint(0.0, 0.0);
        double zoom = map.getZoomLevelDouble();
        lpos.clear();
        ltxt.clear();
        lcol.clear();
        java.util.Arrays.fill(sectorSeen, false);
        for (Item it : items) {
            double[] b = it.bb;
            if (hidden.contains(it.layer)) continue;
            if (b == null || b[2] < minLon || b[0] > maxLon || b[3] < minLat || b[1] > maxLat) continue;
            Feature f = it.f;
            int col = it.layer.color != 0 ? it.layer.color | 0xFF000000 : colorFor(it.layer.id);
            int alpha = Math.max(20, Math.min(255, Math.round(255 * it.layer.opacity)));
            float wmul = it.layer.width > 0 ? it.layer.width / 2f : 1f;
            if (f.geom == Feature.POINT) {
                gp.setCoords(f.lat, f.lon);
                pj.toPixels(gp, p1);
                if (colorBySector) {
                    int si = iq.gis.poiexporter.core.SectorColors.indexOf(f.category);
                    if (si >= 0) {
                        col = iq.gis.poiexporter.core.SectorColors.colorAt(si);
                        sectorSeen[si] = true;
                    }
                }
                pt.setColor((col & 0x00FFFFFF) | (alpha << 24));
                if (++visiblePts > 4000) {
                    c.drawCircle(p1.x, p1.y, 2f * d, pt);
                } else {
                    c.drawCircle(p1.x, p1.y, 5f * d, ring);
                    c.drawCircle(p1.x, p1.y, 5f * d, pt);
                    if (labelMode > 0 && (zoom >= (labelMode == 2 ? 10 : 14) || (zoom >= 11 && it.layer.id.equals("manual"))) && !labelOf(f).isEmpty() && lpos.size() < 500) {
                        lpos.add(new float[]{p1.x + 8f * d, p1.y + 4f * d, 0});
                        ltxt.add(labelOf(f));
                        lcol.add(col);
                    }
                }
                continue;
            }
            path.rewind();
            float minStep = 1.5f * d;
            for (int pi = 0; pi < f.parts.size(); pi++) {
                double[] a = f.parts.get(pi);
                int n = a.length / 2;
                float lx = 0, ly = 0;
                boolean first = true;
                for (int i = 0; i < n; i++) {
                    gp.setCoords(a[2 * i + 1], a[2 * i]);
                    pj.toPixels(gp, p1);
                    boolean last = i == n - 1;
                    if (!first && !last && Math.abs(p1.x - lx) < minStep && Math.abs(p1.y - ly) < minStep) continue;
                    if (first) path.moveTo(p1.x, p1.y);
                    else path.lineTo(p1.x, p1.y);
                    lx = p1.x;
                    ly = p1.y;
                    first = false;
                }
                if (f.geom == Feature.POLYGON) path.close();
            }
            if (f.geom == Feature.POLYGON) {
                boolean admin = it.layer.id.startsWith("admin_");
                path.setFillType(Path.FillType.EVEN_ODD);
                if (!admin) {
                    fill.setColor((col & 0x00FFFFFF) | (Math.min(alpha, 0x33) << 24));
                    c.drawPath(path, fill);
                }
                ln.setStrokeWidth((admin ? 3.5f : 2f) * wmul * d);
            } else {
                ln.setStrokeWidth((it.layer.id.equals("roads_main") ? 3.2f : 2f) * wmul * d);
            }
            ln.setColor((col & 0x00FFFFFF) | (alpha << 24));
            c.drawPath(path, ln);
            if (labelMode > 0 && zoom >= (labelMode == 2 ? 11 : 15) && !labelOf(f).isEmpty() && lpos.size() < 500) {
                gp.setCoords(f.lat, f.lon);
                pj.toPixels(gp, p1);
                lpos.add(new float[]{p1.x, p1.y, 1});
                ltxt.add(labelOf(f));
                lcol.add(col);
            }
        }
        drawLabels(c);
        if (colorBySector) drawLegend(c, map);
        drawFlash(c, map);
    }

    /** Small key of the sectors that have a point on screen, bottom-left above the toolbar. */
    private void drawLegend(Canvas c, MapView map) {
        int n = 0;
        for (boolean b : sectorSeen) if (b) n++;
        if (n == 0) return;
        float d = density;
        legendTx.setTextSize(11.5f * d);
        legendTx.setColor(Color.WHITE);
        float rowH = 17f * d, w = 0;
        for (int i = 0; i < sectorSeen.length; i++) {
            if (!sectorSeen[i]) continue;
            w = Math.max(w, legendTx.measureText(sectorShort(i)));
        }
        float boxW = w + 34f * d, boxH = n * rowH + 12f * d;
        float x = 8f * d, y = map.getHeight() - 84f * d - boxH;
        legendBg.setColor(0xB3000000);
        rc.set(x, y, x + boxW, y + boxH);
        c.drawRoundRect(rc, 10f * d, 10f * d, legendBg);
        float yy = y + 6f * d + rowH * 0.75f;
        for (int i = 0; i < sectorSeen.length; i++) {
            if (!sectorSeen[i]) continue;
            pt.setColor(iq.gis.poiexporter.core.SectorColors.colorAt(i));
            c.drawCircle(x + 12f * d, yy - 4f * d, 5f * d, pt);
            c.drawText(sectorShort(i), x + 24f * d, yy, legendTx);
            yy += rowH;
        }
    }

    private static String sectorShort(int i) {
        return iq.gis.poiexporter.core.Sectors.ALL[i].name.replace("القطاع ", "").replace("قطاع ", "");
    }

    /** Pulses a ring on a point, or blinks the outline of a line/polygon, for about 2.6 seconds so the eye finds it. */
    public void flash(Feature f, MapView map) {
        flashFeature = f;
        flashStart = android.os.SystemClock.uptimeMillis();
        map.postInvalidateOnAnimation();
    }

    private void drawFlash(Canvas c, MapView map) {
        if (flashFeature == null) return;
        long t = android.os.SystemClock.uptimeMillis() - flashStart;
        if (t > FLASH_MS) {
            flashFeature = null;
            return;
        }
        Projection pj = map.getProjection();
        float d = density;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        float phase = (t % 650) / 650f;
        Feature f = flashFeature;
        if (f.geom == Feature.POINT) {
            Point q = new Point();
            pj.toPixels(new GeoPoint(f.lat, f.lon), q);
            for (int k = 0; k < 2; k++) {
                float ph = (phase + k * 0.5f) % 1f;
                p.setColor(((int) (255 * (1 - ph)) << 24) | 0xFFC107);
                p.setStrokeWidth(4f * d);
                c.drawCircle(q.x, q.y, (10 + 46 * ph) * d, p);
            }
            p.setColor(0xFFFFC107);
            p.setStrokeWidth(3f * d);
            c.drawCircle(q.x, q.y, 9f * d, p);
        } else if (((t / 260) & 1) == 0) {
            Path pa = new Path();
            Point q = new Point();
            for (double[] part : f.parts) {
                for (int i = 0; i + 1 < part.length; i += 2) {
                    pj.toPixels(new GeoPoint(part[i + 1], part[i]), q);
                    if (i == 0) pa.moveTo(q.x, q.y);
                    else pa.lineTo(q.x, q.y);
                }
                if (f.geom == Feature.POLYGON) pa.close();
            }
            p.setColor(0xFFFFC107);
            p.setStrokeWidth(6f * d);
            p.setStrokeJoin(Paint.Join.ROUND);
            c.drawPath(pa, p);
        }
        map.postInvalidateOnAnimation();
    }

    private void drawLabels(Canvas c) {
        if (lpos.isEmpty()) return;
        float d = density;
        float ls = Math.max(0.8f, Math.min(2f, labelScale));
        txt.setTextSize(12f * d * ls);
        halo.setTextSize(12f * d * ls);
        halo.setStrokeWidth(3f * d * ls);
        used.clear();
        int w = c.getWidth(), h = c.getHeight();
        for (int i = 0; i < lpos.size(); i++) {
            float[] p = lpos.get(i);
            String t = ltxt.get(i);
            float tw = txt.measureText(t);
            float x = p[2] == 1 ? p[0] - tw / 2 : p[0], y = p[1];
            if (x > w || x + tw < 0 || y < 0 || y - 14 * d > h) continue;
            rc.set(x - 2 * d, y - 12 * d * ls, x + tw + 2 * d, y + 4 * d * ls);
            boolean clash = false;
            for (android.graphics.RectF u : used) {
                if (android.graphics.RectF.intersects(u, rc)) {
                    clash = true;
                    break;
                }
            }
            if (clash) continue;
            used.add(new android.graphics.RectF(rc));
            txt.setColor(lightLabels ? Color.WHITE : Color.parseColor("#102030"));
            halo.setColor(lightLabels ? Color.parseColor("#CC000000") : Color.WHITE);
            c.drawText(t, x, y, halo);
            c.drawText(t, x, y, txt);
        }
    }

    private static double segDist(double px, double py, double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay;
        double len2 = dx * dx + dy * dy;
        double t = len2 == 0 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / len2));
        return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
    }

    @Override
    public boolean onSingleTapConfirmed(android.view.MotionEvent e, MapView map) {
        if (tap == null || items.isEmpty()) return false;
        Projection pj = map.getProjection();
        float tolPx = 26 * density;
        org.osmdroid.api.IGeoPoint g = pj.fromPixels((int) e.getX(), (int) e.getY());
        org.osmdroid.api.IGeoPoint gx = pj.fromPixels((int) (e.getX() + tolPx), (int) e.getY());
        org.osmdroid.api.IGeoPoint gy = pj.fromPixels((int) e.getX(), (int) (e.getY() + tolPx));
        double mLat = 1.6 * Math.max(Math.abs(gx.getLatitude() - g.getLatitude()), Math.abs(gy.getLatitude() - g.getLatitude()));
        double mLon = 1.6 * Math.max(Math.abs(gx.getLongitude() - g.getLongitude()), Math.abs(gy.getLongitude() - g.getLongitude()));
        double best = tolPx;
        Item hit = null;
        Point p = new Point();
        GeoPoint gp = new GeoPoint(0.0, 0.0);
        for (Item it : items) {
            if (hidden.contains(it.layer)) continue;
            double[] b = it.bb;
            if (b == null || g.getLongitude() < b[0] - mLon || g.getLongitude() > b[2] + mLon
                    || g.getLatitude() < b[1] - mLat || g.getLatitude() > b[3] + mLat) continue;
            Feature f = it.f;
            double d = Double.MAX_VALUE;
            if (f.geom == Feature.POINT) {
                gp.setCoords(f.lat, f.lon);
                pj.toPixels(gp, p);
                d = Math.hypot(p.x - e.getX(), p.y - e.getY());
            } else {
                for (double[] a : f.parts) {
                    int n = a.length / 2;
                    float lx = 0, ly = 0;
                    int cnt = Math.max(1, n / 2000 + 1); // thin out huge geometries
                    for (int i = 0; i < n; i += cnt) {
                        gp.setCoords(a[2 * i + 1], a[2 * i]);
                        pj.toPixels(gp, p);
                        if (i > 0) d = Math.min(d, segDist(e.getX(), e.getY(), lx, ly, p.x, p.y));
                        else d = Math.min(d, Math.hypot(p.x - e.getX(), p.y - e.getY()));
                        lx = p.x;
                        ly = p.y;
                    }
                }
                if (f.geom == Feature.POLYGON && d >= tolPx * 0.95 && Geo.inPolygon(f, g.getLongitude(), g.getLatitude())) d = tolPx * 0.95;
            }
            if (d < best) {
                best = d;
                hit = it;
            }
        }
        if (hit == null) return false;
        tap.onFeature(hit.f, hit.layer);
        return true;
    }
}
