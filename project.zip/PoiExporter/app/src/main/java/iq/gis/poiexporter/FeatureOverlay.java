package iq.gis.poiexporter;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.Projection;
import org.osmdroid.views.overlay.Overlay;

import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;

/** Fast Canvas drawing of downloaded layers, with bbox culling and pixel decimation. */
public final class FeatureOverlay extends Overlay {
    public interface Tap {
        void onFeature(Feature f, String layer);
    }

    private static final class Item {
        final Feature f;
        final LayerData layer;
        final double[] bb; // minLon,minLat,maxLon,maxLat

        Item(Feature f, LayerData l) {
            this.f = f;
            this.layer = l;
            this.bb = f.geom == Feature.POINT ? new double[]{f.lon, f.lat, f.lon, f.lat} : Geo.bbox(f);
        }
    }

    private final List<Item> items = new ArrayList<>();
    private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG), ln = new Paint(Paint.ANTI_ALIAS_FLAG),
            fill = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Point p1 = new Point();
    private Tap tap;
    private float density = 2f;
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG), halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<float[]> lpos = new ArrayList<>();
    private final List<String> ltxt = new ArrayList<>();
    private final List<Integer> lcol = new ArrayList<>();
    private final android.graphics.RectF rc = new android.graphics.RectF();
    private final List<android.graphics.RectF> used = new ArrayList<>();

    public FeatureOverlay() {
        ln.setStyle(Paint.Style.STROKE);
        ln.setStrokeJoin(Paint.Join.ROUND);
        ln.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(Color.WHITE);
        ring.setStrokeWidth(2f);
        txt.setStyle(Paint.Style.FILL);
        txt.setFakeBoldText(true);
        halo.setStyle(Paint.Style.STROKE);
        halo.setStrokeJoin(Paint.Join.ROUND);
        halo.setColor(Color.WHITE);
    }

    public void setTap(Tap t) {
        tap = t;
    }

    public void setData(List<LayerData> layers, float density) {
        this.density = density;
        items.clear();
        if (layers != null) {
            for (LayerData l : layers) for (Feature f : l.features) items.add(new Item(f, l));
        }
    }

    public int count() {
        return items.size();
    }

    /** minLon,minLat,maxLon,maxLat of all data or null. */
    public double[] bounds() {
        double[] r = null;
        for (Item it : items) {
            double[] b = it.bb;
            if (b == null) continue;
            if (r == null) r = b.clone();
            else {
                r[0] = Math.min(r[0], b[0]);
                r[1] = Math.min(r[1], b[1]);
                r[2] = Math.max(r[2], b[2]);
                r[3] = Math.max(r[3], b[3]);
            }
        }
        return r;
    }

    static int colorFor(String id) {
        switch (id) {
            case "roads_main": return Color.parseColor("#E8590C");
            case "roads_secondary": return Color.parseColor("#F59F00");
            case "rivers": return Color.parseColor("#1C7ED6");
            case "lakes": return Color.parseColor("#4DABF7");
            case "dams": return Color.parseColor("#7048E8");
            case "tourism": return Color.parseColor("#D6336C");
            case "admin_gov": return Color.parseColor("#C2255C");
            case "admin_qadaa": return Color.parseColor("#9C36B5");
            case "admin_nahiya": return Color.parseColor("#2F9E44");
            default: return Color.parseColor("#0CA678");
        }
    }

    @Override
    public void draw(Canvas c, MapView map, boolean shadow) {
        if (shadow || items.isEmpty()) return;
        Projection pj = map.getProjection();
        org.osmdroid.util.BoundingBox vb = pj.getBoundingBox();
        double minLat = vb.getLatSouth(), maxLat = vb.getLatNorth(), minLon = vb.getLonWest(), maxLon = vb.getLonEast();
        float d = density;
        int visiblePts = 0;
        GeoPoint gp = new GeoPoint(0.0, 0.0);
        double zoom = map.getZoomLevelDouble();
        lpos.clear();
        ltxt.clear();
        lcol.clear();
        for (Item it : items) {
            double[] b = it.bb;
            if (b == null || b[2] < minLon || b[0] > maxLon || b[3] < minLat || b[1] > maxLat) continue;
            Feature f = it.f;
            int col = colorFor(it.layer.id);
            if (f.geom == Feature.POINT) {
                gp.setCoords(f.lat, f.lon);
                pj.toPixels(gp, p1);
                pt.setColor(col);
                if (++visiblePts > 4000) {
                    c.drawCircle(p1.x, p1.y, 2f * d, pt);
                } else {
                    c.drawCircle(p1.x, p1.y, 5f * d, ring);
                    c.drawCircle(p1.x, p1.y, 5f * d, pt);
                    if (zoom >= 14 && !f.name.isEmpty() && lpos.size() < 500) {
                        lpos.add(new float[]{p1.x + 8f * d, p1.y + 4f * d, 0});
                        ltxt.add(f.name);
                        lcol.add(col);
                    }
                }
                continue;
            }
            path.rewind();
            float minStep = 1.5f * d;
            for (int pi = 0; pi < f.parts.size(); pi++) {
                double[] a = f.parts.get(pi);
                int n = a.length / 2;
                float lx = 0, ly = 0;
                boolean first = true;
                for (int i = 0; i < n; i++) {
                    gp.setCoords(a[2 * i + 1], a[2 * i]);
                    pj.toPixels(gp, p1);
                    boolean last = i == n - 1;
                    if (!first && !last && Math.abs(p1.x - lx) < minStep && Math.abs(p1.y - ly) < minStep) continue;
                    if (first) path.moveTo(p1.x, p1.y);
                    else path.lineTo(p1.x, p1.y);
                    lx = p1.x;
                    ly = p1.y;
                    first = false;
                }
                if (f.geom == Feature.POLYGON) path.close();
            }
            if (f.geom == Feature.POLYGON) {
                path.setFillType(Path.FillType.EVEN_ODD);
                fill.setColor((col & 0x00FFFFFF) | 0x33000000);
                c.drawPath(path, fill);
                ln.setStrokeWidth(2f * d);
            } else {
                ln.setStrokeWidth((it.layer.id.equals("roads_main") ? 3.2f : 2f) * d);
            }
            ln.setColor(col);
            c.drawPath(path, ln);
            if (zoom >= 15 && !f.name.isEmpty() && lpos.size() < 500) {
                gp.setCoords(f.lat, f.lon);
                pj.toPixels(gp, p1);
                lpos.add(new float[]{p1.x, p1.y, 1});
                ltxt.add(f.name);
                lcol.add(col);
            }
        }
        drawLabels(c);
    }

    private void drawLabels(Canvas c) {
        if (lpos.isEmpty()) return;
        float d = density;
        txt.setTextSize(12f * d);
        halo.setTextSize(12f * d);
        halo.setStrokeWidth(3f * d);
        used.clear();
        int w = c.getWidth(), h = c.getHeight();
        for (int i = 0; i < lpos.size(); i++) {
            float[] p = lpos.get(i);
            String t = ltxt.get(i);
            float tw = txt.measureText(t);
            float x = p[2] == 1 ? p[0] - tw / 2 : p[0], y = p[1];
            if (x > w || x + tw < 0 || y < 0 || y - 14 * d > h) continue;
            rc.set(x - 2 * d, y - 12 * d, x + tw + 2 * d, y + 4 * d);
            boolean clash = false;
            for (android.graphics.RectF u : used) {
                if (android.graphics.RectF.intersects(u, rc)) {
                    clash = true;
                    break;
                }
            }
            if (clash) continue;
            used.add(new android.graphics.RectF(rc));
            txt.setColor(Theme.dark ? Color.parseColor("#102030") : Color.parseColor("#102030"));
            c.drawText(t, x, y, halo);
            c.drawText(t, x, y, txt);
        }
    }

    @Override
    public boolean onSingleTapConfirmed(android.view.MotionEvent e, MapView map) {
        if (tap == null || items.isEmpty()) return false;
        Projection pj = map.getProjection();
        double best = 28 * density;
        Item hit = null;
        Point p = new Point();
        for (Item it : items) {
            Feature f = it.f;
            if (f.geom == Feature.POINT || f.geom == Feature.POLYGON || f.geom == Feature.LINE) {
                pj.toPixels(new GeoPoint(f.lat, f.lon), p);
                double dist = Math.hypot(p.x - e.getX(), p.y - e.getY());
                if (dist < best) {
                    best = dist;
                    hit = it;
                }
            }
        }
        if (hit == null) return false;
        tap.onFeature(hit.f, hit.layer.label);
        return true;
    }
}
