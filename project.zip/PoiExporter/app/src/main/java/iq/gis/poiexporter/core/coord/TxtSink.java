package iq.gis.poiexporter.core.coord;

import java.io.IOException;
import java.io.OutputStream;

/** Tab separated text, UTF-8 (no BOM). */
public final class TxtSink extends CsvSink {
    public TxtSink(OutputStream os) throws IOException {
        super(os, '\t', false);
    }
}
