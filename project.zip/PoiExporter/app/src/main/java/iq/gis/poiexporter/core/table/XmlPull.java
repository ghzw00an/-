package iq.gis.poiexporter.core.table;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/** Minimal streaming XML tokenizer (enough for OOXML parts): START, END, TEXT, EOF. Not namespace aware. */
final class XmlPull {
    static final int START = 1, END = 2, TEXT = 3, EOF = 0;

    private final Reader in;
    private int peeked = -2;
    private boolean pendingEnd;
    private final StringBuilder sb = new StringBuilder();

    /** Name of the current START/END element without prefix. */
    String name = "";
    /** Text of the current TEXT token (entities decoded). */
    String text = "";
    private final List<String> an = new ArrayList<>(), av = new ArrayList<>();

    XmlPull(Reader in) {
        this.in = in;
    }

    private int read() throws IOException {
        if (peeked != -2) {
            int c = peeked;
            peeked = -2;
            return c;
        }
        return in.read();
    }

    private int peek() throws IOException {
        if (peeked == -2) peeked = in.read();
        return peeked;
    }

    String attr(String n) {
        for (int i = 0; i < an.size(); i++) if (an.get(i).equals(n)) return av.get(i);
        return null;
    }

    int next() throws IOException {
        if (pendingEnd) {
            pendingEnd = false;
            return END;
        }
        while (true) {
            int c = read();
            if (c < 0) return EOF;
            if (c != '<') {
                sb.setLength(0);
                sb.append((char) c);
                while (true) {
                    int d = peek();
                    if (d < 0 || d == '<') break;
                    sb.append((char) read());
                }
                text = decode(sb.toString());
                return TEXT;
            }
            int d = read();
            if (d == '?') {
                skipUntil("?>");
                continue;
            }
            if (d == '!') {
                if (peek() == '-') {
                    skipUntil("-->");
                    continue;
                }
                // CDATA or DOCTYPE
                sb.setLength(0);
                for (int k = 0; k < 7; k++) sb.append((char) read());
                if (sb.toString().startsWith("[CDATA[")) {
                    StringBuilder t = new StringBuilder();
                    t.append(sb.substring(7));
                    while (!endsWith(t, "]]>")) {
                        int x = read();
                        if (x < 0) break;
                        t.append((char) x);
                    }
                    text = t.length() >= 3 ? t.substring(0, t.length() - 3) : "";
                    return TEXT;
                }
                skipUntil(">");
                continue;
            }
            if (d == '/') {
                sb.setLength(0);
                int x;
                while ((x = read()) >= 0 && x != '>') sb.append((char) x);
                name = local(sb.toString().trim());
                return END;
            }
            sb.setLength(0);
            sb.append((char) d);
            int x;
            while ((x = read()) >= 0 && x != '>' && x != '/' && x > ' ') sb.append((char) x);
            name = local(sb.toString());
            an.clear();
            av.clear();
            boolean selfClose = false;
            while (x >= 0 && x != '>') {
                if (x == '/') {
                    selfClose = true;
                    x = read();
                    continue;
                }
                if (x <= ' ') {
                    x = read();
                    continue;
                }
                sb.setLength(0);
                sb.append((char) x);
                while ((x = read()) >= 0 && x != '=' && x > ' ' && x != '>' && x != '/') sb.append((char) x);
                String an1 = sb.toString();
                while (x >= 0 && x <= ' ') x = read();
                if (x == '=') {
                    x = read();
                    while (x >= 0 && x <= ' ') x = read();
                    int q = x;
                    sb.setLength(0);
                    while ((x = read()) >= 0 && x != q) sb.append((char) x);
                    an.add(an1);
                    av.add(decode(sb.toString()));
                    x = read();
                } else {
                    an.add(an1);
                    av.add("");
                }
            }
            if (selfClose) pendingEnd = true;
            return START;
        }
    }

    private static boolean endsWith(StringBuilder b, String s) {
        int n = b.length(), m = s.length();
        if (n < m) return false;
        for (int i = 0; i < m; i++) if (b.charAt(n - m + i) != s.charAt(i)) return false;
        return true;
    }

    private void skipUntil(String end) throws IOException {
        StringBuilder t = new StringBuilder();
        int x;
        while ((x = read()) >= 0) {
            t.append((char) x);
            if (endsWith(t, end)) return;
            if (t.length() > 8) t.delete(0, t.length() - 8);
        }
    }

    private static String local(String n) {
        int k = n.indexOf(':');
        return k >= 0 ? n.substring(k + 1) : n;
    }

    static String decode(String s) {
        if (s.indexOf('&') < 0) return s;
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '&') {
                b.append(c);
                continue;
            }
            int e = s.indexOf(';', i);
            if (e < 0) {
                b.append(c);
                continue;
            }
            String ent = s.substring(i + 1, e);
            String r = null;
            switch (ent) {
                case "amp": r = "&"; break;
                case "lt": r = "<"; break;
                case "gt": r = ">"; break;
                case "quot": r = "\""; break;
                case "apos": r = "'"; break;
                default:
                    try {
                        if (ent.startsWith("#x") || ent.startsWith("#X")) r = new String(Character.toChars(Integer.parseInt(ent.substring(2), 16)));
                        else if (ent.startsWith("#")) r = new String(Character.toChars(Integer.parseInt(ent.substring(1))));
                    } catch (RuntimeException ex) {
                        r = null;
                    }
            }
            if (r == null) {
                b.append(c);
            } else {
                b.append(r);
                i = e;
            }
        }
        return b.toString();
    }
}
