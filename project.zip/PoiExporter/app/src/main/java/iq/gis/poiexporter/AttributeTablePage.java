package iq.gis.poiexporter;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LandmarkFields;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.Utm;
import iq.gis.poiexporter.core.io.DupFinder;

/**
 * Attribute table (name, type, Gategory, gathaa, Nahia, mohafadha, x, y, link).
 * Search, sort, pick rows and columns, edit a cell (undoable), delete, copy, save CSV, share, print, flash-and-zoom to a row,
 * and a second "selected only" view that shows just the chosen cells (rows × columns).
 */
final class AttributeTablePage {
    private static final int PAGE = 200;
    private static final int[] W = {150, 110, 150, 110, 100, 110, 100, 100, 120};
    private final MainActivity a;
    private int layerIdx, sortCol = -1, page;
    private boolean desc, selectedOnly;
    private String query = "", focusId = "";
    private final Set<String> selRows = new HashSet<>();
    private final boolean[] colOn = {true, true, true, true, true, true, true, true, true};
    private LinearLayout tableBox;
    private TextView info;
    private List<LayerData> ls = new ArrayList<>();

    AttributeTablePage(MainActivity a) {
        this.a = a;
    }

    private List<LayerData> all() {
        List<LayerData> r = new ArrayList<>(MainActivity.LIB);
        r.addAll(MainActivity.DL);
        return r;
    }

    /** Opens the table on the layer and brings the feature into view (used by "Show table" in the feature sheet). */
    void openFor(LayerData l, Feature f) {
        List<LayerData> all = all();
        int i = all.indexOf(l);
        layerIdx = Math.max(0, i);
        query = "";
        selectedOnly = false;
        sortCol = -1;
        focusId = f == null ? "" : f.id;
        selRows.clear();
        if (f != null) selRows.add(f.id);
        page = 0;
        a.showPage("attrs");
    }

    private LayerData layer() {
        return ls.get(Math.min(layerIdx, ls.size() - 1));
    }

    private boolean editable(LayerData l) {
        return MainActivity.WS.layer(l.id) != null;
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        ls = all();
        LinearLayout top = Ui.card(a);
        top.addView(UiKit.head(a, selectedOnly ? S.t("العرض الثاني: المحدد فقط", "Second view: selection only") : S.t("جدول الخصائص (Attribute table)", "Attribute table")));
        if (ls.isEmpty()) {
            top.addView(UiKit.note(a, S.t("لا توجد طبقات بعد. أضف معالم أو استورد أو نزّل بيانات.", "No layers yet.")));
            p.addView(top);
            return p;
        }
        if (layerIdx >= ls.size()) layerIdx = 0;
        List<String> names = new ArrayList<>();
        for (LayerData l : ls) names.add(l.label + "  (" + l.features.size() + ")");
        Spinner sp = ConverterPage.spinner(a, names, layerIdx);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                if (pos != layerIdx) {
                    layerIdx = pos;
                    page = 0;
                    sortCol = -1;
                    selRows.clear();
                    render();
                }
            }

            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        top.addView(sp);
        if (!selectedOnly) {
            EditText q = Ui.field(a, S.t("بحث في كل الحقول", "Search all fields"), InputType.TYPE_CLASS_TEXT);
            q.setText(query);
            q.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int st, int c, int af) {
                }

                public void onTextChanged(CharSequence s, int st, int b, int c) {
                }

                public void afterTextChanged(Editable e) {
                    if (e.toString().equals(query)) return;
                    query = e.toString();
                    page = 0;
                    render();
                }
            });
            top.addView(q);
        }
        top.addView(UiKit.label(a, S.t("الأعمدة المعروضة والمحددة", "Columns shown / selected")));
        HorizontalScrollView cs = new HorizontalScrollView(a);
        cs.setHorizontalScrollBarEnabled(false);
        LinearLayout cr = new LinearLayout(a);
        for (int c = 0; c < 9; c++) {
            final int col = c;
            final TextView ch = Ui.chip(a, LandmarkFields.NAMES[c]);
            Ui.setChip(ch, colOn[c]);
            ch.setOnClickListener(v -> {
                colOn[col] = !colOn[col];
                boolean any = false;
                for (boolean b : colOn) any |= b;
                if (!any) colOn[col] = true;
                Ui.setChip(ch, colOn[col]);
                render();
            });
            cr.addView(ch, Ui.lp(-2, -2, 0, a, 3, 4, 3, 4));
        }
        cs.addView(cr);
        top.addView(cs);
        info = UiKit.note(a, "");
        top.addView(info);

        LinearLayout r1 = Ui.row(a);
        r1.addView(Ui.button(a, "☑ " + S.t("الكل", "All"), false, () -> selectAll(true)), Ui.lp(0, -2, 1f, a, 0, 4, 3, 0));
        r1.addView(Ui.button(a, "☐ " + S.t("لا شيء", "None"), false, () -> selectAll(false)), Ui.lp(0, -2, 1f, a, 3, 4, 3, 0));
        r1.addView(Ui.button(a, selectedOnly ? "↩ " + S.t("الجدول كله", "Full table") : "👁 " + S.t("المحدد فقط", "Selected only"), true, () -> {
            if (!selectedOnly && selRows.isEmpty()) {
                a.toast(S.t("حدد صفاً واحداً على الأقل بمربع الاختيار", "Tick at least one row"));
                return;
            }
            selectedOnly = !selectedOnly;
            page = 0;
            a.showPage("attrs");
        }), Ui.lp(0, -2, 1.3f, a, 3, 4, 0, 0));
        top.addView(r1);
        LinearLayout r2 = Ui.row(a);
        r2.addView(Ui.button(a, "⧉ " + S.t("نسخ", "Copy"), false, this::copySel), Ui.lp(0, -2, 1f, a, 0, 4, 3, 0));
        r2.addView(Ui.button(a, "↗ " + S.t("مشاركة", "Share"), false, () -> saveSel(true)), Ui.lp(0, -2, 1f, a, 3, 4, 3, 0));
        r2.addView(Ui.button(a, "💾 CSV", false, () -> saveSel(false)), Ui.lp(0, -2, 1f, a, 3, 4, 3, 0));
        r2.addView(Ui.button(a, "🖨 PDF", false, this::printSel), Ui.lp(0, -2, 1f, a, 3, 4, 0, 0));
        top.addView(r2);
        top.addView(Ui.button(a, "🗑 " + S.t("حذف المحدد", "Delete selected"), false, this::deleteSel), Ui.lp(-1, -2, 0, a, 0, 4, 0, 0));
        top.addView(UiKit.note(a, S.t("مربع الصف لتحديده • المس خلية لتعديلها • 🔍 للوميض والتقريب • المس عنواناً للترتيب. الإجراءات تُطبَّق على الصفوف المحددة والأعمدة المفعّلة.",
                "Row box selects • tap a cell to edit • 🔍 flashes and zooms • tap a header to sort. Actions apply to the ticked rows and the enabled columns.")));
        p.addView(top);
        tableBox = UiKit.col(a);
        p.addView(tableBox);
        render();
        return p;
    }

    // ------------------------------------------------------------------------------------------------ data

    private static String[] row(Feature f) {
        String[] t = LandmarkFields.text(f);
        double[] xy = LandmarkFields.xy(f, null);
        String[] r = new String[9];
        System.arraycopy(t, 0, r, 0, 6);
        r[6] = LandmarkFields.num(xy[0], 2);
        r[7] = LandmarkFields.num(xy[1], 2);
        r[8] = LandmarkFields.link(f);
        return r;
    }

    private List<Feature> shown;
    private List<String[]> shownRows;
    private int[] order;

    private void compute() {
        LayerData l = layer();
        shown = new ArrayList<>();
        shownRows = new ArrayList<>();
        String nq = DupFinder.normName(query);
        for (Feature f : l.features) {
            if (selectedOnly && !selRows.contains(f.id)) continue;
            String[] r = row(f);
            if (!selectedOnly && !nq.isEmpty()) {
                boolean hit = false;
                for (String c : r) if (DupFinder.normName(c).contains(nq)) {
                    hit = true;
                    break;
                }
                if (!hit) continue;
            }
            shown.add(f);
            shownRows.add(r);
        }
        Integer[] o = new Integer[shown.size()];
        for (int i = 0; i < o.length; i++) o[i] = i;
        if (sortCol >= 0) {
            final boolean numeric = sortCol == 6 || sortCol == 7;
            Collections.sort(java.util.Arrays.asList(o), new Comparator<Integer>() {
                public int compare(Integer x, Integer y) {
                    String s1 = shownRows.get(x)[sortCol], s2 = shownRows.get(y)[sortCol];
                    int c;
                    if (numeric) {
                        double d1 = s1.isEmpty() ? Double.NaN : Double.parseDouble(s1), d2 = s2.isEmpty() ? Double.NaN : Double.parseDouble(s2);
                        c = Double.compare(d1, d2);
                    } else c = s1.compareToIgnoreCase(s2);
                    return desc ? -c : c;
                }
            });
        }
        order = new int[o.length];
        for (int i = 0; i < o.length; i++) order[i] = o[i];
        if (!focusId.isEmpty()) {
            for (int i = 0; i < order.length; i++) if (shown.get(order[i]).id.equals(focusId)) {
                page = i / PAGE;
                break;
            }
        }
    }

    private void render() {
        if (tableBox == null) return;
        tableBox.removeAllViews();
        compute();
        final LayerData l = layer();
        int pages = Math.max(1, (order.length + PAGE - 1) / PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        info.setText(S.t("العناصر: ", "Features: ") + order.length + " / " + l.features.size() + "   •   " + S.t("محدد: ", "Ticked: ") + selRows.size()
                + "   •   " + S.t("صفحة ", "Page ") + (page + 1) + " / " + pages
                + (editable(l) ? "" : "\n" + S.t("طبقة للقراءة فقط (منزّلة/مرجعية): احفظها في المشروع لتعديلها.", "Read-only layer (downloaded/reference): save it to the project to edit.")));

        HorizontalScrollView hs = new HorizontalScrollView(a);
        LinearLayout tbl = new LinearLayout(a);
        tbl.setOrientation(LinearLayout.VERTICAL);
        tbl.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout hr = new LinearLayout(a);
        hr.setBackgroundColor(Theme.primary);
        hr.addView(cell("", 80, true));
        for (int c = 0; c < 9; c++) {
            if (!colOn[c]) continue;
            final int col = c;
            TextView h = cell(LandmarkFields.NAMES[c] + (sortCol == c ? (desc ? " ▼" : " ▲") : ""), W[c], true);
            h.setTextColor(0xFFFFFFFF);
            h.setOnClickListener(v -> {
                if (sortCol == col) desc = !desc;
                else {
                    sortCol = col;
                    desc = false;
                }
                render();
            });
            hr.addView(h);
        }
        tbl.addView(hr);
        int from = page * PAGE, to = Math.min(order.length, from + PAGE);
        for (int k = from; k < to; k++) {
            final Feature f = shown.get(order[k]);
            String[] r = shownRows.get(order[k]);
            LinearLayout rl = new LinearLayout(a);
            rl.setGravity(Gravity.CENTER_VERTICAL);
            boolean focus = f.id.equals(focusId);
            rl.setBackgroundColor(focus ? 0x55FFC107 : (k & 1) == 0 ? Theme.card : Theme.bg);
            LinearLayout lead = new LinearLayout(a);
            lead.setGravity(Gravity.CENTER_VERTICAL);
            lead.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(a, 80), -2));
            CheckBox cb = new CheckBox(a);
            cb.setChecked(selRows.contains(f.id));
            cb.setOnCheckedChangeListener((b, on) -> {
                if (on) selRows.add(f.id);
                else selRows.remove(f.id);
                info.setText(info.getText().toString().replaceAll("(محدد|Ticked): \\d+", S.t("محدد: ", "Ticked: ") + selRows.size()));
            });
            lead.addView(cb);
            TextView go = Ui.text(a, "🔍", 16, Theme.text, false);
            go.setPadding(Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6));
            go.setOnClickListener(v -> a.flashTo(f));
            lead.addView(go);
            rl.addView(lead);
            for (int c = 0; c < 9; c++) {
                if (!colOn[c]) continue;
                final int col = c;
                TextView t = cell(r[c], W[c], false);
                t.setOnClickListener(v -> editCell(l, f, col));
                rl.addView(t);
            }
            tbl.addView(rl);
        }
        hs.addView(tbl);
        tableBox.addView(hs);
        LinearLayout nav = Ui.row(a);
        nav.addView(Ui.button(a, "◀", false, () -> {
            if (page > 0) {
                page--;
                focusId = "";
                render();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 8, 4, 0));
        nav.addView(Ui.button(a, "▶", false, () -> {
            page++;
            focusId = "";
            render();
        }), Ui.lp(0, -2, 1f, a, 4, 8, 0, 0));
        tableBox.addView(nav);
    }

    private TextView cell(String s, int widthDp, boolean bold) {
        TextView t = Ui.text(a, s, 12.5f, Theme.text, bold);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        t.setPadding(Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10));
        t.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(a, widthDp), -2));
        return t;
    }

    // ------------------------------------------------------------------------------------------------ selection and actions

    private void selectAll(boolean on) {
        compute();
        if (!on) selRows.clear();
        else for (Feature f : shown) selRows.add(f.id);
        render();
    }

    /** Ticked rows (or, if none are ticked, nothing). Cells = these rows × the enabled columns. */
    private List<Feature> selected() {
        List<Feature> r = new ArrayList<>();
        for (Feature f : layer().features) if (selRows.contains(f.id)) r.add(f);
        return r;
    }

    private String[] headerSel() {
        List<String> h = new ArrayList<>();
        for (int c = 0; c < 9; c++) if (colOn[c]) h.add(LandmarkFields.NAMES[c]);
        return h.toArray(new String[0]);
    }

    private List<String[]> rowsSel(List<Feature> fs) {
        List<String[]> out = new ArrayList<>();
        for (Feature f : fs) {
            String[] r = row(f);
            List<String> v = new ArrayList<>();
            for (int c = 0; c < 9; c++) if (colOn[c]) v.add(r[c]);
            out.add(v.toArray(new String[0]));
        }
        return out;
    }

    private boolean needSel(List<Feature> fs) {
        if (fs.isEmpty()) {
            a.toast(S.t("حدد صفاً واحداً على الأقل بمربع الاختيار", "Tick at least one row"));
            return false;
        }
        return true;
    }

    private static String csvCell(String s) {
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }

    private String toCsv(List<Feature> fs) {
        StringBuilder b = new StringBuilder();
        String[] h = headerSel();
        for (int i = 0; i < h.length; i++) b.append(i > 0 ? "," : "").append(h[i]);
        b.append("\r\n");
        for (String[] r : rowsSel(fs)) {
            for (int i = 0; i < r.length; i++) b.append(i > 0 ? "," : "").append(csvCell(r[i]));
            b.append("\r\n");
        }
        return b.toString();
    }

    private void copySel() {
        List<Feature> fs = selected();
        if (!needSel(fs)) return;
        StringBuilder b = new StringBuilder();
        for (String[] r : rowsSel(fs.size() > 5000 ? fs.subList(0, 5000) : fs)) b.append(String.join("\t", r)).append('\n');
        a.copy(b.toString());
    }

    private String baseName() {
        return layer().label.replaceAll("[^\\p{L}\\p{N}_-]+", "_") + "_" + System.currentTimeMillis() / 1000;
    }

    private void saveSel(final boolean share) {
        final List<Feature> fs = selected();
        if (!needSel(fs)) return;
        final String csv = toCsv(fs);
        new Thread(() -> {
            try {
                final Storage.Saved sv = Storage.save(a, a.prefs, baseName() + ".csv", "text/csv", os -> {
                    OutputStreamWriter w = new OutputStreamWriter(os, "UTF-8");
                    w.write('﻿');
                    w.write(csv);
                    w.flush();
                });
                a.runOnUiThread(() -> {
                    if (share) Storage.share(a, sv.uri, "text/csv");
                    else a.report.saved(sv, "text/csv", fs.size() + S.t(" صفاً", " rows"));
                });
            } catch (Throwable t) {
                fail(t);
            }
        }).start();
    }

    private void printSel() {
        final List<Feature> fs = selected();
        if (!needSel(fs)) return;
        final String[] h = headerSel();
        final List<String[]> rows = rowsSel(fs);
        final String title = layer().label;
        new Thread(() -> {
            try {
                final int[] pages = {0};
                final Storage.Saved sv = Storage.save(a, a.prefs, baseName() + ".pdf", "application/pdf", os -> pages[0] = TablePdf.write(os, title, h, rows, h.length > 5));
                a.runOnUiThread(() -> a.report.saved(sv, "application/pdf", S.t("الصفحات: ", "Pages: ") + pages[0]));
            } catch (Throwable t) {
                fail(t);
            }
        }).start();
    }

    private void fail(Throwable t) {
        ErrorLog.add("attr-table", t);
        a.runOnUiThread(() -> a.message(S.t("تعذّرت العملية", "Operation failed"), String.valueOf(t.getMessage()), null, null));
    }

    private void deleteSel() {
        final LayerData l = layer();
        final List<Feature> fs = selected();
        if (!needSel(fs)) return;
        if (!editable(l)) {
            a.toast(S.t("الطبقة للقراءة فقط", "Read-only layer"));
            return;
        }
        final List<String> ids = new ArrayList<>();
        for (Feature f : fs) ids.add(f.id);
        a.messageConfirm(S.t("حذف المحدد", "Delete selected"), S.t("سيُحذف " + ids.size() + " عنصراً. يمكن التراجع.", ids.size() + " features will be deleted. Undo is available."),
                S.t("حذف", "Delete"), () -> {
                    MainActivity.WS.deleteFeatures(l.id, ids, S.t("حذف من الجدول", "Delete from table"));
                    selRows.removeAll(ids);
                    a.rebuild();
                    if (selectedOnly && selRows.isEmpty()) selectedOnly = false;
                    a.showPage("attrs");
                });
    }

    // ------------------------------------------------------------------------------------------------ cell editing

    private void editCell(final LayerData l, final Feature f, final int col) {
        if (!editable(l)) {
            a.toast(S.t("الطبقة للقراءة فقط (احفظها في المشروع لتعديلها)", "Read-only layer (save it to the project to edit)"));
            return;
        }
        if ((col == 6 || col == 7) && f.geom != Feature.POINT) {
            a.toast(S.t("تعديل x وy للنقاط فقط", "x/y editing is for points only"));
            return;
        }
        LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, LandmarkFields.NAMES[col]));
        final String cur = row(f)[col];
        final EditText e = Ui.field(a, LandmarkFields.NAMES[col], col == 6 || col == 7 ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL : InputType.TYPE_CLASS_TEXT);
        e.setText(cur);
        box.addView(e);
        final android.app.Dialog d = a.card(box);
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, d::dismiss), Ui.lp(0, -2, 1f, a, 0, 10, 4, 0));
        r.addView(Ui.button(a, S.t("حفظ", "Save"), true, () -> {
            String v = e.getText().toString().trim();
            Feature before = f.copy(), after = f.copy();
            switch (col) {
                case 0:
                    after.name = v;
                    break;
                case 1:
                    after.type = v;
                    break;
                case 2:
                    after.category = v;
                    break;
                case 3:
                    after.qadaa = v;
                    break;
                case 4:
                    after.nahiya = v;
                    break;
                case 5:
                    after.governorate = v;
                    break;
                case 8:
                    LandmarkFields.setLink(after, v);
                    break;
                default:
                    try {
                        Utm.Result u = Utm.fromLatLon(f.lat, f.lon);
                        double x = col == 6 ? Double.parseDouble(v) : u.easting, y = col == 7 ? Double.parseDouble(v) : u.northing;
                        double[] ll = Utm.toLatLon(u.zone, u.north, x, y);
                        after.parts.set(0, new double[]{ll[1], ll[0]});
                        after.lat = ll[0];
                        after.lon = ll[1];
                    } catch (RuntimeException ex) {
                        a.toast(S.t("قيمة غير صالحة", "Invalid value"));
                        return;
                    }
            }
            after.updated = java.time.LocalDate.now().toString();
            d.dismiss();
            MainActivity.WS.updateFeature(before, after, S.t("تعديل خلية ", "Edit cell ") + LandmarkFields.NAMES[col]);
            a.rebuild();
            render();
        }), Ui.lp(0, -2, 1f, a, 4, 10, 0, 0));
        box.addView(r);
        d.show();
    }
}
