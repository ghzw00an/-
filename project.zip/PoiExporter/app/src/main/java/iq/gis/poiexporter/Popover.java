package iq.gis.poiexporter;

import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Small floating menu shown just above a button (used for long-press on the map buttons). */
final class Popover {
    private final MainActivity a;
    private final List<String> labels = new ArrayList<>();
    private final List<Runnable> actions = new ArrayList<>();
    private PopupWindow pw;

    Popover(MainActivity a) {
        this.a = a;
    }

    Popover add(String label, Runnable r) {
        labels.add(label);
        actions.add(r);
        return this;
    }

    Popover addIf(boolean cond, String label, Runnable r) {
        return cond ? add(label, r) : this;
    }

    void show(View anchor) {
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackground(Ui.round(Theme.card, 12, a));
        col.setElevation(Ui.dp(a, 10));
        int pad = Ui.dp(a, 4);
        col.setPadding(pad, pad, pad, pad);
        for (int i = 0; i < labels.size(); i++) {
            final Runnable r = actions.get(i);
            TextView t = Ui.text(a, labels.get(i), 15, Theme.text, false);
            t.setPadding(Ui.dp(a, 14), Ui.dp(a, 11), Ui.dp(a, 14), Ui.dp(a, 11));
            t.setClickable(true);
            Ui.pressable(t);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    dismiss();
                    r.run();
                }
            });
            col.addView(t, new LinearLayout.LayoutParams(-2, -2));
        }
        col.measure(View.MeasureSpec.makeMeasureSpec(a.getResources().getDisplayMetrics().widthPixels * 3 / 4, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.UNSPECIFIED);
        pw = new PopupWindow(col, col.getMeasuredWidth(), col.getMeasuredHeight(), true);
        pw.setBackgroundDrawable(new ColorDrawable(0));
        pw.setOutsideTouchable(true);
        int[] loc = new int[2];
        anchor.getLocationOnScreen(loc);
        int sw = a.getResources().getDisplayMetrics().widthPixels;
        int x = Math.max(Ui.dp(a, 6), Math.min(sw - col.getMeasuredWidth() - Ui.dp(a, 6), loc[0] + anchor.getWidth() / 2 - col.getMeasuredWidth() / 2));
        int y = Math.max(Ui.dp(a, 30), loc[1] - col.getMeasuredHeight() - Ui.dp(a, 8));
        pw.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y);
        anchor.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
    }

    void dismiss() {
        if (pw != null) pw.dismiss();
    }
}
