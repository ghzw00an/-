package iq.gis.poiexporter;

import android.net.Uri;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.io.ExportHub;
import iq.gis.poiexporter.core.io.ExportOptions;
import iq.gis.poiexporter.core.io.GeoFormat;
import iq.gis.poiexporter.core.io.Gpkg;
import iq.gis.poiexporter.core.io.ImportHub;
import iq.gis.poiexporter.core.table.PointTable;

/** Import / export hub: preview before import, CRS assignment, pre-flight warnings before export. */
final class HubPage {
    private final MainActivity a;
    private final java.util.Set<String> chosen = new HashSet<>();
    private int fmtIdx = 0;
    private Crs target;
    private boolean attributes = true;

    private static final GeoFormat[] OUT = {GeoFormat.SHP_ZIP, GeoFormat.KML, GeoFormat.KMZ, GeoFormat.GEOJSON, GeoFormat.GPKG,
            GeoFormat.GPX, GeoFormat.CSV, GeoFormat.XLSX};

    HubPage(MainActivity a) {
        this.a = a;
    }

    View build() {
        LinearLayout p = UiKit.col(a);
        LinearLayout imp = Ui.card(a);
        imp.addView(UiKit.head(a, S.t("استيراد", "Import")));
        imp.addView(UiKit.note(a, S.t("GeoJSON • KML/KMZ • GPX • Shapefile (ZIP) • CSV/TXT • Excel • GeoPackage.\nتُعرض معاينة (الطبقات، العدد، النظام، عيّنة) قبل الاستيراد، ويُقرأ نظام الإحداثيات من ملف .prj.",
                "GeoJSON • KML/KMZ • GPX • Shapefile (ZIP) • CSV/TXT • Excel • GeoPackage.\nA preview (layers, count, CRS, sample) is shown before importing; the CRS is read from .prj.")));
        imp.addView(Ui.button(a, S.t("اختيار ملف…", "Choose file…"), true, a::pickHub), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(imp);

        LinearLayout exp = Ui.card(a);
        exp.addView(UiKit.head(a, S.t("تصدير", "Export")));
        exp.addView(UiKit.label(a, S.t("الطبقات", "Layers")));
        List<LayerData> all = new ArrayList<>(MainActivity.LIB);
        all.addAll(MainActivity.DL);
        if (all.isEmpty()) exp.addView(UiKit.note(a, S.t("لا توجد طبقات. أضف معالم أو نزّل بيانات أولاً.", "No layers yet.")));
        for (final LayerData l : all) {
            exp.addView(UiKit.check(a, l.label + "  (" + l.features.size() + ")", chosen.contains(l.id), v -> {
                if (v) chosen.add(l.id);
                else chosen.remove(l.id);
            }));
        }
        String[] names = new String[OUT.length];
        for (int i = 0; i < OUT.length; i++) names[i] = OUT[i].label;
        exp.addView(UiKit.label(a, S.t("الصيغة", "Format")));
        android.widget.Spinner sp = ConverterPage.spinner(a, java.util.Arrays.asList(names), fmtIdx);
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> parent, View v, int pos, long id) {
                fmtIdx = pos;
            }

            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });
        exp.addView(sp);
        exp.addView(UiKit.label(a, S.t("نظام الإحداثيات", "Coordinate system")));
        final TextView tb = Ui.button(a, UiKit.crsText(target, "EPSG:4326 WGS84"), false, null);
        tb.setOnClickListener(v -> UiKit.pickCrs(a, "EPSG:4326 WGS84", c -> {
            target = c;
            tb.setText(UiKit.crsText(c, "EPSG:4326 WGS84"));
        }));
        exp.addView(tb);
        exp.addView(UiKit.check(a, S.t("تضمين الحقول (الاسم، النوع، الحالة، المصدر…)", "Include attributes"), attributes, v -> attributes = v));
        exp.addView(Ui.button(a, S.t("فحص ثم تصدير", "Check & export"), true, this::exportNow), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        exp.addView(UiKit.note(a, S.t("KML وGPX وGeoPackage بنظام WGS84 فقط. Shapefile وCSV وGeoJSON تدعم أي نظام مدعوم. أسماء حقول Shapefile تُحوَّل إلى ASCII (القيم تبقى عربية).",
                "KML, GPX and GeoPackage are WGS84 only. Shapefile, CSV and GeoJSON support any supported CRS. Shapefile field names become ASCII (values stay Arabic).")));
        p.addView(exp);
        return p;
    }

    // ---------------------------------------------------------------- export

    private void exportNow() {
        final List<LayerData> sel = new ArrayList<>();
        List<LayerData> all = new ArrayList<>(MainActivity.LIB);
        all.addAll(MainActivity.DL);
        for (LayerData l : all) if (chosen.contains(l.id)) sel.add(l);
        if (sel.isEmpty()) {
            a.toast(S.t("اختر طبقة واحدة على الأقل", "Choose at least one layer"));
            return;
        }
        final GeoFormat fmt = OUT[fmtIdx];
        final ExportOptions o = new ExportOptions();
        o.target = target;
        o.attributes = attributes;
        final List<String> warn = ExportHub.preflight(sel, fmt, o);
        boolean blocking = false;
        for (String w : warn) if (w.contains("WGS84") && w.contains(fmt.label)) blocking = true;
        if (blocking) {
            a.message(S.t("لا يمكن التصدير", "Cannot export"), join(warn), null, null);
            return;
        }
        if (warn.isEmpty()) {
            doExport(sel, fmt, o);
        } else {
            a.messageConfirm(S.t("تحذيرات قبل التصدير", "Warnings before export"), join(warn), S.t("تصدير رغم ذلك", "Export anyway"), () -> doExport(sel, fmt, o));
        }
    }

    private static String join(List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String s : l) b.append("• ").append(s).append('\n');
        return b.toString().trim();
    }

    private void doExport(final List<LayerData> sel, final GeoFormat fmt, final ExportOptions o) {
        final LinearLayout box = UiKit.col(a);
        box.addView(Ui.text(a, S.t("جارٍ التصدير…", "Exporting…"), 16, Theme.text, true));
        final android.app.Dialog busy = a.card(box);
        busy.setCancelable(false);
        busy.show();
        final String base = (sel.size() == 1 ? iq.gis.poiexporter.core.ShapeWriter.safeName(sel.get(0).label) : "poi");
        final String stamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(new java.util.Date());
        final String name = (base.isEmpty() ? "poi" : base) + "_" + stamp + (fmt == GeoFormat.SHP_ZIP ? "_shp.zip" : "." + fmt.ext);
        // snapshot on the UI thread
        final List<LayerData> snap = new ArrayList<>();
        for (LayerData l : sel) {
            LayerData c = new LayerData(l.id, l.label, l.geom);
            for (Feature f : l.features) c.features.add(f);
            snap.add(c);
        }
        new Thread(() -> {
            try {
                final Storage.Saved sv;
                if (fmt == GeoFormat.GPKG) {
                    File tmp = new File(a.getCacheDir(), "export_" + stamp + ".gpkg");
                    GpkgAndroid.Writer w = new GpkgAndroid.Writer(tmp);
                    try {
                        ExportHub.writeGpkg(snap, o, w);
                    } finally {
                        w.close();
                    }
                    sv = Storage.save(a, a.prefs, name, fmt.mime, os -> {
                        try (java.io.FileInputStream in = new java.io.FileInputStream(tmp)) {
                            byte[] buf = new byte[65536];
                            int n;
                            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                        }
                    });
                    tmp.delete();
                } else {
                    sv = Storage.save(a, a.prefs, name, fmt.mime, os -> ExportHub.write(snap, fmt, o, os));
                }
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("تم الحفظ ✔", "Saved ✔"), sv.where, S.t("مشاركة / فتح", "Share / open"), () -> Storage.share(a, sv.uri, fmt.mime));
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("فشل التصدير", "Export failed"), String.valueOf(t.getMessage()), null, null);
                });
            }
        }).start();
    }

    // ---------------------------------------------------------------- import

    void picked(final Uri u, final String name) {
        a.toast(S.t("جارٍ قراءة الملف…", "Reading file…"));
        new Thread(() -> {
            try {
                final File f = ConverterPage.copyToCache(a, u, name);
                final ImportHub.Preview pv = ImportHub.preview(f, name);
                a.runOnUiThread(() -> previewDialog(f, name, pv));
            } catch (final Throwable t) {
                a.runOnUiThread(() -> a.message(S.t("تعذّرت القراءة", "Cannot read"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }

    private void previewDialog(final File f, final String name, final ImportHub.Preview pv) {
        final ImportHub.Options o = new ImportHub.Options();
        final Set<Integer> sel = new HashSet<>();
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, name));
        box.addView(UiKit.note(a, S.t("الصيغة: ", "Format: ") + pv.format.label));
        for (String w : pv.warnings) {
            TextView t = UiKit.note(a, "⚠ " + w);
            t.setTextColor(Theme.danger);
            box.addView(t);
        }
        for (int i = 0; i < pv.layers.size(); i++) {
            final int idx = i;
            ImportHub.LayerInfo li = pv.layers.get(i);
            sel.add(i);
            String crs = li.crs == null ? S.t("نظام غير محدد", "CRS unknown") : li.crs.code();
            box.addView(UiKit.check(a, li.name + "  •  " + li.displayGeom(S.ar) + "  •  " + li.count + "  •  " + crs, true, v -> {
                if (v) sel.add(idx);
                else sel.remove(idx);
            }));
            if (!li.sample.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (java.util.Map<String, String> row : li.sample) {
                    int k = 0;
                    for (java.util.Map.Entry<String, String> e : row.entrySet()) {
                        if (k++ >= 4) break;
                        sb.append(e.getKey()).append('=').append(e.getValue()).append("  ");
                    }
                    sb.append('\n');
                    if (sb.length() > 400) break;
                }
                box.addView(UiKit.note(a, sb.toString().trim()));
            }
        }
        final boolean table = pv.format == GeoFormat.CSV || pv.format == GeoFormat.XLSX;
        final PointTable.Mapping m = table && pv.guess != null ? new PointTable.Mapping(pv.guess) : null;
        final android.widget.Spinner[] cols = new android.widget.Spinner[3];
        if (table) {
            java.util.List<String> ch = ConverterPage.columnChoices(pv.header);
            cols[0] = ConverterPage.spinner(a, ch, m.x + 1);
            cols[1] = ConverterPage.spinner(a, ch, m.y + 1);
            cols[2] = ConverterPage.spinner(a, ch, m.name + 1);
            box.addView(UiKit.label(a, S.t("عمود X / خط الطول", "X / longitude column")));
            box.addView(cols[0]);
            box.addView(UiKit.label(a, S.t("عمود Y / دائرة العرض", "Y / latitude column")));
            box.addView(cols[1]);
            box.addView(UiKit.label(a, S.t("عمود الاسم", "Name column")));
            box.addView(cols[2]);
            box.addView(UiKit.check(a, S.t("العمود الأول هو خط العرض", "First column is latitude"), m.latFirst, v -> m.latFirst = v));
        }
        if (table || !pv.crsKnown()) {
            final TextView cb = Ui.button(a, table ? S.t("نظام الإحداثيات: WGS84 (اضغط للتغيير)", "CRS: WGS84 (tap to change)")
                    : S.t("النظام غير محدد — اضغط للاختيار (الافتراضي WGS84)", "CRS not declared — tap to choose (default WGS84)"), false, null);
            cb.setOnClickListener(v -> UiKit.pickCrs(a, "WGS84", c -> {
                o.sourceCrs = c;
                cb.setText(S.t("نظام الإحداثيات: ", "CRS: ") + UiKit.crsText(c, "WGS84"));
            }));
            box.addView(cb, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        }
        box.addView(UiKit.check(a, S.t("تخطي المعالم المكررة (نفس الاسم وعلى بُعد أقل من 25 م)", "Skip duplicates (same name within 25 m)"), false, v -> o.skipDuplicates = v));
        box.addView(UiKit.check(a, S.t("إصلاح الهندسة البسيطة (حلقات غير مغلقة، نقاط مكررة)", "Fix simple geometry problems"), true, v -> o.fixGeometry = v));
        box.addView(UiKit.check(a, S.t("إصلاح التقاطعات الذاتية للمضلعات (يغيّر الشكل)", "Repair self-intersections (changes shape)"), false, v -> o.makeValid = v));
        final android.app.Dialog d = a.card(ConverterPage.scroll(box));
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, d::dismiss), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("استيراد", "Import"), true, () -> {
            if (sel.isEmpty()) {
                a.toast(S.t("اختر طبقة", "Choose a layer"));
                return;
            }
            o.layers = sel;
            if (table) {
                m.x = cols[0].getSelectedItemPosition() - 1;
                m.y = cols[1].getSelectedItemPosition() - 1;
                m.name = cols[2].getSelectedItemPosition() - 1;
                if (m.combined < 0 && (m.x < 0 || m.y < 0)) {
                    a.toast(S.t("حدّد عمودَي الإحداثيات", "Choose the coordinate columns"));
                    return;
                }
                o.csv = m;
            }
            d.dismiss();
            load(f, name, pv, o);
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    private void load(final File f, final String name, final ImportHub.Preview pv, final ImportHub.Options o) {
        final LinearLayout box = UiKit.col(a);
        final TextView msg = Ui.text(a, S.t("جارٍ الاستيراد…", "Importing…"), 16, Theme.text, true);
        box.addView(msg);
        final boolean[] cancel = {false};
        box.addView(Ui.button(a, S.t("إيقاف", "Stop"), false, () -> cancel[0] = true));
        final android.app.Dialog busy = a.card(box);
        busy.setCancelable(false);
        busy.show();
        new Thread(() -> {
            try {
                final ImportHub.Result res = ImportHub.load(f, name, pv, o, new ImportHub.Progress() {
                    long last;

                    public void update(long n) {
                        if (n - last >= 5000) {
                            last = n;
                            a.runOnUiThread(() -> msg.setText(S.t("جارٍ الاستيراد… ", "Importing… ") + n));
                        }
                    }

                    public boolean cancelled() {
                        return cancel[0];
                    }
                });
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    List<LayerData> added = new ArrayList<>();
                    for (LayerData l : res.layers) {
                        l.kind = "import";
                        added.add(MainActivity.WS.addLayerWithFeatures(l));
                    }
                    a.rebuild();
                    if (!added.isEmpty()) {
                        a.showMap();
                        a.zoomToLayer(added.get(0));
                    }
                    a.message(S.t("تقرير الاستيراد", "Import report"), res.report.toText(S.ar), null, null);
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("فشل الاستيراد", "Import failed"), String.valueOf(t.getMessage()), null, null);
                });
            }
        }).start();
    }
}
