package iq.gis.poiexporter;

import android.net.Uri;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.io.ExportHub;
import iq.gis.poiexporter.core.io.ExportOptions;
import iq.gis.poiexporter.core.io.GeoFormat;
import iq.gis.poiexporter.core.io.Gpkg;
import iq.gis.poiexporter.core.io.ImportHub;
import iq.gis.poiexporter.core.table.PointTable;

/** Import / export hub: preview before import, CRS assignment, pre-flight warnings before export. */
final class HubPage {
    private final MainActivity a;
    private final java.util.Set<String> chosen = new HashSet<>();
    private int fmtIdx = 0;
    private Crs target;
    private boolean attributes = true, separate = false;
    private String fileName = "";

    private static final GeoFormat[] OUT = {GeoFormat.SHP_ZIP, GeoFormat.KML, GeoFormat.KMZ, GeoFormat.GEOJSON, GeoFormat.GPKG,
            GeoFormat.GPX, GeoFormat.CSV, GeoFormat.XLSX, GeoFormat.DXF};

    HubPage(MainActivity a) {
        this.a = a;
    }

    View build() {
        LinearLayout p = UiKit.col(a);
        LinearLayout imp = Ui.card(a);
        imp.addView(UiKit.head(a, S.t("استيراد", "Import")));
        imp.addView(UiKit.note(a, S.t("GeoJSON • KML/KMZ • GPX • Shapefile (ZIP) • CSV/TXT • Excel • GeoPackage • DXF.\nتُعرض معاينة (الطبقات، العدد، النظام، عيّنة) قبل الاستيراد، ويُقرأ نظام الإحداثيات من ملف .prj.",
                "GeoJSON • KML/KMZ • GPX • Shapefile (ZIP) • CSV/TXT • Excel • GeoPackage • DXF.\nA preview (layers, count, CRS, sample) is shown before importing; the CRS is read from .prj.")));
        imp.addView(Ui.button(a, S.t("اختيار ملف…", "Choose file…"), true, a::pickHub), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        imp.addView(Ui.button(a, S.t("📚 استيراد عدة ملفات دفعة واحدة", "📚 Import several files at once"), false, a::pickHubMany), Ui.lp(-1, -2, 0, a, 0, 6, 0, 0));
        imp.addView(Ui.button(a, "📍 " + S.t("استيراد Plus Codes (لصق قائمة)", "Import Plus Codes (paste list)"), false, () -> PlusTools.importDialog(a)), Ui.lp(-1, -2, 0, a, 0, 6, 0, 0));
        imp.addView(UiKit.note(a, S.t("الاستيراد الجماعي يأخذ كل الطبقات بالإعدادات الافتراضية؛ الملفات التي تحتاج تحديد نظام إحداثيات (مثل DXF وShapefile بلا .prj) تُترك لتستورد منفردة.",
                "Bulk import takes every layer with default settings; files that need a CRS chosen (DXF, shapefile without .prj) are left for single import.")));
        p.addView(imp);

        LinearLayout exp = Ui.card(a);
        exp.addView(UiKit.head(a, S.t("تصدير", "Export")));
        exp.addView(Ui.button(a, "📍 " + S.t("تصدير Plus Codes (قائمة نصية)", "Export Plus Codes (text list)"), false, () -> PlusTools.exportDialog(a)), Ui.lp(-1, -2, 0, a, 0, 6, 0, 6));
        exp.addView(Ui.button(a, "</> " + S.t("الطبقات ككود (GeoJSON, Leaflet, Python, SQL, R)", "Layers as code (GeoJSON, Leaflet, Python, SQL, R)"), false, () -> CodeTools.dialog(a)), Ui.lp(-1, -2, 0, a, 0, 6, 0, 6));
        exp.addView(UiKit.label(a, S.t("الطبقات", "Layers")));
        List<LayerData> all = new ArrayList<>(MainActivity.LIB);
        all.addAll(MainActivity.DL);
        if (all.isEmpty()) exp.addView(UiKit.note(a, S.t("لا توجد طبقات. أضف معالم أو نزّل بيانات أولاً.", "No layers yet.")));
        if (all.size() > 1) {
            LinearLayout sn = Ui.row(a);
            sn.addView(Ui.button(a, S.t("تحديد الكل", "Select all"), false, () -> {
                for (LayerData l : all) chosen.add(l.id);
                a.showPage("hub");
            }), Ui.lp(0, -2, 1f, a, 0, 4, 3, 4));
            sn.addView(Ui.button(a, S.t("إلغاء التحديد", "Select none"), false, () -> {
                chosen.clear();
                a.showPage("hub");
            }), Ui.lp(0, -2, 1f, a, 3, 4, 0, 4));
            exp.addView(sn);
        }
        for (final LayerData l : all) {
            exp.addView(UiKit.check(a, l.label + "  (" + l.features.size() + ")", chosen.contains(l.id), v -> {
                if (v) chosen.add(l.id);
                else chosen.remove(l.id);
            }));
        }
        String[] names = new String[OUT.length];
        for (int i = 0; i < OUT.length; i++) names[i] = OUT[i].label;
        exp.addView(UiKit.label(a, S.t("الصيغة", "Format")));
        android.widget.Spinner sp = ConverterPage.spinner(a, java.util.Arrays.asList(names), fmtIdx);
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> parent, View v, int pos, long id) {
                fmtIdx = pos;
            }

            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });
        exp.addView(sp);
        exp.addView(UiKit.label(a, S.t("نظام الإحداثيات", "Coordinate system")));
        final TextView tb = Ui.button(a, UiKit.crsText(target, "EPSG:4326 WGS84"), false, null);
        tb.setOnClickListener(v -> UiKit.pickCrs(a, "EPSG:4326 WGS84", c -> {
            target = c;
            tb.setText(UiKit.crsText(c, "EPSG:4326 WGS84"));
        }));
        exp.addView(tb);
        exp.addView(UiKit.check(a, S.t("تضمين الحقول (الاسم، النوع، الحالة، المصدر…)", "Include attributes"), attributes, v -> attributes = v));
        exp.addView(UiKit.label(a, S.t("اسم الملف (اختياري)", "File name (optional)")));
        final android.widget.EditText fn = Ui.field(a, S.t("يُضاف التاريخ تلقائياً", "The date is added automatically"), android.text.InputType.TYPE_CLASS_TEXT);
        fn.setText(fileName);
        fn.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
                fileName = s.toString();
            }

            public void afterTextChanged(android.text.Editable s) {
            }
        });
        exp.addView(fn);
        exp.addView(UiKit.check(a, S.t("حفظ كل طبقة في ملف مستقل (بدل دمجها في ملف واحد)", "Save each layer as its own file (instead of one merged file)"), separate, v -> separate = v));
        exp.addView(Ui.button(a, S.t("فحص ثم تصدير", "Check & export"), true, this::exportNow), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        exp.addView(UiKit.note(a, S.t("KML وGPX وGeoPackage بنظام WGS84 فقط. Shapefile وCSV وGeoJSON تدعم أي نظام مدعوم. أسماء حقول Shapefile تُحوَّل إلى ASCII (القيم تبقى عربية).",
                "KML, GPX and GeoPackage are WGS84 only. Shapefile, CSV and GeoJSON support any supported CRS. Shapefile field names become ASCII (values stay Arabic).")));
        p.addView(exp);
        return p;
    }

    // ---------------------------------------------------------------- export

    private void exportNow() {
        final List<LayerData> sel = new ArrayList<>();
        List<LayerData> all = new ArrayList<>(MainActivity.LIB);
        all.addAll(MainActivity.DL);
        for (LayerData l : all) if (chosen.contains(l.id)) sel.add(l);
        if (sel.isEmpty()) {
            a.toast(S.t("اختر طبقة واحدة على الأقل", "Choose at least one layer"));
            return;
        }
        final GeoFormat fmt = OUT[fmtIdx];
        if (fmt == GeoFormat.DXF && target == null && sel.size() > 0) {
            // CAD files are metric: the writer picks UTM; nothing to ask
        }
        final ExportOptions o = new ExportOptions();
        o.target = target;
        o.attributes = attributes;
        final List<String> warn = ExportHub.preflight(sel, fmt, o);
        boolean blocking = false;
        for (String w : warn) if (w.contains("WGS84") && w.contains(fmt.label)) blocking = true;
        if (blocking) {
            a.message(S.t("لا يمكن التصدير", "Cannot export"), join(warn), null, null);
            return;
        }
        final Runnable go = () -> {
            if (separate && sel.size() > 1) doExportSeparate(sel, fmt, o);
            else doExport(sel, fmt, o);
        };
        if (warn.isEmpty()) go.run();
        else a.messageConfirm(S.t("تحذيرات قبل التصدير", "Warnings before export"), join(warn), S.t("تصدير رغم ذلك", "Export anyway"), go);
    }

    private static String join(List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String s : l) b.append("• ").append(s).append('\n');
        return b.toString().trim();
    }

    private void doExport(final List<LayerData> sel, final GeoFormat fmt, final ExportOptions o) {
        final LinearLayout box = UiKit.col(a);
        box.addView(Ui.text(a, S.t("جارٍ التصدير…", "Exporting…"), 16, Theme.text, true));
        final android.app.Dialog busy = a.card(box);
        busy.setCancelable(false);
        busy.show();
        final String base = !cleanName(fileName).isEmpty() ? cleanName(fileName)
                : (sel.size() == 1 ? iq.gis.poiexporter.core.ShapeWriter.safeName(sel.get(0).label) : "poi");
        final String stamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(new java.util.Date());
        final String name = (base.isEmpty() ? "poi" : base) + "_" + stamp + (fmt == GeoFormat.SHP_ZIP ? "_shp.zip" : "." + fmt.ext);
        // snapshot on the UI thread
        final List<LayerData> snap = new ArrayList<>();
        for (LayerData l : sel) {
            LayerData c = new LayerData(l.id, l.label, l.geom);
            for (Feature f : l.features) c.features.add(f);
            snap.add(c);
        }
        new Thread(() -> {
            try {
                final Storage.Saved sv = saveOne(snap, fmt, o, name, stamp);
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("تم الحفظ ✔", "Saved ✔"), sv.where, S.t("مشاركة / فتح", "Share / open"), () -> Storage.share(a, sv.uri, fmt.mime));
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("فشل التصدير", "Export failed"), String.valueOf(t.getMessage()), null, null);
                });
            }
        }).start();
    }

    private static String cleanName(String s) {
        if (s == null) return "";
        String t = s.trim().replaceAll("[\\\\/:*?\"<>|\\r\\n]", "_");
        while (t.startsWith(".")) t = t.substring(1);
        return t.length() > 80 ? t.substring(0, 80) : t;
    }

    /** Writes one file (any format, GeoPackage through a temp file) to the chosen folder. Runs off the UI thread. */
    private Storage.Saved saveOne(List<LayerData> snap, final GeoFormat fmt, final ExportOptions o, String name, String stamp) throws Exception {
        if (fmt == GeoFormat.GPKG) {
            final File tmp = new File(a.getCacheDir(), "export_" + stamp + "_" + Math.abs(name.hashCode()) + ".gpkg");
            GpkgAndroid.Writer w = new GpkgAndroid.Writer(tmp);
            try {
                ExportHub.writeGpkg(snap, o, w);
            } finally {
                w.close();
            }
            Storage.Saved sv = Storage.save(a, a.prefs, name, fmt.mime, os -> {
                try (java.io.FileInputStream in = new java.io.FileInputStream(tmp)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                }
            });
            tmp.delete();
            return sv;
        }
        final List<LayerData> fs = snap;
        return Storage.save(a, a.prefs, name, fmt.mime, os -> ExportHub.write(fs, fmt, o, os));
    }

    /** One file per layer; the result lists every saved file. */
    private void doExportSeparate(final List<LayerData> sel, final GeoFormat fmt, final ExportOptions o) {
        final LinearLayout box = UiKit.col(a);
        final TextView msg = Ui.text(a, S.t("جارٍ التصدير…", "Exporting…"), 16, Theme.text, true);
        box.addView(msg);
        final android.app.Dialog busy = a.card(box);
        busy.setCancelable(false);
        busy.show();
        final String stamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(new java.util.Date());
        final String prefix = cleanName(fileName);
        final List<LayerData> snaps = new ArrayList<>();
        for (LayerData l : sel) {
            LayerData c = new LayerData(l.id, l.label, l.geom);
            c.features.addAll(l.features);
            snaps.add(c);
        }
        new Thread(() -> {
            final StringBuilder ok = new StringBuilder(), bad = new StringBuilder();
            java.util.HashSet<String> used = new java.util.HashSet<>();
            int n = 0;
            for (LayerData l : snaps) {
                n++;
                final int k = n;
                a.runOnUiThread(() -> msg.setText(S.t("جارٍ التصدير… ", "Exporting… ") + k + "/" + snaps.size()));
                try {
                    String b = cleanName(l.label);
                    if (b.isEmpty()) b = "layer" + n;
                    if (!prefix.isEmpty()) b = prefix + "_" + b;
                    while (!used.add(b)) b = b + "_" + n;
                    List<LayerData> one = new ArrayList<>();
                    one.add(l);
                    Storage.Saved sv = saveOne(one, fmt, o, b + "_" + stamp + (fmt == GeoFormat.SHP_ZIP ? "_shp.zip" : "." + fmt.ext), stamp);
                    ok.append("✔ ").append(l.label).append(" → ").append(sv.where).append('\n');
                } catch (Throwable t) {
                    bad.append("✖ ").append(l.label).append(": ").append(t.getMessage()).append('\n');
                }
            }
            a.runOnUiThread(() -> {
                busy.dismiss();
                a.message(S.t("اكتمل التصدير", "Export finished"), (ok.toString() + bad).trim(), null, null);
            });
        }).start();
    }

    // ---------------------------------------------------------------- import

    void picked(final Uri u, final String name) {
        a.toast(S.t("جارٍ قراءة الملف…", "Reading file…"));
        new Thread(() -> {
            try {
                final File f = ConverterPage.copyToCache(a, u, name);
                final ImportHub.Preview pv = ImportHub.preview(f, name);
                a.runOnUiThread(() -> previewDialog(f, name, pv));
            } catch (final Throwable t) {
                a.runOnUiThread(() -> a.message(S.t("تعذّرت القراءة", "Cannot read"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }

    /** Several files at once: each is previewed and imported with default settings; files that need a CRS or column choice are skipped. */
    void pickedMany(final List<Uri> uris, final List<String> names) {
        a.toast(S.t("جارٍ استيراد " + uris.size() + " ملفات…", "Importing " + uris.size() + " files…"));
        new Thread(() -> {
            final StringBuilder rep = new StringBuilder();
            final List<LayerData> added = new ArrayList<>();
            for (int i = 0; i < uris.size(); i++) {
                String name = names.get(i);
                try {
                    File f = ConverterPage.copyToCache(a, uris.get(i), name);
                    ImportHub.Preview pv = ImportHub.preview(f, name);
                    boolean table = pv.format == GeoFormat.CSV || pv.format == GeoFormat.XLSX;
                    if (!table && !pv.crsKnown()) {
                        rep.append("↷ ").append(name).append(": ").append(S.t("يحتاج تحديد نظام الإحداثيات — استورده منفرداً", "needs a CRS: import it on its own")).append('\n');
                        continue;
                    }
                    ImportHub.Options o = new ImportHub.Options();
                    Set<Integer> sel = new HashSet<>();
                    for (int k = 0; k < pv.layers.size(); k++) sel.add(k);
                    o.layers = sel;
                    if (table) {
                        PointTable.Mapping m = pv.guess == null ? null : new PointTable.Mapping(pv.guess);
                        if (m == null || (m.combined < 0 && (m.x < 0 || m.y < 0))) {
                            rep.append("↷ ").append(name).append(": ").append(S.t("أعمدة الإحداثيات غير واضحة — استورده منفرداً", "coordinate columns unclear: import it on its own")).append('\n');
                            continue;
                        }
                        o.csv = m;
                    }
                    ImportHub.Result res = ImportHub.load(f, name, pv, o, null);
                    int n = 0;
                    for (LayerData l : res.layers) {
                        l.kind = "import";
                        n += l.features.size();
                        added.add(l);
                    }
                    rep.append("✔ ").append(name).append(": ").append(n).append(S.t(" عنصر", " features")).append('\n');
                } catch (Throwable t) {
                    rep.append("✖ ").append(name).append(": ").append(t.getMessage()).append('\n');
                }
            }
            a.runOnUiThread(() -> {
                LayerData first = null;
                for (LayerData l : added) {
                    LayerData x = MainActivity.WS.addLayerWithFeatures(l);
                    if (first == null) first = x;
                }
                a.rebuild();
                if (first != null) {
                    a.showMap();
                    a.zoomToLayer(first);
                }
                a.message(S.t("تقرير الاستيراد الجماعي", "Bulk import report"), rep.toString().trim(), null, null);
            });
        }).start();
    }

    private void previewDialog(final File f, final String name, final ImportHub.Preview pv) {
        final ImportHub.Options o = new ImportHub.Options();
        final Set<Integer> sel = new HashSet<>();
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, name));
        box.addView(UiKit.note(a, S.t("الصيغة: ", "Format: ") + pv.format.label));
        for (String w : pv.warnings) {
            TextView t = UiKit.note(a, "⚠ " + w);
            t.setTextColor(Theme.danger);
            box.addView(t);
        }
        for (int i = 0; i < pv.layers.size(); i++) {
            final int idx = i;
            ImportHub.LayerInfo li = pv.layers.get(i);
            sel.add(i);
            String crs = li.crs == null ? S.t("نظام غير محدد", "CRS unknown") : li.crs.code();
            box.addView(UiKit.check(a, li.name + "  •  " + li.displayGeom(S.ar) + "  •  " + li.count + "  •  " + crs, true, v -> {
                if (v) sel.add(idx);
                else sel.remove(idx);
            }));
            if (!li.sample.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (java.util.Map<String, String> row : li.sample) {
                    int k = 0;
                    for (java.util.Map.Entry<String, String> e : row.entrySet()) {
                        if (k++ >= 4) break;
                        sb.append(e.getKey()).append('=').append(e.getValue()).append("  ");
                    }
                    sb.append('\n');
                    if (sb.length() > 400) break;
                }
                box.addView(UiKit.note(a, sb.toString().trim()));
            }
        }
        final boolean table = pv.format == GeoFormat.CSV || pv.format == GeoFormat.XLSX;
        final PointTable.Mapping m = table && pv.guess != null ? new PointTable.Mapping(pv.guess) : null;
        final android.widget.Spinner[] cols = new android.widget.Spinner[3];
        if (table) {
            java.util.List<String> ch = ConverterPage.columnChoices(pv.header);
            cols[0] = ConverterPage.spinner(a, ch, m.x + 1);
            cols[1] = ConverterPage.spinner(a, ch, m.y + 1);
            cols[2] = ConverterPage.spinner(a, ch, m.name + 1);
            box.addView(UiKit.label(a, S.t("عمود X / خط الطول", "X / longitude column")));
            box.addView(cols[0]);
            box.addView(UiKit.label(a, S.t("عمود Y / دائرة العرض", "Y / latitude column")));
            box.addView(cols[1]);
            box.addView(UiKit.label(a, S.t("عمود الاسم", "Name column")));
            box.addView(cols[2]);
            box.addView(UiKit.check(a, S.t("العمود الأول هو خط العرض", "First column is latitude"), m.latFirst, v -> m.latFirst = v));
        }
        if (table || !pv.crsKnown()) {
            final TextView cb = Ui.button(a, table ? S.t("نظام الإحداثيات: WGS84 (اضغط للتغيير)", "CRS: WGS84 (tap to change)")
                    : S.t("النظام غير محدد — اضغط للاختيار (الافتراضي WGS84)", "CRS not declared — tap to choose (default WGS84)"), false, null);
            cb.setOnClickListener(v -> UiKit.pickCrs(a, "WGS84", c -> {
                o.sourceCrs = c;
                cb.setText(S.t("نظام الإحداثيات: ", "CRS: ") + UiKit.crsText(c, "WGS84"));
            }));
            box.addView(cb, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        }
        box.addView(UiKit.check(a, S.t("تخطي المعالم المكررة (نفس الاسم وعلى بُعد أقل من 25 م)", "Skip duplicates (same name within 25 m)"), false, v -> o.skipDuplicates = v));
        box.addView(UiKit.check(a, S.t("إصلاح الهندسة البسيطة (حلقات غير مغلقة، نقاط مكررة)", "Fix simple geometry problems"), true, v -> o.fixGeometry = v));
        box.addView(UiKit.check(a, S.t("إصلاح التقاطعات الذاتية للمضلعات (يغيّر الشكل)", "Repair self-intersections (changes shape)"), false, v -> o.makeValid = v));
        final android.app.Dialog d = a.card(ConverterPage.scroll(box));
        LinearLayout r = Ui.row(a);
        r.addView(Ui.button(a, S.t("إلغاء", "Cancel"), false, d::dismiss), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        r.addView(Ui.button(a, S.t("استيراد", "Import"), true, () -> {
            if (sel.isEmpty()) {
                a.toast(S.t("اختر طبقة", "Choose a layer"));
                return;
            }
            o.layers = sel;
            if (table) {
                m.x = cols[0].getSelectedItemPosition() - 1;
                m.y = cols[1].getSelectedItemPosition() - 1;
                m.name = cols[2].getSelectedItemPosition() - 1;
                if (m.combined < 0 && (m.x < 0 || m.y < 0)) {
                    a.toast(S.t("حدّد عمودَي الإحداثيات", "Choose the coordinate columns"));
                    return;
                }
                o.csv = m;
            }
            d.dismiss();
            load(f, name, pv, o);
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    private void load(final File f, final String name, final ImportHub.Preview pv, final ImportHub.Options o) {
        final LinearLayout box = UiKit.col(a);
        final TextView msg = Ui.text(a, S.t("جارٍ الاستيراد…", "Importing…"), 16, Theme.text, true);
        box.addView(msg);
        final boolean[] cancel = {false};
        box.addView(Ui.button(a, S.t("إيقاف", "Stop"), false, () -> cancel[0] = true));
        final android.app.Dialog busy = a.card(box);
        busy.setCancelable(false);
        busy.show();
        new Thread(() -> {
            try {
                final ImportHub.Result res = ImportHub.load(f, name, pv, o, new ImportHub.Progress() {
                    long last;

                    public void update(long n) {
                        if (n - last >= 5000) {
                            last = n;
                            a.runOnUiThread(() -> msg.setText(S.t("جارٍ الاستيراد… ", "Importing… ") + n));
                        }
                    }

                    public boolean cancelled() {
                        return cancel[0];
                    }
                });
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    List<LayerData> added = new ArrayList<>();
                    for (LayerData l : res.layers) {
                        l.kind = "import";
                        added.add(MainActivity.WS.addLayerWithFeatures(l));
                    }
                    a.rebuild();
                    if (!added.isEmpty()) {
                        a.showMap();
                        a.zoomToLayer(added.get(0));
                    }
                    a.message(S.t("تقرير الاستيراد", "Import report"), res.report.toText(S.ar), null, null);
                });
            } catch (final Throwable t) {
                a.runOnUiThread(() -> {
                    busy.dismiss();
                    a.message(S.t("فشل الاستيراد", "Import failed"), String.valueOf(t.getMessage()), null, null);
                });
            }
        }).start();
    }
}
