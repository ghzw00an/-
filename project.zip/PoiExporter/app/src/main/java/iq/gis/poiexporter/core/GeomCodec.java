package iq.gis.poiexporter.core;

import java.nio.ByteBuffer;

/** Compact binary form of a feature geometry for the SQLite store: type, then parts of doubles. */
public final class GeomCodec {
    private GeomCodec() {
    }

    public static byte[] encode(Feature f) {
        int n = 1 + 4;
        for (double[] p : f.parts) n += 1 + 4 + p.length * 8;
        ByteBuffer b = ByteBuffer.allocate(n);
        b.put((byte) f.geom);
        b.putInt(f.parts.size());
        for (int i = 0; i < f.parts.size(); i++) {
            double[] p = f.parts.get(i);
            b.put((byte) (f.isHole(i) ? 1 : 0));
            b.putInt(p.length / 2);
            for (double v : p) b.putDouble(v);
        }
        return b.array();
    }

    /** Fills geom, parts, holes, lat and lon of the feature. */
    public static void decode(byte[] data, Feature f) {
        ByteBuffer b = ByteBuffer.wrap(data);
        f.geom = b.get();
        int np = b.getInt();
        f.parts.clear();
        f.holes.clear();
        for (int i = 0; i < np; i++) {
            boolean hole = b.get() == 1;
            int n = b.getInt();
            double[] p = new double[n * 2];
            for (int k = 0; k < p.length; k++) p[k] = b.getDouble();
            f.parts.add(p);
            f.holes.add(hole);
        }
        Geo.setRepresentative(f);
    }

    /** {minLon, minLat, maxLon, maxLat} of any feature. */
    public static double[] bbox(Feature f) {
        double[] r = {Double.MAX_VALUE, Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE};
        for (double[] p : f.parts) {
            for (int i = 0; i + 1 < p.length; i += 2) {
                r[0] = Math.min(r[0], p[i]);
                r[1] = Math.min(r[1], p[i + 1]);
                r[2] = Math.max(r[2], p[i]);
                r[3] = Math.max(r[3], p[i + 1]);
            }
        }
        return r;
    }
}
