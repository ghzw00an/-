package iq.gis.poiexporter;

import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.geo.Analysis;
import iq.gis.poiexporter.core.geo.LayerTools;

/** Advanced analysis tools. Every tool takes the layer picked at the top, has its own controls, and adds its result as a new layer. */
final class AnalysisPage {
    private final MainActivity a;
    private int layerIdx, fieldIdx, modeIdx, mergeIdx;
    private boolean keepEmpty, hulls = true, polygonPath, sortByName, mbrEach = true;

    AnalysisPage(MainActivity a) {
        this.a = a;
    }

    private List<LayerData> layers() {
        List<LayerData> r = new ArrayList<>(MainActivity.LIB);
        r.addAll(MainActivity.DL);
        return r;
    }

    private interface Job {
        List<LayerData> make();
    }

    private Spinner pick(List<String> items, int sel, final java.util.function.IntConsumer set) {
        Spinner sp = ConverterPage.spinner(a, items, sel);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                set.accept(pos);
            }

            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        return sp;
    }

    private EditText num(String hint, String def) {
        EditText e = Ui.field(a, hint, InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(def);
        return e;
    }

    private static double val(EditText e, String what) {
        try {
            return Double.parseDouble(e.getText().toString().trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(S.t("قيمة غير صالحة: ", "Invalid value: ") + what);
        }
    }

    private List<String> fieldNames() {
        return Arrays.asList(Analysis.FIELD_NAMES);
    }

    /** group: 1 analysis, 2 generate, 3 two layers, 4 bulk edit. */
    View build(final int group) {
        final LinearLayout p = UiKit.col(a);
        final List<LayerData> ls = group == 4 ? new ArrayList<>(MainActivity.LIB) : layers();
        LinearLayout top = Ui.card(a);
        top.addView(UiKit.head(a, S.t("الطبقة المُحلَّلة", "Layer to analyse")));
        if (ls.isEmpty()) {
            top.addView(UiKit.note(a, S.t("لا توجد طبقات. أضف معالم أو استورد بيانات أولاً.", "No layers yet.")));
            p.addView(top);
            return p;
        }
        List<String> names = new ArrayList<>();
        for (LayerData l : ls) names.add(l.label + "  (" + l.features.size() + ")");
        if (layerIdx >= ls.size()) layerIdx = 0;
        if (mergeIdx >= ls.size()) mergeIdx = 0;
        top.addView(pick(names, layerIdx, i -> layerIdx = i));
        if (group == 4) top.addView(UiKit.note(a, S.t("التحرير الجماعي يعمل على طبقات المشروع فقط، ويُنفَّذ كخطوة تراجع واحدة.", "Bulk editing works on project layers only and is ONE undo step.")));
        top.addView(UiKit.note(a, S.t("كل أداة تُنتج طبقة جديدة في المشروع ويمكن التراجع عنها. المسافات تقريبية (مستوى محلي) وتناسب التحليل لا المسح الهندسي.",
                "Each tool adds a new layer to the project and can be undone. Distances use a local plane: fine for analysis, not for surveying.")));
        p.addView(top);

        // 1 filter
        LinearLayout c1 = Ui.card(a);
        c1.addView(UiKit.head(a, S.t("① تصفية بالخصائص", "① Filter by attribute")));
        c1.addView(pick(fieldNames(), fieldIdx, i -> fieldIdx = i));
        c1.addView(pick(Arrays.asList(S.t("يحتوي", "contains"), S.t("يساوي", "equals"), S.t("فارغ", "is empty"), S.t("غير فارغ", "is not empty")), modeIdx, i -> modeIdx = i));
        final EditText ft = Ui.field(a, S.t("النص (يتجاهل الهمزات والتشكيل)", "Text (ignores hamza/diacritics)"), InputType.TYPE_CLASS_TEXT);
        c1.addView(ft);
        c1.addView(Ui.button(a, S.t("تصفية", "Filter"), true, () -> run(() -> one(Analysis.filter(ls.get(layerIdx), fieldIdx, ft.getText().toString(),
                Analysis.Match.values()[modeIdx])))), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        if (group == 1) p.addView(c1);

        // 2 summary
        LinearLayout c2 = Ui.card(a);
        c2.addView(UiKit.head(a, S.t("② ملخص بالعدد (جدول تكراري)", "② Count summary")));
        c2.addView(UiKit.note(a, S.t("يستخدم الحقل المختار في البند ①. مثال: عدد المعالم لكل قطاع أو محافظة.", "Uses the field chosen in ①. Example: landmarks per sector or governorate.")));
        c2.addView(Ui.button(a, S.t("عرض الملخص", "Show summary"), false, () -> {
            LayerData l = ls.get(layerIdx);
            final String t = Analysis.summaryText(l, fieldIdx, S.ar);
            a.message(l.label + " — " + Analysis.FIELD_NAMES[fieldIdx], t.isEmpty() ? "—" : t, S.t("نسخ", "Copy"), () -> a.copy(t));
        }));
        if (group == 1) p.addView(c2);

        // 3 proximity
        LinearLayout c3 = Ui.card(a);
        c3.addView(UiKit.head(a, S.t("③ ما حول نقطة (نصف قطر)", "③ Around a point (radius)")));
        final EditText rad = num(S.t("نصف القطر بالمتر", "Radius in metres"), "500");
        c3.addView(rad);
        c3.addView(Ui.button(a, S.t("حول مركز الخريطة", "Around the map centre"), false, () -> {
            org.osmdroid.api.IGeoPoint c = a.map.getMapCenter();
            run(() -> one(Analysis.withinRadius(ls.get(layerIdx), c.getLatitude(), c.getLongitude(), val(rad, "radius"))));
        }), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        if (group == 1) p.addView(c3);

        // 4 centroids
        LinearLayout c4 = Ui.card(a);
        c4.addView(UiKit.head(a, S.t("④ مراكز العناصر", "④ Centroids")));
        c4.addView(Ui.button(a, S.t("إنشاء نقاط المراكز", "Create centroid points"), false, () -> run(() -> one(Analysis.centroids(ls.get(layerIdx))))));
        if (group == 2) p.addView(c4);

        // 5 density
        LinearLayout c5 = Ui.card(a);
        c5.addView(UiKit.head(a, S.t("⑤ شبكة كثافة النقاط", "⑤ Point density grid")));
        final EditText cell = num(S.t("حجم الخلية بالمتر", "Cell size in metres"), "500");
        c5.addView(cell);
        c5.addView(UiKit.check(a, S.t("إبقاء الخلايا الفارغة", "Keep empty cells"), keepEmpty, v -> keepEmpty = v));
        c5.addView(Ui.button(a, S.t("إنشاء الشبكة", "Create grid"), false, () -> run(() -> one(Analysis.densityGrid(ls.get(layerIdx), val(cell, "cell"), keepEmpty)))),
                Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        if (group == 1) p.addView(c5);

        // 6 thiessen
        LinearLayout c6 = Ui.card(a);
        c6.addView(UiKit.head(a, S.t("⑥ مضلعات ثيسن (منطقة نفوذ كل نقطة)", "⑥ Thiessen polygons (each point's zone)")));
        c6.addView(Ui.button(a, S.t("إنشاء مضلعات ثيسن", "Create Thiessen polygons"), false, () -> run(() -> one(Analysis.thiessen(ls.get(layerIdx))))));
        if (group == 2) p.addView(c6);

        // 7 clusters
        LinearLayout c7 = Ui.card(a);
        c7.addView(UiKit.head(a, S.t("⑦ تجمعات النقاط (DBSCAN)", "⑦ Point clusters (DBSCAN)")));
        final EditText eps = num(S.t("المسافة بالمتر", "Distance in metres"), "150");
        final EditText minp = num(S.t("أقل عدد نقاط في التجمع", "Minimum points per cluster"), "4");
        c7.addView(eps);
        c7.addView(minp);
        c7.addView(UiKit.check(a, S.t("طبقة حدود التجمعات (غلاف محدب)", "Cluster outline layer (convex hull)"), hulls, v -> hulls = v));
        c7.addView(Ui.button(a, S.t("كشف التجمعات", "Find clusters"), false, () -> run(() -> Analysis.clusterLayers(ls.get(layerIdx), val(eps, "distance"),
                (int) val(minp, "min points"), hulls))), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        if (group == 1) p.addView(c7);

        // 8 NN
        LinearLayout c8 = Ui.card(a);
        c8.addView(UiKit.head(a, S.t("⑧ مؤشر أقرب جار (هل التوزيع متجمّع؟)", "⑧ Nearest-neighbour index")));
        c8.addView(Ui.button(a, S.t("احسب المؤشر", "Compute"), false, () -> {
            final LayerData l = ls.get(layerIdx);
            new Thread(() -> {
                try {
                    final String t = Analysis.nearestNeighbour(l).toText(S.ar);
                    a.runOnUiThread(() -> a.message(l.label, t, S.t("نسخ", "Copy"), () -> a.copy(t)));
                } catch (Throwable e) {
                    fail(e);
                }
            }).start();
        }));
        if (group == 1) p.addView(c8);

        // 9 MBR
        LinearLayout c9 = Ui.card(a);
        c9.addView(UiKit.head(a, S.t("⑨ أصغر مستطيل محيط", "⑨ Minimum bounding rectangle")));
        c9.addView(UiKit.check(a, S.t("مستطيل لكل عنصر (وإلا فمستطيل للطبقة كلها)", "One per feature (otherwise one for the whole layer)"), mbrEach, v -> mbrEach = v));
        c9.addView(Ui.button(a, S.t("إنشاء", "Create"), false, () -> run(() -> one(Analysis.boundingRectangles(ls.get(layerIdx), mbrEach)))));
        if (group == 2) p.addView(c9);

        // 10 path
        LinearLayout c10 = Ui.card(a);
        c10.addView(UiKit.head(a, S.t("⑩ خط أو مضلع من النقاط", "⑩ Line or polygon from points")));
        c10.addView(UiKit.check(a, S.t("مضلع مغلق (وإلا خط)", "Closed polygon (otherwise a line)"), polygonPath, v -> polygonPath = v));
        c10.addView(UiKit.check(a, S.t("ترتيب النقاط حسب الاسم (وإلا حسب ترتيب الطبقة)", "Order by name (otherwise layer order)"), sortByName, v -> sortByName = v));
        c10.addView(Ui.button(a, S.t("إنشاء", "Create"), false, () -> run(() -> one(Analysis.pointPath(ls.get(layerIdx), polygonPath, sortByName)))));
        if (group == 2) p.addView(c10);

        // 11 simplify
        LinearLayout c11 = Ui.card(a);
        c11.addView(UiKit.head(a, S.t("⑪ تبسيط الخطوط والمضلعات", "⑪ Simplify lines and polygons")));
        final EditText tol = num(S.t("التسامح بالمتر", "Tolerance in metres"), "10");
        c11.addView(tol);
        c11.addView(Ui.button(a, S.t("تبسيط", "Simplify"), false, () -> run(() -> one(Analysis.simplifyLayer(ls.get(layerIdx), val(tol, "tolerance"))))),
                Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        if (group == 2) p.addView(c11);

        // 12 merge
        LinearLayout c12 = Ui.card(a);
        c12.addView(UiKit.head(a, S.t("⑫ دمج طبقتين", "⑫ Merge two layers")));
        c12.addView(UiKit.note(a, S.t("تُدمج الطبقة المُحلَّلة مع الطبقة التالية (يجب أن يتطابق نوع الهندسة).", "The analysed layer is merged with the one below (same geometry type).")));
        c12.addView(pick(names, mergeIdx, i -> mergeIdx = i));
        c12.addView(Ui.button(a, S.t("دمج", "Merge"), false, () -> run(() -> {
            LayerData x = ls.get(layerIdx), y = ls.get(mergeIdx);
            if (x == y) throw new IllegalArgumentException(S.t("اختر طبقة مختلفة", "Pick a different layer"));
            return one(Analysis.merge(Arrays.asList(x, y), x.label + " + " + y.label));
        })), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        if (group == 3) p.addView(c12);

        if (group == 1) {
            // mean centre
            LinearLayout c13 = Ui.card(a);
            c13.addView(UiKit.head(a, S.t("⑬ المركز المتوسط والمسافة المعيارية", "⑬ Mean centre and standard distance")));
            c13.addView(UiKit.note(a, S.t("نقطة المركز ودائرة تضم نحو ثلثي انتشار النقاط.", "The centre point and a circle holding about two thirds of the spread.")));
            c13.addView(Ui.button(a, S.t("حساب", "Compute"), false, () -> run(() -> LayerTools.meanCentreLayers(ls.get(layerIdx)))));
            p.addView(c13);
        }
        if (group == 2) {
            LinearLayout g1 = Ui.card(a);
            g1.addView(UiKit.head(a, S.t("⑭ حلقات حول العناصر (Multi-ring buffer)", "⑭ Multi-ring buffers")));
            final EditText rd = Ui.field(a, S.t("المسافات بالمتر مفصولة بفواصل", "Distances in metres, comma separated"), InputType.TYPE_CLASS_TEXT);
            rd.setText("100,250,500");
            g1.addView(rd);
            g1.addView(Ui.button(a, S.t("إنشاء الحلقات", "Create rings"), false, () -> run(() -> one(LayerTools.multiRing(ls.get(layerIdx), parseList(rd.getText().toString()))))),
                    Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
            p.addView(g1);

            LinearLayout g2 = Ui.card(a);
            g2.addView(UiKit.head(a, S.t("⑮ نقاط على امتداد الخطوط والحدود", "⑮ Points along lines and outlines")));
            final EditText iv = num(S.t("كل كم متر", "Every N metres"), "100");
            g2.addView(iv);
            g2.addView(UiKit.check(a, S.t("إضافة نقطة النهاية", "Add the end point"), alongEnds, v -> alongEnds = v));
            g2.addView(Ui.button(a, S.t("إنشاء النقاط", "Create points"), false, () -> run(() -> one(LayerTools.alongLines(ls.get(layerIdx), val(iv, "interval"), alongEnds)))),
                    Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
            p.addView(g2);

            LinearLayout g3 = Ui.card(a);
            g3.addView(UiKit.head(a, S.t("⑯ تفكيك الشكل", "⑯ Break shapes apart")));
            LinearLayout r3 = Ui.row(a);
            r3.addView(Ui.button(a, S.t("رؤوس كنقاط", "Vertices"), false, () -> run(() -> one(LayerTools.vertices(ls.get(layerIdx))))), Ui.lp(0, -2, 1f, a, 0, 4, 3, 0));
            r3.addView(Ui.button(a, S.t("حدود كخطوط", "Outlines"), false, () -> run(() -> one(LayerTools.boundaries(ls.get(layerIdx))))), Ui.lp(0, -2, 1f, a, 3, 4, 3, 0));
            r3.addView(Ui.button(a, S.t("أجزاء", "Parts"), false, () -> run(() -> one(LayerTools.explode(ls.get(layerIdx))))), Ui.lp(0, -2, 1f, a, 3, 4, 0, 0));
            g3.addView(r3);
            p.addView(g3);

            LinearLayout g4 = Ui.card(a);
            g4.addView(UiKit.head(a, S.t("⑰ نقاط داخل المضلعات", "⑰ Points inside polygons")));
            final EditText cnt = num(S.t("عدد النقاط العشوائية", "Number of random points"), "100");
            final EditText seed = num(S.t("البذرة (نفس الرقم = نفس النتيجة)", "Seed (same number = same result)"), "1");
            final EditText sp = num(S.t("مسافة الشبكة المنتظمة بالمتر", "Regular grid spacing in metres"), "200");
            g4.addView(cnt);
            g4.addView(seed);
            g4.addView(Ui.button(a, S.t("نقاط عشوائية", "Random points"), false, () -> run(() -> one(LayerTools.randomPoints(ls.get(layerIdx), (int) val(cnt, "count"), (long) val(seed, "seed"))))),
                    Ui.lp(-1, -2, 0, a, 0, 8, 0, 8));
            g4.addView(sp);
            g4.addView(Ui.button(a, S.t("شبكة نقاط منتظمة", "Regular point grid"), false, () -> run(() -> one(LayerTools.regularPoints(ls.get(layerIdx), val(sp, "spacing"))))),
                    Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
            p.addView(g4);

            LinearLayout g5 = Ui.card(a);
            g5.addView(UiKit.head(a, S.t("⑱ دمج وغلاف حسب حقل", "⑱ Dissolve / hull by field")));
            g5.addView(UiKit.note(a, S.t("يستخدم الحقل المختار في البند ① من تبويب «تحليل».", "Uses the field chosen in ① on the Analysis tab.")));
            g5.addView(pick(fieldNames(), fieldIdx, i -> fieldIdx = i));
            LinearLayout r5 = Ui.row(a);
            r5.addView(Ui.button(a, S.t("دمج المضلعات", "Dissolve"), false, () -> run(() -> one(LayerTools.dissolveBy(ls.get(layerIdx), fieldIdx)))), Ui.lp(0, -2, 1f, a, 0, 6, 3, 0));
            r5.addView(Ui.button(a, S.t("غلاف لكل قيمة", "Hull per value"), false, () -> run(() -> one(LayerTools.hullBy(ls.get(layerIdx), fieldIdx)))), Ui.lp(0, -2, 1f, a, 3, 6, 0, 0));
            g5.addView(r5);
            p.addView(g5);
        }
        if (group == 3) {
            LinearLayout b0 = Ui.card(a);
            b0.addView(UiKit.head(a, S.t("الطبقة الثانية (B)", "Second layer (B)")));
            b0.addView(UiKit.note(a, S.t("الطبقة المُحلَّلة أعلاه هي A. اختر B هنا.", "The analysed layer above is A. Pick B here.")));
            b0.addView(pick(names, mergeIdx, i -> mergeIdx = i));
            p.addView(b0);
            LinearLayout h1 = Ui.card(a);
            h1.addView(UiKit.head(a, S.t("⑲ محو A بمضلعات B", "⑲ Erase A with B's polygons")));
            h1.addView(Ui.button(a, S.t("تنفيذ المحو", "Erase"), false, () -> run(() -> one(LayerTools.erase(ls.get(layerIdx), other(ls))))));
            p.addView(h1);
            LinearLayout h2 = Ui.card(a);
            h2.addView(UiKit.head(a, S.t("⑳ تقاطع A مع مضلعات B", "⑳ Intersect A with B's polygons")));
            h2.addView(Ui.button(a, S.t("تنفيذ التقاطع", "Intersect"), false, () -> run(() -> one(LayerTools.intersect(ls.get(layerIdx), other(ls))))));
            p.addView(h2);
            LinearLayout h3 = Ui.card(a);
            h3.addView(UiKit.head(a, S.t("㉑ عدّ نقاط A داخل مضلعات B", "㉑ Count A's points inside B's polygons")));
            h3.addView(Ui.button(a, S.t("عدّ", "Count"), false, () -> run(() -> one(LayerTools.countInPolygons(ls.get(layerIdx), other(ls))))));
            p.addView(h3);
            LinearLayout h4 = Ui.card(a);
            h4.addView(UiKit.head(a, S.t("㉒ أقرب عنصر في B لكل عنصر في A", "㉒ Nearest B feature for each A feature")));
            h4.addView(Ui.button(a, S.t("ربط الأقرب", "Join nearest"), false, () -> run(() -> one(LayerTools.nearestJoin(ls.get(layerIdx), other(ls))))));
            p.addView(h4);
            LinearLayout h5 = Ui.card(a);
            h5.addView(UiKit.head(a, S.t("㉓ عناصر A ضمن مسافة من B", "㉓ A features within a distance of B")));
            final EditText wd = num(S.t("المسافة بالمتر", "Distance in metres"), "300");
            h5.addView(wd);
            h5.addView(Ui.button(a, S.t("تحديد", "Select"), false, () -> run(() -> one(LayerTools.withinDistanceOf(ls.get(layerIdx), other(ls), val(wd, "distance"))))),
                    Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
            p.addView(h5);
        }
        if (group == 4) {
            LinearLayout e1 = Ui.card(a);
            e1.addView(UiKit.head(a, S.t("㉔ تصنيف القطاع تلقائياً من النوع", "㉔ Auto-assign sector from type")));
            e1.addView(UiKit.note(a, S.t("يملأ Gategory من type حسب قائمة القطاعات (مثل مسجد ← القطاع الديني). الأنواع الموجودة في أكثر من قطاع (مثل مخزن) تُترك.", "Fills Gategory from type using the sector list. Types that belong to several sectors (e.g. مخزن) are left alone.")));
            e1.addView(UiKit.check(a, S.t("استبدال القيم الموجودة", "Overwrite existing values"), overwriteSector, v -> overwriteSector = v));
            e1.addView(Ui.button(a, S.t("تصنيف", "Classify"), false, () -> edit(ls, S.t("تصنيف القطاع", "Auto sector"), l -> LayerTools.autoSector(l.features, overwriteSector))));
            p.addView(e1);
            LinearLayout e2 = Ui.card(a);
            e2.addView(UiKit.head(a, S.t("㉕ تعيين قيمة لحقل", "㉕ Set a field value")));
            e2.addView(pick(fieldNames(), fieldIdx, i -> fieldIdx = i));
            final EditText sv = Ui.field(a, S.t("القيمة", "Value"), InputType.TYPE_CLASS_TEXT);
            e2.addView(sv);
            e2.addView(UiKit.check(a, S.t("للحقول الفارغة فقط", "Only where empty"), onlyEmpty, v -> onlyEmpty = v));
            e2.addView(Ui.button(a, S.t("تطبيق على الطبقة", "Apply to the layer"), false, () -> edit(ls, S.t("تعيين حقل", "Set field"),
                    l -> LayerTools.setField(l.features, fieldIdx, sv.getText().toString().trim(), onlyEmpty))));
            p.addView(e2);
            LinearLayout e3 = Ui.card(a);
            e3.addView(UiKit.head(a, S.t("㉖ استبدال نص في حقل", "㉖ Replace text in a field")));
            final EditText fd = Ui.field(a, S.t("البحث عن", "Find"), InputType.TYPE_CLASS_TEXT);
            final EditText rp = Ui.field(a, S.t("استبدال بـ", "Replace with"), InputType.TYPE_CLASS_TEXT);
            e3.addView(fd);
            e3.addView(rp);
            e3.addView(Ui.button(a, S.t("استبدال (في الحقل المختار أعلاه)", "Replace (in the field chosen above)"), false, () -> edit(ls, S.t("استبدال نص", "Replace text"),
                    l -> LayerTools.replaceText(l.features, fieldIdx, fd.getText().toString(), rp.getText().toString()))), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
            p.addView(e3);
            LinearLayout e4 = Ui.card(a);
            e4.addView(UiKit.head(a, S.t("㉗ تنظيف النصوص العربية", "㉗ Clean Arabic text")));
            e4.addView(UiKit.note(a, S.t("يوحّد ى/ی→ي وک→ك، يحذف التطويل والمسافات الزائدة في الحقول الستة.", "Unifies Arabic letter variants, drops tatweel and extra spaces in the six text fields.")));
            e4.addView(Ui.button(a, S.t("تنظيف", "Clean"), false, () -> edit(ls, S.t("تنظيف النصوص", "Clean text"), l -> LayerTools.cleanText(l.features))));
            p.addView(e4);
            LinearLayout e5 = Ui.card(a);
            e5.addView(UiKit.head(a, S.t("㉘ إضافة المساحة والطول كخصائص", "㉘ Add area / length as attributes")));
            e5.addView(Ui.button(a, S.t("إضافة", "Add"), false, () -> edit(ls, S.t("إضافة القياسات", "Add measures"), l -> LayerTools.addMeasures(l.features))));
            p.addView(e5);
        }
        return p;
    }

    private boolean alongEnds = true, overwriteSector, onlyEmpty = true;

    private LayerData other(List<LayerData> ls) {
        LayerData x = ls.get(layerIdx), y = ls.get(mergeIdx);
        if (x == y) throw new IllegalArgumentException(S.t("اختر في B طبقة غير A", "Pick a layer for B that is not A"));
        return y;
    }

    private static double[] parseList(String s) {
        String[] t = s.split("[,،;\\s]+");
        List<Double> r = new ArrayList<>();
        for (String x : t) {
            if (x.trim().isEmpty()) continue;
            try {
                r.add(Double.parseDouble(x.trim()));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException(S.t("قيمة غير صالحة: ", "Invalid value: ") + x);
            }
        }
        double[] d = new double[r.size()];
        for (int i = 0; i < d.length; i++) d[i] = r.get(i);
        return d;
    }

    private interface EditJob {
        LayerTools.Edits make(LayerData l);
    }

    /** Runs a bulk edit on the picked project layer as ONE undo step, after showing how many features would change. */
    private void edit(final List<LayerData> ls, final String label, final EditJob job) {
        final LayerData l = ls.get(layerIdx);
        new Thread(() -> {
            try {
                final LayerTools.Edits e = job.make(l);
                a.runOnUiThread(() -> {
                    if (e.pairs.isEmpty()) {
                        a.message(label, S.t("لا شيء يتغيّر. ", "Nothing would change. ") + e.note, null, null);
                        return;
                    }
                    a.messageConfirm(label, S.t("سيتغير " + e.pairs.size() + " عنصراً في «" + l.label + "». يمكن التراجع.", e.pairs.size() + " features in \"" + l.label + "\" will change. Undo is available.")
                            + (e.skipped > 0 ? "\n" + S.t("متروك: ", "Skipped: ") + e.skipped : "") + (e.note.isEmpty() ? "" : "\n" + e.note), S.t("تطبيق", "Apply"), () -> {
                        List<Feature> before = new ArrayList<>(), after = new ArrayList<>();
                        for (Feature[] pr : e.pairs) {
                            before.add(pr[0]);
                            after.add(pr[1]);
                        }
                        MainActivity.WS.updateFeatures(l.id, before, after, label);
                        a.rebuild();
                        a.toast(S.t("تم تعديل " + e.pairs.size() + " عنصراً", e.pairs.size() + " features changed"));
                    });
                });
            } catch (Throwable t) {
                fail(t);
            }
        }).start();
    }


    private static List<LayerData> one(LayerData l) {
        List<LayerData> r = new ArrayList<>();
        r.add(l);
        return r;
    }

    private void fail(final Throwable t) {
        ErrorLog.add("analysis", t);
        a.runOnUiThread(() -> a.message(S.t("تعذّرت العملية", "Operation failed"), String.valueOf(t.getMessage()), null, null));
    }

    private void run(final Job job) {
        a.toast(S.t("جارٍ التنفيذ…", "Working…"));
        new Thread(() -> {
            try {
                final List<LayerData> out = job.make();
                a.runOnUiThread(() -> {
                    int n = 0;
                    LayerData first = null;
                    for (LayerData r : out) {
                        if (r.features.isEmpty()) continue;
                        LayerData added = MainActivity.WS.addLayerWithFeatures(r);
                        if (first == null) first = added;
                        n += added.features.size();
                    }
                    if (first == null) {
                        a.message(S.t("النتيجة فارغة", "Empty result"), S.t("لم يُعثر على عناصر تطابق الشرط.", "No features matched."), null, null);
                        return;
                    }
                    a.rebuild();
                    a.showMap();
                    a.zoomToLayer(first);
                    a.toast(S.t("أُنشئت طبقة: ", "Layer created: ") + first.label + " (" + n + ")");
                });
            } catch (final Throwable t) {
                fail(t);
            }
        }).start();
    }
}
