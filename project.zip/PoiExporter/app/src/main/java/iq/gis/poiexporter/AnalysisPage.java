package iq.gis.poiexporter;

import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.geo.Analysis;

/** Advanced analysis tools. Every tool takes the layer picked at the top, has its own controls, and adds its result as a new layer. */
final class AnalysisPage {
    private final MainActivity a;
    private int layerIdx, fieldIdx, modeIdx, mergeIdx;
    private boolean keepEmpty, hulls = true, polygonPath, sortByName, mbrEach = true;

    AnalysisPage(MainActivity a) {
        this.a = a;
    }

    private List<LayerData> layers() {
        List<LayerData> r = new ArrayList<>(MainActivity.LIB);
        r.addAll(MainActivity.DL);
        return r;
    }

    private interface Job {
        List<LayerData> make();
    }

    private Spinner pick(List<String> items, int sel, final java.util.function.IntConsumer set) {
        Spinner sp = ConverterPage.spinner(a, items, sel);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                set.accept(pos);
            }

            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        return sp;
    }

    private EditText num(String hint, String def) {
        EditText e = Ui.field(a, hint, InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(def);
        return e;
    }

    private static double val(EditText e, String what) {
        try {
            return Double.parseDouble(e.getText().toString().trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(S.t("قيمة غير صالحة: ", "Invalid value: ") + what);
        }
    }

    private List<String> fieldNames() {
        return Arrays.asList(Analysis.FIELD_NAMES);
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        final List<LayerData> ls = layers();
        LinearLayout top = Ui.card(a);
        top.addView(UiKit.head(a, S.t("الطبقة المُحلَّلة", "Layer to analyse")));
        if (ls.isEmpty()) {
            top.addView(UiKit.note(a, S.t("لا توجد طبقات. أضف معالم أو استورد بيانات أولاً.", "No layers yet.")));
            p.addView(top);
            return p;
        }
        List<String> names = new ArrayList<>();
        for (LayerData l : ls) names.add(l.label + "  (" + l.features.size() + ")");
        if (layerIdx >= ls.size()) layerIdx = 0;
        if (mergeIdx >= ls.size()) mergeIdx = 0;
        top.addView(pick(names, layerIdx, i -> layerIdx = i));
        top.addView(UiKit.note(a, S.t("كل أداة تُنتج طبقة جديدة في المشروع ويمكن التراجع عنها. المسافات تقريبية (مستوى محلي) وتناسب التحليل لا المسح الهندسي.",
                "Each tool adds a new layer to the project and can be undone. Distances use a local plane: fine for analysis, not for surveying.")));
        p.addView(top);

        // 1 filter
        LinearLayout c1 = Ui.card(a);
        c1.addView(UiKit.head(a, S.t("① تصفية بالخصائص", "① Filter by attribute")));
        c1.addView(pick(fieldNames(), fieldIdx, i -> fieldIdx = i));
        c1.addView(pick(Arrays.asList(S.t("يحتوي", "contains"), S.t("يساوي", "equals"), S.t("فارغ", "is empty"), S.t("غير فارغ", "is not empty")), modeIdx, i -> modeIdx = i));
        final EditText ft = Ui.field(a, S.t("النص (يتجاهل الهمزات والتشكيل)", "Text (ignores hamza/diacritics)"), InputType.TYPE_CLASS_TEXT);
        c1.addView(ft);
        c1.addView(Ui.button(a, S.t("تصفية", "Filter"), true, () -> run(() -> one(Analysis.filter(ls.get(layerIdx), fieldIdx, ft.getText().toString(),
                Analysis.Match.values()[modeIdx])))), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(c1);

        // 2 summary
        LinearLayout c2 = Ui.card(a);
        c2.addView(UiKit.head(a, S.t("② ملخص بالعدد (جدول تكراري)", "② Count summary")));
        c2.addView(UiKit.note(a, S.t("يستخدم الحقل المختار في البند ①. مثال: عدد المعالم لكل قطاع أو محافظة.", "Uses the field chosen in ①. Example: landmarks per sector or governorate.")));
        c2.addView(Ui.button(a, S.t("عرض الملخص", "Show summary"), false, () -> {
            LayerData l = ls.get(layerIdx);
            final String t = Analysis.summaryText(l, fieldIdx, S.ar);
            a.message(l.label + " — " + Analysis.FIELD_NAMES[fieldIdx], t.isEmpty() ? "—" : t, S.t("نسخ", "Copy"), () -> a.copy(t));
        }));
        p.addView(c2);

        // 3 proximity
        LinearLayout c3 = Ui.card(a);
        c3.addView(UiKit.head(a, S.t("③ ما حول نقطة (نصف قطر)", "③ Around a point (radius)")));
        final EditText rad = num(S.t("نصف القطر بالمتر", "Radius in metres"), "500");
        c3.addView(rad);
        c3.addView(Ui.button(a, S.t("حول مركز الخريطة", "Around the map centre"), false, () -> {
            org.osmdroid.api.IGeoPoint c = a.map.getMapCenter();
            run(() -> one(Analysis.withinRadius(ls.get(layerIdx), c.getLatitude(), c.getLongitude(), val(rad, "radius"))));
        }), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(c3);

        // 4 centroids
        LinearLayout c4 = Ui.card(a);
        c4.addView(UiKit.head(a, S.t("④ مراكز العناصر", "④ Centroids")));
        c4.addView(Ui.button(a, S.t("إنشاء نقاط المراكز", "Create centroid points"), false, () -> run(() -> one(Analysis.centroids(ls.get(layerIdx))))));
        p.addView(c4);

        // 5 density
        LinearLayout c5 = Ui.card(a);
        c5.addView(UiKit.head(a, S.t("⑤ شبكة كثافة النقاط", "⑤ Point density grid")));
        final EditText cell = num(S.t("حجم الخلية بالمتر", "Cell size in metres"), "500");
        c5.addView(cell);
        c5.addView(UiKit.check(a, S.t("إبقاء الخلايا الفارغة", "Keep empty cells"), keepEmpty, v -> keepEmpty = v));
        c5.addView(Ui.button(a, S.t("إنشاء الشبكة", "Create grid"), false, () -> run(() -> one(Analysis.densityGrid(ls.get(layerIdx), val(cell, "cell"), keepEmpty)))),
                Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(c5);

        // 6 thiessen
        LinearLayout c6 = Ui.card(a);
        c6.addView(UiKit.head(a, S.t("⑥ مضلعات ثيسن (منطقة نفوذ كل نقطة)", "⑥ Thiessen polygons (each point's zone)")));
        c6.addView(Ui.button(a, S.t("إنشاء مضلعات ثيسن", "Create Thiessen polygons"), false, () -> run(() -> one(Analysis.thiessen(ls.get(layerIdx))))));
        p.addView(c6);

        // 7 clusters
        LinearLayout c7 = Ui.card(a);
        c7.addView(UiKit.head(a, S.t("⑦ تجمعات النقاط (DBSCAN)", "⑦ Point clusters (DBSCAN)")));
        final EditText eps = num(S.t("المسافة بالمتر", "Distance in metres"), "150");
        final EditText minp = num(S.t("أقل عدد نقاط في التجمع", "Minimum points per cluster"), "4");
        c7.addView(eps);
        c7.addView(minp);
        c7.addView(UiKit.check(a, S.t("طبقة حدود التجمعات (غلاف محدب)", "Cluster outline layer (convex hull)"), hulls, v -> hulls = v));
        c7.addView(Ui.button(a, S.t("كشف التجمعات", "Find clusters"), false, () -> run(() -> Analysis.clusterLayers(ls.get(layerIdx), val(eps, "distance"),
                (int) val(minp, "min points"), hulls))), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(c7);

        // 8 NN
        LinearLayout c8 = Ui.card(a);
        c8.addView(UiKit.head(a, S.t("⑧ مؤشر أقرب جار (هل التوزيع متجمّع؟)", "⑧ Nearest-neighbour index")));
        c8.addView(Ui.button(a, S.t("احسب المؤشر", "Compute"), false, () -> {
            final LayerData l = ls.get(layerIdx);
            new Thread(() -> {
                try {
                    final String t = Analysis.nearestNeighbour(l).toText(S.ar);
                    a.runOnUiThread(() -> a.message(l.label, t, S.t("نسخ", "Copy"), () -> a.copy(t)));
                } catch (Throwable e) {
                    fail(e);
                }
            }).start();
        }));
        p.addView(c8);

        // 9 MBR
        LinearLayout c9 = Ui.card(a);
        c9.addView(UiKit.head(a, S.t("⑨ أصغر مستطيل محيط", "⑨ Minimum bounding rectangle")));
        c9.addView(UiKit.check(a, S.t("مستطيل لكل عنصر (وإلا فمستطيل للطبقة كلها)", "One per feature (otherwise one for the whole layer)"), mbrEach, v -> mbrEach = v));
        c9.addView(Ui.button(a, S.t("إنشاء", "Create"), false, () -> run(() -> one(Analysis.boundingRectangles(ls.get(layerIdx), mbrEach)))));
        p.addView(c9);

        // 10 path
        LinearLayout c10 = Ui.card(a);
        c10.addView(UiKit.head(a, S.t("⑩ خط أو مضلع من النقاط", "⑩ Line or polygon from points")));
        c10.addView(UiKit.check(a, S.t("مضلع مغلق (وإلا خط)", "Closed polygon (otherwise a line)"), polygonPath, v -> polygonPath = v));
        c10.addView(UiKit.check(a, S.t("ترتيب النقاط حسب الاسم (وإلا حسب ترتيب الطبقة)", "Order by name (otherwise layer order)"), sortByName, v -> sortByName = v));
        c10.addView(Ui.button(a, S.t("إنشاء", "Create"), false, () -> run(() -> one(Analysis.pointPath(ls.get(layerIdx), polygonPath, sortByName)))));
        p.addView(c10);

        // 11 simplify
        LinearLayout c11 = Ui.card(a);
        c11.addView(UiKit.head(a, S.t("⑪ تبسيط الخطوط والمضلعات", "⑪ Simplify lines and polygons")));
        final EditText tol = num(S.t("التسامح بالمتر", "Tolerance in metres"), "10");
        c11.addView(tol);
        c11.addView(Ui.button(a, S.t("تبسيط", "Simplify"), false, () -> run(() -> one(Analysis.simplifyLayer(ls.get(layerIdx), val(tol, "tolerance"))))),
                Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(c11);

        // 12 merge
        LinearLayout c12 = Ui.card(a);
        c12.addView(UiKit.head(a, S.t("⑫ دمج طبقتين", "⑫ Merge two layers")));
        c12.addView(UiKit.note(a, S.t("تُدمج الطبقة المُحلَّلة مع الطبقة التالية (يجب أن يتطابق نوع الهندسة).", "The analysed layer is merged with the one below (same geometry type).")));
        c12.addView(pick(names, mergeIdx, i -> mergeIdx = i));
        c12.addView(Ui.button(a, S.t("دمج", "Merge"), false, () -> run(() -> {
            LayerData x = ls.get(layerIdx), y = ls.get(mergeIdx);
            if (x == y) throw new IllegalArgumentException(S.t("اختر طبقة مختلفة", "Pick a different layer"));
            return one(Analysis.merge(Arrays.asList(x, y), x.label + " + " + y.label));
        })), Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        p.addView(c12);
        return p;
    }

    private static List<LayerData> one(LayerData l) {
        List<LayerData> r = new ArrayList<>();
        r.add(l);
        return r;
    }

    private void fail(final Throwable t) {
        ErrorLog.add("analysis", t);
        a.runOnUiThread(() -> a.message(S.t("تعذّرت العملية", "Operation failed"), String.valueOf(t.getMessage()), null, null));
    }

    private void run(final Job job) {
        a.toast(S.t("جارٍ التنفيذ…", "Working…"));
        new Thread(() -> {
            try {
                final List<LayerData> out = job.make();
                a.runOnUiThread(() -> {
                    int n = 0;
                    LayerData first = null;
                    for (LayerData r : out) {
                        if (r.features.isEmpty()) continue;
                        LayerData added = MainActivity.WS.addLayerWithFeatures(r);
                        if (first == null) first = added;
                        n += added.features.size();
                    }
                    if (first == null) {
                        a.message(S.t("النتيجة فارغة", "Empty result"), S.t("لم يُعثر على عناصر تطابق الشرط.", "No features matched."), null, null);
                        return;
                    }
                    a.rebuild();
                    a.showMap();
                    a.zoomToLayer(first);
                    a.toast(S.t("أُنشئت طبقة: ", "Layer created: ") + first.label + " (" + n + ")");
                });
            } catch (final Throwable t) {
                fail(t);
            }
        }).start();
    }
}
