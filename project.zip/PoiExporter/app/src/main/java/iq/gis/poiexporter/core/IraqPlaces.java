package iq.gis.poiexporter.core;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import iq.gis.poiexporter.core.io.DupFinder;

/**
 * Iraqi governorates, districts and cities (Arabic and English names; cities with coordinates and population).
 * Data: github.com/hoshmandent/iraqi-geography-data (MIT, (c) 2024 Hoshmand M. Qadir); Arabic names added for this app.
 * Offline gazetteer: not an official source, no boundaries.
 */
public final class IraqPlaces {
    public static final String RESOURCE = "/geo/iraq_geography.json";

    public enum Kind { GOVERNORATE, DISTRICT, CITY }

    public static final class Place {
        public final Kind kind;
        public final String ar, en, govAr, govEn, districtAr, districtEn, slug, note;
        /** WGS84; NaN for governorates and districts (the source has no coordinates for them). */
        public final double lat, lon;
        public final long pop;
        final String key;

        Place(Kind kind, String ar, String en, String govAr, String govEn, String districtAr, String districtEn, String slug,
              double lat, double lon, long pop, String note) {
            this.kind = kind;
            this.ar = ar;
            this.en = en;
            this.govAr = govAr;
            this.govEn = govEn;
            this.districtAr = districtAr;
            this.districtEn = districtEn;
            this.slug = slug;
            this.lat = lat;
            this.lon = lon;
            this.pop = pop;
            this.note = note;
            this.key = DupFinder.normName(ar) + "|" + en.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
        }

        public boolean hasPosition() {
            return !Double.isNaN(lat) && !Double.isNaN(lon);
        }

        /** "الحلة — قضاء الحلة — بابل" style breadcrumb in Arabic. */
        public String where() {
            if (kind == Kind.GOVERNORATE) return "محافظة";
            if (kind == Kind.DISTRICT) return "قضاء — " + govAr;
            return districtAr + " — " + govAr;
        }
    }

    public static final class Data {
        public final String source, commit, license, notes;
        public final List<Place> governorates = new ArrayList<>(), districts = new ArrayList<>(), cities = new ArrayList<>();

        Data(String source, String commit, String license, String notes) {
            this.source = source;
            this.commit = commit;
            this.license = license;
            this.notes = notes;
        }
    }

    private static Data data;

    private IraqPlaces() {
    }

    public static synchronized Data get() {
        if (data == null) {
            try (InputStream in = IraqPlaces.class.getResourceAsStream(RESOURCE)) {
                if (in == null) throw new IllegalStateException("missing " + RESOURCE);
                data = parse(new String(readAll(in), StandardCharsets.UTF_8));
            } catch (java.io.IOException e) {
                throw new IllegalStateException(e);
            }
        }
        return data;
    }

    private static byte[] readAll(InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        return b.toByteArray();
    }

    @SuppressWarnings("unchecked")
    static Data parse(String json) {
        Map<String, Object> root = MiniJson.obj(json);
        Map<String, Object> meta = (Map<String, Object>) root.get("meta");
        Data d = new Data(MiniJson.str(meta, "source", ""), MiniJson.str(meta, "commit", ""), MiniJson.str(meta, "license", ""), MiniJson.str(meta, "notes", ""));
        for (Object o : (List<Object>) root.get("governorates")) {
            Map<String, Object> m = (Map<String, Object>) o;
            d.governorates.add(new Place(Kind.GOVERNORATE, MiniJson.str(m, "ar", ""), MiniJson.str(m, "en", ""), MiniJson.str(m, "ar", ""), MiniJson.str(m, "en", ""),
                    "", "", MiniJson.str(m, "slug", ""), Double.NaN, Double.NaN, 0, ""));
        }
        for (Object o : (List<Object>) root.get("districts")) {
            Map<String, Object> m = (Map<String, Object>) o;
            d.districts.add(new Place(Kind.DISTRICT, MiniJson.str(m, "ar", ""), MiniJson.str(m, "en", ""), MiniJson.str(m, "gov_ar", ""), MiniJson.str(m, "gov_en", ""),
                    MiniJson.str(m, "ar", ""), MiniJson.str(m, "en", ""), MiniJson.str(m, "slug", ""), Double.NaN, Double.NaN, 0, ""));
        }
        for (Object o : (List<Object>) root.get("cities")) {
            Map<String, Object> m = (Map<String, Object>) o;
            d.cities.add(new Place(Kind.CITY, MiniJson.str(m, "ar", ""), MiniJson.str(m, "en", ""), MiniJson.str(m, "gov_ar", ""), MiniJson.str(m, "gov_en", ""),
                    MiniJson.str(m, "district_ar", ""), MiniJson.str(m, "district_en", ""), MiniJson.str(m, "slug", ""),
                    MiniJson.num(m, "lat", Double.NaN), MiniJson.num(m, "lon", Double.NaN), (long) MiniJson.num(m, "pop", 0), MiniJson.str(m, "note", "")));
        }
        return d;
    }

    // ------------------------------------------------------------------ queries

    public static List<Place> citiesOf(String govSlugOrAr) {
        List<Place> out = new ArrayList<>();
        for (Place c : get().cities) if (c.govAr.equals(govSlugOrAr) || c.govEn.equals(govSlugOrAr)) out.add(c);
        return out;
    }

    public static List<Place> districtsOf(String govAr) {
        List<Place> out = new ArrayList<>();
        for (Place c : get().districts) if (c.govAr.equals(govAr)) out.add(c);
        return out;
    }

    /** Mean of the cities' positions: a rough centre for a governorate or district (they have no coordinates in the source). */
    public static double[] approxCenter(Place p) {
        if (p.hasPosition()) return new double[]{p.lat, p.lon};
        double la = 0, lo = 0;
        int n = 0;
        for (Place c : get().cities) {
            boolean in = p.kind == Kind.GOVERNORATE ? c.govAr.equals(p.ar) : c.districtAr.equals(p.ar) && c.govAr.equals(p.govAr);
            if (in) {
                la += c.lat;
                lo += c.lon;
                n++;
            }
        }
        return n == 0 ? null : new double[]{la / n, lo / n};
    }

    /** Arabic- and English-aware search over cities, districts and governorates; exact and prefix matches first, cities before districts. */
    public static List<Place> search(String query, int max) {
        String q = DupFinder.normName(query);
        String qe = query == null ? "" : query.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
        if (q.isEmpty() && qe.isEmpty()) return Collections.emptyList();
        List<Place> all = new ArrayList<>(get().cities);
        all.addAll(get().districts);
        all.addAll(get().governorates);
        final List<int[]> scored = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) {
            Place p = all.get(i);
            String na = DupFinder.normName(p.ar), ne = p.key.substring(p.key.indexOf('|') + 1);
            int s = 0;
            if (!q.isEmpty() && na.equals(q) || !qe.isEmpty() && ne.equals(qe)) s = 100;
            else if (!q.isEmpty() && na.startsWith(q) || !qe.isEmpty() && ne.startsWith(qe)) s = 60;
            else if (!q.isEmpty() && na.contains(q) || !qe.isEmpty() && ne.contains(qe)) s = 30;
            if (s == 0) continue;
            s += p.kind == Kind.CITY ? 3 : p.kind == Kind.DISTRICT ? 2 : 1;
            scored.add(new int[]{s, i});
        }
        Collections.sort(scored, (a, b) -> a[0] != b[0] ? b[0] - a[0] : a[1] - b[1]);
        List<Place> out = new ArrayList<>();
        for (int[] s : scored) {
            if (out.size() >= max) break;
            out.add(all.get(s[1]));
        }
        return out;
    }

    /** Words of a text, each normalised (Arabic-aware) and joined with single spaces ({@link DupFinder#normName} drops spaces itself). */
    private static String words(String text) {
        StringBuilder b = new StringBuilder();
        for (String w : text.split("[^\\p{L}\\p{N}\\p{M}]+")) {
            if (w.isEmpty()) continue;
            if (b.length() > 0) b.append(' ');
            b.append(DupFinder.normName(w));
        }
        return b.toString();
    }

    /** The city named in a free text (Arabic or English; longest name wins), or null. Used for the locality of short Plus Codes. */
    public static Place cityIn(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        String t = " " + words(text) + " ";
        String te = " " + text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim() + " ";
        Place best = null;
        int bestLen = 0;
        for (Place c : get().cities) {
            String na = words(c.ar.replaceAll("\\(.*?\\)", " "));
            String ne = c.key.substring(c.key.indexOf('|') + 1);
            // "ال" prefix is optional in speech: also try the bare name
            String bare = na.startsWith("ال") ? na.substring(2) : na;
            int len = 0;
            if (!na.isEmpty() && t.contains(" " + na + " ")) len = na.length();
            else if (bare.length() >= 3 && t.contains(" " + bare + " ")) len = bare.length();
            else if (ne.length() >= 3 && te.contains(" " + ne + " ")) len = ne.length();
            if (len > bestLen) {
                bestLen = len;
                best = c;
            }
        }
        return best;
    }

    /**
     * Position of the first Plus Code in a text. Full codes are decoded as they are; a short code is placed next to the city named
     * after it ("7JVW+P8 الموصل"), otherwise next to the app's reference position (map centre). Null when there is no usable code.
     */
    public static double[] resolvePlusCode(String text) {
        String code = PlusCode.find(text);
        if (code == null) return null;
        try {
            if (PlusCode.isShort(code)) {
                Place c = cityIn(PlusCode.localityAfter(text, code));
                if (c == null) c = cityIn(text.replace(code, " "));
                // very short codes (6+ leading digits dropped) only fix the place within about 2.5 km of the reference:
                // a city centre is too far for them, so the map reference wins when there is one
                boolean veryShort = code.indexOf('+') < 4;
                if (c != null && !(veryShort && PlusCode.hasReference())) {
                    PlusCode.Area a = PlusCode.decode(PlusCode.recoverNearest(code, c.lat, c.lon));
                    return new double[]{a.centerLat(), a.centerLon()};
                }
            }
            return PlusCode.toLatLon(code);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
