package iq.gis.poiexporter.core.db;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.MiniJson;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** JSON snapshots of features and layers (history entries, project archives). */
public final class FeatureJson {
    private FeatureJson() {
    }

    private static void kv(StringBuilder b, String k, String v) {
        b.append(',');
        MiniJson.quote(k, b);
        b.append(':');
        MiniJson.quote(v == null ? "" : v, b);
    }

    public static String toJson(Feature f) {
        StringBuilder b = new StringBuilder(256);
        b.append("{\"geom\":").append(f.geom);
        kv(b, "id", f.id);
        kv(b, "name", f.name);
        kv(b, "nameEn", f.nameEn);
        kv(b, "type", f.type);
        kv(b, "category", f.category);
        kv(b, "nahiya", f.nahiya);
        kv(b, "qadaa", f.qadaa);
        kv(b, "governorate", f.governorate);
        kv(b, "description", f.description);
        kv(b, "notes", f.notes);
        kv(b, "source", f.source);
        kv(b, "updated", f.updated);
        b.append(",\"accuracy\":").append(Double.isNaN(f.accuracy) ? "null" : String.valueOf(f.accuracy));
        b.append(",\"status\":").append(f.status);
        b.append(",\"photos\":[");
        for (int i = 0; i < f.photos.size(); i++) {
            if (i > 0) b.append(',');
            MiniJson.quote(f.photos.get(i), b);
        }
        b.append("],\"attrs\":{");
        boolean first = true;
        for (Map.Entry<String, String> e : f.attrs.entrySet()) {
            if (!first) b.append(',');
            first = false;
            MiniJson.quote(e.getKey(), b);
            b.append(':');
            MiniJson.quote(e.getValue() == null ? "" : e.getValue(), b);
        }
        b.append("},\"parts\":[");
        for (int i = 0; i < f.parts.size(); i++) {
            if (i > 0) b.append(',');
            b.append("{\"hole\":").append(f.isHole(i)).append(",\"c\":[");
            double[] p = f.parts.get(i);
            for (int k = 0; k < p.length; k++) {
                if (k > 0) b.append(',');
                b.append(p[k]);
            }
            b.append("]}");
        }
        b.append("]}");
        return b.toString();
    }

    @SuppressWarnings("unchecked")
    public static Feature fromJson(Map<String, Object> m) {
        Feature f = new Feature();
        f.geom = (int) MiniJson.num(m, "geom", Feature.POINT);
        f.id = MiniJson.str(m, "id", "");
        f.name = MiniJson.str(m, "name", "");
        f.nameEn = MiniJson.str(m, "nameEn", "");
        f.type = MiniJson.str(m, "type", "");
        f.category = MiniJson.str(m, "category", "");
        f.nahiya = MiniJson.str(m, "nahiya", "");
        f.qadaa = MiniJson.str(m, "qadaa", "");
        f.governorate = MiniJson.str(m, "governorate", "");
        f.description = MiniJson.str(m, "description", "");
        f.notes = MiniJson.str(m, "notes", "");
        f.source = MiniJson.str(m, "source", "");
        f.updated = MiniJson.str(m, "updated", "");
        f.accuracy = m.get("accuracy") == null ? Double.NaN : MiniJson.num(m, "accuracy", Double.NaN);
        f.status = (int) MiniJson.num(m, "status", 0);
        Object ph = m.get("photos");
        if (ph instanceof List) for (Object o : (List<Object>) ph) f.photos.add(String.valueOf(o));
        Object at = m.get("attrs");
        if (at instanceof Map) for (Map.Entry<String, Object> e : ((Map<String, Object>) at).entrySet())
            f.attrs.put(e.getKey(), e.getValue() == null ? "" : String.valueOf(e.getValue()));
        Object parts = m.get("parts");
        if (parts instanceof List) {
            for (Object po : (List<Object>) parts) {
                Map<String, Object> pm = (Map<String, Object>) po;
                List<Object> c = (List<Object>) pm.get("c");
                double[] arr = new double[c.size()];
                for (int i = 0; i < arr.length; i++) arr[i] = (Double) c.get(i);
                f.addPart(arr, Boolean.TRUE.equals(pm.get("hole")));
            }
        }
        Geo.setRepresentative(f);
        return f;
    }

    public static Feature fromJson(String s) {
        return fromJson(MiniJson.obj(s));
    }

    public static String layerJson(LayerData l) {
        StringBuilder b = new StringBuilder();
        b.append("{\"geom\":").append(l.geom);
        kv(b, "id", l.id);
        kv(b, "label", l.label);
        kv(b, "kind", l.kind);
        b.append(",\"color\":").append(l.color).append(",\"width\":").append(l.width).append(",\"opacity\":").append(l.opacity)
                .append(",\"order\":").append(l.order).append(",\"visible\":").append(l.visible).append(",\"official\":").append(l.official);
        kv(b, "source", l.source);
        kv(b, "sourceDate", l.sourceDate);
        kv(b, "accuracyNote", l.accuracyNote);
        b.append('}');
        return b.toString();
    }

    public static LayerData layerFrom(Map<String, Object> m) {
        LayerData l = new LayerData(MiniJson.str(m, "id", ""), MiniJson.str(m, "label", ""), (int) MiniJson.num(m, "geom", Feature.POINT));
        l.kind = MiniJson.str(m, "kind", "user");
        l.color = (int) (long) MiniJson.num(m, "color", 0);
        l.width = (float) MiniJson.num(m, "width", 0);
        l.opacity = (float) MiniJson.num(m, "opacity", 1);
        l.order = (int) MiniJson.num(m, "order", 0);
        l.visible = !Boolean.FALSE.equals(m.get("visible"));
        l.official = Boolean.TRUE.equals(m.get("official"));
        l.source = MiniJson.str(m, "source", "");
        l.sourceDate = MiniJson.str(m, "sourceDate", "");
        l.accuracyNote = MiniJson.str(m, "accuracyNote", "");
        return l;
    }

    public static List<String> idsOf(List<Feature> fs) {
        List<String> r = new ArrayList<>(fs.size());
        for (Feature f : fs) r.add(f.id);
        return r;
    }
}
