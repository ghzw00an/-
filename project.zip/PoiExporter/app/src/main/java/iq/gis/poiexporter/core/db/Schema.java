package iq.gis.poiexporter.core.db;

/** SQL of the project database (SQLite). Kept as plain strings so the JVM tests can run it with python's sqlite3. */
public final class Schema {
    private Schema() {
    }

    public static final int VERSION = 1;

    public static final String[] DDL = {
            "CREATE TABLE IF NOT EXISTS project (id TEXT PRIMARY KEY, name TEXT NOT NULL, created TEXT, updated TEXT, note TEXT DEFAULT '')",
            "CREATE TABLE IF NOT EXISTS layer (id TEXT PRIMARY KEY, project TEXT NOT NULL, name TEXT NOT NULL, geom INTEGER NOT NULL, "
                    + "kind TEXT DEFAULT 'user', color INTEGER DEFAULT 0, width REAL DEFAULT 0, opacity REAL DEFAULT 1, ord INTEGER DEFAULT 0, "
                    + "visible INTEGER DEFAULT 1, source TEXT DEFAULT '', source_date TEXT DEFAULT '', accuracy_note TEXT DEFAULT '', "
                    + "official INTEGER DEFAULT 0, deleted INTEGER DEFAULT 0)",
            "CREATE INDEX IF NOT EXISTS layer_project ON layer(project, deleted)",
            "CREATE TABLE IF NOT EXISTS feature (id TEXT PRIMARY KEY, layer TEXT NOT NULL, geom INTEGER NOT NULL, shape BLOB NOT NULL, "
                    + "minx REAL, miny REAL, maxx REAL, maxy REAL, lat REAL, lon REAL, name TEXT DEFAULT '', name_en TEXT DEFAULT '', "
                    + "type TEXT DEFAULT '', category TEXT DEFAULT '', governorate TEXT DEFAULT '', qadaa TEXT DEFAULT '', nahiya TEXT DEFAULT '', "
                    + "descr TEXT DEFAULT '', notes TEXT DEFAULT '', source TEXT DEFAULT '', updated TEXT DEFAULT '', accuracy REAL, "
                    + "status INTEGER DEFAULT 0, photos TEXT DEFAULT '', attrs TEXT DEFAULT '', deleted INTEGER DEFAULT 0)",
            "CREATE INDEX IF NOT EXISTS feature_layer ON feature(layer, deleted)",
            "CREATE INDEX IF NOT EXISTS feature_minx ON feature(minx, maxx)",
            "CREATE INDEX IF NOT EXISTS feature_miny ON feature(miny, maxy)",
            "CREATE INDEX IF NOT EXISTS feature_name ON feature(name)",
            "CREATE TABLE IF NOT EXISTS history (seq INTEGER PRIMARY KEY AUTOINCREMENT, project TEXT NOT NULL, ts TEXT, label TEXT, "
                    + "json TEXT NOT NULL, undone INTEGER DEFAULT 0)",
            "CREATE INDEX IF NOT EXISTS history_project ON history(project, seq)",
            "CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)"
    };

    public static final String UPSERT_FEATURE = "INSERT OR REPLACE INTO feature (id, layer, geom, shape, minx, miny, maxx, maxy, lat, lon, name, name_en, "
            + "type, category, governorate, qadaa, nahiya, descr, notes, source, updated, accuracy, status, photos, attrs, deleted) "
            + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)";

    public static final String LAYER_FEATURES = "SELECT id, geom, shape, lat, lon, name, name_en, type, category, governorate, qadaa, nahiya, "
            + "descr, notes, source, updated, accuracy, status, photos, attrs FROM feature WHERE layer = ? AND deleted = 0 ORDER BY rowid";

    /** Features whose bounding box intersects the box (minx, maxx, miny, maxy order of parameters: maxx, minx, maxy, miny). */
    public static final String BBOX_QUERY = "SELECT id FROM feature WHERE layer = ? AND deleted = 0 AND maxx >= ? AND minx <= ? AND maxy >= ? AND miny <= ?";

    public static final String SEARCH = "SELECT f.id, f.layer FROM feature f JOIN layer l ON l.id = f.layer WHERE l.project = ? AND l.deleted = 0 "
            + "AND f.deleted = 0 AND (f.name LIKE ? OR f.name_en LIKE ? OR f.type LIKE ? OR f.category LIKE ? OR f.id = ? "
            + "OR f.governorate LIKE ? OR f.qadaa LIKE ? OR f.nahiya LIKE ?) LIMIT ?";
}
