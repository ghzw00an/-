package iq.gis.poiexporter;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import iq.gis.poiexporter.core.Sectors;

/**
 * Two rows of chips under the Gategory field: the sectors, and — once a sector is chosen or typed — only that sector's
 * items, which fill the type field. The user may always type any text instead.
 */
final class SectorPicker {
    private SectorPicker() {
    }

    static View build(final MainActivity a, final EditText category, final EditText type) {
        final LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        final LinearLayout secRow = new LinearLayout(a);
        hs.addView(secRow);
        final HorizontalScrollView hi = new HorizontalScrollView(a);
        hi.setHorizontalScrollBarEnabled(false);
        final LinearLayout itemRow = new LinearLayout(a);
        hi.addView(itemRow);
        final TextView hint = Ui.text(a, "", 11.5f, Theme.sub, false);
        final TextView[] secChips = new TextView[Sectors.ALL.length];
        for (int i = 0; i < Sectors.ALL.length; i++) {
            final Sectors.Sector s = Sectors.ALL[i];
            final int idx = i;
            TextView ch = Ui.chip(a, s.name.replace("القطاع ", "").replace("قطاع ", ""));
            ch.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    category.setText(s.name);
                }
            });
            secChips[i] = ch;
            secRow.addView(ch, Ui.lp(-2, -2, 0, a, 3, 8, 3, 0));
        }
        final Runnable refresh = new Runnable() {
            public void run() {
                Sectors.Sector cur = Sectors.find(category.getText().toString());
                for (int i = 0; i < secChips.length; i++) Ui.setChip(secChips[i], cur != null && Sectors.ALL[i] == cur);
                itemRow.removeAllViews();
                if (cur == null) {
                    hi.setVisibility(View.GONE);
                    hint.setVisibility(View.GONE);
                    return;
                }
                hi.setVisibility(View.VISIBLE);
                hint.setVisibility(View.VISIBLE);
                hint.setText(S.t("عناصر " + cur.name + " (اضغط لملء type):", cur.name + " items (tap to fill type):"));
                String curType = type.getText().toString().trim();
                for (final String it : cur.items) {
                    TextView ch = Ui.chip(a, it);
                    Ui.setChip(ch, it.equals(curType));
                    ch.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            type.setText(it);
                            for (int k = 0; k < itemRow.getChildCount(); k++)
                                Ui.setChip((TextView) itemRow.getChildAt(k), ((TextView) itemRow.getChildAt(k)).getText().toString().equals(it));
                        }
                    });
                    itemRow.addView(ch, Ui.lp(-2, -2, 0, a, 3, 8, 3, 0));
                }
            }
        };
        category.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                refresh.run();
            }
        });
        root.addView(hs);
        root.addView(hint, Ui.lp(-2, -2, 0, a, 4, 8, 0, 0));
        root.addView(hi);
        refresh.run();
        return root;
    }
}
