package iq.gis.poiexporter;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.GeomCodec;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.MiniJson;
import iq.gis.poiexporter.core.db.FeatureJson;
import iq.gis.poiexporter.core.db.HistoryEntry;
import iq.gis.poiexporter.core.db.ProjectInfo;
import iq.gis.poiexporter.core.db.Repo;
import iq.gis.poiexporter.core.db.Schema;

/** Project database (gis.db) on Android SQLite. Thread-safe: the UI thread reads, one background thread writes. */
public final class SqliteRepo implements Repo {
    private final SQLiteDatabase db;

    public static File file(Context c) {
        return new File(c.getFilesDir(), "gis.db");
    }

    public SqliteRepo(Context c) {
        db = SQLiteDatabase.openDatabase(file(c).getAbsolutePath(), null, SQLiteDatabase.CREATE_IF_NECESSARY);
        db.enableWriteAheadLogging();
        for (String s : Schema.DDL) db.execSQL(s);
        db.execSQL("INSERT OR IGNORE INTO meta(k,v) VALUES('schema','" + Schema.VERSION + "')");
    }

    public void close() {
        db.close();
    }

    private static String now() {
        return java.time.Instant.now().toString();
    }

    // ------------------------------------------------------------ projects

    @Override
    public List<ProjectInfo> projects() {
        List<ProjectInfo> out = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT id, name, created, updated FROM project ORDER BY created", null)) {
            while (c.moveToNext()) {
                ProjectInfo p = new ProjectInfo();
                p.id = c.getString(0);
                p.name = c.getString(1);
                p.created = c.getString(2);
                p.updated = c.getString(3);
                out.add(p);
            }
        }
        for (ProjectInfo p : out) {
            try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM layer WHERE project = ? AND deleted = 0", new String[]{p.id})) {
                if (c.moveToFirst()) p.layers = c.getInt(0);
            }
            try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM feature f JOIN layer l ON l.id = f.layer WHERE l.project = ? AND l.deleted = 0 AND f.deleted = 0",
                    new String[]{p.id})) {
                if (c.moveToFirst()) p.features = c.getLong(0);
            }
        }
        return out;
    }

    @Override
    public ProjectInfo createProject(String name) {
        ProjectInfo p = new ProjectInfo();
        p.id = Feature.newId();
        p.name = name;
        p.created = p.updated = now();
        db.execSQL("INSERT INTO project(id,name,created,updated) VALUES(?,?,?,?)", new Object[]{p.id, name, p.created, p.updated});
        return p;
    }

    @Override
    public void renameProject(String id, String name) {
        db.execSQL("UPDATE project SET name = ?, updated = ? WHERE id = ?", new Object[]{name, now(), id});
    }

    @Override
    public void deleteProject(String id) {
        db.beginTransaction();
        try {
            db.execSQL("DELETE FROM feature WHERE layer IN (SELECT id FROM layer WHERE project = ?)", new Object[]{id});
            db.execSQL("DELETE FROM layer WHERE project = ?", new Object[]{id});
            db.execSQL("DELETE FROM history WHERE project = ?", new Object[]{id});
            db.execSQL("DELETE FROM project WHERE id = ?", new Object[]{id});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    // ------------------------------------------------------------ layers

    private LayerData layerFrom(Cursor c) {
        LayerData l = new LayerData(c.getString(0), c.getString(2), c.getInt(3));
        l.projectId = c.getString(1);
        l.kind = c.getString(4);
        l.color = c.getInt(5);
        l.width = (float) c.getDouble(6);
        l.opacity = (float) c.getDouble(7);
        l.order = c.getInt(8);
        l.visible = c.getInt(9) != 0;
        l.source = c.getString(10);
        l.sourceDate = c.getString(11);
        l.accuracyNote = c.getString(12);
        l.official = c.getInt(13) != 0;
        return l;
    }

    private static final String LAYER_COLS = "id, project, name, geom, kind, color, width, opacity, ord, visible, source, source_date, accuracy_note, official";

    @Override
    public List<LayerData> loadLayers(String projectId) {
        List<LayerData> out = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT " + LAYER_COLS + " FROM layer WHERE project = ? AND deleted = 0 ORDER BY ord, rowid", new String[]{projectId})) {
            while (c.moveToNext()) out.add(layerFrom(c));
        }
        for (LayerData l : out) loadFeatures(l);
        return out;
    }

    @Override
    public LayerData loadLayer(String layerId) {
        LayerData l = null;
        try (Cursor c = db.rawQuery("SELECT " + LAYER_COLS + " FROM layer WHERE id = ?", new String[]{layerId})) {
            if (c.moveToFirst()) l = layerFrom(c);
        }
        if (l != null) loadFeatures(l);
        return l;
    }

    private void loadFeatures(LayerData l) {
        try (Cursor c = db.rawQuery(Schema.LAYER_FEATURES, new String[]{l.id})) {
            while (c.moveToNext()) l.features.add(featureFrom(c));
        }
    }

    /** Columns of Schema.LAYER_FEATURES. */
    private static Feature featureFrom(Cursor c) {
        Feature f = new Feature();
        f.id = c.getString(0);
        f.geom = c.getInt(1);
        GeomCodec.decode(c.getBlob(2), f);
        f.lat = c.getDouble(3);
        f.lon = c.getDouble(4);
        f.name = c.getString(5);
        f.nameEn = c.getString(6);
        f.type = c.getString(7);
        f.category = c.getString(8);
        f.governorate = c.getString(9);
        f.qadaa = c.getString(10);
        f.nahiya = c.getString(11);
        f.description = c.getString(12);
        f.notes = c.getString(13);
        f.source = c.getString(14);
        f.updated = c.getString(15);
        f.accuracy = c.isNull(16) ? Double.NaN : c.getDouble(16);
        f.status = c.getInt(17);
        String ph = c.getString(18);
        if (ph != null && !ph.isEmpty()) for (String p : ph.split("\n")) if (!p.isEmpty()) f.photos.add(p);
        String at = c.getString(19);
        if (at != null && !at.isEmpty()) {
            try {
                for (Map.Entry<String, Object> e : MiniJson.obj(at).entrySet()) f.attrs.put(e.getKey(), e.getValue() == null ? "" : String.valueOf(e.getValue()));
            } catch (RuntimeException ignored) {
                // damaged attribute JSON: keep the feature
            }
        }
        return f;
    }

    @Override
    public void saveLayerMeta(String projectId, LayerData l) {
        db.execSQL("INSERT OR REPLACE INTO layer(id, project, name, geom, kind, color, width, opacity, ord, visible, source, source_date, accuracy_note, official, deleted) "
                        + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
                new Object[]{l.id, projectId, l.label, l.geom, l.kind, l.color, (double) l.width, (double) l.opacity, l.order, l.visible ? 1 : 0,
                        l.source, l.sourceDate, l.accuracyNote, l.official ? 1 : 0});
        db.execSQL("UPDATE project SET updated = ? WHERE id = ?", new Object[]{now(), projectId});
    }

    @Override
    public void setLayerDeleted(String layerId, boolean deleted) {
        db.execSQL("UPDATE layer SET deleted = ? WHERE id = ?", new Object[]{deleted ? 1 : 0, layerId});
    }

    // ------------------------------------------------------------ features

    @Override
    public void saveFeatures(String layerId, List<Feature> fs) {
        db.beginTransaction();
        try {
            SQLiteStatement st = db.compileStatement(Schema.UPSERT_FEATURE);
            try {
                for (Feature f : fs) {
                    double[] bb = GeomCodec.bbox(f);
                    st.clearBindings();
                    st.bindString(1, f.id);
                    st.bindString(2, layerId);
                    st.bindLong(3, f.geom);
                    st.bindBlob(4, GeomCodec.encode(f));
                    st.bindDouble(5, bb[0]);
                    st.bindDouble(6, bb[1]);
                    st.bindDouble(7, bb[2]);
                    st.bindDouble(8, bb[3]);
                    st.bindDouble(9, f.lat);
                    st.bindDouble(10, f.lon);
                    st.bindString(11, nz(f.name));
                    st.bindString(12, nz(f.nameEn));
                    st.bindString(13, nz(f.type));
                    st.bindString(14, nz(f.category));
                    st.bindString(15, nz(f.governorate));
                    st.bindString(16, nz(f.qadaa));
                    st.bindString(17, nz(f.nahiya));
                    st.bindString(18, nz(f.description));
                    st.bindString(19, nz(f.notes));
                    st.bindString(20, nz(f.source));
                    st.bindString(21, nz(f.updated));
                    if (Double.isNaN(f.accuracy)) st.bindNull(22);
                    else st.bindDouble(22, f.accuracy);
                    st.bindLong(23, f.status);
                    st.bindString(24, String.join("\n", f.photos));
                    st.bindString(25, attrsJson(f));
                    st.execute();
                }
            } finally {
                st.close();
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static String attrsJson(Feature f) {
        if (f.attrs.isEmpty()) return "";
        StringBuilder b = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, String> e : f.attrs.entrySet()) {
            if (!first) b.append(',');
            first = false;
            MiniJson.quote(e.getKey(), b);
            b.append(':');
            MiniJson.quote(e.getValue() == null ? "" : e.getValue(), b);
        }
        return b.append('}').toString();
    }

    private void batchIds(String sql, List<String> ids, Object... lead) {
        db.beginTransaction();
        try {
            SQLiteStatement st = db.compileStatement(sql);
            try {
                for (String id : ids) {
                    st.clearBindings();
                    int k = 1;
                    for (Object o : lead) st.bindLong(k++, ((Number) o).longValue());
                    st.bindString(k, id);
                    st.execute();
                }
            } finally {
                st.close();
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    @Override
    public void setFeaturesDeleted(List<String> ids, boolean deleted) {
        batchIds("UPDATE feature SET deleted = ? WHERE id = ?", ids, deleted ? 1 : 0);
    }

    @Override
    public void purgeFeatures(List<String> ids) {
        batchIds("DELETE FROM feature WHERE id = ?", ids);
    }

    @Override
    public void purgeLayer(String layerId) {
        db.beginTransaction();
        try {
            db.execSQL("DELETE FROM feature WHERE layer = ?", new Object[]{layerId});
            db.execSQL("DELETE FROM layer WHERE id = ?", new Object[]{layerId});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private Feature one(String id, boolean any) {
        String sql = "SELECT id, geom, shape, lat, lon, name, name_en, type, category, governorate, qadaa, nahiya, descr, notes, source, updated, accuracy, status, photos, attrs "
                + "FROM feature WHERE id = ?" + (any ? "" : " AND deleted = 0");
        try (Cursor c = db.rawQuery(sql, new String[]{id})) {
            return c.moveToFirst() ? featureFrom(c) : null;
        }
    }

    @Override
    public Feature getFeature(String id) {
        return one(id, false);
    }

    @Override
    public Feature getFeatureAny(String id) {
        return one(id, true);
    }

    @Override
    public List<Feature> search(String projectId, String text, int limit) {
        String like = "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%";
        List<String> ids = new ArrayList<>();
        String sql = Schema.SEARCH.replace("LIKE ?", "LIKE ? ESCAPE '\\'");
        try (Cursor c = db.rawQuery(sql, new String[]{projectId, like, like, like, like, text, like, like, like, String.valueOf(limit)})) {
            while (c.moveToNext()) ids.add(c.getString(0));
        }
        List<Feature> out = new ArrayList<>();
        for (String id : ids) {
            Feature f = one(id, false);
            if (f != null) out.add(f);
        }
        return out;
    }

    // ------------------------------------------------------------ history / meta

    @Override
    public long addHistory(String projectId, HistoryEntry e) {
        SQLiteStatement st = db.compileStatement("INSERT INTO history(project, ts, label, json, undone) VALUES(?,?,?,?,?)");
        try {
            st.bindString(1, projectId);
            st.bindString(2, nz(e.ts));
            st.bindString(3, nz(e.label));
            st.bindString(4, e.json);
            st.bindLong(5, e.undone ? 1 : 0);
            return st.executeInsert();
        } finally {
            st.close();
        }
    }

    @Override
    public List<HistoryEntry> history(String projectId) {
        List<HistoryEntry> out = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT seq, ts, label, json, undone FROM history WHERE project = ? ORDER BY seq", new String[]{projectId})) {
            while (c.moveToNext()) {
                HistoryEntry e = new HistoryEntry();
                e.seq = c.getLong(0);
                e.ts = c.getString(1);
                e.label = c.getString(2);
                e.json = c.getString(3);
                e.undone = c.getInt(4) != 0;
                out.add(e);
            }
        }
        return out;
    }

    @Override
    public void setHistoryUndone(long seq, boolean undone) {
        db.execSQL("UPDATE history SET undone = ? WHERE seq = ?", new Object[]{undone ? 1 : 0, seq});
    }

    @Override
    public void deleteHistory(List<Long> seqs) {
        for (Long s : seqs) db.execSQL("DELETE FROM history WHERE seq = ?", new Object[]{s});
    }

    @Override
    public String getMeta(String key, String def) {
        try (Cursor c = db.rawQuery("SELECT v FROM meta WHERE k = ?", new String[]{key})) {
            return c.moveToFirst() ? c.getString(0) : def;
        }
    }

    @Override
    public void setMeta(String key, String value) {
        db.execSQL("INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)", new Object[]{key, value});
    }
}
