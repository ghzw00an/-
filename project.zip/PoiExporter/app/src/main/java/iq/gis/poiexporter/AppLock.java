package iq.gis.poiexporter;

import android.app.Dialog;
import android.content.Context;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import iq.gis.poiexporter.core.LockSecret;

/** Optional app lock: PIN or pattern, with fingerprint / face as a shortcut. The secret is stored only as a salted hash. */
final class AppLock {
    private final MainActivity a;
    private Dialog dlg;
    private long leftAt;
    private android.os.CancellationSignal bioSignal;

    AppLock(MainActivity a) {
        this.a = a;
    }

    String mode() {
        return a.prefs.get("lockMode", "none");
    }

    boolean enabled() {
        return !"none".equals(mode()) && !a.prefs.get("lockHash", "").isEmpty();
    }

    /** Seconds the app may stay in the background before it asks again. */
    int delaySeconds() {
        try {
            return Integer.parseInt(a.prefs.get("lockDelay", "30"));
        } catch (NumberFormatException e) {
            return 30;
        }
    }

    boolean bioWanted() {
        return a.prefs.flag("lockBio", false);
    }

    boolean bioAvailable() {
        try {
            android.hardware.biometrics.BiometricManager bm = (android.hardware.biometrics.BiometricManager) a.getSystemService(Context.BIOMETRIC_SERVICE);
            return bm != null && bm.canAuthenticate() == android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS;
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------ lifecycle hooks

    void onStart() {
        if (enabled()) show();
    }

    void onPause() {
        leftAt = SystemClock.elapsedRealtime();
    }

    void onResume() {
        if (!enabled() || dlg != null || leftAt == 0) return;
        if (SystemClock.elapsedRealtime() - leftAt >= delaySeconds() * 1000L) show();
    }

    // ------------------------------------------------------------------ lock screen

    private void show() {
        if (dlg != null) return;
        final Dialog d = new Dialog(a, android.R.style.Theme_Material_NoActionBar_Fullscreen);
        dlg = d;
        d.setCancelable(false);
        d.setOnKeyListener((di, code, ev) -> {
            if (code == KeyEvent.KEYCODE_BACK && ev.getAction() == KeyEvent.ACTION_UP) a.moveTaskToBack(true);
            return code == KeyEvent.KEYCODE_BACK;
        });
        d.setOnDismissListener(di -> {
            dlg = null;
            if (bioSignal != null) bioSignal.cancel();
            bioSignal = null;
        });
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Theme.bg);
        root.setPadding(Ui.dp(a, 24), Ui.dp(a, 24), Ui.dp(a, 24), Ui.dp(a, 24));
        TextView lock = Ui.text(a, "🔒", 44, Theme.primary, false);
        lock.setGravity(Gravity.CENTER);
        root.addView(lock, new LinearLayout.LayoutParams(-1, -2));
        TextView title = Ui.text(a, "PoiExporter", 22, Theme.text, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        final TextView msg = Ui.text(a, "pin".equals(mode()) ? S.t("أدخل الرمز", "Enter your PIN") : S.t("ارسم النمط", "Draw your pattern"), 14, Theme.sub, false);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 14));
        root.addView(msg, new LinearLayout.LayoutParams(-1, -2));
        if ("pin".equals(mode())) buildPin(root, msg, d);
        else buildPattern(root, msg, d);
        if (bioWanted() && bioAvailable()) {
            TextView bio = Ui.button(a, "🖐 " + S.t("بصمة / وجه", "Fingerprint / face"), false, () -> biometric(d));
            root.addView(bio, Ui.lp(-1, -2, 0, a, 0, 16, 0, 0));
        }
        d.setContentView(root);
        d.show();
        if (bioWanted() && bioAvailable()) root.postDelayed(() -> biometric(d), 250);
    }

    private boolean blocked(TextView msg) {
        long until = 0;
        try {
            until = Long.parseLong(a.prefs.get("lockUntil", "0"));
        } catch (NumberFormatException ignored) {
            // treated as no wait
        }
        long left = (until - System.currentTimeMillis()) / 1000;
        if (left > 0) {
            msg.setTextColor(Theme.danger);
            msg.setText(S.t("محاولات خاطئة كثيرة. انتظر " + left + " ثانية", "Too many wrong tries. Wait " + left + " s"));
            return true;
        }
        return false;
    }

    private void wrong(TextView msg) {
        int f = 1;
        try {
            f = Integer.parseInt(a.prefs.get("lockFails", "0")) + 1;
        } catch (NumberFormatException ignored) {
            // start again from one
        }
        a.prefs.put("lockFails", String.valueOf(f));
        int w = LockSecret.waitSeconds(f);
        if (w > 0) a.prefs.put("lockUntil", String.valueOf(System.currentTimeMillis() + w * 1000L));
        msg.setTextColor(Theme.danger);
        msg.setText(w > 0 ? S.t("خطأ. انتظر " + w + " ثانية", "Wrong. Wait " + w + " s") : S.t("خطأ، حاول مرة أخرى", "Wrong, try again"));
    }

    private void unlock(Dialog d) {
        a.prefs.put("lockFails", "0");
        a.prefs.put("lockUntil", "0");
        d.dismiss();
    }

    private boolean check(String secret) {
        return LockSecret.verify(a.prefs.get("lockSalt", ""), a.prefs.get("lockHash", ""), secret);
    }

    private void buildPin(LinearLayout root, final TextView msg, final Dialog d) {
        final StringBuilder pin = new StringBuilder();
        final TextView dots = Ui.text(a, "", 30, Theme.text, true);
        dots.setGravity(Gravity.CENTER);
        dots.setLetterSpacing(0.3f);
        root.addView(dots, new LinearLayout.LayoutParams(-1, Ui.dp(a, 46)));
        String[] keys = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "✔"};
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(a);
            row.setGravity(Gravity.CENTER);
            for (int c = 0; c < 3; c++) {
                final String k = keys[r * 3 + c];
                TextView b = Ui.text(a, k, 24, k.equals("✔") ? Theme.onPrimary : Theme.text, true);
                b.setGravity(Gravity.CENTER);
                b.setBackground(Ui.round(k.equals("✔") ? Theme.primary : Theme.card, 36, a));
                b.setClickable(true);
                Ui.pressable(b);
                b.setOnClickListener(v -> {
                    if (blocked(msg)) return;
                    msg.setTextColor(Theme.sub);
                    if (k.equals("⌫")) {
                        if (pin.length() > 0) pin.deleteCharAt(pin.length() - 1);
                    } else if (k.equals("✔")) {
                        if (check(pin.toString())) {
                            unlock(d);
                            return;
                        }
                        wrong(msg);
                        pin.setLength(0);
                    } else if (pin.length() < 8) {
                        pin.append(k);
                    }
                    StringBuilder s = new StringBuilder();
                    for (int i = 0; i < pin.length(); i++) s.append('●');
                    dots.setText(s);
                });
                row.addView(b, Ui.lp(Ui.dp(a, 72), Ui.dp(a, 72), 0, a, 8, 8, 8, 8));
            }
            root.addView(row);
        }
    }

    private void buildPattern(LinearLayout root, final TextView msg, final Dialog d) {
        final PatternView pv = new PatternView(a);
        pv.setDone(p -> {
            if (blocked(msg)) {
                pv.flashError();
                return;
            }
            if (check(p)) {
                unlock(d);
            } else {
                wrong(msg);
                pv.flashError();
            }
        });
        root.addView(pv, new LinearLayout.LayoutParams(-1, -2));
    }

    private void biometric(final Dialog d) {
        if (bioSignal != null) return;
        try {
            final java.util.concurrent.Executor ex = a.getMainExecutor();
            android.hardware.biometrics.BiometricPrompt bp = new android.hardware.biometrics.BiometricPrompt.Builder(a)
                    .setTitle(S.t("فتح PoiExporter", "Unlock PoiExporter"))
                    .setNegativeButton(S.t("استخدم الرمز", "Use PIN / pattern"), ex, (di, w) -> {
                    })
                    .build();
            bioSignal = new android.os.CancellationSignal();
            bp.authenticate(bioSignal, ex, new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult r) {
                    bioSignal = null;
                    unlock(d);
                }

                @Override
                public void onAuthenticationError(int code, CharSequence m) {
                    bioSignal = null;
                }
            });
        } catch (Throwable t) {
            bioSignal = null;
            ErrorLog.add("biometric", t);
        }
    }

    // ------------------------------------------------------------------ setting up / removing

    /** Asks for the current secret, then runs ok. */
    void verify(final Runnable ok) {
        if (!enabled()) {
            ok.run();
            return;
        }
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, S.t("أدخل الرمز الحالي", "Enter the current lock")));
        final Dialog d = a.card(box);
        final TextView msg = UiKit.note(a, "");
        if ("pin".equals(mode())) {
            final EditText f = Ui.field(a, "PIN", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            box.addView(f);
            box.addView(msg);
            box.addView(Ui.button(a, S.t("تأكيد", "Confirm"), true, () -> {
                if (check(f.getText().toString())) {
                    d.dismiss();
                    ok.run();
                } else {
                    msg.setText(S.t("خطأ", "Wrong"));
                }
            }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        } else {
            final PatternView pv = new PatternView(a);
            pv.setDone(p -> {
                if (check(p)) {
                    d.dismiss();
                    ok.run();
                } else {
                    pv.flashError();
                }
            });
            box.addView(pv, new LinearLayout.LayoutParams(-1, -2));
        }
        d.show();
    }

    void setupPin(final Runnable done) {
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, S.t("تعيين رمز PIN", "Set a PIN")));
        box.addView(UiKit.note(a, S.t("من 4 إلى 8 أرقام. لا يمكن استرجاع الرمز إن نسيته؛ الحل الوحيد مسح بيانات التطبيق (فتُفقد البيانات غير المنسوخة احتياطياً).",
                "4 to 8 digits. A forgotten PIN cannot be recovered; the only way out is clearing the app data (anything not backed up elsewhere is lost).")));
        final EditText p1 = Ui.field(a, S.t("الرمز", "PIN"), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        final EditText p2 = Ui.field(a, S.t("أعد كتابة الرمز", "Repeat PIN"), InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        box.addView(p1, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        box.addView(p2, Ui.lp(-1, -2, 0, a, 0, 8, 0, 0));
        final Dialog d = a.card(box);
        box.addView(Ui.button(a, S.t("حفظ", "Save"), true, () -> {
            String x = p1.getText().toString();
            if (!LockSecret.validPin(x)) {
                a.toast(S.t("الرمز من 4 إلى 8 أرقام", "PIN must be 4 to 8 digits"));
                return;
            }
            if (!x.equals(p2.getText().toString())) {
                a.toast(S.t("الرمزان غير متطابقين", "PINs do not match"));
                return;
            }
            store("pin", x);
            d.dismiss();
            done.run();
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        d.show();
    }

    void setupPattern(final Runnable done) {
        final LinearLayout box = UiKit.col(a);
        box.addView(UiKit.head(a, S.t("تعيين نمط", "Set a pattern")));
        final TextView msg = UiKit.note(a, S.t("صل 4 نقاط على الأقل", "Connect at least 4 dots"));
        box.addView(msg);
        final PatternView pv = new PatternView(a);
        final String[] first = {null};
        final Dialog d = a.card(box);
        pv.setDone(p -> {
            if (!LockSecret.validPattern(p)) {
                msg.setText(S.t("4 نقاط على الأقل", "At least 4 dots"));
                pv.flashError();
            } else if (first[0] == null) {
                first[0] = p;
                msg.setText(S.t("ارسمه مرة أخرى للتأكيد", "Draw it again to confirm"));
                pv.reset();
            } else if (first[0].equals(p)) {
                store("pattern", p);
                d.dismiss();
                done.run();
            } else {
                first[0] = null;
                msg.setText(S.t("غير متطابق، ابدأ من جديد", "Does not match, start again"));
                pv.flashError();
            }
        });
        box.addView(pv, new LinearLayout.LayoutParams(-1, -2));
        d.show();
    }

    private void store(String mode, String secret) {
        String salt = LockSecret.newSalt();
        a.prefs.put("lockSalt", salt);
        a.prefs.put("lockHash", LockSecret.hash(salt, secret));
        a.prefs.put("lockMode", mode);
        a.prefs.put("lockFails", "0");
        a.prefs.put("lockUntil", "0");
    }

    void remove() {
        a.prefs.put("lockMode", "none");
        a.prefs.put("lockHash", "");
        a.prefs.put("lockSalt", "");
        a.prefs.setFlag("lockBio", false);
    }
}
