package iq.gis.poiexporter.core;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/** Salted, slow-ish hash of the app-lock PIN or pattern, and the wait time after wrong tries. Pure Java so it can be tested on a JVM. */
public final class LockSecret {
    private LockSecret() {
    }

    public static final int ROUNDS = 20000;

    public static String newSalt() {
        byte[] b = new byte[16];
        new SecureRandom().nextBytes(b);
        return hex(b);
    }

    public static String hash(String salt, String secret) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] cur = (salt + ":" + secret).getBytes(StandardCharsets.UTF_8);
            for (int i = 0; i < ROUNDS; i++) {
                md.reset();
                md.update(cur);
                md.update(salt.getBytes(StandardCharsets.UTF_8));
                cur = md.digest();
            }
            return hex(cur);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static boolean verify(String salt, String expectedHash, String secret) {
        if (salt == null || expectedHash == null || secret == null || expectedHash.isEmpty()) return false;
        return MessageDigest.isEqual(hash(salt, secret).getBytes(StandardCharsets.UTF_8), expectedHash.getBytes(StandardCharsets.UTF_8));
    }

    /** A PIN is 4 to 8 digits. */
    public static boolean validPin(String s) {
        if (s == null || s.length() < 4 || s.length() > 8) return false;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) < '0' || s.charAt(i) > '9') return false;
        return true;
    }

    /** A pattern is a list of distinct dot numbers 0..8 joined by '-', at least 4 dots. */
    public static boolean validPattern(String s) {
        if (s == null) return false;
        String[] p = s.split("-");
        if (p.length < 4) return false;
        boolean[] seen = new boolean[9];
        for (String x : p) {
            if (x.length() != 1 || x.charAt(0) < '0' || x.charAt(0) > '8') return false;
            int k = x.charAt(0) - '0';
            if (seen[k]) return false;
            seen[k] = true;
        }
        return true;
    }

    /** Seconds to wait after this many wrong tries in a row: none for 4, then 30 s, 1 min, 5 min, 15 min, 1 h. */
    public static int waitSeconds(int fails) {
        if (fails < 5) return 0;
        int[] w = {30, 60, 300, 900, 3600};
        return w[Math.min(w.length - 1, fails - 5)];
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x & 0xff));
        return sb.toString();
    }
}
