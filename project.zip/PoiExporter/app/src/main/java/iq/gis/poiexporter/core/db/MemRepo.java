package iq.gis.poiexporter.core.db;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** In-memory Repo for tests; keeps copies so callers cannot mutate stored data by accident. */
public final class MemRepo implements Repo {
    private static final class L {
        String project;
        LayerData meta;
        boolean deleted;
    }

    private static final class F {
        String layer;
        Feature f;
        boolean deleted;
    }

    private final Map<String, ProjectInfo> projects = new LinkedHashMap<>();
    private final Map<String, L> layers = new LinkedHashMap<>();
    private final Map<String, F> feats = new LinkedHashMap<>();
    private final Map<String, List<HistoryEntry>> hist = new LinkedHashMap<>();
    private final Map<String, String> meta = new LinkedHashMap<>();
    private long seq;

    private static String now() {
        return java.time.Instant.now().toString();
    }

    @Override
    public synchronized List<ProjectInfo> projects() {
        List<ProjectInfo> r = new ArrayList<>();
        for (ProjectInfo p : projects.values()) {
            ProjectInfo c = new ProjectInfo();
            c.id = p.id;
            c.name = p.name;
            c.created = p.created;
            c.updated = p.updated;
            for (L l : layers.values()) if (l.project.equals(p.id) && !l.deleted) c.layers++;
            for (F f : feats.values()) {
                L l = layers.get(f.layer);
                if (l != null && l.project.equals(p.id) && !l.deleted && !f.deleted) c.features++;
            }
            r.add(c);
        }
        return r;
    }

    @Override
    public synchronized ProjectInfo createProject(String name) {
        ProjectInfo p = new ProjectInfo();
        p.id = Feature.newId();
        p.name = name;
        p.created = p.updated = now();
        projects.put(p.id, p);
        return p;
    }

    @Override
    public synchronized void renameProject(String id, String name) {
        ProjectInfo p = projects.get(id);
        if (p != null) p.name = name;
    }

    @Override
    public synchronized void deleteProject(String id) {
        projects.remove(id);
        List<String> ls = new ArrayList<>();
        for (Map.Entry<String, L> e : layers.entrySet()) if (e.getValue().project.equals(id)) ls.add(e.getKey());
        for (String l : ls) purgeLayer(l);
        hist.remove(id);
    }

    private LayerData copyMeta(LayerData m) {
        LayerData c = FeatureJson.layerFrom(iq.gis.poiexporter.core.MiniJson.obj(FeatureJson.layerJson(m)));
        c.projectId = m.projectId;
        return c;
    }

    @Override
    public synchronized List<LayerData> loadLayers(String projectId) {
        List<LayerData> r = new ArrayList<>();
        for (L l : layers.values()) {
            if (l.project.equals(projectId) && !l.deleted) r.add(loadLayer(l.meta.id));
        }
        r.sort((a, b) -> Integer.compare(a.order, b.order));
        return r;
    }

    @Override
    public synchronized LayerData loadLayer(String layerId) {
        L l = layers.get(layerId);
        if (l == null) return null;
        LayerData c = copyMeta(l.meta);
        c.projectId = l.project;
        for (F f : feats.values()) if (f.layer.equals(layerId) && !f.deleted) c.features.add(f.f.copy());
        return c;
    }

    @Override
    public synchronized void saveLayerMeta(String projectId, LayerData l) {
        L x = layers.get(l.id);
        if (x == null) {
            x = new L();
            layers.put(l.id, x);
        }
        x.project = projectId;
        x.meta = copyMeta(l);
        x.deleted = false;
    }

    @Override
    public synchronized void setLayerDeleted(String layerId, boolean deleted) {
        L l = layers.get(layerId);
        if (l != null) l.deleted = deleted;
    }

    @Override
    public synchronized void saveFeatures(String layerId, List<Feature> fs) {
        for (Feature f : fs) {
            F x = new F();
            x.layer = layerId;
            x.f = f.copy();
            feats.put(f.id, x);
        }
    }

    @Override
    public synchronized void setFeaturesDeleted(List<String> ids, boolean deleted) {
        for (String id : ids) {
            F f = feats.get(id);
            if (f != null) f.deleted = deleted;
        }
    }

    @Override
    public synchronized void purgeFeatures(List<String> ids) {
        for (String id : ids) feats.remove(id);
    }

    @Override
    public synchronized void purgeLayer(String layerId) {
        layers.remove(layerId);
        feats.values().removeIf(f -> f.layer.equals(layerId));
    }

    @Override
    public synchronized Feature getFeature(String id) {
        F f = feats.get(id);
        return f == null || f.deleted ? null : f.f.copy();
    }

    @Override
    public synchronized Feature getFeatureAny(String id) {
        F f = feats.get(id);
        return f == null ? null : f.f.copy();
    }

    @Override
    public synchronized List<Feature> search(String projectId, String text, int limit) {
        String q = text.toLowerCase(Locale.ROOT);
        List<Feature> r = new ArrayList<>();
        for (F f : feats.values()) {
            if (f.deleted) continue;
            L l = layers.get(f.layer);
            if (l == null || l.deleted || !l.project.equals(projectId)) continue;
            Feature x = f.f;
            if (has(x.name, q) || has(x.nameEn, q) || has(x.type, q) || has(x.category, q) || has(x.governorate, q)
                    || has(x.qadaa, q) || has(x.nahiya, q) || x.id.equals(text)) {
                r.add(x.copy());
                if (r.size() >= limit) break;
            }
        }
        return r;
    }

    private static boolean has(String s, String q) {
        return s != null && s.toLowerCase(Locale.ROOT).contains(q);
    }

    @Override
    public synchronized long addHistory(String projectId, HistoryEntry e) {
        HistoryEntry c = new HistoryEntry();
        c.seq = ++seq;
        c.ts = e.ts;
        c.label = e.label;
        c.json = e.json;
        c.undone = e.undone;
        hist.computeIfAbsent(projectId, k -> new ArrayList<>()).add(c);
        return c.seq;
    }

    @Override
    public synchronized List<HistoryEntry> history(String projectId) {
        List<HistoryEntry> r = new ArrayList<>();
        List<HistoryEntry> h = hist.get(projectId);
        if (h != null) for (HistoryEntry e : h) {
            HistoryEntry c = new HistoryEntry();
            c.seq = e.seq;
            c.ts = e.ts;
            c.label = e.label;
            c.json = e.json;
            c.undone = e.undone;
            r.add(c);
        }
        return r;
    }

    @Override
    public synchronized void setHistoryUndone(long s, boolean undone) {
        for (List<HistoryEntry> h : hist.values()) for (HistoryEntry e : h) if (e.seq == s) e.undone = undone;
    }

    @Override
    public synchronized void deleteHistory(List<Long> seqs) {
        for (List<HistoryEntry> h : hist.values()) h.removeIf(e -> seqs.contains(e.seq));
    }

    @Override
    public synchronized String getMeta(String key, String def) {
        String v = meta.get(key);
        return v == null ? def : v;
    }

    @Override
    public synchronized void setMeta(String key, String value) {
        meta.put(key, value);
    }
}
