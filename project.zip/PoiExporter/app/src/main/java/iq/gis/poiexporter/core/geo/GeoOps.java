package iq.gis.poiexporter.core.geo;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.GeomCodec;
import iq.gis.poiexporter.core.Jts;
import iq.gis.poiexporter.core.LayerData;

import org.locationtech.jts.algorithm.distance.DistanceToPoint;
import org.locationtech.jts.algorithm.distance.PointPairDistance;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Envelope;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.prep.PreparedGeometry;
import org.locationtech.jts.geom.prep.PreparedGeometryFactory;
import org.locationtech.jts.index.strtree.STRtree;
import org.locationtech.jts.operation.overlay.snap.GeometrySnapper;
import org.locationtech.jts.operation.polygonize.Polygonizer;
import org.locationtech.jts.operation.union.UnaryUnionOp;
import org.locationtech.jts.simplify.TopologyPreservingSimplifier;
import org.locationtech.jts.operation.distance.DistanceOp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Spatial operations on app features. Inputs and outputs are WGS84 lon/lat {@link Feature}s; every metric
 * computation runs in a local azimuthal-equidistant CRS centred on the data (distances from the centre are exact,
 * distortion stays below ~1e-4 for regions up to ~100 km). Invalid polygons are repaired automatically before use.
 * Operations that can produce nothing return null or an empty list.
 */
public final class GeoOps {
    private GeoOps() {
    }

    public enum Mode {
        /** Geometry lies in the polygon interior (touching the boundary does not count). */
        INSIDE,
        /** Geometry is fully inside, boundary contact allowed (covers). */
        BOUNDARY_INCLUDED,
        /** Geometry shares at least one point with the polygon. */
        INTERSECTS
    }

    private static IllegalArgumentException bad(String ar, String en) {
        return new IllegalArgumentException(S.t(ar, en));
    }

    private static Geometry need(Local l, Feature f, String what) {
        if (f == null) throw bad("المعلم " + what + " غير موجود", "Missing feature: " + what);
        Geometry g = l.geom(f);
        if (g == null || g.isEmpty()) throw bad("الهندسة فارغة: " + what, "Empty geometry: " + what);
        return g;
    }

    private static Feature template(Feature t) {
        if (t == null) return null;
        Feature c = t.copy();
        c.id = "";
        return c;
    }

    private static List<Feature> out(Local l, Geometry m, Feature t) {
        if (m == null || m.isEmpty()) return new ArrayList<>();
        return Jts.toFeatures(l.from(m), template(t));
    }

    private static Feature first(List<Feature> l) {
        return l.isEmpty() ? null : l.get(0);
    }

    // ------------------------------------------------------------------ overlay

    /**
     * Buffer in metres. Points, lines and polygons; a negative distance shrinks polygons. Returns a polygon feature or
     * null when the result is empty (e.g. a polygon shrunk away). segmentsPerQuarter 8..64 (accuracy: area error of a
     * point buffer is below 0.6 % at 16, 0.1 % at 32, 0.03 % at 64).
     */
    public static Feature buffer(Feature f, double meters, int segmentsPerQuarter) {
        if (Double.isNaN(meters) || Double.isInfinite(meters))
            throw bad("المسافة غير صالحة", "Invalid distance");
        if (meters < 0 && f.geom != Feature.POLYGON)
            throw bad("المسافة السالبة للمضلعات فقط", "Negative distance applies to polygons only");
        Local l = Local.around(Collections.singletonList(f));
        Geometry g = need(l, f, "buffer");
        int seg = Math.max(4, Math.min(128, segmentsPerQuarter));
        Geometry b = g.buffer(meters, seg);
        Feature t = template(f);
        if (t != null) t.geom = Feature.POLYGON;
        return first(out(l, b, t));
    }

    /** Union of the features; polygons give one (multi)polygon feature. Null when the list is empty. */
    public static Feature union(List<Feature> fs) {
        if (fs == null || fs.isEmpty()) return null;
        Local l = Local.around(fs);
        List<Geometry> gs = new ArrayList<>();
        for (Feature f : fs) {
            Geometry g = l.geom(f);
            if (g != null && !g.isEmpty()) gs.add(g);
        }
        if (gs.isEmpty()) return null;
        return first(out(l, UnaryUnionOp.union(gs), null));
    }

    /** Overlap of two features. */
    public static final class Overlap {
        public final Feature geometry;
        public final double areaM2, lengthM;

        Overlap(Feature g, double a, double len) {
            geometry = g;
            areaM2 = a;
            lengthM = len;
        }
    }

    /** Intersection of a and b; null when they do not overlap. areaM2 is ellipsoidal (polygons only). */
    public static Overlap intersection(Feature a, Feature b) {
        Local l = Local.around(java.util.Arrays.asList(a, b));
        Geometry ga = need(l, a, "A"), gb = need(l, b, "B");
        Geometry r = ga.intersection(gb);
        List<Feature> fs = out(l, r, null);
        Feature f = first(fs);
        if (f == null) return null;
        double ar = 0, len = 0;
        for (Feature x : fs) {
            if (x.geom == Feature.POLYGON) ar += Geodesy.area(x);
            else if (x.geom == Feature.LINE) len += Geodesy.length(x);
        }
        return new Overlap(f, ar, len);
    }

    /** a minus b; null when nothing remains. */
    public static Feature difference(Feature a, Feature b) {
        Local l = Local.around(java.util.Arrays.asList(a, b));
        Geometry ga = need(l, a, "A"), gb = need(l, b, "B");
        return first(out(l, ga.difference(gb), a));
    }

    /**
     * Splits a polygon (with holes / multi-part allowed) by a line. Returns the parts (new ids, attributes of the
     * polygon). The line may extend beyond the polygon. Throws when the line does not cut the polygon in two or more
     * pieces.
     */
    public static List<Feature> split(Feature polygon, Feature line) {
        if (polygon.geom != Feature.POLYGON || line.geom != Feature.LINE)
            throw bad("التقسيم يحتاج مضلعاً وخطاً", "Split needs a polygon and a line");
        Local l = Local.around(java.util.Arrays.asList(polygon, line));
        Geometry pg = need(l, polygon, "polygon"), ln = need(l, line, "line");
        Geometry nodes = pg.getBoundary().union(ln);
        Polygonizer pz = new Polygonizer();
        pz.add(nodes);
        @SuppressWarnings("unchecked")
        Collection<Geometry> faces = pz.getPolygons();
        PreparedGeometry prep = PreparedGeometryFactory.prepare(pg);
        List<Feature> parts = new ArrayList<>();
        for (Geometry face : faces) {
            Point ip = face.getInteriorPoint();
            if (!prep.covers(ip)) continue;
            parts.addAll(out(l, face, polygon));
        }
        if (parts.size() < 2)
            throw bad("الخط لا يقسم المضلع إلى جزأين", "The line does not split the polygon into two parts");
        return parts;
    }

    /** Convex hull of the features as a polygon (null for fewer than three distinct points). */
    public static Feature convexHull(List<Feature> fs) {
        if (fs == null || fs.isEmpty()) return null;
        Local l = Local.around(fs);
        List<Geometry> gs = new ArrayList<>();
        for (Feature f : fs) {
            Geometry g = l.geom(f);
            if (g != null) gs.add(g);
        }
        if (gs.isEmpty()) return null;
        Geometry h = new GeometryFactory().buildGeometry(gs).convexHull();
        return first(out(l, h, null));
    }

    /** Douglas-Peucker simplification (topology preserving) with the tolerance in metres. */
    public static Feature simplify(Feature f, double toleranceM) {
        if (f.geom == Feature.POINT) return f.copy();
        Local l = Local.around(Collections.singletonList(f));
        Geometry g = need(l, f, "simplify");
        Feature t = template(f);
        Feature r = first(out(l, TopologyPreservingSimplifier.simplify(g, Math.max(0, toleranceM)), t));
        if (r != null) r.id = f.id;
        return r;
    }

    // ------------------------------------------------------------------ selection

    private static boolean test(PreparedGeometry p, Geometry g, Mode m, boolean point) {
        switch (m) {
            case INSIDE:
                return point ? p.containsProperly(g) : p.contains(g);
            case BOUNDARY_INCLUDED:
                return p.covers(g);
            default:
                return p.intersects(g);
        }
    }

    /**
     * Indices (into the interleaved lon,lat array) of the points selected by the polygon. Allocation-light path for
     * very large point sets (1M points in about a second). Mode.INSIDE excludes points exactly on the boundary.
     */
    public static int[] selectIndices(double[] lonlat, Feature polygon, Mode mode) {
        Geometry pg = Jts.toGeometry(polygon);
        if (pg == null || polygon.geom != Feature.POLYGON) throw bad("المنطقة ليست مضلعاً", "Area is not a polygon");
        pg = Local.fix(pg);
        PreparedGeometry prep = PreparedGeometryFactory.prepare(pg);
        Envelope env = pg.getEnvelopeInternal();
        int n = lonlat.length / 2;
        int[] tmp = new int[1024];
        int c = 0;
        GeometryFactory gf = Jts.GF;
        Coordinate co = new Coordinate();
        for (int i = 0; i < n; i++) {
            double x = lonlat[2 * i], y = lonlat[2 * i + 1];
            if (!env.contains(x, y)) continue;
            co.x = x;
            co.y = y;
            Point p = gf.createPoint(new Coordinate(x, y));
            if (test(prep, p, mode, true)) {
                if (c == tmp.length) tmp = java.util.Arrays.copyOf(tmp, c * 2);
                tmp[c++] = i;
            }
        }
        return java.util.Arrays.copyOf(tmp, c);
    }

    /** Features of the layer selected by the polygon (same Feature objects, not copies). */
    public static List<Feature> select(LayerData layer, Feature polygon, Mode mode) {
        return select(layer.features, polygon, mode);
    }

    public static List<Feature> select(List<Feature> feats, Feature polygon, Mode mode) {
        if (polygon.geom != Feature.POLYGON) throw bad("المنطقة ليست مضلعاً", "Area is not a polygon");
        Geometry pg = Jts.toGeometry(polygon);
        if (pg == null) throw bad("المضلع فارغ", "Empty polygon");
        pg = Local.fix(pg);
        PreparedGeometry prep = PreparedGeometryFactory.prepare(pg);
        Envelope env = pg.getEnvelopeInternal();
        List<Feature> res = new ArrayList<>();
        STRtree tree = null;
        List<Feature> cand;
        boolean allPoints = true;
        for (Feature f : feats) if (f.geom != Feature.POINT) {
            allPoints = false;
            break;
        }
        if (allPoints) {
            cand = feats;
        } else {
            tree = new STRtree();
            for (Feature f : feats) {
                double[] b = GeomCodec.bbox(f);
                if (b[0] > b[2]) continue;
                tree.insert(new Envelope(b[0], b[2], b[1], b[3]), f);
            }
            @SuppressWarnings("unchecked")
            List<Feature> q = tree.query(env);
            cand = q;
        }
        for (Feature f : cand) {
            if (f.parts.isEmpty()) continue;
            if (f.geom == Feature.POINT) {
                double[] p = f.parts.get(0);
                if (!env.contains(p[0], p[1])) continue;
            }
            Geometry g = Jts.toGeometry(f);
            if (g == null) continue;
            if (!g.isValid()) g = Local.fix(g);
            if (test(prep, g, mode, f.geom == Feature.POINT)) res.add(f);
        }
        return res;
    }

    /**
     * Clips a layer with a polygon: points are filtered, lines and polygons are cut at the boundary. The result is a
     * new layer; features are copies with new ids. includeBoundary=true keeps points exactly on the boundary.
     */
    public static LayerData clip(LayerData layer, Feature polygon, boolean includeBoundary) {
        if (polygon.geom != Feature.POLYGON) throw bad("منطقة القص ليست مضلعاً", "Clip area is not a polygon");
        LayerData res = new LayerData("clip_" + Feature.newId(), layer.label, layer.geom);
        res.kind = "user";
        res.color = layer.color;
        res.width = layer.width;
        res.opacity = layer.opacity;
        res.source = layer.source;
        res.sourceDate = layer.sourceDate;
        Mode mode = includeBoundary ? Mode.BOUNDARY_INCLUDED : Mode.INSIDE;
        List<Feature> pts = new ArrayList<>(), rest = new ArrayList<>();
        for (Feature f : layer.features) (f.geom == Feature.POINT ? pts : rest).add(f);
        for (Feature f : select(pts, polygon, mode)) {
            Feature c = f.copy();
            c.id = Feature.newId();
            res.features.add(c);
        }
        if (!rest.isEmpty()) {
            List<Feature> all = new ArrayList<>(rest);
            all.add(polygon);
            Local l = Local.around(all);
            Geometry clipG = need(l, polygon, "clip");
            PreparedGeometry prep = PreparedGeometryFactory.prepare(clipG);
            for (Feature f : rest) {
                Geometry g = l.geom(f);
                if (g == null || g.isEmpty() || !prep.intersects(g)) continue;
                Geometry r = prep.covers(g) ? g : g.intersection(clipG);
                for (Feature o : out(l, r, f)) {
                    if (o.geom != f.geom) continue;
                    o.id = Feature.newId();
                    res.features.add(o);
                }
            }
        }
        return res;
    }

    // ------------------------------------------------------------------ nearest

    /** A nearest-feature answer. */
    public static final class Hit {
        public final Feature feature;
        public final double distanceM, bearingDeg, lat, lon;

        Hit(Feature f, double d, double b, double lat, double lon) {
            feature = f;
            distanceM = d;
            bearingDeg = b;
            this.lat = lat;
            this.lon = lon;
        }
    }

    /** Spatial index for repeated nearest queries. */
    public static final class NearestIndex {
        private final STRtree tree = new STRtree();
        private final double cosLat;
        private final List<Feature> feats;

        public NearestIndex(List<Feature> feats) {
            this.feats = feats;
            Local c = Local.around(feats);
            cosLat = Math.max(0.05, Math.cos(Math.toRadians(c.lat)));
            for (Feature f : feats) {
                Geometry g = Jts.toGeometry(f);
                if (g == null || g.isEmpty()) continue;
                Geometry s = scaled(g);
                tree.insert(s.getEnvelopeInternal(), new Object[]{f, s});
            }
            if (!feats.isEmpty()) tree.build();
        }

        private Geometry scaled(Geometry g) {
            Geometry c = g.copy();
            c.apply(new org.locationtech.jts.geom.CoordinateFilter() {
                public void filter(Coordinate co) {
                    co.x *= cosLat;
                }
            });
            c.geometryChanged();
            return c;
        }

        /** The k nearest features to the position, nearest first, with geodesic distances. */
        public List<Hit> query(double lat, double lon, int k) {
            List<Hit> hits = new ArrayList<>();
            if (feats.isEmpty() || k <= 0) return hits;
            Point q = Jts.GF.createPoint(new Coordinate(lon * cosLat, lat));
            int kk = Math.min(feats.size(), Math.max(k * 3, k + 8));
            Object[] items = tree.nearestNeighbour(q.getEnvelopeInternal(), new Object[]{null, q},
                    new org.locationtech.jts.index.strtree.ItemDistance() {
                        public double distance(org.locationtech.jts.index.strtree.ItemBoundable a,
                                               org.locationtech.jts.index.strtree.ItemBoundable b) {
                            Object[] x = (Object[]) a.getItem(), y = (Object[]) b.getItem();
                            return ((Geometry) x[1]).distance((Geometry) y[1]);
                        }
                    }, kk);
            Local loc = new Local(lon, lat);
            Geometry origin = Jts.GF.createPoint(new Coordinate(0, 0));
            for (Object it : items) {
                Feature f = (Feature) ((Object[]) it)[0];
                Geometry g = loc.to(Jts.toGeometry(f));
                Coordinate[] nn = DistanceOp.nearestPoints(g, origin);
                Coordinate on = nn[0];
                Geometry back = loc.from(Jts.GF.createPoint(on));
                double plat = back.getCoordinate().y, plon = back.getCoordinate().x;
                Geodesy.Inverse inv = Geodesy.inverse(lat, lon, plat, plon);
                hits.add(new Hit(f, inv.distance, inv.azimuth1, plat, plon));
            }
            Collections.sort(hits, new Comparator<Hit>() {
                public int compare(Hit a, Hit b) {
                    return Double.compare(a.distanceM, b.distanceM);
                }
            });
            return hits.size() > k ? new ArrayList<>(hits.subList(0, k)) : hits;
        }
    }

    public static List<Hit> nearest(LayerData layer, double lat, double lon, int k) {
        return new NearestIndex(layer.features).query(lat, lon, k);
    }

    // ------------------------------------------------------------------ grids, centres, vertices

    private static final int GRID_LIMIT = 2_000_000;

    /** Regular point grid (spacing in metres, in the local metric plane) of the points that fall in the polygon. */
    public static List<Feature> pointGrid(Feature polygon, double spacingM) {
        if (!(spacingM > 0)) throw bad("المسافة يجب أن تكون موجبة", "Spacing must be positive");
        Local l = Local.around(Collections.singletonList(polygon));
        Geometry pg = need(l, polygon, "polygon");
        Envelope e = pg.getEnvelopeInternal();
        double est = (e.getWidth() / spacingM + 1) * (e.getHeight() / spacingM + 1);
        if (est > GRID_LIMIT) throw bad("الشبكة كبيرة جداً (" + (long) est + " نقطة)، زد المسافة",
                "Grid too large (" + (long) est + " points); increase the spacing");
        PreparedGeometry prep = PreparedGeometryFactory.prepare(pg);
        List<Feature> res = new ArrayList<>();
        int row = 0;
        for (double y = e.getMinY() + spacingM / 2; y <= e.getMaxY(); y += spacingM, row++) {
            int col = 0;
            for (double x = e.getMinX() + spacingM / 2; x <= e.getMaxX(); x += spacingM, col++) {
                Point p = Jts.GF.createPoint(new Coordinate(x, y));
                if (!prep.covers(p)) continue;
                Feature f = first(out(l, p, null));
                f.attrs.put("row", String.valueOf(row));
                f.attrs.put("col", String.valueOf(col));
                res.add(f);
            }
        }
        return res;
    }

    /**
     * Square grid of cellM-metre cells over the polygon. clipToPolygon=true cuts edge cells at the boundary,
     * otherwise every cell that touches the polygon is kept whole. Cells carry attrs row/col.
     */
    public static List<Feature> squareGrid(Feature polygon, double cellM, boolean clipToPolygon) {
        if (!(cellM > 0)) throw bad("حجم الخلية يجب أن يكون موجباً", "Cell size must be positive");
        Local l = Local.around(Collections.singletonList(polygon));
        Geometry pg = need(l, polygon, "polygon");
        Envelope e = pg.getEnvelopeInternal();
        double est = (e.getWidth() / cellM + 1) * (e.getHeight() / cellM + 1);
        if (est > 500_000) throw bad("الشبكة كبيرة جداً (" + (long) est + " خلية)، زد الحجم",
                "Grid too large (" + (long) est + " cells); increase the cell size");
        PreparedGeometry prep = PreparedGeometryFactory.prepare(pg);
        GeometryFactory gf = Jts.GF;
        List<Feature> res = new ArrayList<>();
        int row = 0;
        for (double y = e.getMinY(); y < e.getMaxY(); y += cellM, row++) {
            int col = 0;
            for (double x = e.getMinX(); x < e.getMaxX(); x += cellM, col++) {
                Geometry cell = gf.toGeometry(new Envelope(x, x + cellM, y, y + cellM));
                if (!prep.intersects(cell)) continue;
                Geometry g = cell;
                if (clipToPolygon && !prep.covers(cell)) {
                    g = cell.intersection(pg);
                    if (g.isEmpty() || g.getArea() <= 0) continue;
                } else {
                    Geometry ix = cell.intersection(pg);
                    if (ix.isEmpty() || ix.getArea() <= 0) continue;
                }
                for (Feature f : out(l, g, null)) {
                    if (f.geom != Feature.POLYGON) continue;
                    f.attrs.put("row", String.valueOf(row));
                    f.attrs.put("col", String.valueOf(col));
                    res.add(f);
                }
            }
        }
        return res;
    }

    /** Centre of mass {lon, lat}, computed in the local metric plane (area-weighted for polygons). */
    public static double[] centroid(Feature f) {
        Local l = Local.around(Collections.singletonList(f));
        Geometry g = need(l, f, "centroid");
        Coordinate c = l.from(g.getCentroid()).getCoordinate();
        return new double[]{c.x, c.y};
    }

    /** A point guaranteed to lie on/in the feature {lon, lat}. */
    public static double[] representativePoint(Feature f) {
        Local l = Local.around(Collections.singletonList(f));
        Geometry g = need(l, f, "point");
        Coordinate c = l.from(g.getInteriorPoint()).getCoordinate();
        return new double[]{c.x, c.y};
    }

    /** One vertex of a feature (closing vertices of rings are omitted). */
    public static final class Vertex {
        public final int part, index;
        public final double lon, lat;
        public final boolean hole;

        Vertex(int part, int index, double lon, double lat, boolean hole) {
            this.part = part;
            this.index = index;
            this.lon = lon;
            this.lat = lat;
            this.hole = hole;
        }
    }

    public static List<Vertex> vertices(Feature f) {
        List<Vertex> v = new ArrayList<>();
        for (int p = 0; p < f.parts.size(); p++) {
            double[] a = f.parts.get(p);
            int n = a.length / 2;
            if (f.geom == Feature.POLYGON && n > 1 && a[0] == a[2 * n - 2] && a[1] == a[2 * n - 1]) n--;
            for (int i = 0; i < n; i++) v.add(new Vertex(p, i, a[2 * i], a[2 * i + 1], f.isHole(p)));
        }
        return v;
    }
}
