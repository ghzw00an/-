package iq.gis.poiexporter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

/** Image that fits the view at first and can be pinched, dragged and double-tapped (for the report preview). */
final class ZoomImageView extends ImageView {
    private final Matrix m = new Matrix();
    private final ScaleGestureDetector sd;
    private final GestureDetector gd;
    private float minScale = 1f, lastX, lastY;
    private boolean dragging;

    ZoomImageView(Context c) {
        super(c);
        setScaleType(ScaleType.MATRIX);
        sd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float s = d.getScaleFactor();
                float cur = scale();
                s = Math.max(minScale * 0.99f / cur, Math.min(8f * minScale / cur, s));
                m.postScale(s, s, d.getFocusX(), d.getFocusY());
                fix();
                return true;
            }
        });
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (scale() > minScale * 1.5f) fit();
                else {
                    m.postScale(3f, 3f, e.getX(), e.getY());
                    fix();
                }
                return true;
            }
        });
    }

    void show(Bitmap b) {
        setImageBitmap(b);
        post(this::fit);
    }

    private float scale() {
        float[] v = new float[9];
        m.getValues(v);
        return v[Matrix.MSCALE_X];
    }

    private void fit() {
        if (getDrawable() == null || getWidth() == 0) return;
        float bw = getDrawable().getIntrinsicWidth(), bh = getDrawable().getIntrinsicHeight();
        float s = Math.min(getWidth() / bw, getHeight() / bh);
        m.reset();
        m.postScale(s, s);
        m.postTranslate((getWidth() - bw * s) / 2, (getHeight() - bh * s) / 2);
        minScale = s;
        setImageMatrix(m);
    }

    private void fix() {
        if (getDrawable() == null) return;
        RectF r = new RectF(0, 0, getDrawable().getIntrinsicWidth(), getDrawable().getIntrinsicHeight());
        m.mapRect(r);
        float dx = 0, dy = 0;
        if (r.width() <= getWidth()) dx = (getWidth() - r.width()) / 2 - r.left;
        else if (r.left > 0) dx = -r.left;
        else if (r.right < getWidth()) dx = getWidth() - r.right;
        if (r.height() <= getHeight()) dy = (getHeight() - r.height()) / 2 - r.top;
        else if (r.top > 0) dy = -r.top;
        else if (r.bottom < getHeight()) dy = getHeight() - r.bottom;
        m.postTranslate(dx, dy);
        setImageMatrix(m);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fit();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        sd.onTouchEvent(e);
        gd.onTouchEvent(e);
        if (!sd.isInProgress()) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = e.getX();
                    lastY = e.getY();
                    dragging = true;
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (dragging && e.getPointerCount() == 1) {
                        m.postTranslate(e.getX() - lastX, e.getY() - lastY);
                        lastX = e.getX();
                        lastY = e.getY();
                        fix();
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    break;
                default:
                    break;
            }
        } else dragging = false;
        getParent().requestDisallowInterceptTouchEvent(true);
        return true;
    }
}
