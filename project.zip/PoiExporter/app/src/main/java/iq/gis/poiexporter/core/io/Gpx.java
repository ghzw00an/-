package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.MiniJson;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/** GPX 1.1 reader (waypoints, routes, tracks) and writer. GPX is WGS84 by definition. */
public final class Gpx {
    private Gpx() {
    }

    public static final String L_WPT = "waypoints", L_RTE = "routes", L_TRK = "tracks";

    public static void read(File f, Visitor v, ReadInfo info) throws IOException {
        info.crs = iq.gis.poiexporter.core.crs.Crs.wgs84();
        try {
            SAXParserFactory sf = SAXParserFactory.newInstance();
            sf.setNamespaceAware(false);
            try {
                sf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            } catch (Exception ignored) {
                // Android's parser does not resolve external entities anyway
            }
            SAXParser p = sf.newSAXParser();
            p.parse(new InputSource(new BufferedInputStream(new FileInputStream(f), 1 << 16)), new H(v, info));
        } catch (StopException e) {
            // visitor asked to stop
        } catch (SAXException e) {
            throw new IOException(S.t("ملف GPX غير صالح: ", "Invalid GPX file: ") + e.getMessage());
        } catch (javax.xml.parsers.ParserConfigurationException e) {
            throw new IOException(e.getMessage());
        }
    }

    private static final class StopException extends SAXException {
    }

    private static final class H extends DefaultHandler {
        final Visitor v;
        final ReadInfo info;
        final StringBuilder text = new StringBuilder();
        String kind; // wpt, rte, trk
        Feature cur;
        List<double[]> segs = new ArrayList<>();
        List<Double> pts = new ArrayList<>();
        boolean inPt;
        double ptLat, ptLon;
        String ele = "";

        H(Visitor v, ReadInfo info) {
            this.v = v;
            this.info = info;
        }

        public void startElement(String u, String l, String q, Attributes a) {
            text.setLength(0);
            switch (q) {
                case "wpt":
                    kind = "wpt";
                    cur = new Feature();
                    cur.geom = Feature.POINT;
                    ptLat = num(a.getValue("lat"));
                    ptLon = num(a.getValue("lon"));
                    break;
                case "rte":
                case "trk":
                    kind = q;
                    cur = new Feature();
                    cur.geom = Feature.LINE;
                    segs = new ArrayList<>();
                    pts = new ArrayList<>();
                    break;
                case "trkseg":
                    pts = new ArrayList<>();
                    break;
                case "rtept":
                case "trkpt":
                    inPt = true;
                    pts.add(num(a.getValue("lon")));
                    pts.add(num(a.getValue("lat")));
                    break;
                default:
                    break;
            }
        }

        public void characters(char[] ch, int s, int n) {
            if (text.length() < 4096) text.append(ch, s, n);
        }

        public void endElement(String u, String l, String q) throws SAXException {
            String t = text.toString().trim();
            switch (q) {
                case "name":
                    if (cur != null && !inPt) cur.name = t;
                    break;
                case "desc":
                case "cmt":
                    if (cur != null && !inPt && cur.description.isEmpty()) cur.description = t;
                    break;
                case "ele":
                    if (cur != null && kind.equals("wpt")) cur.attrs.put("ele", t);
                    break;
                case "time":
                    if (cur != null && kind.equals("wpt")) cur.attrs.put("time", t);
                    break;
                case "sym":
                case "type":
                    if (cur != null && kind.equals("wpt") && cur.type.isEmpty()) cur.type = t;
                    break;
                case "rtept":
                case "trkpt":
                    inPt = false;
                    break;
                case "trkseg":
                    if (pts.size() >= 4) segs.add(toArr(pts));
                    pts = new ArrayList<>();
                    break;
                case "wpt":
                    if (!Double.isNaN(ptLat) && !Double.isNaN(ptLon) && Math.abs(ptLat) <= 90 && Math.abs(ptLon) <= 180) {
                        cur.parts.add(new double[]{ptLon, ptLat});
                        cur.holes.add(Boolean.FALSE);
                        cur.lat = ptLat;
                        cur.lon = ptLon;
                        cur.id = Feature.newId();
                        emit(L_WPT, cur);
                    } else {
                        info.unreadable++;
                    }
                    cur = null;
                    break;
                case "rte":
                    if (pts.size() >= 4) segs.add(toArr(pts));
                    finishLine(L_RTE);
                    break;
                case "trk":
                    if (pts.size() >= 4) segs.add(toArr(pts));
                    finishLine(L_TRK);
                    break;
                default:
                    break;
            }
            text.setLength(0);
        }

        void finishLine(String layer) throws SAXException {
            if (cur != null) {
                for (double[] s : segs) cur.addPart(s, false);
                if (!cur.parts.isEmpty()) {
                    Geo.setRepresentative(cur);
                    cur.id = Feature.newId();
                    emit(layer, cur);
                } else {
                    info.unreadable++;
                }
            }
            cur = null;
            segs = new ArrayList<>();
            pts = new ArrayList<>();
        }

        void emit(String layer, Feature f) throws SAXException {
            if (info.cancel || !v.feature(layer, f)) throw new StopException();
        }
    }

    private static double[] toArr(List<Double> l) {
        double[] r = new double[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = l.get(i);
        return r;
    }

    private static double num(String s) {
        try {
            return s == null ? Double.NaN : Double.parseDouble(s.trim());
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    // ------------------------------------------------------------------ writing

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static String c(double d) {
        return String.format(Locale.US, "%.9f", d);
    }

    /** Points become waypoints, lines tracks, polygons closed tracks (GPX has no polygons). */
    public static void write(List<LayerData> layers, ExportOptions o, OutputStream os) throws IOException {
        Writer w = new BufferedWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8), 1 << 16);
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"PoiExporter\" "
                + "xmlns=\"http://www.topografix.com/GPX/1/1\">\n<metadata><name>" + esc(o.docName) + "</name></metadata>\n");
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                if (f.parts.isEmpty() || f.geom != Feature.POINT) continue;
                double[] p = f.parts.get(0);
                w.write("<wpt lat=\"" + c(p[1]) + "\" lon=\"" + c(p[0]) + "\">");
                if (f.attrs.containsKey("ele")) w.write("<ele>" + esc(f.attrs.get("ele")) + "</ele>");
                w.write("<name>" + esc(f.name) + "</name>");
                String d = f.description.isEmpty() ? f.notes : f.description;
                if (!d.isEmpty()) w.write("<desc>" + esc(d) + "</desc>");
                if (!f.type.isEmpty()) w.write("<type>" + esc(f.type) + "</type>");
                w.write("</wpt>\n");
            }
        }
        for (LayerData l : layers) {
            for (Feature f : l.features) {
                if (f.parts.isEmpty() || f.geom == Feature.POINT) continue;
                w.write("<trk><name>" + esc(f.name.isEmpty() ? l.label : f.name) + "</name>");
                if (f.geom == Feature.POLYGON) w.write("<desc>polygon ring</desc>");
                for (double[] p : f.parts) {
                    w.write("<trkseg>");
                    for (int i = 0; i + 1 < p.length; i += 2)
                        w.write("<trkpt lat=\"" + c(p[i + 1]) + "\" lon=\"" + c(p[i]) + "\"/>");
                    w.write("</trkseg>");
                }
                w.write("</trk>\n");
            }
        }
        w.write("</gpx>\n");
        w.flush();
    }
}
