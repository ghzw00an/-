package iq.gis.poiexporter.core.io;

import java.util.Locale;

/** File formats handled by the import/export hub. */
public enum GeoFormat {
    GEOJSON("GeoJSON", "geojson", "application/geo+json"),
    KML("KML", "kml", "application/vnd.google-earth.kml+xml"),
    KMZ("KMZ", "kmz", "application/vnd.google-earth.kmz"),
    GPX("GPX", "gpx", "application/gpx+xml"),
    SHP_ZIP("Shapefile (ZIP)", "zip", "application/zip"),
    CSV("CSV / TXT", "csv", "text/csv"),
    XLSX("Excel (XLSX)", "xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    GPKG("GeoPackage", "gpkg", "application/geopackage+sqlite3"),
    DXF("DXF (AutoCAD)", "dxf", "image/vnd.dxf"),
    UNKNOWN("?", "bin", "application/octet-stream");

    public final String label, ext, mime;

    GeoFormat(String label, String ext, String mime) {
        this.label = label;
        this.ext = ext;
        this.mime = mime;
    }

    /** Detects the format from the file name and the first bytes of the file (the content wins over the extension). */
    public static GeoFormat detect(String name, byte[] head) {
        String n = name == null ? "" : name.toLowerCase(Locale.US);
        int len = head == null ? 0 : head.length;
        if (len >= 16 && new String(head, 0, 15, java.nio.charset.StandardCharsets.ISO_8859_1).equals("SQLite format 3")) return GPKG;
        if (len >= 4 && head[0] == 'P' && head[1] == 'K' && head[2] == 3 && head[3] == 4) {
            if (n.endsWith(".kmz")) return KMZ;
            if (n.endsWith(".xlsx") || n.endsWith(".xlsm")) return XLSX;
            String h = new String(head, 0, Math.min(len, 4096), java.nio.charset.StandardCharsets.ISO_8859_1);
            if (h.contains("[Content_Types].xml") || h.contains("xl/")) return XLSX;
            if (h.contains("doc.kml") || h.contains(".kml")) return KMZ;
            return SHP_ZIP;
        }
        String text = len == 0 ? "" : new String(head, 0, Math.min(len, 2048), java.nio.charset.StandardCharsets.UTF_8).trim();
        if (text.startsWith("﻿")) text = text.substring(1).trim();
        if (text.startsWith("{") || text.startsWith("[")) {
            if (text.contains("\"type\"") || text.contains("coordinates") || n.endsWith("json")) return GEOJSON;
        }
        if (text.startsWith("0\nSECTION") || text.startsWith("0\r\nSECTION") || text.startsWith("  0\nSECTION") || text.startsWith("  0\r\nSECTION")) return DXF;
        if (text.startsWith("<")) {
            String low = text.toLowerCase(Locale.US);
            if (low.contains("<gpx")) return GPX;
            if (low.contains("<kml")) return KML;
        }
        if (n.endsWith(".dxf")) return DXF;
        if (n.endsWith(".geojson") || n.endsWith(".json")) return GEOJSON;
        if (n.endsWith(".gpx")) return GPX;
        if (n.endsWith(".kml")) return KML;
        if (n.endsWith(".kmz")) return KMZ;
        if (n.endsWith(".gpkg")) return GPKG;
        if (n.endsWith(".xlsx")) return XLSX;
        if (n.endsWith(".zip")) return SHP_ZIP;
        if (n.endsWith(".csv") || n.endsWith(".txt") || n.endsWith(".tsv") || n.endsWith(".tab")) return CSV;
        return UNKNOWN;
    }
}
