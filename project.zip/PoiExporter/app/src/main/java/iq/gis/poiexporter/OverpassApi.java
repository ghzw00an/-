package iq.gis.poiexporter;

import iq.gis.poiexporter.core.AdminIndex;
import iq.gis.poiexporter.core.Poi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Free OpenStreetMap data through the Overpass API. No key needed. */
final class OverpassApi {
    private static final String[] ENDPOINTS = {
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter"};

    static final class Category {
        final String label, key;
        final String[] values; // empty = any value of the key

        Category(String label, String key, String... values) {
            this.label = label;
            this.key = key;
            this.values = values;
        }

        String selector() {
            if (values.length == 0) return "[\"" + key + "\"]";
            StringBuilder sb = new StringBuilder("[\"" + key + "\"~\"^(");
            for (int i = 0; i < values.length; i++) sb.append(i > 0 ? "|" : "").append(values[i]);
            return sb.append(")$\"]").toString();
        }

        boolean matches(JSONObject tags) {
            String v = tags.optString(key, "");
            if (v.isEmpty()) return false;
            if (values.length == 0) return true;
            for (String s : values) if (s.equals(v)) return true;
            return false;
        }
    }

    static final Category[] CATEGORIES = {
            new Category("مدرسة", "amenity", "school", "kindergarten"),
            new Category("جامعة / كلية", "amenity", "university", "college"),
            new Category("مستشفى", "amenity", "hospital"),
            new Category("عيادة / مركز صحي", "amenity", "clinic", "doctors"),
            new Category("صيدلية", "amenity", "pharmacy"),
            new Category("مسجد / دار عبادة", "amenity", "place_of_worship"),
            new Category("مطعم / مقهى", "amenity", "restaurant", "cafe", "fast_food"),
            new Category("مصرف", "amenity", "bank"),
            new Category("محطة وقود", "amenity", "fuel"),
            new Category("فندق", "tourism", "hotel", "guest_house", "motel"),
            new Category("شرطة / أمن", "amenity", "police"),
            new Category("دائرة حكومية", "amenity", "townhall", "courthouse", "public_building"),
            new Category("متجر / سوق", "shop"),
            new Category("سياحي", "tourism", "attraction", "museum", "viewpoint"),
            new Category("أثري / تاريخي", "historic"),
    };

    private static final String[] TYPE_KEYS = {"amenity", "shop", "tourism", "historic", "leisure", "office",
            "healthcare", "man_made", "building"};

    private OverpassApi() {}

    private static String num(double d) {
        return String.format(Locale.US, "%.6f", d);
    }

    /** Accepts "key=value" or "key"; returns an Overpass filter or null if invalid. */
    static String customSelector(String raw) {
        if (raw == null) return null;
        raw = raw.trim();
        if (raw.isEmpty()) return null;
        String[] kv = raw.split("=", 2);
        String ok = "[A-Za-z0-9_:\\-|]+";
        if (!kv[0].matches(ok)) throw new IllegalArgumentException("مرشح غير صالح: " + raw);
        if (kv.length == 1 || kv[1].isEmpty()) return "[\"" + kv[0] + "\"]";
        if (!kv[1].matches(ok)) throw new IllegalArgumentException("مرشح غير صالح: " + raw);
        if (kv[1].contains("|")) return "[\"" + kv[0] + "\"~\"^(" + kv[1] + ")$\"]";
        return "[\"" + kv[0] + "\"=\"" + kv[1] + "\"]";
    }

    /** Fetches POIs inside the rectangle. */
    static List<Poi> fetchPois(double s, double w, double n, double e, boolean[] sel, String custom,
                               boolean includeUnnamed) throws IOException {
        String bbox = "(" + num(s) + "," + num(w) + "," + num(n) + "," + num(e) + ")";
        String named = includeUnnamed ? "" : "[\"name\"]";
        StringBuilder q = new StringBuilder("[out:json][timeout:90];(");
        int parts = 0;
        for (int i = 0; i < CATEGORIES.length; i++) {
            if (sel[i]) {
                q.append("nwr").append(CATEGORIES[i].selector()).append(named).append(bbox).append(";");
                parts++;
            }
        }
        String cs;
        try {
            cs = customSelector(custom);
        } catch (IllegalArgumentException ex) {
            throw new IOException(ex.getMessage());
        }
        if (cs != null) {
            q.append("nwr").append(cs).append(named).append(bbox).append(";");
            parts++;
        }
        if (parts == 0) throw new IOException("اختر فئة واحدة على الأقل");
        q.append(");out center tags;");

        try {
            JSONObject root = new JSONObject(post(q.toString()));
            JSONArray els = root.optJSONArray("elements");
            List<Poi> list = new ArrayList<>();
            if (els == null || els.length() == 0) {
                String remark = root.optString("remark", "");
                if (remark.contains("error")) throw new IOException("انتهت مهلة الخادم، قلّل المساحة أو زد التقسيم");
                return list;
            }
            for (int i = 0; i < els.length(); i++) {
                JSONObject el = els.getJSONObject(i);
                JSONObject tags = el.optJSONObject("tags");
                if (tags == null) continue;
                double lat, lon;
                if (el.has("lat")) {
                    lat = el.getDouble("lat");
                    lon = el.getDouble("lon");
                } else {
                    JSONObject c = el.optJSONObject("center");
                    if (c == null) continue;
                    lat = c.getDouble("lat");
                    lon = c.getDouble("lon");
                }
                Poi p = new Poi();
                p.id = el.optString("type", "") + "/" + el.optLong("id");
                p.name = firstNonEmpty(tags.optString("name:ar", ""), tags.optString("name", ""),
                        tags.optString("name:en", ""));
                p.lat = lat;
                p.lon = lon;
                classify(p, tags, sel, cs != null ? custom.trim() : null);
                list.add(p);
            }
            return list;
        } catch (JSONException ex) {
            throw new IOException("استجابة غير مفهومة من الخادم");
        }
    }

    private static String firstNonEmpty(String... v) {
        for (String s : v) if (s != null && !s.isEmpty()) return s;
        return "";
    }

    private static void classify(Poi p, JSONObject tags, boolean[] sel, String custom) {
        for (int i = 0; i < CATEGORIES.length; i++) {
            Category c = CATEGORIES[i];
            if (sel[i] && c.matches(tags)) {
                p.type = c.key + "=" + tags.optString(c.key, "");
                p.category = c.label;
                return;
            }
        }
        for (String k : TYPE_KEYS) {
            String v = tags.optString(k, "");
            if (!v.isEmpty()) {
                p.type = k + "=" + v;
                p.category = v;
                return;
            }
        }
    }

    /** Downloads administrative boundaries of the given levels covering the rectangle. */
    static AdminIndex fetchAdmin(double s, double w, double n, double e, int[] levels) throws IOException {
        StringBuilder lv = new StringBuilder();
        for (int i = 0; i < levels.length; i++) lv.append(i > 0 ? "|" : "").append(levels[i]);
        String q = "[out:json][timeout:120];rel[\"boundary\"=\"administrative\"][\"admin_level\"~\"^(" + lv + ")$\"]("
                + num(s) + "," + num(w) + "," + num(n) + "," + num(e) + ");out geom qt;";
        AdminIndex idx = new AdminIndex();
        try {
            JSONObject root = new JSONObject(post(q));
            JSONArray els = root.optJSONArray("elements");
            if (els == null) return idx;
            for (int i = 0; i < els.length(); i++) {
                JSONObject el = els.getJSONObject(i);
                JSONObject tags = el.optJSONObject("tags");
                JSONArray members = el.optJSONArray("members");
                if (tags == null || members == null) continue;
                int level;
                try {
                    level = Integer.parseInt(tags.optString("admin_level", ""));
                } catch (NumberFormatException nfe) {
                    continue;
                }
                String name = firstNonEmpty(tags.optString("name:ar", ""), tags.optString("name", ""),
                        tags.optString("name:en", ""));
                List<double[]> ways = new ArrayList<>();
                for (int m = 0; m < members.length(); m++) {
                    JSONObject mem = members.getJSONObject(m);
                    if (!"way".equals(mem.optString("type"))) continue;
                    String role = mem.optString("role", "");
                    if (!role.isEmpty() && !role.equals("outer")) continue;
                    JSONArray g = mem.optJSONArray("geometry");
                    if (g == null || g.length() < 2) continue;
                    double[] arr = new double[g.length() * 2];
                    for (int k = 0; k < g.length(); k++) {
                        JSONObject pt = g.optJSONObject(k);
                        if (pt == null) {
                            arr[2 * k] = Double.NaN;
                            arr[2 * k + 1] = Double.NaN;
                        } else {
                            arr[2 * k] = pt.getDouble("lat");
                            arr[2 * k + 1] = pt.getDouble("lon");
                        }
                    }
                    ways.add(arr);
                }
                if (!ways.isEmpty()) idx.add(level, name, ways);
            }
            return idx;
        } catch (JSONException ex) {
            throw new IOException("استجابة الحدود الإدارية غير مفهومة");
        }
    }

    private static String post(String query) throws IOException {
        IOException last = null;
        for (String ep : ENDPOINTS) {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(ep).openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(20000);
                c.setReadTimeout(150000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                c.setRequestProperty("User-Agent", "PoiExporter/1.0 (Android)");
                OutputStream os = c.getOutputStream();
                try {
                    os.write(("data=" + URLEncoder.encode(query, "UTF-8")).getBytes("UTF-8"));
                } finally {
                    os.close();
                }
                int code = c.getResponseCode();
                InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                if (in != null) {
                    byte[] buf = new byte[16384];
                    int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                    in.close();
                }
                if (code >= 400) {
                    last = new IOException("HTTP " + code + " من " + ep);
                    continue;
                }
                return out.toString("UTF-8");
            } catch (IOException ex) {
                last = ex;
            }
        }
        throw last != null ? last : new IOException("تعذّر الاتصال");
    }
}
