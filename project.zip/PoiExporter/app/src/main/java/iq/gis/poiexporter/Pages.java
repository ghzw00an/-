package iq.gis.poiexporter;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.net.Uri;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;
import java.util.Set;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Catalog;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.LayerData;

/** The full-screen pages reachable from the side menu. */
public final class Pages {
    private final MainActivity a;
    private EditText centerField;
    private TextView infoView, formatsView;
    private boolean silent;

    Pages(MainActivity a) {
        this.a = a;
    }

    // ------------------------------------------------------------------ small builders

    private LinearLayout col() {
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private TextView head(String s) {
        TextView t = Ui.text(a, s, 16, Theme.text, true);
        t.setPadding(0, 0, 0, Ui.dp(a, 8));
        return t;
    }

    private TextView note(String s) {
        TextView t = Ui.text(a, s, 12.5f, Theme.sub, false);
        t.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 4));
        return t;
    }

    private TextView label(String s) {
        TextView t = Ui.text(a, s, 13, Theme.sub, false);
        t.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 4));
        return t;
    }

    private View toggle(String text, boolean on, final java.util.function.Consumer<Boolean> cb) {
        final boolean[] st = {on};
        LinearLayout r = Ui.row(a);
        r.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
        r.setClickable(true);
        final TextView box = Ui.text(a, on ? "☑" : "☐", 22, on ? Theme.primary : Theme.sub, true);
        TextView t = Ui.text(a, text, 14.5f, Theme.text, false);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.setMargins(Ui.dp(a, 10), 0, 0, 0);
        r.addView(box, new LinearLayout.LayoutParams(Ui.dp(a, 30), -2));
        r.addView(t, tl);
        Ui.pressable(r);
        r.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                st[0] = !st[0];
                box.setText(st[0] ? "☑" : "☐");
                box.setTextColor(st[0] ? Theme.primary : Theme.sub);
                box.animate().scaleX(1.25f).scaleY(1.25f).setDuration(90).withEndAction(new Runnable() {
                    public void run() {
                        box.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
                    }
                }).start();
                cb.accept(st[0]);
            }
        });
        return r;
    }

    static String folderName(String uri) {
        try {
            String id = Uri.parse(uri).getLastPathSegment();
            return id == null ? uri : id.replace(':', '/');
        } catch (Exception e) {
            return uri;
        }
    }

    private static double num(String s, double def) {
        try {
            return Double.parseDouble(s.trim().replace(',', '.'));
        } catch (Exception e) {
            return def;
        }
    }

    // ------------------------------------------------------------------ shape & size (shared)

    private final boolean[] kmUnit = {true};

    private void shapeSize(final LinearLayout box) {
        box.removeAllViews();
        final int shape = a.prefs.shape();
        box.addView(label(S.t("نوع المنطقة المحددة", "Selection shape")));
        LinearLayout ch = Ui.chips(a, new String[]{S.t("مستطيل", "Rectangle"), S.t("مربع", "Square"), S.t("دائرة", "Circle")},
                shape, new Ui.OnPick() {
                    public void pick(int i) {
                        a.prefs.shape(i);
                        a.applyArea(false);
                        shapeSize(box);
                    }
                });
        box.addView(ch, new LinearLayout.LayoutParams(-1, -2));
        box.addView(label(S.t("الوحدة", "Unit")));
        box.addView(Ui.chips(a, new String[]{S.t("كيلومتر", "Kilometres"), S.t("متر", "Metres")}, kmUnit[0] ? 0 : 1,
                new Ui.OnPick() {
                    public void pick(int i) {
                        kmUnit[0] = i == 0;
                        shapeSize(box);
                    }
                }), new LinearLayout.LayoutParams(-1, -2));
        final double f = kmUnit[0] ? 1000 : 1;
        final EditText w = Ui.field(a, "", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        w.setText(trim(a.prefs.width() / f));
        box.addView(label(shape == 2 ? S.t("نصف القطر", "Radius")
                : shape == 1 ? S.t("طول الضلع", "Side length") : S.t("العرض (شرق – غرب)", "Width (east–west)")));
        box.addView(w, new LinearLayout.LayoutParams(-1, -2));
        final EditText h = Ui.field(a, "", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        h.setText(trim(a.prefs.height() / f));
        if (shape == 0) {
            box.addView(label(S.t("الطول (شمال – جنوب)", "Height (north–south)")));
            box.addView(h, new LinearLayout.LayoutParams(-1, -2));
        }
        if (shape != 2) {
            box.addView(label(S.t("الاتجاه (دوران 0–360°)", "Rotation (0–360°)")));
            final EditText rf = Ui.field(a, "0", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            rf.setText(trim(a.prefs.rot()));
            rf.setGravity(Gravity.CENTER);
            rf.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int st, int c, int af) {
                }

                public void onTextChanged(CharSequence s, int st, int b, int c) {
                }

                public void afterTextChanged(Editable e) {
                    a.prefs.rot(num(e.toString(), 0));
                    a.applyArea(false);
                }
            });
            LinearLayout rr = Ui.row(a);
            rr.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            rr.addView(Ui.button(a, "−15°", false, new Runnable() {
                public void run() {
                    rf.setText(trim(((a.prefs.rot() - 15) % 360 + 360) % 360));
                }
            }), new LinearLayout.LayoutParams(Ui.dp(a, 80), -2));
            rr.addView(rf, Ui.lp(0, -2, 1f, a, 6, 0, 6, 0));
            rr.addView(Ui.button(a, "+15°", false, new Runnable() {
                public void run() {
                    rf.setText(trim((a.prefs.rot() + 15) % 360));
                }
            }), new LinearLayout.LayoutParams(Ui.dp(a, 80), -2));
            box.addView(rr);
            box.addView(note(S.t("على الخريطة: اسحب المقبض الأزرق ↻ فوق المنطقة لتدويرها.", "On the map: drag the blue ↻ handle above the area to rotate it.")));
        }
        TextWatcher tw = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                double wm = Math.max(10, Math.min(5.0e7, num(w.getText().toString(), a.prefs.width() / f) * f));
                double hm = Math.max(10, Math.min(5.0e7, num(h.getText().toString(), a.prefs.height() / f) * f));
                if (shape != 0) hm = wm;
                a.prefs.size(wm, shape == 0 ? hm : Math.max(a.prefs.height(), 10));
                if (shape != 0) a.prefs.size(wm, wm);
                a.applyArea(false);
            }
        };
        w.addTextChangedListener(tw);
        h.addTextChangedListener(tw);
    }

    private static String trim(double v) {
        String s = String.format(Locale.US, "%.4f", v);
        s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }

    // ------------------------------------------------------------------ settings

    View settings() {
        LinearLayout p = col();
        LinearLayout c = Ui.card(a);
        c.addView(head(S.t("المظهر", "Appearance")));
        c.addView(label(S.t("الثيم", "Theme")));
        c.addView(Ui.chips(a, new String[]{S.t("النظام", "System"), S.t("فاتح", "Light"), S.t("داكن", "Dark")},
                a.prefs.theme(), new Ui.OnPick() {
                    public void pick(int i) {
                        a.prefs.theme(i);
                        MainActivity.RESTORE_PAGE = "settings";
                        a.recreate();
                    }
                }), new LinearLayout.LayoutParams(-1, -2));
        c.addView(label(S.t("اللغة", "Language")));
        c.addView(Ui.chips(a, new String[]{"العربية", "English"}, a.prefs.arabic() ? 0 : 1, new Ui.OnPick() {
            public void pick(int i) {
                a.prefs.arabic(i == 0);
                MainActivity.RESTORE_PAGE = "settings";
                a.recreate();
            }
        }), new LinearLayout.LayoutParams(-1, -2));
        p.addView(c);

        LinearLayout f = Ui.card(a);
        f.addView(head(S.t("مجلد الحفظ", "Save folder")));
        final String cur = a.prefs.folder();
        f.addView(note(cur == null ? S.t("الافتراضي: التنزيلات / PoiExporter", "Default: Downloads / PoiExporter")
                : folderName(cur)));
        LinearLayout fr = Ui.row(a);
        fr.addView(Ui.button(a, S.t("اختيار مجلد", "Choose folder"), true, new Runnable() {
            public void run() {
                a.pickFolder();
            }
        }), Ui.lp(0, -2, 1f, a, 0, 6, 4, 0));
        fr.addView(Ui.button(a, S.t("الافتراضي", "Default"), false, new Runnable() {
            public void run() {
                a.prefs.folder(null);
                a.showPage("settings");
            }
        }), Ui.lp(0, -2, 1f, a, 4, 6, 0, 0));
        f.addView(fr);
        p.addView(f);

        LinearLayout k = Ui.card(a);
        k.addView(head(S.t("نوع الإحداثيات", "Coordinate type")));
        k.addView(note(S.t("يُستخدم في عمود COORD وفي ملفات KML وفي نوافذ المعلومات.", "Used for the COORD column, KML files and info dialogs.")));
        final TextView ex = Ui.text(a, "", 13, Theme.accent, false);
        ex.setTextIsSelectable(true);
        k.addView(Ui.chips(a, new String[]{"DD", "DMS", "UTM", "MGRS"}, a.prefs.fmt(), new Ui.OnPick() {
            public void pick(int i) {
                a.prefs.fmt(i);
                ex.setText(example());
            }
        }), new LinearLayout.LayoutParams(-1, -2));
        ex.setText(example());
        ex.setPadding(0, Ui.dp(a, 8), 0, 0);
        k.addView(ex);
        p.addView(k);

        LinearLayout s = Ui.card(a);
        s.addView(head(S.t("المنطقة المحددة (افتراضي)", "Selection area (default)")));
        LinearLayout box = col();
        s.addView(box);
        shapeSize(box);
        p.addView(s);
        return p;
    }

    private String example() {
        double[] c = a.prefs.center();
        return S.t("مثال لمركز المنطقة: ", "Example (area centre): ") + CoordFmt.format(a.fmt(), c[0], c[1]);
    }

    // ------------------------------------------------------------------ area

    View area() {
        LinearLayout p = col();
        LinearLayout c = Ui.card(a);
        c.addView(head(S.t("مركز المنطقة", "Area centre")));
        c.addView(note(S.t("اكتب الإحداثيات بأي صيغة: درجات عشرية أو DMS أو UTM أو MGRS (يُكتشف النوع تلقائياً).",
                "Type coordinates in any format: decimal, DMS, UTM or MGRS (auto-detected).")));
        centerField = Ui.field(a, "33.3152, 44.3661  |  38S 444000 3688000", InputType.TYPE_CLASS_TEXT);
        centerField.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        centerField.setGravity(Gravity.START);
        double[] cc = a.prefs.center();
        centerField.setText(CoordFmt.format(a.fmt(), cc[0], cc[1]));
        c.addView(centerField, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout r1 = Ui.row(a);
        r1.addView(Ui.button(a, S.t("تطبيق", "Apply"), true, new Runnable() {
            public void run() {
                try {
                    CoordFmt.Parsed ps = CoordFmt.parse(centerField.getText().toString());
                    a.setCenter(ps.lat, ps.lon);
                    a.zoomToArea();
                    a.toast(S.t("تم تحديد المركز (" + ps.fmt + ")", "Centre set (" + ps.fmt + ")"));
                } catch (Exception e) {
                    a.toast(S.t("إحداثيات غير صالحة", "Invalid coordinates"));
                }
            }
        }), Ui.lp(0, -2, 1f, a, 0, 8, 4, 0));
        r1.addView(Ui.button(a, S.t("من مركز الخريطة", "From map centre"), false, new Runnable() {
            public void run() {
                org.osmdroid.api.IGeoPoint g = a.map.getMapCenter();
                a.setCenter(g.getLatitude(), g.getLongitude());
            }
        }), Ui.lp(0, -2, 1f, a, 4, 8, 0, 0));
        c.addView(r1);
        c.addView(Ui.button(a, S.t("◎ من موقعي (GPS)", "◎ From my GPS location"), false, new Runnable() {
            public void run() {
                a.useLocationAsCenter();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 6, 0, 0));
        formatsView = Ui.text(a, "", 13, Theme.accent, false);
        formatsView.setTextIsSelectable(true);
        formatsView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        formatsView.setPadding(0, Ui.dp(a, 10), 0, 0);
        c.addView(formatsView);
        p.addView(c);

        LinearLayout n = Ui.card(a);
        n.addView(head(S.t("تحريك المنطقة", "Nudge the area")));
        n.addView(note(S.t("كل ضغطة تحرّك المنطقة ربع حجمها. على الخريطة: اسحب المنطقة لتحريكها، واسحب النقاط الحمراء لتكبيرها وتصغيرها، أو اضغط مطوّلاً لنقل المركز.",
                "Each tap moves the area by a quarter of its size. On the map drag the area to move it, drag the red handles to resize, or long-press to re-centre.")));
        LinearLayout up = Ui.row(a);
        up.setGravity(Gravity.CENTER);
        up.addView(nudge("▲", 0, 1));
        n.addView(up);
        LinearLayout mid = Ui.row(a);
        mid.setGravity(Gravity.CENTER);
        mid.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        mid.addView(nudge("◀", -1, 0));
        mid.addView(nudge("⌖", 0, 0));
        mid.addView(nudge("▶", 1, 0));
        n.addView(mid);
        LinearLayout dn = Ui.row(a);
        dn.setGravity(Gravity.CENTER);
        dn.addView(nudge("▼", 0, -1));
        n.addView(dn);
        p.addView(n);

        LinearLayout s = Ui.card(a);
        s.addView(head(S.t("الشكل والأبعاد", "Shape & size")));
        LinearLayout box = col();
        s.addView(box);
        shapeSize(box);
        s.addView(Ui.button(a, S.t("عرض المنطقة على الخريطة", "Show area on map"), true, new Runnable() {
            public void run() {
                a.showMap();
                a.zoomToArea();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        p.addView(s);

        LinearLayout i = Ui.card(a);
        i.addView(head(S.t("معلومات المنطقة", "Area info")));
        infoView = Ui.text(a, "", 13, Theme.text, false);
        infoView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        infoView.setTextIsSelectable(true);
        i.addView(infoView);
        p.addView(i);
        refreshArea();
        return p;
    }

    private View nudge(String label, final int dx, final int dy) {
        View b = Ui.button(a, label, dx == 0 && dy == 0 ? false : true, new Runnable() {
            public void run() {
                AreaSpec s = a.area();
                double w = s.circle ? s.radius * 2 : s.widthM(), h = s.circle ? s.radius * 2 : s.heightM();
                double c[] = a.prefs.center();
                if (dx == 0 && dy == 0) {
                    a.zoomToArea();
                    return;
                }
                double dLat = dy * h * 0.25 / 111320.0;
                double dLon = dx * w * 0.25 / (111320.0 * Math.max(0.05, Math.cos(Math.toRadians(c[0]))));
                a.setCenter(c[0] + dLat, c[1] + dLon);
            }
        });
        b.setLayoutParams(Ui.lp(Ui.dp(a, 64), Ui.dp(a, 50), 0, a, 4, 4, 4, 4));
        return b;
    }

    void onAreaChanged() {
        refreshArea();
    }

    private void refreshArea() {
        if (centerField == null || !centerField.isAttachedToWindow()) return;
        AreaSpec s = a.area();
        double[] c = a.prefs.center();
        if (!centerField.hasFocus()) centerField.setText(CoordFmt.format(a.fmt(), c[0], c[1]));
        formatsView.setText("DD:   " + CoordFmt.dd(c[0], c[1]) + "\nDMS:  " + CoordFmt.dms(c[0], c[1]) + "\nUTM:  "
                + CoordFmt.utm(c[0], c[1]) + "\nMGRS: " + CoordFmt.format(CoordFmt.Fmt.MGRS, c[0], c[1]));
        StringBuilder sb = new StringBuilder();
        if (s.circle) sb.append("R = ").append(MainActivity.fmtLen(s.radius)).append('\n');
        else sb.append(MainActivity.fmtLen(s.widthM())).append(" × ").append(MainActivity.fmtLen(s.heightM())).append('\n');
        sb.append(String.format(Locale.US, "%.3f km²\n", s.areaKm2()));
        if (!s.circle) sb.append(String.format(Locale.US, "↻ %.1f°\n", s.rot));
        sb.append("SW: ").append(CoordFmt.format(a.fmt(), s.south, s.west)).append('\n');
        sb.append("NE: ").append(CoordFmt.format(a.fmt(), s.north, s.east));
        infoView.setText(sb.toString());
    }

    // ------------------------------------------------------------------ layers

    View layers() {
        LinearLayout p = col();

        final Set<String> poi = a.csv("poi", a.allPoi());
        LinearLayout c = Ui.card(a);
        c.addView(head(S.t("المعالم (حسب الفئة)", "Landmarks (by category)")));
        final LinearLayout list = col();
        LinearLayout ar = Ui.row(a);
        ar.addView(Ui.button(a, S.t("تحديد الكل", "All"), false, new Runnable() {
            public void run() {
                poi.clear();
                for (Catalog.PoiCat pc : Catalog.POI) poi.add(pc.id);
                a.saveCsv("poi", poi);
                a.showPage("layers");
            }
        }), Ui.lp(0, -2, 1f, a, 0, 0, 4, 6));
        ar.addView(Ui.button(a, S.t("إلغاء الكل", "None"), false, new Runnable() {
            public void run() {
                poi.clear();
                a.saveCsv("poi", poi);
                a.showPage("layers");
            }
        }), Ui.lp(0, -2, 1f, a, 4, 0, 0, 6));
        c.addView(ar);
        for (final Catalog.PoiCat pc : Catalog.POI) {
            c.addView(toggle(pc.label(S.ar), poi.contains(pc.id), new java.util.function.Consumer<Boolean>() {
                public void accept(Boolean on) {
                    if (on) poi.add(pc.id);
                    else poi.remove(pc.id);
                    a.saveCsv("poi", poi);
                }
            }));
        }
        p.addView(c);

        final Set<String> lay = a.csv("layers", "");
        LinearLayout o = Ui.card(a);
        o.addView(head(S.t("الطرق والمياه والسياحة", "Roads, water & tourism")));
        for (final Catalog.LayerDef d : Catalog.LAYERS) {
            o.addView(toggle(d.label(S.ar), lay.contains(d.id), new java.util.function.Consumer<Boolean>() {
                public void accept(Boolean on) {
                    if (on) lay.add(d.id);
                    else lay.remove(d.id);
                    a.saveCsv("layers", lay);
                }
            }));
        }
        p.addView(o);

        final Set<String> adm = a.csv("adm", "");
        LinearLayout ad = Ui.card(a);
        ad.addView(head(S.t("الحدود الإدارية", "Administrative boundaries")));
        for (int i = 0; i < 3; i++) {
            final String id = Catalog.ADMIN_IDS[i];
            ad.addView(toggle(Catalog.adminLabel(i, S.ar), adm.contains(id), new java.util.function.Consumer<Boolean>() {
                public void accept(Boolean on) {
                    if (on) adm.add(id);
                    else adm.remove(id);
                    a.saveCsv("adm", adm);
                }
            }));
        }
        ad.addView(note(S.t("رقم المستوى في OpenStreetMap (admin_level) للمحافظة / القضاء / الناحية. القيم الافتراضية 4 / 5 / 6 — عدّلها إن اختلفت في منطقتك.",
                "OpenStreetMap admin_level for governorate / qadaa / nahiya. Defaults 4 / 5 / 6 — change if your area differs.")));
        LinearLayout lv = Ui.row(a);
        lv.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        for (int i = 0; i < 3; i++) {
            final String key = "lv" + (i + 4);
            final EditText e = Ui.field(a, String.valueOf(i + 4), InputType.TYPE_CLASS_NUMBER);
            e.setText(a.prefs.get(key, String.valueOf(i + 4)));
            e.setGravity(Gravity.CENTER);
            e.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int st, int c1, int af) {
                }

                public void onTextChanged(CharSequence s, int st, int b, int c1) {
                }

                public void afterTextChanged(Editable ed) {
                    a.prefs.put(key, ed.toString());
                }
            });
            lv.addView(e, Ui.lp(0, -2, 1f, a, 4, 4, 4, 4));
        }
        ad.addView(lv);
        ad.addView(toggle(S.t("تعبئة الناحية والقضاء والمحافظة لكل معلم", "Fill NAHIYA / QADAA / GOVERNORAT for each feature"),
                a.prefs.flag("fillAdmin", true), new java.util.function.Consumer<Boolean>() {
                    public void accept(Boolean on) {
                        a.prefs.setFlag("fillAdmin", on);
                    }
                }));
        p.addView(ad);

        LinearLayout ex = Ui.card(a);
        ex.addView(head(S.t("خيارات إضافية", "Extra options")));
        ex.addView(toggle(S.t("تضمين المعالم بلا اسم", "Include unnamed features"), a.prefs.flag("unnamed", false),
                new java.util.function.Consumer<Boolean>() {
                    public void accept(Boolean on) {
                        a.prefs.setFlag("unnamed", on);
                    }
                }));
        ex.addView(label(S.t("فلتر مخصص (اختياري) مثل amenity=cafe", "Custom filter (optional), e.g. amenity=cafe")));
        final EditText cf = Ui.field(a, "key=value", InputType.TYPE_CLASS_TEXT);
        cf.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        cf.setText(a.prefs.get("custom", ""));
        cf.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c1, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c1) {
            }

            public void afterTextChanged(Editable ed) {
                a.prefs.put("custom", ed.toString());
            }
        });
        ex.addView(cf, new LinearLayout.LayoutParams(-1, -2));
        p.addView(ex);

        p.addView(Ui.button(a, S.t("⬇ تحميل الآن", "⬇ Download now"), true, new Runnable() {
            public void run() {
                a.showMap();
                a.download();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 10, 0, 0));
        return p;
    }

    // ------------------------------------------------------------------ KML exchange

    View kml() {
        LinearLayout p = col();
        LinearLayout i = Ui.card(a);
        i.addView(head(S.t("بيني كويست (KML / KMZ)", "PineQuest (KML / KMZ)")));
        i.addView(note(S.t("صدّر المعالم كملف KML أو KMZ ثم افتحه في البرنامج عبر «مشاركة / فتح»، أو استورد ملفاً من البرنامج لعرضه هنا وتحويله إلى Shapefile.",
                "Export landmarks as KML/KMZ and open them in the app via Share/Open, or import a file from it to view here and convert to Shapefile.")));
        i.addView(Ui.button(a, S.t("⬆ استيراد ملف KML / KMZ", "⬆ Import KML / KMZ file"), true, new Runnable() {
            public void run() {
                a.pickImport();
            }
        }), Ui.lp(-1, -2, 0, a, 0, 8, 0, 4));
        p.addView(i);

        LinearLayout e = Ui.card(a);
        e.addView(head(S.t("تصدير البيانات الحالية", "Export current data")));
        int n = 0;
        for (LayerData l : MainActivity.DATA) n += l.features.size();
        e.addView(note(S.t("المحمّل حالياً: ", "Currently loaded: ") + n + S.t(" عنصر في ", " features in ")
                + MainActivity.DATA.size() + S.t(" طبقة", " layers")));
        e.addView(Ui.button(a, "KML", false, new Runnable() {
            public void run() {
                a.export("kml");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
        e.addView(Ui.button(a, "KMZ", false, new Runnable() {
            public void run() {
                a.export("kmz");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
        e.addView(Ui.button(a, "Shapefile (ZIP)", true, new Runnable() {
            public void run() {
                a.export("shp");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 4, 0, 4));
        e.addView(Ui.button(a, S.t("مسح البيانات المحمّلة", "Clear loaded data"), false, new Runnable() {
            public void run() {
                a.clearData();
                a.showPage("kml");
            }
        }), Ui.lp(-1, -2, 0, a, 0, 12, 0, 0));
        p.addView(e);
        return p;
    }

    // ------------------------------------------------------------------ converter

    View converter() {
        LinearLayout p = col();
        LinearLayout in = Ui.card(a);
        in.addView(head(S.t("أدخل إحداثيات بأي صيغة", "Enter coordinates in any format")));
        in.addView(note(S.t("33.3152, 44.3661\n33°18'54.7\"N 44°21'58.0\"E\n38S 444000 3688000\n38SMB4400088000",
                "33.3152, 44.3661\n33°18'54.7\"N 44°21'58.0\"E\n38S 444000 3688000\n38SMB4400088000")));
        final EditText f = Ui.field(a, S.t("الصق أو اكتب هنا", "Paste or type here"), InputType.TYPE_CLASS_TEXT);
        f.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        f.setGravity(Gravity.START);
        in.addView(f, new LinearLayout.LayoutParams(-1, -2));
        final TextView status = Ui.text(a, "", 13, Theme.sub, false);
        status.setPadding(0, Ui.dp(a, 8), 0, 0);
        in.addView(status);
        LinearLayout br = Ui.row(a);
        br.addView(Ui.button(a, S.t("لصق", "Paste"), false, new Runnable() {
            public void run() {
                ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(a);
                    f.setText(t);
                }
            }
        }), Ui.lp(0, -2, 1f, a, 0, 8, 4, 0));
        br.addView(Ui.button(a, S.t("مسح", "Clear"), false, new Runnable() {
            public void run() {
                f.setText("");
            }
        }), Ui.lp(0, -2, 1f, a, 4, 8, 0, 0));
        in.addView(br);
        p.addView(in);

        final TextView[] vals = new TextView[4];
        final String[] names = {"DD", "DMS", "UTM", "MGRS"};
        LinearLayout out = Ui.card(a);
        out.addView(head(S.t("النتائج", "Results")));
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            out.addView(label(names[i] + (i == 0 ? S.t("  (خط الطول / دائرة العرض)", "  (lat / lon degrees)") : "")));
            LinearLayout r = Ui.row(a);
            r.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            vals[i] = Ui.text(a, "—", 15, Theme.text, true);
            vals[i].setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
            vals[i].setTextIsSelectable(true);
            r.addView(vals[i], new LinearLayout.LayoutParams(0, -2, 1f));
            r.addView(Ui.button(a, S.t("نسخ", "Copy"), false, new Runnable() {
                public void run() {
                    String s = vals[idx].getText().toString();
                    if (!s.equals("—")) a.copy(s);
                }
            }), new LinearLayout.LayoutParams(Ui.dp(a, 84), -2));
            out.addView(r);
        }
        final double[] cur = new double[2];
        final boolean[] ok = {false};
        LinearLayout ar = Ui.row(a);
        ar.addView(Ui.button(a, S.t("إظهار على الخريطة", "Show on map"), true, new Runnable() {
            public void run() {
                if (!ok[0]) {
                    a.toast(S.t("أدخل إحداثيات صحيحة أولاً", "Enter valid coordinates first"));
                    return;
                }
                a.setCenter(cur[0], cur[1]);
                a.showMap();
                a.map.getController().setZoom(15.0);
                a.map.getController().animateTo(new org.osmdroid.util.GeoPoint(cur[0], cur[1]));
            }
        }), Ui.lp(0, -2, 1f, a, 0, 12, 4, 0));
        ar.addView(Ui.button(a, S.t("نسخ الكل", "Copy all"), false, new Runnable() {
            public void run() {
                if (!ok[0]) return;
                a.copy(vals[0].getText() + "\n" + vals[1].getText() + "\n" + vals[2].getText() + "\n" + vals[3].getText());
            }
        }), Ui.lp(0, -2, 1f, a, 4, 12, 0, 0));
        out.addView(ar);
        p.addView(out);

        f.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                String t = e.toString();
                if (t.trim().isEmpty()) {
                    ok[0] = false;
                    status.setText("");
                    for (TextView v : vals) v.setText("—");
                    return;
                }
                try {
                    CoordFmt.Parsed ps = CoordFmt.parse(t);
                    cur[0] = ps.lat;
                    cur[1] = ps.lon;
                    ok[0] = true;
                    status.setTextColor(Theme.ok);
                    status.setText("✔ " + S.t("النوع المكتشف: ", "Detected: ") + ps.fmt);
                    vals[0].setText(CoordFmt.dd(ps.lat, ps.lon));
                    vals[1].setText(CoordFmt.dms(ps.lat, ps.lon));
                    vals[2].setText(CoordFmt.utm(ps.lat, ps.lon));
                    vals[3].setText(CoordFmt.format(CoordFmt.Fmt.MGRS, ps.lat, ps.lon));
                } catch (Exception ex) {
                    ok[0] = false;
                    status.setTextColor(Theme.danger);
                    status.setText("✖ " + S.t("صيغة غير مفهومة", "Unrecognised format"));
                    for (TextView v : vals) v.setText("—");
                }
            }
        });
        return p;
    }
}
