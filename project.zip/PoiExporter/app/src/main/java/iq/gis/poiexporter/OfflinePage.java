package iq.gis.poiexporter;

import android.net.Uri;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.osmdroid.tileprovider.MapTileProviderBasic;
import org.osmdroid.tileprovider.modules.IArchiveFile;
import org.osmdroid.tileprovider.modules.OfflineTileProvider;
import org.osmdroid.tileprovider.tilesource.FileBasedTileSource;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.tileprovider.util.SimpleRegisterReceiver;

/**
 * Offline maps and diagnostics. Honest scope: this does NOT bulk-download OpenStreetMap tiles (the OSM tile usage policy
 * forbids it) and never caches Google tiles. Offline use = (1) tiles already viewed stay in the cache, (2) "cache only"
 * mode never touches the network, (3) the user can load their own tile file (.mbtiles, .zip, .sqlite, .gemf).
 */
final class OfflinePage {
    private final MainActivity a;
    private TextView sizeView, fileView;

    OfflinePage(MainActivity a) {
        this.a = a;
    }

    static File tileCache(MainActivity a) {
        return new File(a.getCacheDir(), "osmdroid/tiles");
    }

    static File offlineDir(MainActivity a) {
        File d = new File(a.getFilesDir(), "offline");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static long size(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long s = 0;
        File[] c = f.listFiles();
        if (c != null) for (File x : c) s += size(x);
        return s;
    }

    static String human(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format(java.util.Locale.ROOT, "%.1f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format(java.util.Locale.ROOT, "%.1f MB", b / 1048576.0);
        return String.format(java.util.Locale.ROOT, "%.2f GB", b / 1073741824.0);
    }

    static void deleteTree(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteTree(x);
        f.delete();
    }

    /** Applies the saved tile mode (user's own file, or cache-only) to the map. Safe to call repeatedly. */
    static void apply(MainActivity a) {
        if (a.map == null) return;
        try {
            String name = a.prefs.get("offline_file", "");
            File f = name.isEmpty() ? null : new File(offlineDir(a), name);
            if (f != null && f.isFile()) {
                OfflineTileProvider tp = new OfflineTileProvider(new SimpleRegisterReceiver(a), new File[]{f});
                a.map.setTileProvider(tp);
                IArchiveFile[] ar = tp.getArchives();
                if (ar.length > 0 && !ar[0].getTileSources().isEmpty())
                    a.map.setTileSource(FileBasedTileSource.getSource(ar[0].getTileSources().iterator().next()));
                else a.map.setTileSource(TileSourceFactory.DEFAULT_TILE_SOURCE);
            } else if (a.map.getTileProvider() instanceof OfflineTileProvider) {
                a.map.setTileProvider(new MapTileProviderBasic(a));
                a.setBaseMap(Math.max(0, parse(a.prefs.get("basemap", "0"))), false);
            }
            a.map.setUseDataConnection(!"1".equals(a.prefs.get("cacheonly", "0")) && (f == null || !f.isFile()));
            a.map.invalidate();
        } catch (Throwable t) {
            ErrorLog.add("offline", t);
        }
    }

    private static int parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    View build() {
        final LinearLayout p = UiKit.col(a);
        LinearLayout c = Ui.card(a);
        c.addView(UiKit.head(a, S.t("الخرائط دون إنترنت", "Offline maps")));
        c.addView(UiKit.note(a, S.t(
                "• البلاطات التي شاهدتها تُحفظ مؤقتاً وتُعرض دون إنترنت.\n• «وضع الذاكرة فقط» يمنع أي اتصال بالإنترنت للخرائط.\n• يمكنك تحميل ملف خرائط خاص بك (.mbtiles أو .zip أو .sqlite أو .gemf).\n\nلا يوجد تنزيل جماعي لبلاطات OpenStreetMap لأن سياسة OSM تمنعه، ولا تُخزَّن خرائط Google. لتغطية منطقة كاملة جهّز ملفاً من مصدر يسمح بذلك (مثل مشروعك أو مزوّد مرخّص).",
                "• Tiles you have viewed are cached and shown offline.\n• \"Cache only\" blocks all network use for the map.\n• You can load your own tile file (.mbtiles, .zip, .sqlite, .gemf).\n\nNo bulk download of OpenStreetMap tiles: the OSM tile usage policy forbids it, and Google tiles are never cached. To cover a whole area, prepare a file from a source that permits it.")));
        sizeView = UiKit.note(a, "");
        c.addView(sizeView);
        refresh();
        c.addView(UiKit.check(a, S.t("وضع الذاكرة فقط (بلا إنترنت)", "Cache only (no network)"), "1".equals(a.prefs.get("cacheonly", "0")), v -> {
            a.prefs.put("cacheonly", v ? "1" : "0");
            apply(a);
        }));
        c.addView(Ui.button(a, S.t("مسح ذاكرة البلاطات", "Clear tile cache"), false, () -> a.messageConfirm(
                S.t("مسح الذاكرة", "Clear cache"), S.t("ستُحذف البلاطات المخزنة مؤقتاً فقط، لا بياناتك.", "Only cached tiles are deleted, not your data."),
                S.t("مسح", "Clear"), () -> {
                    deleteTree(tileCache(a));
                    tileCache(a).mkdirs();
                    refresh();
                    a.toast(S.t("تم المسح", "Cleared"));
                })));
        p.addView(c);

        LinearLayout f = Ui.card(a);
        f.addView(UiKit.head(a, S.t("ملف خرائط خاص بي", "My own tile file")));
        fileView = UiKit.note(a, "");
        f.addView(fileView);
        refresh();
        f.addView(Ui.button(a, S.t("اختيار ملف…", "Choose file…"), true, a::pickOffline));
        f.addView(Ui.button(a, S.t("العودة للخرائط على الإنترنت", "Back to online maps"), false, () -> {
            String n = a.prefs.get("offline_file", "");
            if (!n.isEmpty()) new File(offlineDir(a), n).delete();
            a.prefs.put("offline_file", "");
            apply(a);
            refresh();
        }));
        f.addView(UiKit.note(a, S.t("الملف يُنسخ إلى ذاكرة التطبيق. يعرض ما يحتويه فقط؛ خارج تغطيته تظهر الخريطة فارغة.", "The file is copied into app storage. It shows only what it contains; outside its coverage the map is blank. Device-tested behaviour depends on the file's tile scheme.")));
        p.addView(f);

        LinearLayout lg = Ui.card(a);
        lg.addView(UiKit.head(a, S.t("سجل الأخطاء", "Error log")));
        String we = MainActivity.WS == null ? null : MainActivity.WS.lastError();
        String txt = (we == null ? "" : S.t("آخر خطأ في قاعدة البيانات: ", "Last database error: ") + we + "\n\n") + ErrorLog.text();
        TextView t = UiKit.note(a, txt.trim().isEmpty() ? S.t("لا أخطاء مسجلة في هذه الجلسة.", "No errors logged this session.") : txt);
        t.setTextIsSelectable(true);
        lg.addView(t);
        lg.addView(Ui.button(a, S.t("نسخ السجل", "Copy log"), false, () -> a.copy(txt)));
        lg.addView(Ui.button(a, S.t("مسح السجل", "Clear log"), false, () -> {
            ErrorLog.clear();
            a.showPage("offline");
        }));
        lg.addView(UiKit.note(a, S.t("السجل في ذاكرة الجلسة فقط ولا يُرسل لأي جهة.", "The log lives in memory for this session only and is never sent anywhere.")));
        p.addView(lg);
        return p;
    }

    private void refresh() {
        if (sizeView != null) sizeView.setText(S.t("حجم الذاكرة المؤقتة: ", "Tile cache size: ") + human(size(tileCache(a))));
        if (fileView != null) {
            String n = a.prefs.get("offline_file", "");
            fileView.setText(n.isEmpty() ? S.t("لا يوجد ملف محمّل.", "No file loaded.") : S.t("الملف الحالي: ", "Current file: ") + n + " (" + human(new File(offlineDir(a), n).length()) + ")");
        }
    }

    /** Called with the file the user picked. Copies it (streamed) and switches the map over. */
    void picked(final Uri u, final String name) {
        final String lower = name.toLowerCase(java.util.Locale.ROOT);
        if (!(lower.endsWith(".mbtiles") || lower.endsWith(".zip") || lower.endsWith(".sqlite") || lower.endsWith(".gemf"))) {
            a.toast(S.t("الصيغة غير مدعومة. استخدم mbtiles أو zip أو sqlite أو gemf.", "Unsupported format. Use mbtiles, zip, sqlite or gemf."));
            return;
        }
        a.toast(S.t("جارٍ نسخ الملف…", "Copying file…"));
        new Thread(() -> {
            try {
                String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
                File dst = new File(offlineDir(a), safe);
                try (InputStream in = a.getContentResolver().openInputStream(u); FileOutputStream os = new FileOutputStream(dst)) {
                    if (in == null) throw new java.io.IOException("cannot open");
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                }
                final String prev = a.prefs.get("offline_file", "");
                if (!prev.isEmpty() && !prev.equals(safe)) new File(offlineDir(a), prev).delete();
                a.prefs.put("offline_file", safe);
                a.runOnUiThread(() -> {
                    apply(a);
                    a.showPage("offline");
                    a.toast(S.t("تم تحميل الملف", "File loaded"));
                });
            } catch (Throwable t) {
                ErrorLog.add("offline-file", t);
                a.runOnUiThread(() -> a.message(S.t("تعذّر تحميل الملف", "Could not load the file"), String.valueOf(t.getMessage()), null, null));
            }
        }).start();
    }
}
