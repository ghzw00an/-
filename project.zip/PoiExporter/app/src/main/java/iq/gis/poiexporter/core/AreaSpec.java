package iq.gis.poiexporter.core;

import java.util.Locale;

/** The area to download: a lat/lon rectangle or a circle. */
public final class AreaSpec {
    public final double south, west, north, east;
    public final boolean circle;
    public final double clat, clon, radius;

    private AreaSpec(double s, double w, double n, double e, boolean circle, double clat, double clon, double r) {
        this.south = s;
        this.west = w;
        this.north = n;
        this.east = e;
        this.circle = circle;
        this.clat = clat;
        this.clon = clon;
        this.radius = r;
    }

    public static AreaSpec rect(double s, double w, double n, double e) {
        return new AreaSpec(s, w, n, e, false, (s + n) / 2, (w + e) / 2, 0);
    }

    public static AreaSpec circle(double lat, double lon, double radiusM) {
        double[] b = Geo.rectAround(lat, lon, radiusM * 2, radiusM * 2);
        return new AreaSpec(b[0], b[1], b[2], b[3], true, lat, lon, radiusM);
    }

    /** Rectangle of w x h metres around a centre. */
    public static AreaSpec centered(double lat, double lon, double wM, double hM) {
        double[] b = Geo.rectAround(lat, lon, wM, hM);
        return rect(b[0], b[1], b[2], b[3]);
    }

    public double widthM() {
        return circle ? radius * 2 : Geo.haversine(clat, west, clat, east);
    }

    public double heightM() {
        return circle ? radius * 2 : Geo.haversine(south, clon, north, clon);
    }

    public double areaKm2() {
        if (circle) return Math.PI * radius * radius / 1e6;
        return widthM() * heightM() / 1e6;
    }

    /** Overpass area filter, such as (s,w,n,e) or (around:r,lat,lon). */
    public String overpass() {
        if (circle) return String.format(Locale.US, "(around:%.0f,%.6f,%.6f)", radius, clat, clon);
        return String.format(Locale.US, "(%.6f,%.6f,%.6f,%.6f)", south, west, north, east);
    }

    public boolean contains(double lat, double lon) {
        if (circle) return Geo.haversine(clat, clon, lat, lon) <= radius * 1.0005;
        return lat >= south && lat <= north && lon >= west && lon <= east;
    }
}
