package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Map decorations that are not data: text boxes and small pictures anchored to a geographic position.
 * Kept apart from the landmark layers so they never end up in the exports. Serialised as one small JSON file.
 */
public final class Annotations {
    public static final String TEXT = "text", IMAGE = "image";

    public static final class Item {
        public String id = Feature.newId();
        public String kind = TEXT;
        public double lat, lon;
        public String text = "";
        public float sizeSp = 14f;
        public int color = 0xFF000000, background = 0xE6FFFFFF;
        /** Image file name inside the app's annotation folder (images only). */
        public String file = "";
        public int widthDp = 96;

        public Item copy() {
            Item c = new Item();
            c.id = id;
            c.kind = kind;
            c.lat = lat;
            c.lon = lon;
            c.text = text;
            c.sizeSp = sizeSp;
            c.color = color;
            c.background = background;
            c.file = file;
            c.widthDp = widthDp;
            return c;
        }
    }

    private final List<Item> items = new ArrayList<>();

    public List<Item> items() {
        return items;
    }

    public Item find(String id) {
        for (Item i : items) if (i.id.equals(id)) return i;
        return null;
    }

    public boolean remove(String id) {
        for (int k = 0; k < items.size(); k++)
            if (items.get(k).id.equals(id)) {
                items.remove(k);
                return true;
            }
        return false;
    }

    /** Nearest item within maxMetres of the point, or null. Text and images both count as a point at their anchor. */
    public Item nearest(double lat, double lon, double maxMetres) {
        Item best = null;
        double bd = maxMetres;
        for (Item i : items) {
            double dy = (i.lat - lat) * 111320.0, dx = (i.lon - lon) * 111320.0 * Math.cos(Math.toRadians(lat));
            double d = Math.sqrt(dx * dx + dy * dy);
            if (d <= bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    public String toJson() {
        StringBuilder b = new StringBuilder("{\"items\":[");
        for (int k = 0; k < items.size(); k++) {
            Item i = items.get(k);
            if (k > 0) b.append(',');
            b.append("{\"id\":").append(MiniJson.quote(i.id)).append(",\"kind\":").append(MiniJson.quote(i.kind))
                    .append(",\"lat\":").append(i.lat).append(",\"lon\":").append(i.lon)
                    .append(",\"text\":").append(MiniJson.quote(i.text)).append(",\"size\":").append(i.sizeSp)
                    .append(",\"color\":").append(i.color).append(",\"bg\":").append(i.background)
                    .append(",\"file\":").append(MiniJson.quote(i.file)).append(",\"w\":").append(i.widthDp).append('}');
        }
        return b.append("]}").toString();
    }

    @SuppressWarnings("unchecked")
    public static Annotations fromJson(String json) {
        Annotations a = new Annotations();
        if (json == null || json.trim().isEmpty()) return a;
        try {
            Object arr = MiniJson.obj(json).get("items");
            if (!(arr instanceof List)) return a;
            for (Object o : (List<Object>) arr) {
                if (!(o instanceof Map)) continue;
                Map<String, Object> m = (Map<String, Object>) o;
                Item i = new Item();
                i.id = MiniJson.str(m, "id", i.id);
                i.kind = IMAGE.equals(MiniJson.str(m, "kind", TEXT)) ? IMAGE : TEXT;
                i.lat = MiniJson.num(m, "lat", 0);
                i.lon = MiniJson.num(m, "lon", 0);
                i.text = MiniJson.str(m, "text", "");
                i.sizeSp = (float) Math.max(6, Math.min(72, MiniJson.num(m, "size", 14)));
                i.color = (int) (long) MiniJson.num(m, "color", 0xFF000000L | 0);
                i.background = (int) (long) MiniJson.num(m, "bg", 0xE6FFFFFFL | 0);
                i.file = MiniJson.str(m, "file", "");
                i.widthDp = (int) Math.max(24, Math.min(400, MiniJson.num(m, "w", 96)));
                if (Math.abs(i.lat) <= 90 && Math.abs(i.lon) <= 180) a.items.add(i);
            }
        } catch (RuntimeException e) {
            // a damaged file must never stop the app: start empty
            return new Annotations();
        }
        return a;
    }
}
