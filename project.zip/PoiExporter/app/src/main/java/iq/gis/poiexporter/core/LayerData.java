package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;

/** A set of features of one geometry type that is shown, saved and exported together. */
public final class LayerData {
    public final String id;
    public String label;
    public final int geom;
    public final List<Feature> features = new ArrayList<>();

    /** "user" (own data), "download" (OSM), "reference" (admin boundaries), "import". */
    public String kind = "user";
    /** Style: colour ARGB (0 = automatic), line width in dp (0 = automatic), opacity 0..1. */
    public int color;
    public float width;
    public float opacity = 1f;
    public int order;
    public boolean visible = true;
    /** Provenance: where the data came from, when, how accurate, and whether it is official. */
    public String source = "", sourceDate = "", accuracyNote = "";
    public boolean official;
    public String projectId = "";

    public LayerData(String id, String label, int geom) {
        this.id = id;
        this.label = label;
        this.geom = geom;
    }

    public static String geomName(int g) {
        return g == Feature.POINT ? "point" : g == Feature.LINE ? "line" : "polygon";
    }
}
