package iq.gis.poiexporter;

import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.MapTileIndex;

/** Selectable base maps. Google tiles are fetched from Google's public tile servers. */
public final class BaseMaps {
    public static final class Def {
        public final String ar, en, kind, param;

        Def(String ar, String en, String kind, String param) {
            this.ar = ar;
            this.en = en;
            this.kind = kind;
            this.param = param;
        }

        public String label() {
            return S.t(ar, en);
        }

        public boolean isOsm() {
            return kind.equals("osm");
        }
    }

    public static final Def[] ALL = {
            new Def("OpenStreetMap", "OpenStreetMap", "osm", ""),
            new Def("Google", "Google Maps", "g", "lyrs=m"),
            new Def("Google قمر صناعي", "Google Satellite", "g", "lyrs=s"),
            new Def("Google Roads Layer", "Google Roads Layer", "g", "lyrs=h"),
            new Def("Hybrid Map", "Hybrid Map", "g", "lyrs=y"),
            new Def("GOOGLE MAPS (LOCALIZED)", "GOOGLE MAPS (LOCALIZED)", "gl", "lyrs=m"),
            new Def("Google تضاريس", "Google Terrain", "g", "lyrs=p"),
            new Def("Esri Imagery", "Esri Imagery", "esri", ""),
    };

    private BaseMaps() {
    }

    public static ITileSource source(Def d, boolean arabic) {
        switch (d.kind) {
            case "g":
            case "gl":
                final String lang = d.kind.equals("gl") ? "&hl=" + (arabic ? "ar" : "en") : "";
                final String q = d.param;
                return new OnlineTileSourceBase("G" + d.param + lang, 0, 20, 256, ".png",
                        new String[]{"https://mt0.google.com/vt/"}) {
                    @Override
                    public String getTileURLString(long t) {
                        int z = MapTileIndex.getZoom(t), x = MapTileIndex.getX(t), y = MapTileIndex.getY(t);
                        return "https://mt" + ((x + y) & 3) + ".google.com/vt/" + "?" + q + "&x=" + x + "&y=" + y + "&z=" + z + lang;
                    }
                };
            case "esri":
                return new OnlineTileSourceBase("EsriImagery", 0, 19, 256, ".jpg",
                        new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"}) {
                    @Override
                    public String getTileURLString(long t) {
                        return getBaseUrl() + MapTileIndex.getZoom(t) + "/" + MapTileIndex.getY(t) + "/" + MapTileIndex.getX(t);
                    }
                };
            default:
                return TileSourceFactory.MAPNIK;
        }
    }
}
