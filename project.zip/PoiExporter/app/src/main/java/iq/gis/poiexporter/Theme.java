package iq.gis.poiexporter;

import android.graphics.Color;

/** Colour palette for light and dark mode. */
public final class Theme {
    public static boolean dark;
    public static int bg, card, text, sub, primary, onPrimary, accent, line, field, danger, ok;

    private Theme() {
    }

    public static void apply(boolean isDark) {
        dark = isDark;
        if (isDark) {
            bg = Color.parseColor("#0A1424");
            card = Color.parseColor("#13213A");
            text = Color.parseColor("#EAF1F7");
            sub = Color.parseColor("#93A4B5");
            primary = Color.parseColor("#D9B25A");
            onPrimary = Color.parseColor("#1B1404");
            accent = Color.parseColor("#5AA9FF");
            line = Color.parseColor("#24385A");
            field = Color.parseColor("#0D1A30");
            danger = Color.parseColor("#FF6B6B");
            ok = Color.parseColor("#5BD68A");
        } else {
            bg = Color.parseColor("#F1F4FA");
            card = Color.WHITE;
            text = Color.parseColor("#12202B");
            sub = Color.parseColor("#5F7284");
            primary = Color.parseColor("#17407E");
            onPrimary = Color.WHITE;
            accent = Color.parseColor("#A8791A");
            line = Color.parseColor("#D5DDEB");
            field = Color.parseColor("#F5F7FC");
            danger = Color.parseColor("#D64545");
            ok = Color.parseColor("#1E9E5A");
        }
    }
}
