package iq.gis.poiexporter;

import android.graphics.Color;

/** Colour palette for light and dark mode. */
public final class Theme {
    public static boolean dark;
    public static int bg, card, text, sub, primary, onPrimary, accent, line, field, danger, ok;

    private Theme() {
    }

    public static void apply(boolean isDark) {
        dark = isDark;
        if (isDark) {
            bg = Color.parseColor("#0F1720");
            card = Color.parseColor("#18232F");
            text = Color.parseColor("#EAF1F7");
            sub = Color.parseColor("#93A4B5");
            primary = Color.parseColor("#3DB8A5");
            onPrimary = Color.parseColor("#06201C");
            accent = Color.parseColor("#5AA9FF");
            line = Color.parseColor("#2A3A4A");
            field = Color.parseColor("#101A24");
            danger = Color.parseColor("#FF6B6B");
            ok = Color.parseColor("#5BD68A");
        } else {
            bg = Color.parseColor("#F2F6F9");
            card = Color.WHITE;
            text = Color.parseColor("#12202B");
            sub = Color.parseColor("#5F7284");
            primary = Color.parseColor("#0E8F7E");
            onPrimary = Color.WHITE;
            accent = Color.parseColor("#1F6FD1");
            line = Color.parseColor("#D9E3EB");
            field = Color.parseColor("#F6F9FB");
            danger = Color.parseColor("#D64545");
            ok = Color.parseColor("#1E9E5A");
        }
    }
}
