package iq.gis.poiexporter.core.report;

/** Paper sizes. PDF points are 1/72 inch. */
public final class Paper {
    public final String name;
    public final double widthMm, heightMm;

    private Paper(String name, double w, double h) {
        this.name = name;
        this.widthMm = w;
        this.heightMm = h;
    }

    public static final Paper A5 = new Paper("A5", 148, 210), A4 = new Paper("A4", 210, 297), A3 = new Paper("A3", 297, 420);
    public static final Paper[] ALL = {A5, A4, A3};

    public static Paper byName(String n) {
        for (Paper p : ALL) if (p.name.equalsIgnoreCase(n)) return p;
        return A4;
    }

    public Paper orient(boolean landscape) {
        double w = Math.min(widthMm, heightMm), h = Math.max(widthMm, heightMm);
        return landscape ? new Paper(name, h, w) : new Paper(name, w, h);
    }

    public static double mmToPt(double mm) {
        return mm / 25.4 * 72.0;
    }

    public int widthPt() {
        return (int) Math.round(mmToPt(widthMm));
    }

    public int heightPt() {
        return (int) Math.round(mmToPt(heightMm));
    }

    public int widthPx(int dpi) {
        return (int) Math.round(widthMm / 25.4 * dpi);
    }

    public int heightPx(int dpi) {
        return (int) Math.round(heightMm / 25.4 * dpi);
    }
}
