package iq.gis.poiexporter;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.IConfigurationProvider;
import org.osmdroid.tileprovider.MapTileProviderBasic;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.TilesOverlay;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Catalog;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.Kml;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.Pipeline;
import iq.gis.poiexporter.core.ShapeWriter;

public class MainActivity extends Activity {
    static final int REQ_IMPORT = 11, REQ_FOLDER = 12;
    static List<LayerData> DATA = new ArrayList<>();
    static String RESTORE_PAGE;
    static List<LayerData> LIB = new ArrayList<>(); // saved groups
    static List<LayerData> DL = new ArrayList<>(); // downloaded layers
    static final Set<String> HIDDEN = new LinkedHashSet<>();
    static String ACTIVE;
    static boolean libLoaded;
    /** Group being recorded with the flag button (not saved until the user presses save). */
    static LayerData DRAFT;

    Prefs prefs;
    Pages pages;
    MapView map;
    FeatureOverlay fo;
    AreaOverlay ao;
    private FrameLayout root, pageHolder;
    private LinearLayout drawer;
    private View scrim;
    private TextView title, summary;
    private View topBar;
    private boolean drawerOpen;
    private String page;
    private float edgeX = -1;
    private volatile boolean cancel;
    private boolean bigOk;
    LocationDot dot;
    private LocationManager lm;
    private LocationListener ll;
    private Location lastLoc;
    private boolean tracking, centerOnFix, areaOnFix;
    private TextView editBtn, addBtn;
    private TextView areaBtn;
    Landmarks marks;
    GuideOverlay guide;
    private String guideLabel = "";
    private TextView gpsBtn, compassBtn, dlBtn, flagBtn;
    private LinearLayout statusStack, groupBanner, guideBanner, progressBanner;
    private TextView groupBannerText, guideBannerText, progressText;
    private ProgressBar progressBar;
    private Runnable progressCancel;
    private final List<TilesOverlay> customOv = new ArrayList<>();
    private final Map<String, TilesOverlay> ovById = new HashMap<>();
    private android.hardware.SensorManager sensorMgr;
    private android.hardware.SensorEventListener sensorLis;
    private boolean compassOn, compassFirst = true;
    private float compassSmooth, compassApplied;
    private final float[] rotM = new float[9], oriV = new float[3];

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        S.ar = prefs.arabic();
        int th = prefs.theme();
        boolean night = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        Theme.apply(th == 2 || (th == 0 && night));
        IConfigurationProvider cfg = org.osmdroid.config.Configuration.getInstance();
        cfg.setUserAgentValue("PoiExporter/2.0 (" + getPackageName() + ")");
        // kept in the app's private files (not the cache) so downloaded maps survive
        cfg.setOsmdroidBasePath(new File(getFilesDir(), "osmdroid"));
        cfg.setOsmdroidTileCache(new File(getFilesDir(), "osmdroid/tiles"));
        cfg.setTileFileSystemCacheMaxBytes(2L * 1024 * 1024 * 1024);
        cfg.setTileFileSystemCacheTrimBytes(1700L * 1024 * 1024);
        if (!libLoaded) {
            LIB = Library.loadAll(this);
            libLoaded = true;
            HIDDEN.addAll(csv("hidden", ""));
            ACTIVE = prefs.get("active", null);
        }
        if (prefs.flag("awake", true)) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        pages = new Pages(this);
        marks = new Landmarks(this);
        buildUi();
        rebuild();
        String r = RESTORE_PAGE;
        RESTORE_PAGE = null;
        if (r != null) showPage(r);
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleIntent(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (map != null) map.onResume();
        if (tracking) startLocation();
        if (compassOn) startCompass();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (map != null) map.onPause();
        stopLocation();
        pauseCompass();
    }

    @Override
    public void onBackPressed() {
        if (drawerOpen) closeDrawer();
        else if (page != null) showMap();
        else super.onBackPressed();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        float edge = Ui.dp(this, 20);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                edgeX = e.getX() < edge && !drawerOpen ? e.getX() : -1;
                break;
            case MotionEvent.ACTION_MOVE:
                if (edgeX >= 0 && e.getX() - edgeX > Ui.dp(this, 48)) {
                    edgeX = -1;
                    openDrawer();
                }
                break;
            default:
                edgeX = -1;
                break;
        }
        return super.dispatchTouchEvent(e);
    }

    // ------------------------------------------------------------------ UI shell

    private void buildUi() {
        root = new FrameLayout(this);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setBackgroundColor(Theme.bg);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(Theme.card);
        top.setElevation(Ui.dp(this, 4));
        top.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4));

        TextView menu = Ui.text(this, "☰", 26, Theme.text, true);
        menu.setGravity(Gravity.CENTER);
        menu.setClickable(true);
        menu.setContentDescription("menu");
        Ui.pressable(menu);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDrawer();
            }
        });
        top.addView(menu, new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 48)));

        title = Ui.text(this, S.t("مصدّر المعالم", "POI Exporter"), 18, Theme.text, true);
        title.setSingleLine(true);
        title.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView conv = Ui.text(this, "⇄", 24, Theme.primary, true);
        conv.setGravity(Gravity.CENTER);
        conv.setClickable(true);
        Ui.pressable(conv);
        conv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage("converter");
            }
        });
        top.addView(conv, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        topBar = top;
        top.setVisibility(View.GONE);
        content.addView(top, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout body = new FrameLayout(this);
        body.addView(buildMapBox(), new FrameLayout.LayoutParams(-1, -1));
        pageHolder = new FrameLayout(this);
        pageHolder.setBackgroundColor(Theme.bg);
        pageHolder.setClickable(true);
        pageHolder.setVisibility(View.GONE);
        body.addView(pageHolder, new FrameLayout.LayoutParams(-1, -1));
        content.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        scrim = new View(this);
        scrim.setBackgroundColor(0x88000000);
        scrim.setAlpha(0f);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
            }
        });
        root.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        drawer = buildDrawer();
        FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(Ui.dp(this, 300), -1, Gravity.LEFT);
        drawer.setTranslationX(-Ui.dp(this, 310));
        root.addView(drawer, dl);

        setContentView(root);
        getWindow().setStatusBarColor(Theme.card);
        getWindow().setNavigationBarColor(Theme.bg);
        int flags = 0;
        if (!Theme.dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (!Theme.dark && android.os.Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
        updateSummary();
    }

    private View buildMapBox() {
        FrameLayout box = new FrameLayout(this);
        float density = getResources().getDisplayMetrics().density;
        map = new MapView(this);
        map.setMultiTouchControls(true);
        map.setMinZoomLevel(3.0);
        map.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER);
        fo = new FeatureOverlay();
        fo.setData(DATA, density);
        fo.setTap(new FeatureOverlay.Tap() {
            @Override
            public void onFeature(Feature f, LayerData layer) {
                showFeature(f, layer);
            }
        });
        ao = new AreaOverlay(density);
        ao.onMoved(new AreaOverlay.Moved() {
            @Override
            public void to(double lat, double lon) {
                setCenter(lat, lon);
            }
        });
        org.osmdroid.views.overlay.gestures.RotationGestureOverlay rg =
                new org.osmdroid.views.overlay.gestures.RotationGestureOverlay(map);
        rg.setEnabled(true);
        map.getOverlays().add(rg);
        map.getOverlays().add(fo);
        dot = new LocationDot(density);
        map.getOverlays().add(dot);
        guide = new GuideOverlay(density);
        map.getOverlays().add(guide);
        map.getOverlays().add(ao);
        org.osmdroid.views.overlay.ScaleBarOverlay sbar = new org.osmdroid.views.overlay.ScaleBarOverlay(map);
        sbar.setCentred(true);
        sbar.setAlignBottom(false);
        sbar.setScaleBarOffset(0, Ui.dp(this, 12));
        map.getOverlays().add(sbar);
        map.getOverlays().add(new org.osmdroid.views.overlay.Overlay() {
            private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

            {
                p.setColor(0xFF000000);
                p.setStrokeWidth(2f * density);
            }

            @Override
            public boolean onSingleTapConfirmed(android.view.MotionEvent e, MapView mv) {
                float cx = mv.getWidth() / 2f, cy = mv.getHeight() / 2f;
                if (Math.hypot(e.getX() - cx, e.getY() - cy) <= 36 * density) {
                    addAtCenter();
                    return true;
                }
                return false;
            }

            @Override
            public void draw(android.graphics.Canvas c, MapView mv, boolean shadow) {
                if (shadow) return;
                float x = c.getWidth() / 2f, y = c.getHeight() / 2f, r = 12f * density;
                c.drawLine(x - r, y, x + r, y, p);
                c.drawLine(x, y - r, x, y + r, p);
            }
        });
        ao.onEdited(new AreaOverlay.Edited() {
            @Override
            public void changed(double clat, double clon, double wM, double hM, boolean circle, double rot) {
                prefs.rot(circle ? 0 : rot);
                int shape = prefs.shape();
                if (circle) {
                    if (shape != 2) prefs.shape(2);
                    prefs.size(wM, wM);
                } else if (shape == 1) {
                    prefs.size(Math.max(wM, hM), Math.max(wM, hM));
                } else {
                    prefs.size(wM, hM);
                }
                setCenter(clat, clon);
            }
        });
        double[] c = prefs.center();
        map.getController().setZoom(13.0);
        map.getController().setCenter(new GeoPoint(c[0], c[1]));
        box.addView(map, new FrameLayout.LayoutParams(-1, -1));
        map.addMapListener(new org.osmdroid.events.MapListener() {
            public boolean onScroll(org.osmdroid.events.ScrollEvent e) {
                updateCard();
                updateGuide();
                return false;
            }

            public boolean onZoom(org.osmdroid.events.ZoomEvent e) {
                return false;
            }
        });

        // coordinate card (top-left), like Locus/Orux style
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        card.setBackground(Ui.round(0xF2FFFFFF, 6, this));
        card.setElevation(Ui.dp(this, 4));
        card.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 6));
        coordLine1 = Ui.text(this, "", 17, 0xFF111111, true);
        coordLine1.setSingleLine(true);
        coordLine2 = Ui.text(this, "", 13, 0xFF1F57D6, false);
        coordLine2.setSingleLine(true);
        summary = Ui.text(this, "", 11, 0xFF666666, false);
        card.addView(coordLine1);
        card.addView(coordLine2);
        card.addView(summary);
        card.setClickable(true);
        card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                copy(coordLine1.getText().toString());
            }
        });
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        cp.setMargins(Ui.dp(this, 8), Ui.dp(this, 8), 0, 0);
        box.addView(card, cp);

        // attribution
        TextView attr = Ui.text(this, "", 10, Color.parseColor("#333333"), false);
        attrView = attr;
        attr.setBackgroundColor(0xAAFFFFFF);
        attr.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
        FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        ap.bottomMargin = Ui.dp(this, 72);
        box.addView(attr, ap);

        // small area tools (right side)
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.VERTICAL);
        tools.addView(roundBtn("⌖", new Runnable() {
            public void run() {
                org.osmdroid.api.IGeoPoint g = map.getMapCenter();
                setCenter(g.getLatitude(), g.getLongitude());
                toast(S.t("تم وضع مركز المنطقة في مركز الخريطة", "Area centre set to map centre"));
            }
        }));
        editBtn = (TextView) roundBtn("✥", new Runnable() {
            public void run() {
                ao.setEditable(!ao.isEditable());
                styleEdit();
                map.invalidate();
                toast(ao.isEditable() ? S.t("تحريك/تغيير حجم المنطقة بالسحب: مفعّل", "Drag to move/resize area: ON")
                        : S.t("تحريك المنطقة بالسحب: متوقف (للتنقل بالخريطة)", "Drag to move area: OFF (map panning)"));
            }
        });
        tools.addView(editBtn);
        styleEdit();
        areaBtn = (TextView) roundBtn("👁", new Runnable() {
            public void run() {
                boolean v = !ao.isVisible2();
                ao.setVisible2(v);
                prefs.setFlag("areaVis", v);
                areaBtn.setText(v ? "👁" : "🚫");
                map.invalidate();
                toast(v ? S.t("تم إظهار مستطيل التحديد", "Selection shown") : S.t("تم إخفاء مستطيل التحديد", "Selection hidden"));
            }
        });
        tools.addView(areaBtn);
        ao.setVisible2(prefs.flag("areaVis", true));
        areaBtn.setText(ao.isVisible2() ? "👁" : "🚫");
        tools.addView(roundBtn("⛶", new Runnable() {
            public void run() {
                zoomToArea();
            }
        }));
        tools.addView(roundBtn("▣", new Runnable() {
            public void run() {
                zoomToData();
            }
        }));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT | Gravity.TOP);
        tp.topMargin = Ui.dp(this, 90);
        tp.rightMargin = Ui.dp(this, 10);
        box.addView(tools, tp);

        // big zoom buttons (bottom-right)
        LinearLayout zoom = new LinearLayout(this);
        zoom.setOrientation(LinearLayout.VERTICAL);
        zoom.addView(zoomBtn("+", new Runnable() {
            public void run() {
                map.getController().zoomIn();
            }
        }));
        zoom.addView(zoomBtn("−", new Runnable() {
            public void run() {
                map.getController().zoomOut();
            }
        }));
        FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT | Gravity.BOTTOM);
        zp.rightMargin = Ui.dp(this, 8);
        zp.bottomMargin = Ui.dp(this, 8);
        box.addView(zoom, zp);

        // status banners (group recording, guidance line, progress)
        buildStatus(box);

        // bottom toolbar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        bar.setBackground(Ui.round(0xCC5F6368, 6, this));
        bar.setElevation(Ui.dp(this, 6));
        bar.addView(barBtn("☰", new Runnable() {
            public void run() {
                openDrawer();
            }
        }, null), new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        bar.addView(barBtn("🗺", new Runnable() {
            public void run() {
                mapTypeDialog();
            }
        }, null), new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        // flag: tap = add a landmark, long press = choose landmark / landmark group
        flagBtn = barBtn("⚑", new Runnable() {
            public void run() {
                addAtCenter();
            }
        }, new Runnable() {
            public void run() {
                flagMenu(flagBtn);
            }
        });
        addBtn = flagBtn;
        bar.addView(flagBtn, new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        // GPS: tap = on / off, long press = menu
        gpsBtn = barBtn("◎", new Runnable() {
            public void run() {
                gpsTap();
            }
        }, new Runnable() {
            public void run() {
                gpsMenu();
            }
        });
        bar.addView(gpsBtn, new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        // compass: tap = on / off, long press = menu
        compassBtn = barBtn("🧭", new Runnable() {
            public void run() {
                compassTap();
            }
        }, new Runnable() {
            public void run() {
                compassMenu();
            }
        });
        bar.addView(compassBtn, new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        // download: tap = start / stop, long press = menu
        dlBtn = barBtn("⬇", new Runnable() {
            public void run() {
                downloadTap();
            }
        }, new Runnable() {
            public void run() {
                downloadMenu();
            }
        });
        bar.addView(dlBtn, new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        int sw = getResources().getDisplayMetrics().widthPixels;
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams((int) (sw * 0.76f), -2, Gravity.BOTTOM | Gravity.LEFT);
        bp.setMargins(Ui.dp(this, 6), 0, 0, Ui.dp(this, 8));
        box.addView(bar, bp);

        setBase(prefs.get("basemap", "0"), false);
        applyMapOverlays();
        ao.set(area());
        ao.setSquare(prefs.shape() == 1);
        updateCard();
        return box;
    }

    private TextView coordLine1, coordLine2;

    void updateCard() {
        if (coordLine1 == null || map == null) return;
        org.osmdroid.api.IGeoPoint g = map.getMapCenter();
        double lat = g.getLatitude(), lon = g.getLongitude();
        String l1 = CoordFmt.format(fmt(), lat, lon);
        if (lastLoc != null && lastLoc.hasAltitude()) l1 += "  ↑" + Math.round(lastLoc.getAltitude()) + " m";
        coordLine1.setText(l1);
        coordLine2.setText(CoordFmt.dd(lat, lon) + "  WGS84");
    }

    private TextView barBtn(String glyph, final Runnable r, final Runnable longPress) {
        TextView t = new TextView(this);
        t.setText(glyph);
        t.setTextSize(24);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                r.run();
            }
        });
        if (longPress != null) {
            t.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                    longPress.run();
                    return true;
                }
            });
        }
        return t;
    }

    private View zoomBtn(String glyph, final Runnable r) {
        TextView t = new TextView(this);
        t.setText(glyph);
        t.setTextSize(34);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.round(0xCC5F6368, 10, this));
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                r.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 52));
        lp.topMargin = Ui.dp(this, 6);
        t.setLayoutParams(lp);
        return t;
    }

    void mapTypeDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("نوع الخريطة", "Map type"), 18, Theme.text, true));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        final Dialog d = card(box);
        String cur = prefs.get("basemap", "0");
        for (int i = 0; i < BaseMaps.ALL.length; i++) {
            final int idx = i;
            boolean on = cur.equals(String.valueOf(i));
            list.addView(Ui.button(this, (on ? "✔  " : "") + BaseMaps.ALL[i].label(), on, new Runnable() {
                public void run() {
                    setBaseMap(idx, true);
                    d.dismiss();
                }
            }), Ui.lp(-1, -2, 0, this, 0, 6, 0, 0));
        }
        final List<MapSources.Item> items = MapSources.load(prefs);
        for (final MapSources.Item it : items) {
            if (it.overlay) continue;
            final String key = "c:" + it.id;
            boolean on = cur.equals(key);
            list.addView(Ui.button(this, (on ? "✔  " : "🌐  ") + it.name, on, new Runnable() {
                public void run() {
                    setBase(key, true);
                    d.dismiss();
                }
            }), Ui.lp(-1, -2, 0, this, 0, 6, 0, 0));
        }
        boolean anyOverlay = false;
        for (MapSources.Item it : items) if (it.overlay) anyOverlay = true;
        if (anyOverlay) {
            list.addView(Ui.text(this, S.t("طبقات للعرض فقط", "View-only layers"), 13, Theme.sub, false),
                    Ui.lp(-2, -2, 0, this, 2, 14, 0, 2));
            for (final MapSources.Item it : items) {
                if (!it.overlay) continue;
                list.addView(Ui.button(this, (it.visible ? "☑  " : "☐  ") + it.name, it.visible, new Runnable() {
                    public void run() {
                        it.visible = !it.visible;
                        MapSources.save(prefs, items);
                        applyMapOverlays();
                        d.dismiss();
                        mapTypeDialog();
                    }
                }), Ui.lp(-1, -2, 0, this, 0, 6, 0, 0));
            }
        }
        box.addView(sv, Ui.lp(-1, Ui.dp(this, 340), 0, this, 0, 6, 0, 0));
        box.addView(Ui.button(this, S.t("🌐 إدارة الخرائط / إضافة من الإنترنت", "🌐 Manage maps / add from internet"), false, new Runnable() {
            public void run() {
                d.dismiss();
                showPage("maps");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 10, 0, 0));
        d.show();
    }

    void searchDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("بحث عن مكان أو إحداثيات", "Search a place or coordinates"), 18, Theme.text, true));
        final android.widget.EditText q = Ui.field(this, S.t("اسم مكان أو إحداثيات بأي صيغة", "Place name or coordinates"),
                android.text.InputType.TYPE_CLASS_TEXT);
        box.addView(q, Ui.lp(-1, -2, 0, this, 0, 10, 0, 0));
        final Dialog d = card(box);
        box.addView(Ui.button(this, S.t("بحث", "Search"), true, new Runnable() {
            public void run() {
                d.dismiss();
                search(q.getText().toString());
            }
        }), Ui.lp(-1, -2, 0, this, 0, 12, 0, 0));
        d.show();
    }

    private int baseIndex() {
        try {
            return Math.max(0, Math.min(BaseMaps.ALL.length - 1, Integer.parseInt(prefs.get("basemap", "0"))));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private TextView[] mapChips;
    private TextView attrView;

    void setBaseMap(int i, boolean save) {
        BaseMaps.Def d = BaseMaps.ALL[i];
        map.setTileSource(BaseMaps.source(d, S.ar));
        map.getOverlayManager().getTilesOverlay().setColorFilter(Theme.dark && d.isOsm() ? TilesOverlay.INVERT_COLORS : null);
        if (attrView != null) {
            String t = d.isOsm() ? "© OpenStreetMap" : d.kind.equals("esri") ? "© Esri" : "Google";
            attrView.setText(t);
        }
        if (save) prefs.put("basemap", String.valueOf(i));
        if (mapChips != null) for (int k = 0; k < mapChips.length; k++) Ui.setChip(mapChips[k], k == i);
        map.invalidate();
    }

    private View buildSearchAndMaps() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), 0);
        col.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.stroke(Theme.card, Theme.line, 24, this));
        bar.setElevation(Ui.dp(this, 4));
        bar.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 4), 0);
        final android.widget.EditText q = new android.widget.EditText(this);
        q.setHint(S.t("ابحث عن مكان أو إحداثيات…", "Search a place or coordinates…"));
        q.setSingleLine(true);
        q.setTextSize(14.5f);
        q.setTextColor(Theme.text);
        q.setHintTextColor(Theme.sub);
        q.setBackground(null);
        q.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        bar.addView(q, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f));
        final Runnable go = new Runnable() {
            public void run() {
                search(q.getText().toString());
            }
        };
        q.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int a, android.view.KeyEvent e) {
                go.run();
                return true;
            }
        });
        TextView sb = Ui.text(this, "🔍", 20, Theme.primary, true);
        sb.setGravity(Gravity.CENTER);
        sb.setClickable(true);
        Ui.pressable(sb);
        sb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                go.run();
            }
        });
        bar.addView(sb, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));
        col.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        mapChips = new TextView[BaseMaps.ALL.length];
        for (int i = 0; i < BaseMaps.ALL.length; i++) {
            final int idx = i;
            mapChips[i] = Ui.chip(this, BaseMaps.ALL[i].label());
            mapChips[i].setElevation(Ui.dp(this, 2));
            mapChips[i].setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    setBaseMap(idx, true);
                }
            });
            chips.addView(mapChips[i], Ui.lp(-2, -2, 0, this, 3, 8, 3, 0));
        }
        hs.addView(chips);
        col.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        return col;
    }

    void search(final String text) {
        final String t = text == null ? "" : text.trim();
        if (t.isEmpty()) return;
        try {
            CoordFmt.Parsed ps = CoordFmt.parse(t);
            map.getController().setZoom(16.0);
            map.getController().animateTo(new GeoPoint(ps.lat, ps.lon));
            return;
        } catch (Exception ignored) {
            // not coordinates: search by name
        }
        toast(S.t("جارٍ البحث…", "Searching…"));
        new Thread(new Runnable() {
            public void run() {
                try {
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(
                            "https://nominatim.openstreetmap.org/search?format=json&limit=1&q="
                                    + java.net.URLEncoder.encode(t, "UTF-8")).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(20000);
                    c.setRequestProperty("User-Agent", "PoiExporter/2.2 (iq.gis.poiexporter)");
                    InputStream in = c.getInputStream();
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    org.json.JSONArray arr = new org.json.JSONArray(bo.toString("UTF-8"));
                    if (arr.length() == 0) throw new java.io.IOException("none");
                    final double lat = arr.getJSONObject(0).getDouble("lat"), lon = arr.getJSONObject(0).getDouble("lon");
                    runOnUiThread(new Runnable() {
                        public void run() {
                            map.getController().setZoom(15.0);
                            map.getController().animateTo(new GeoPoint(lat, lon));
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            toast(S.t("لم يتم العثور على نتائج", "No results found"));
                        }
                    });
                }
            }
        }).start();
    }

    int[] adminLevels() {
        int[] lv = {4, 5, 6};
        for (int i = 0; i < 3; i++) {
            try {
                lv[i] = Integer.parseInt(prefs.get("lv" + (i + 4), String.valueOf(i + 4)).trim());
            } catch (NumberFormatException ignored) {
                // keep default
            }
        }
        return lv;
    }

    /** Flag tap: adds a landmark at the map centre (quick add while recording a group). */
    void addAtCenter() {
        if (DRAFT != null) {
            groupTapAdd();
            return;
        }
        org.osmdroid.api.IGeoPoint g = map.getMapCenter();
        addDialog(g.getLatitude(), g.getLongitude(), null, false);
    }

    /** Opens the add dialog with the given group preselected (from the points manager). */
    void addAtCenterTo(LayerData l) {
        org.osmdroid.api.IGeoPoint g = map.getMapCenter();
        addDialog(g.getLatitude(), g.getLongitude(), l.label, false);
    }

    private LayerData groupByLabel(String name) {
        for (LayerData l : LIB) if (l.label.equalsIgnoreCase(name)) return l;
        return null;
    }

    private void addDialog(final double lat, final double lon, final String defGroup, final boolean toDraft) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("إضافة معلم في مركز الخريطة", "Add landmark at map centre"), 18, Theme.text, true));
        TextView c = Ui.text(this, CoordFmt.format(fmt(), lat, lon), 12, Theme.sub, false);
        c.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        box.addView(c);
        final android.widget.EditText name = Ui.field(this, S.t("الاسم NAME", "NAME"), android.text.InputType.TYPE_CLASS_TEXT);
        final android.widget.EditText type = Ui.field(this, S.t("النوع TYPE (مثال: مدرسة ابتدائية)", "TYPE (e.g. primary school)"),
                android.text.InputType.TYPE_CLASS_TEXT);
        final android.widget.EditText cat = Ui.field(this, S.t("الفئة CATEGORY", "CATEGORY"), android.text.InputType.TYPE_CLASS_TEXT);
        box.addView(name, Ui.lp(-1, -2, 0, this, 0, 10, 0, 0));
        box.addView(type, Ui.lp(-1, -2, 0, this, 0, 8, 0, 0));
        box.addView(cat, Ui.lp(-1, -2, 0, this, 0, 8, 0, 0));
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        for (final Catalog.PoiCat pc : Catalog.POI) {
            TextView ch = Ui.chip(this, pc.label(S.ar));
            ch.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    cat.setText(pc.label(S.ar));
                }
            });
            chips.addView(ch, Ui.lp(-2, -2, 0, this, 3, 8, 3, 0));
        }
        hs.addView(chips);
        box.addView(hs);

        if (!toDraft) box.addView(Ui.text(this, S.t("المجموعة", "Group"), 13, Theme.sub, false), Ui.lp(-2, -2, 0, this, 0, 12, 0, 2));
        String def = S.t("معالمي", "My landmarks");
        for (LayerData l : LIB) if (l.id.equals(ACTIVE)) def = l.label;
        if (defGroup != null) def = defGroup;
        final android.widget.EditText grp = Ui.field(this, S.t("اسم المجموعة (جديد أو موجود)", "Group name (new or existing)"),
                android.text.InputType.TYPE_CLASS_TEXT);
        grp.setText(def);
        if (!toDraft) box.addView(grp, Ui.lp(-1, -2, 0, this, 0, 0, 0, 0));
        if (!LIB.isEmpty() && !toDraft) {
            android.widget.HorizontalScrollView gs = new android.widget.HorizontalScrollView(this);
            gs.setHorizontalScrollBarEnabled(false);
            LinearLayout gl = new LinearLayout(this);
            for (final LayerData l : LIB) {
                TextView ch = Ui.chip(this, l.label);
                ch.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        grp.setText(l.label);
                    }
                });
                gl.addView(ch, Ui.lp(-2, -2, 0, this, 3, 8, 3, 0));
            }
            gs.addView(gl);
            box.addView(gs);
        }
        final Dialog d = card(box);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 12, 4, 0));
        r.addView(Ui.button(this, S.t("حفظ", "Save"), true, new Runnable() {
            public void run() {
                Feature f = Feature.point(lat, lon);
                f.name = name.getText().toString().trim();
                f.type = type.getText().toString().trim();
                f.category = cat.getText().toString().trim();
                String gname = grp.getText().toString().trim();
                if (gname.isEmpty()) gname = S.t("معالمي", "My landmarks");
                d.dismiss();
                if (toDraft && DRAFT != null) {
                    if (f.name.isEmpty()) f.name = DRAFT.label + " " + (DRAFT.features.size() + 1);
                    DRAFT.features.add(f);
                    rebuild();
                    updateGroupBanner();
                    return;
                }
                addToGroup(f, gname);
            }
        }), Ui.lp(0, -2, 1f, this, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    private void addToGroup(final Feature f, String gname) {
        final LayerData g;
        LayerData ex = groupByLabel(gname);
        if (ex == null) {
            g = new LayerData(Library.newId(), gname, Feature.POINT);
            LIB.add(g);
        } else {
            g = ex;
        }
        ACTIVE = g.id;
        prefs.put("active", g.id);
        g.features.add(f);
        HIDDEN.remove(g.id);
        saveCsv("hidden", HIDDEN);
        rebuild();
        persist(g);
        map.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        toast(S.t("أُضيف إلى المجموعة: ", "Added to group: ") + g.label);
        if (prefs.flag("fillAdmin", true)) {
            new Thread(new Runnable() {
                public void run() {
                    try {
                        List<Feature> one = new ArrayList<>();
                        one.add(f);
                        Pipeline.fillAdminFor(one, adminLevels(), new Net());
                        runOnUiThread(new Runnable() {
                            public void run() {
                                persist(g);
                            }
                        });
                    } catch (Exception ignored) {
                        // offline: admin fields stay empty
                    }
                }
            }).start();
        }
    }

    /** Writes a group to disk in the background (snapshot taken on the calling thread). */
    void persist(LayerData g) {
        final LayerData snap = new LayerData(g.id, g.label, g.geom);
        snap.color = g.color;
        snap.features.addAll(new ArrayList<>(g.features));
        new Thread(new Runnable() {
            public void run() {
                try {
                    Library.save(MainActivity.this, snap);
                } catch (Exception ignored) {
                    // storage problem: the group stays in memory
                }
            }
        }).start();
    }

    /** Rebuilds the visible layer list and redraws. */
    void rebuild() {
        List<LayerData> all = new ArrayList<>();
        for (LayerData l : LIB) if (!HIDDEN.contains(l.id)) all.add(l);
        for (LayerData l : DL) if (!HIDDEN.contains(l.id)) all.add(l);
        if (DRAFT != null) all.add(DRAFT);
        DATA = all;
        if (fo != null) {
            fo.setData(DATA, getResources().getDisplayMetrics().density);
            map.invalidate();
        }
        updateSummary();
    }

    void zoomToLayer(LayerData l) {
        double[] r = null;
        for (Feature f : l.features) {
            double[] b = f.geom == Feature.POINT ? new double[]{f.lon, f.lat, f.lon, f.lat} : Geo.bbox(f);
            if (r == null) r = b.clone();
            else {
                r[0] = Math.min(r[0], b[0]);
                r[1] = Math.min(r[1], b[1]);
                r[2] = Math.max(r[2], b[2]);
                r[3] = Math.max(r[3], b[3]);
            }
        }
        if (r == null) {
            toast(S.t("المجموعة فارغة", "Empty"));
            return;
        }
        zoomToBox(r);
    }

    /** r = minLon, minLat, maxLon, maxLat. */
    void zoomToBox(double[] r) {
        if (r == null) return;
        if (r[2] - r[0] < 1e-4 && r[3] - r[1] < 1e-4) {
            map.getController().setZoom(17.0);
            map.getController().setCenter(new GeoPoint(r[1], r[0]));
            return;
        }
        double pl = Math.max(0.0005, (r[3] - r[1]) * 0.08), po = Math.max(0.0005, (r[2] - r[0]) * 0.08);
        final BoundingBox bb = new BoundingBox(Math.min(85, r[3] + pl), r[2] + po, Math.max(-85, r[1] - pl), r[0] - po);
        map.post(new Runnable() {
            public void run() {
                map.zoomToBoundingBox(bb, true, Ui.dp(MainActivity.this, 40));
            }
        });
    }

    void previewDialog(final LayerData l) {
        HIDDEN.remove(l.id);
        saveCsv("hidden", HIDDEN);
        rebuild();
        marks.pointsManager(l);
        zoomToLayer(l);
    }

    void deleteFeature(Feature f, LayerData l) {
        l.features.remove(f);
        if (Library.isGroup(l)) persist(l);
        else if (l.features.isEmpty() && l != DRAFT) DL.remove(l);
        rebuild();
        if (l == DRAFT) updateGroupBanner();
    }

    void deleteLayer(final LayerData l) {
        message(S.t("حذف", "Delete"), S.t("حذف «", "Delete \u201c") + l.label + S.t("» ونقاطه (" + l.features.size() + ")؟",
                "\u201d with " + l.features.size() + " items?"), S.t("حذف", "Delete"), new Runnable() {
            public void run() {
                if (Library.isGroup(l)) {
                    LIB.remove(l);
                    Library.delete(MainActivity.this, l);
                    if (l.id.equals(ACTIVE)) ACTIVE = null;
                } else {
                    DL.remove(l);
                }
                HIDDEN.remove(l.id);
                rebuild();
                if ("library".equals(page)) showPage("library");
            }
        });
    }

    void saveAsGroup(LayerData l) {
        LayerData g = new LayerData(Library.newId(), l.label, l.geom);
        g.color = l.color;
        g.features.addAll(l.features);
        LIB.add(g);
        persist(g);
        toast(S.t("حُفظت في المعالم المحفوظة: ", "Saved to library: ") + l.label);
        if ("library".equals(page)) showPage("library");
    }

    void shareDialog(final LayerData l) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("مشاركة: ", "Share: ") + l.label, 18, Theme.text, true));
        final Dialog d = card(box);
        String[] kinds = {"kml", "kmz", "shp"};
        String[] names = {"KML (" + S.t("بيني كويست", "PineQuest") + ")", "KMZ", "Shapefile (ZIP)"};
        for (int i = 0; i < 3; i++) {
            final String k = kinds[i];
            box.addView(Ui.button(this, names[i], i == 0, new Runnable() {
                public void run() {
                    d.dismiss();
                    List<LayerData> one = new ArrayList<>();
                    one.add(l);
                    exportLayers(one, k, l.label);
                }
            }), Ui.lp(-1, -2, 0, this, 0, 8, 0, 0));
        }
        d.show();
    }

    private void styleEdit() {
        boolean on = ao.isEditable();
        editBtn.setTextColor(on ? Theme.onPrimary : Theme.text);
        editBtn.setBackground(Ui.stroke(on ? Theme.primary : Theme.card, Theme.line, 24, this));
    }

    private View roundBtn(String label, final Runnable r) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(Theme.text);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.stroke(Theme.card, Theme.line, 24, this));
        t.setElevation(Ui.dp(this, 3));
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46));
        lp.bottomMargin = Ui.dp(this, 8);
        t.setLayoutParams(lp);
        return t;
    }

    private LinearLayout buildDrawer() {
        LinearLayout d = new LinearLayout(this);
        d.setOrientation(LinearLayout.VERTICAL);
        d.setBackgroundColor(Theme.card);
        d.setElevation(Ui.dp(this, 16));
        d.setClickable(true);
        d.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setBackgroundColor(Theme.primary);
        head.setPadding(Ui.dp(this, 18), Ui.dp(this, 36), Ui.dp(this, 18), Ui.dp(this, 18));
        head.addView(Ui.text(this, "🌍", 34, Theme.onPrimary, false));
        head.addView(Ui.text(this, S.t("مصدّر المعالم", "POI Exporter"), 20, Theme.onPrimary, true));
        head.addView(Ui.text(this, S.t("OpenStreetMap • Shapefile • KML", "OpenStreetMap • Shapefile • KML"), 12,
                Theme.onPrimary, false));
        d.addView(head, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        list.addView(item("🗺", S.t("الخريطة", "Map"), new Runnable() {
            public void run() {
                showMap();
            }
        }));
        list.addView(item("▭", S.t("المنطقة المحددة (يدوي)", "Selected area (manual)"), new Runnable() {
            public void run() {
                showPage("area");
            }
        }));
        list.addView(item("☰", S.t("الطبقات والتحميل", "Layers & download"), new Runnable() {
            public void run() {
                showPage("layers");
            }
        }));
        list.addView(item("📁", S.t("المعالم المحفوظة والطبقات", "Saved landmarks & layers"), new Runnable() {
            public void run() {
                showPage("library");
            }
        }));
        list.addView(item("🌐", S.t("الخرائط من الإنترنت", "Online maps"), new Runnable() {
            public void run() {
                showPage("maps");
            }
        }));
        list.addView(item("🔍", S.t("بحث", "Search"), new Runnable() {
            public void run() {
                searchDialog();
            }
        }));
        list.addView(item("⤴", S.t("تصدير البيانات", "Export data"), new Runnable() {
            public void run() {
                exportDialog();
            }
        }));
        list.addView(item("⇄", S.t("محول الإحداثيات", "Coordinate converter"), new Runnable() {
            public void run() {
                showPage("converter");
            }
        }));
        list.addView(item("⇅", S.t("استيراد / تصدير (KML • بيني كويست)", "Import / export (KML • PineQuest)"),
                new Runnable() {
                    public void run() {
                        showPage("kml");
                    }
                }));
        list.addView(item("⚙", S.t("الإعدادات", "Settings"), new Runnable() {
            public void run() {
                showPage("settings");
            }
        }));
        list.addView(item("ⓘ", S.t("حول التطبيق", "About"), new Runnable() {
            public void run() {
                about();
            }
        }));
        sv.addView(list);
        d.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return d;
    }

    private View item(String icon, String label, final Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        row.setClickable(true);
        row.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x333DB8A5), null,
                Ui.round(Color.WHITE, 12, this)));
        TextView i = Ui.text(this, icon, 20, Theme.primary, true);
        i.setGravity(Gravity.CENTER);
        row.addView(i, new LinearLayout.LayoutParams(Ui.dp(this, 34), -2));
        TextView t = Ui.text(this, label, 15, Theme.text, false);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.setMargins(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        row.addView(t, tl);
        Ui.pressable(row);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                r.run();
            }
        });
        return row;
    }

    void openDrawer() {
        if (drawerOpen) return;
        drawerOpen = true;
        scrim.setVisibility(View.VISIBLE);
        scrim.animate().alpha(1f).setDuration(220).start();
        drawer.animate().translationX(0).setDuration(240).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
    }

    void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        scrim.animate().alpha(0f).setDuration(200).withEndAction(new Runnable() {
            public void run() {
                if (!drawerOpen) scrim.setVisibility(View.GONE);
            }
        }).start();
        drawer.animate().translationX(-Ui.dp(this, 310)).setDuration(220).start();
    }

    void showMap() {
        page = null;
        topBar.setVisibility(View.GONE);
        pageHolder.setVisibility(View.GONE);
        pageHolder.removeAllViews();
        title.setText(S.t("مصدّر المعالم", "POI Exporter"));
        updateSummary();
        map.invalidate();
    }

    void showPage(String key) {
        View v;
        String t;
        switch (key) {
            case "settings":
                v = pages.settings();
                t = S.t("الإعدادات", "Settings");
                break;
            case "area":
                v = pages.area();
                t = S.t("المنطقة المحددة", "Selected area");
                break;
            case "layers":
                v = pages.layers();
                t = S.t("الطبقات والتحميل", "Layers & download");
                break;
            case "kml":
                v = pages.kml();
                t = S.t("استيراد / تصدير KML", "Import / export KML");
                break;
            case "library":
                v = pages.library();
                t = S.t("المعالم المحفوظة والطبقات", "Saved landmarks & layers");
                break;
            case "maps":
                v = pages.maps();
                t = S.t("الخرائط من الإنترنت", "Online maps");
                break;
            case "converter":
                v = pages.converter();
                t = S.t("محول الإحداثيات", "Coordinate converter");
                break;
            default:
                showMap();
                return;
        }
        ScrollView sv = new ScrollView(this);
        sv.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        sv.setFillViewport(false);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 40));
        wrap.addView(v, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(wrap, new ViewGroup.LayoutParams(-1, -2));
        pageHolder.removeAllViews();
        pageHolder.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        pageHolder.setAlpha(0f);
        pageHolder.setVisibility(View.VISIBLE);
        pageHolder.animate().alpha(1f).setDuration(180).start();
        title.setText(t);
        topBar.setVisibility(View.VISIBLE);
        page = key;
        closeDrawer();
    }

    // ------------------------------------------------------------------ GPS

    void locate() {
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION}, 21);
            return;
        }
        tracking = true;
        styleToggles();
        startLocation();
        if (lastLoc != null) onFix(lastLoc);
        else toast(S.t("جارٍ تحديد الموقع…", "Getting location…"));
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == 21) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) locate();
            else toast(S.t("لم يُمنح إذن الموقع", "Location permission denied"));
        }
    }

    private void onFix(Location l) {
        lastLoc = l;
        updateCard();
        dot.set(l.getLatitude(), l.getLongitude(), l.getAccuracy());
        if (centerOnFix) {
            centerOnFix = false;
            if (map.getZoomLevelDouble() < 15) map.getController().setZoom(16.0);
            map.getController().animateTo(new GeoPoint(l.getLatitude(), l.getLongitude()));
        }
        if (areaOnFix) {
            areaOnFix = false;
            setCenter(l.getLatitude(), l.getLongitude());
            zoomToArea();
        }
        map.invalidate();
    }

    void useLocationAsCenter() {
        if (lastLoc != null) {
            areaOnFix = true;
            onFix(lastLoc);
        } else {
            areaOnFix = true;
            locate();
        }
    }

    @SuppressWarnings("MissingPermission")
    private void startLocation() {
        try {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                return;
            if (lm == null) lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (ll == null) {
                ll = new LocationListener() {
                    public void onLocationChanged(Location l) {
                        onFix(l);
                    }

                    public void onProviderEnabled(String p) {
                    }

                    public void onProviderDisabled(String p) {
                    }

                    public void onStatusChanged(String p, int st, Bundle b) {
                    }
                };
            }
            lm.removeUpdates(ll);
            boolean any = false;
            for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                if (lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, 1000, 0f, ll);
                    Location k = lm.getLastKnownLocation(p);
                    if (k != null && lastLoc == null) lastLoc = k;
                    any = true;
                }
            }
            if (!any) toast(S.t("فعّل GPS من إعدادات الجهاز", "Turn on GPS in device settings"));
        } catch (SecurityException ignored) {
            // permission revoked
        }
    }

    private void stopLocation() {
        if (lm != null && ll != null) lm.removeUpdates(ll);
    }

    // ------------------------------------------------------------------ area

    CoordFmt.Fmt fmt() {
        return CoordFmt.Fmt.values()[Math.max(0, Math.min(3, prefs.fmt()))];
    }

    AreaSpec area() {
        double[] c = prefs.center();
        double w = prefs.width(), h = prefs.height();
        switch (prefs.shape()) {
            case 1:
                return AreaSpec.rotated(c[0], c[1], w, w, prefs.rot());
            case 2:
                return AreaSpec.circle(c[0], c[1], w);
            default:
                return AreaSpec.rotated(c[0], c[1], w, h, prefs.rot());
        }
    }

    void setCenter(double lat, double lon) {
        lat = Math.max(-84, Math.min(84, lat));
        lon = ((lon + 540) % 360) - 180;
        prefs.center(lat, lon);
        applyArea(false);
    }

    void applyArea(boolean zoom) {
        ao.set(area());
        ao.setSquare(prefs.shape() == 1);
        map.invalidate();
        updateSummary();
        pages.onAreaChanged();
        if (zoom) zoomToArea();
    }

    void zoomToArea() {
        AreaSpec a = area();
        double s = a.south, n = a.north, w = a.west, e = a.east;
        if (a.circle) {
            double[] r = Geo.rectAround(a.clat, a.clon, a.radius * 2, a.radius * 2);
            s = r[0];
            w = r[1];
            n = r[2];
            e = r[3];
        }
        final BoundingBox bb = new BoundingBox(n, e, s, w);
        map.post(new Runnable() {
            public void run() {
                map.zoomToBoundingBox(bb, true, Ui.dp(MainActivity.this, 40));
            }
        });
    }

    void zoomToData() {
        double[] b = fo.bounds();
        if (b == null) {
            toast(S.t("لا توجد بيانات محمّلة بعد", "No data loaded yet"));
            return;
        }
        double padLat = Math.max(0.0005, (b[3] - b[1]) * 0.05), padLon = Math.max(0.0005, (b[2] - b[0]) * 0.05);
        final BoundingBox bb = new BoundingBox(Math.min(85, b[3] + padLat), b[2] + padLon, Math.max(-85, b[1] - padLat), b[0] - padLon);
        map.post(new Runnable() {
            public void run() {
                map.zoomToBoundingBox(bb, true, Ui.dp(MainActivity.this, 30));
            }
        });
    }

    void updateSummary() {
        if (summary == null) return;
        AreaSpec a = area();
        String dim = a.circle
                ? S.t("دائرة نق ", "Circle r ") + fmtLen(a.radius)
                : fmtLen(a.widthM()) + " × " + fmtLen(a.heightM());
        int n = 0;
        for (LayerData l : DATA) n += l.features.size();
        summary.setText(S.t("المنطقة: ", "Area: ") + dim + String.format(Locale.US, " (%.2f km²)", a.areaKm2())
                + " • " + n + S.t(" عنصر", " items"));
        updateCard();
    }

    static String fmtLen(double m) {
        return m >= 1000 ? String.format(Locale.US, "%.2f km", m / 1000) : String.format(Locale.US, "%.0f m", m);
    }

    // ------------------------------------------------------------------ selection state

    Set<String> csv(String key, String def) {
        Set<String> s = new LinkedHashSet<>();
        String v = prefs.get(key, def);
        if (v != null) for (String p : v.split(",")) if (!p.trim().isEmpty()) s.add(p.trim());
        return s;
    }

    void saveCsv(String key, Set<String> s) {
        StringBuilder b = new StringBuilder();
        for (String x : s) b.append(b.length() > 0 ? "," : "").append(x);
        prefs.put(key, b.toString());
    }

    String allPoi() {
        StringBuilder b = new StringBuilder();
        for (Catalog.PoiCat c : Catalog.POI) b.append(b.length() > 0 ? "," : "").append(c.id);
        return b.toString();
    }

    // ------------------------------------------------------------------ download

    private String stepLabel(String key) {
        if ("admin".equals(key)) return S.t("جلب الحدود الإدارية…", "Fetching administrative boundaries…");
        if ("poi".equals(key)) return S.t("جلب المعالم…", "Fetching landmarks…");
        Catalog.LayerDef d = Catalog.layer(key);
        return S.t("جلب: ", "Fetching: ") + (d != null ? d.label(S.ar) : key);
    }

    void download() {
        if (progressCancel != null) {
            toast(S.t("هناك عملية تحميل جارية", "A download is already running"));
            return;
        }
        final AreaSpec a = area();
        if (a.areaKm2() > 1500 && !bigOk) {
            message(S.t("منطقة كبيرة", "Large area"),
                    S.t("مساحة المنطقة " + String.format(Locale.US, "%.0f", a.areaKm2())
                                    + " كم². لا يوجد حد للمساحة، لكن التحميل قد يطول أو يفشل إذا كانت البيانات ضخمة (يُنصح بتقليل الطبقات). هل تريد المتابعة؟",
                            "Area is " + String.format(Locale.US, "%.0f", a.areaKm2())
                                    + " km². There is no limit, but the download may be slow or fail with huge data (try fewer layers). Continue?"),
                    S.t("متابعة", "Continue"), new Runnable() {
                        public void run() {
                            bigOk = true;
                            download();
                        }
                    });
            return;
        }
        bigOk = false;
        final Pipeline.Params p = new Pipeline.Params();
        p.area = a;
        p.poiCats.addAll(csv("poi", allPoi()));
        p.layerIds.addAll(csv("layers", ""));
        p.layerIds.addAll(csv("adm", ""));
        p.fillAdmin = prefs.flag("fillAdmin", true);
        p.includeUnnamed = prefs.flag("unnamed", false);
        p.custom = prefs.get("custom", "");
        p.arabic = S.ar;
        int[] lv = {4, 5, 6};
        for (int i = 0; i < 3; i++) {
            try {
                lv[i] = Integer.parseInt(prefs.get("lv" + (i + 4), String.valueOf(i + 4)).trim());
            } catch (NumberFormatException ignored) {
                // keep default
            }
        }
        p.adminLevels = lv;
        if (p.poiCats.isEmpty() && p.layerIds.isEmpty() && p.custom.trim().isEmpty()) {
            toast(S.t("اختر طبقة واحدة على الأقل من «الطبقات والتحميل»", "Select at least one layer in Layers & download"));
            showPage("layers");
            return;
        }
        cancel = false;
        showProgress(S.t("جارٍ الاتصال…", "Connecting…"), new Runnable() {
            public void run() {
                cancel = true;
                updateProgress(S.t("جارٍ الإلغاء…", "Cancelling…"), -1);
            }
        });
        new Thread(new Runnable() {
            public void run() {
                Pipeline.Result res;
                try {
                    res = Pipeline.run(p, new Net(), new Pipeline.Progress() {
                        public void update(final String m, final int step, final int steps) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    updateProgress(stepLabel(m) + "  (" + step + "/" + steps + ")",
                                            Math.max(5, (step - 1) * 100 / Math.max(1, steps)));
                                }
                            });
                        }

                        public boolean cancelled() {
                            return cancel;
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            hideProgress();
                            message(S.t("فشل التحميل", "Download failed"), String.valueOf(t.getMessage()), null, null);
                        }
                    });
                    return;
                }
                final Pipeline.Result r = res;
                runOnUiThread(new Runnable() {
                    public void run() {
                        hideProgress();
                        onDownloaded(r);
                    }
                });
            }
        }).start();
    }

    private void onDownloaded(Pipeline.Result r) {
        if (r.cancelled) {
            toast(S.t("أُلغي التحميل", "Download cancelled"));
            return;
        }
        DL = new ArrayList<>(r.layers);
        HIDDEN.removeAll(java.util.Collections.singleton("poi"));
        for (LayerData l : r.layers) HIDDEN.remove(l.id);
        rebuild();
        StringBuilder sb = new StringBuilder();
        sb.append(S.t("تم تحميل ", "Loaded ")).append(r.featureCount()).append(S.t(" عنصر:\n", " features:\n"));
        for (LayerData l : r.layers) sb.append("• ").append(l.label).append(": ").append(l.features.size()).append('\n');
        if (!r.warnings.isEmpty()) {
            sb.append('\n').append(S.t("تنبيهات:\n", "Warnings:\n"));
            for (String w : r.warnings) {
                int k = w.indexOf(':');
                String key = k > 0 ? w.substring(0, k) : w, rest = k > 0 ? w.substring(k + 1) : "";
                if ("admin".equals(key) && "none".equals(rest))
                    sb.append("• ").append(S.t("لم تُوجد حدود إدارية في هذه المنطقة؛ تُركت حقول الناحية/القضاء/المحافظة فارغة.",
                            "No administrative boundaries found here; NAHIYA/QADAA/GOVERNORAT left empty.")).append('\n');
                else sb.append("• ").append(stepLabel(key)).append(' ').append(rest).append('\n');
            }
        }
        zoomToData();
        final boolean any = r.featureCount() > 0;
        message(S.t("اكتمل التحميل", "Download complete"), sb.toString(), any ? S.t("تصدير الآن", "Export now") : null,
                any ? new Runnable() {
                    public void run() {
                        exportDialog();
                    }
                } : null);
    }

    // ------------------------------------------------------------------ export / import

    void exportDialog() {
        if (DATA.isEmpty()) {
            toast(S.t("لا توجد بيانات؛ حمّل المعالم أولاً أو استورد ملف KML", "No data; download or import first"));
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("تصدير البيانات", "Export data"), 18, Theme.text, true));
        TextView hint = Ui.text(this, S.t("سيُحفظ الملف في: ", "Saved to: ") + saveWhere(), 12, Theme.sub, false);
        hint.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
        box.addView(hint);
        final Dialog d = card(box);
        box.addView(Ui.button(this, "Shapefile (ZIP)", true, new Runnable() {
            public void run() {
                d.dismiss();
                export("shp");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        box.addView(Ui.button(this, "KML (" + S.t("بيني كويست", "PineQuest") + ")", false, new Runnable() {
            public void run() {
                d.dismiss();
                export("kml");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        box.addView(Ui.button(this, "KMZ", false, new Runnable() {
            public void run() {
                d.dismiss();
                export("kmz");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        box.addView(Ui.button(this, "CSV (Excel)", false, new Runnable() {
            public void run() {
                d.dismiss();
                export("csv");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        d.show();
    }

    String saveWhere() {
        String f = prefs.folder();
        if (f == null) return "Downloads/PoiExporter";
        return Pages.folderName(f);
    }

    void export(final String kind) {
        if (DATA.isEmpty()) {
            toast(S.t("لا توجد بيانات", "No data"));
            return;
        }
        exportLayers(new ArrayList<>(DATA), kind, "poi");
    }

    void exportLayers(final List<LayerData> snap, final String kind, String prefix) {
        final CoordFmt.Fmt f = fmt();
        String safe = iq.gis.poiexporter.core.ShapeWriter.safeName(prefix);
        final String base = (safe.isEmpty() ? "poi" : safe) + "_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        final String name, mime;
        if (kind.equals("shp")) {
            name = base + "_shp.zip";
            mime = "application/zip";
        } else if (kind.equals("csv")) {
            name = base + ".csv";
            mime = "text/csv";
        } else if (kind.equals("kmz")) {
            name = base + ".kmz";
            mime = "application/vnd.google-earth.kmz";
        } else {
            name = base + ".kml";
            mime = "application/vnd.google-earth.kml+xml";
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("جارٍ التصدير…", "Exporting…"), 16, Theme.text, true));
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminateTintList(ColorStateList.valueOf(Theme.primary));
        box.addView(pb);
        final Dialog busy = card(box);
        busy.setCancelable(false);
        busy.show();
        new Thread(new Runnable() {
            public void run() {
                try {
                    final Storage.Saved sv = Storage.save(MainActivity.this, prefs, name, mime, new Storage.Writer() {
                        public void write(java.io.OutputStream os) throws java.io.IOException {
                            if (kind.equals("shp")) ShapeWriter.writeZip(snap, f, os);
                            else if (kind.equals("csv")) iq.gis.poiexporter.core.CsvWriter.write(snap, os);
                            else Kml.write(snap, "PoiExporter", f, kind.equals("kmz"), os);
                        }
                    });
                    runOnUiThread(new Runnable() {
                        public void run() {
                            busy.dismiss();
                            message(S.t("تم الحفظ ✔", "Saved ✔"), sv.where, S.t("مشاركة / فتح", "Share / open"),
                                    new Runnable() {
                                        public void run() {
                                            Storage.share(MainActivity.this, sv.uri, mime);
                                        }
                                    });
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            busy.dismiss();
                            message(S.t("فشل التصدير", "Export failed"), String.valueOf(t.getMessage()), null, null);
                        }
                    });
                }
            }
        }).start();
    }

    void pickImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    void pickFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_FOLDER);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        if (req == REQ_FOLDER) {
            try {
                getContentResolver().takePersistableUriPermission(u,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {
                // some providers do not offer persistable grants
            }
            prefs.folder(u.toString());
            showPage("settings");
        } else if (req == REQ_IMPORT) {
            importFrom(u);
        }
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        else if (Intent.ACTION_SEND.equals(i.getAction())) u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u != null) importFrom(u);
        setIntent(new Intent());
    }

    private String displayName(Uri u) {
        Cursor c = null;
        try {
            c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
            // fall through
        } finally {
            if (c != null) c.close();
        }
        String s = u.getLastPathSegment();
        return s == null ? "import.kml" : s;
    }

    void importFrom(final Uri u) {
        final String nm = displayName(u);
        toast(S.t("جارٍ استيراد ", "Importing ") + nm);
        new Thread(new Runnable() {
            public void run() {
                try {
                    InputStream in = getContentResolver().openInputStream(u);
                    if (in == null) throw new java.io.IOException("cannot open");
                    final List<LayerData> got = new ArrayList<>();
                    try {
                        for (LayerData l : Kml.read(in, nm)) {
                            if (l.features.isEmpty()) continue;
                            LayerData g = new LayerData(Library.newId(), l.label, l.geom);
                            g.features.addAll(l.features);
                            got.add(g);
                            Library.save(MainActivity.this, g);
                        }
                    } finally {
                        in.close();
                    }
                    runOnUiThread(new Runnable() {
                        public void run() {
                            LIB.addAll(got);
                            int n = 0;
                            for (LayerData l : got) n += l.features.size();
                            rebuild();
                            showMap();
                            if (!got.isEmpty()) zoomToLayer(got.get(0));
                            message(S.t("تم الاستيراد والحفظ", "Imported & saved"),
                                    n + S.t(" عنصر في ", " features in ") + got.size() + S.t(" مجموعة (في «المعالم المحفوظة») من ", " groups (in Saved landmarks) from ") + nm,
                                    null, null);
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            message(S.t("تعذّر الاستيراد", "Import failed"), String.valueOf(t.getMessage()), null, null);
                        }
                    });
                }
            }
        }).start();
    }

    void clearData() {
        DL = new ArrayList<>();
        rebuild();
    }

    // ------------------------------------------------------------------ status banners

    private LinearLayout pill() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setBackground(Ui.stroke(Theme.card, Theme.line, 22, this));
        l.setElevation(Ui.dp(this, 5));
        l.setPadding(Ui.dp(this, 14), Ui.dp(this, 2), Ui.dp(this, 2), Ui.dp(this, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.bottomMargin = Ui.dp(this, 6);
        l.setLayoutParams(lp);
        l.setVisibility(View.GONE);
        return l;
    }

    private TextView pillBtn(String glyph, int color, final Runnable r) {
        TextView t = Ui.text(this, glyph, 18, color, true);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                r.run();
            }
        });
        t.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        return t;
    }

    private void buildStatus(FrameLayout box) {
        statusStack = new LinearLayout(this);
        statusStack.setOrientation(LinearLayout.VERTICAL);
        statusStack.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        groupBanner = pill();
        groupBannerText = Ui.text(this, "", 13, Theme.text, true);
        groupBannerText.setSingleLine(true);
        groupBannerText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        groupBanner.addView(groupBannerText, new LinearLayout.LayoutParams(0, -2, 1f));
        groupBanner.addView(pillBtn("↶", Theme.sub, new Runnable() {
            public void run() {
                groupUndo();
            }
        }));
        groupBanner.addView(pillBtn("✔", Theme.ok, new Runnable() {
            public void run() {
                groupSave();
            }
        }));
        groupBanner.addView(pillBtn("✕", Theme.danger, new Runnable() {
            public void run() {
                groupCancel();
            }
        }));
        groupBanner.setMinimumWidth(Ui.dp(this, 230));
        statusStack.addView(groupBanner);

        guideBanner = pill();
        guideBannerText = Ui.text(this, "", 13, Theme.text, true);
        guideBannerText.setSingleLine(true);
        guideBannerText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        guideBanner.addView(guideBannerText, new LinearLayout.LayoutParams(0, -2, 1f));
        guideBanner.addView(pillBtn("⌖", Theme.accent, new Runnable() {
            public void run() {
                if (guide.isOn()) map.getController().animateTo(new GeoPoint(guide.lat(), guide.lon()));
            }
        }));
        guideBanner.addView(pillBtn("✕", Theme.danger, new Runnable() {
            public void run() {
                clearGuide();
            }
        }));
        guideBanner.setMinimumWidth(Ui.dp(this, 230));
        statusStack.addView(guideBanner);

        progressBanner = pill();
        LinearLayout pc = new LinearLayout(this);
        pc.setOrientation(LinearLayout.VERTICAL);
        progressText = Ui.text(this, "", 12.5f, Theme.text, true);
        progressText.setSingleLine(true);
        progressText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pc.addView(progressText);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setIndeterminateTintList(ColorStateList.valueOf(Theme.primary));
        progressBar.setProgressTintList(ColorStateList.valueOf(Theme.primary));
        pc.addView(progressBar, Ui.lp(-1, Ui.dp(this, 5), 0, this, 0, 5, 0, 0));
        progressBanner.addView(pc, new LinearLayout.LayoutParams(0, -2, 1f));
        progressBanner.addView(pillBtn("✕", Theme.danger, new Runnable() {
            public void run() {
                if (progressCancel != null) progressCancel.run();
            }
        }));
        progressBanner.setMinimumWidth(Ui.dp(this, 250));
        statusStack.addView(progressBanner);

        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        sp.topMargin = Ui.dp(this, 92);
        sp.leftMargin = Ui.dp(this, 8);
        sp.rightMargin = Ui.dp(this, 66);
        box.addView(statusStack, sp);
        updateGroupBanner();
        updateGuide();
    }

    void showProgress(String text, Runnable cancelAction) {
        progressCancel = cancelAction;
        progressText.setText(text);
        progressBar.setIndeterminate(true);
        progressBanner.setVisibility(View.VISIBLE);
        styleToggles();
    }

    void updateProgress(String text, int percent) {
        if (progressBanner == null) return;
        progressText.setText(text);
        if (percent >= 0) {
            progressBar.setIndeterminate(false);
            progressBar.setProgress(percent);
        }
    }

    void hideProgress() {
        progressCancel = null;
        if (progressBanner != null) progressBanner.setVisibility(View.GONE);
        styleToggles();
    }

    private void styleBar(TextView t, boolean on) {
        if (t == null) return;
        t.setTextColor(on ? 0xFF5CE0C6 : 0xFFFFFFFF);
        t.setBackground(on ? Ui.round(0x40FFFFFF, 12, this) : null);
    }

    void styleToggles() {
        styleBar(gpsBtn, tracking);
        styleBar(compassBtn, compassOn);
        styleBar(dlBtn, progressCancel != null);
        styleBar(flagBtn, DRAFT != null);
    }

    void refreshPage(String key) {
        if (key != null && key.equals(page)) showPage(key);
    }

    // ------------------------------------------------------------------ flag: landmark / landmark group

    private void flagMenu(View anchor) {
        if (DRAFT == null) {
            Ui.popupAbove(this, anchor, new String[]{"⚑", "🗂"},
                    new String[]{S.t("إضافة معلم", "Add landmark"), S.t("إنشاء مجموعة معالم", "Create landmark group")},
                    new Runnable[]{new Runnable() {
                        public void run() {
                            org.osmdroid.api.IGeoPoint g = map.getMapCenter();
                            addDialog(g.getLatitude(), g.getLongitude(), null, false);
                        }
                    }, new Runnable() {
                        public void run() {
                            startGroupDialog();
                        }
                    }});
        } else {
            Ui.popupAbove(this, anchor, new String[]{"⚑", "✔", "✕"},
                    new String[]{S.t("إضافة نقطة بتفاصيل", "Add point with details"),
                            S.t("حفظ المجموعة", "Save group"), S.t("إلغاء المجموعة", "Cancel group")},
                    new Runnable[]{new Runnable() {
                        public void run() {
                            org.osmdroid.api.IGeoPoint g = map.getMapCenter();
                            addDialog(g.getLatitude(), g.getLongitude(), null, true);
                        }
                    }, new Runnable() {
                        public void run() {
                            groupSave();
                        }
                    }, new Runnable() {
                        public void run() {
                            groupCancel();
                        }
                    }});
        }
    }

    void startGroupDialog() {
        if (DRAFT != null) {
            toast(S.t("هناك مجموعة قيد الإنشاء: اضغط ✔ لحفظها", "A group is being created: press ✔ to save it"));
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("إنشاء مجموعة معالم", "Create landmark group"), 18, Theme.text, true));
        TextView nt = Ui.text(this, S.t("بعد البدء، كل ضغطة على ⚑ تضيف نقطة في مركز الخريطة. اضغط ✔ للحفظ فتُحفظ المجموعة في مجلد مستقل عن بقية المعالم.",
                "After starting, every tap on ⚑ adds a point at the map centre. Press ✔ to save: the group is stored in its own folder."),
                12.5f, Theme.sub, false);
        nt.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 8));
        box.addView(nt);
        final android.widget.EditText name = Ui.field(this, S.t("اسم المجموعة", "Group name"), android.text.InputType.TYPE_CLASS_TEXT);
        name.setText(uniqueLabel(S.t("مجموعة ", "Group ") + (LIB.size() + 1)));
        box.addView(name, new LinearLayout.LayoutParams(-1, -2));
        box.addView(Ui.text(this, S.t("اللون", "Colour"), 13, Theme.sub, false), Ui.lp(-2, -2, 0, this, 2, 10, 0, 2));
        final int[] sel = {0};
        box.addView(marks.colorRow(sel));
        final Dialog d = card(box);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 12, 4, 0));
        r.addView(Ui.button(this, S.t("ابدأ", "Start"), true, new Runnable() {
            public void run() {
                String n = name.getText().toString().trim();
                if (n.isEmpty()) n = S.t("مجموعة ", "Group ") + (LIB.size() + 1);
                DRAFT = new LayerData("draft_" + System.currentTimeMillis(), n, Feature.POINT);
                DRAFT.color = sel[0];
                d.dismiss();
                rebuild();
                updateGroupBanner();
                styleToggles();
                toast(S.t("اضغط ⚑ لإضافة نقطة في مركز الخريطة، وعند الانتهاء اضغط ✔",
                        "Tap ⚑ to add a point at the map centre; press ✔ when done"));
            }
        }), Ui.lp(0, -2, 1f, this, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    private String uniqueLabel(String base) {
        String l = base;
        int k = 2;
        while (groupByLabel(l) != null) l = base + " (" + (k++) + ")";
        return l;
    }

    void groupTapAdd() {
        if (DRAFT == null) return;
        org.osmdroid.api.IGeoPoint g = map.getMapCenter();
        Feature f = Feature.point(g.getLatitude(), g.getLongitude());
        f.name = DRAFT.label + " " + (DRAFT.features.size() + 1);
        DRAFT.features.add(f);
        rebuild();
        updateGroupBanner();
        map.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
    }

    private void groupUndo() {
        if (DRAFT == null || DRAFT.features.isEmpty()) return;
        DRAFT.features.remove(DRAFT.features.size() - 1);
        rebuild();
        updateGroupBanner();
    }

    void groupSave() {
        if (DRAFT == null) return;
        if (DRAFT.features.isEmpty()) {
            toast(S.t("المجموعة فارغة: أضف نقطة واحدة على الأقل", "The group is empty: add at least one point"));
            return;
        }
        final LayerData g = new LayerData(Library.newId(), uniqueLabel(DRAFT.label), Feature.POINT);
        g.color = DRAFT.color;
        g.features.addAll(DRAFT.features);
        LIB.add(g);
        DRAFT = null;
        persist(g);
        rebuild();
        updateGroupBanner();
        styleToggles();
        toast(S.t("حُفظت المجموعة: ", "Group saved: ") + g.label + " (" + g.features.size() + ")");
        fillAdminAsync(g, new ArrayList<>(g.features));
        refreshPage("library");
    }

    void groupCancel() {
        if (DRAFT == null) return;
        if (DRAFT.features.isEmpty()) {
            DRAFT = null;
            rebuild();
            updateGroupBanner();
            styleToggles();
            return;
        }
        message(S.t("إلغاء المجموعة", "Cancel group"),
                S.t("سيتم تجاهل المجموعة «" + DRAFT.label + "» وجميع نقاطها (" + DRAFT.features.size() + ") دون حفظ.",
                        "Group \u201c" + DRAFT.label + "\u201d and its " + DRAFT.features.size() + " points will be discarded."),
                S.t("تجاهل", "Discard"), new Runnable() {
                    public void run() {
                        DRAFT = null;
                        rebuild();
                        updateGroupBanner();
                        styleToggles();
                    }
                });
    }

    void updateGroupBanner() {
        if (groupBanner == null) return;
        if (DRAFT == null) {
            groupBanner.setVisibility(View.GONE);
        } else {
            groupBanner.setVisibility(View.VISIBLE);
            groupBannerText.setText("🗂 " + DRAFT.label + "  •  " + DRAFT.features.size() + S.t(" نقطة", " pts"));
        }
        styleToggles();
    }

    /** Fills NAHIYA / QADAA / GOVERNORAT for new or moved points in the background. */
    void fillAdminAsync(final LayerData g, final Feature one) {
        List<Feature> l = new ArrayList<>();
        l.add(one);
        fillAdminAsync(g, l);
    }

    void fillAdminAsync(final LayerData g, final List<Feature> fs) {
        if (!prefs.flag("fillAdmin", true) || fs.isEmpty()) return;
        new Thread(new Runnable() {
            public void run() {
                try {
                    Pipeline.fillAdminFor(fs, adminLevels(), new Net());
                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (Library.isGroup(g)) persist(g);
                        }
                    });
                } catch (Exception ignored) {
                    // offline: admin fields stay empty
                }
            }
        }).start();
    }

    // ------------------------------------------------------------------ guidance point

    void setGuide(double lat, double lon, String label) {
        showMap();
        guideLabel = label;
        guide.set(lat, lon);
        guideBanner.setVisibility(View.VISIBLE);
        updateGuide();
        map.invalidate();
        toast(S.t("نقطة التوجيه: ", "Guide point: ") + label);
    }

    void clearGuide() {
        guide.clear();
        guideBanner.setVisibility(View.GONE);
        map.invalidate();
    }

    void updateGuide() {
        if (guide == null || guideBanner == null) return;
        if (!guide.isOn()) {
            guideBanner.setVisibility(View.GONE);
            return;
        }
        guideBanner.setVisibility(View.VISIBLE);
        org.osmdroid.api.IGeoPoint c = map.getMapCenter();
        double dist = Geo.haversine(c.getLatitude(), c.getLongitude(), guide.lat(), guide.lon());
        double p1 = Math.toRadians(c.getLatitude()), p2 = Math.toRadians(guide.lat());
        double dl = Math.toRadians(guide.lon() - c.getLongitude());
        double y = Math.sin(dl) * Math.cos(p2);
        double x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
        double brg = (Math.toDegrees(Math.atan2(y, x)) + 360) % 360;
        guideBannerText.setText("🧭 " + guideLabel + "  •  " + fmtLen(dist) + "  •  " + Math.round(brg) + "°");
    }

    // ------------------------------------------------------------------ GPS / compass / download toggles

    private void gpsTap() {
        if (tracking) stopGps(true);
        else {
            centerOnFix = true;
            locate();
        }
    }

    void stopGps(boolean say) {
        tracking = false;
        centerOnFix = false;
        areaOnFix = false;
        stopLocation();
        lastLoc = null;
        if (dot != null) dot.clear();
        updateCard();
        if (map != null) map.invalidate();
        styleToggles();
        if (say) toast(S.t("تم إيقاف تحديد الموقع", "Location turned off"));
    }

    private void gpsMenu() {
        Ui.popupAbove(this, gpsBtn, new String[]{"▶", "■"},
                new String[]{S.t("تشغيل الموقع", "Turn location on"), S.t("إيقاف الموقع", "Turn location off")},
                new Runnable[]{new Runnable() {
                    public void run() {
                        centerOnFix = true;
                        if (!tracking) locate();
                        else if (lastLoc != null) onFix(lastLoc);
                    }
                }, new Runnable() {
                    public void run() {
                        if (tracking) stopGps(true);
                    }
                }});
    }

    private void compassTap() {
        if (compassOn) stopCompass(true);
        else startCompassUser();
    }

    private void startCompassUser() {
        compassOn = true;
        compassFirst = true;
        startCompass();
        styleToggles();
        if (compassOn) toast(S.t("البوصلة تعمل: الخريطة تدور مع اتجاهك", "Compass on: the map follows your heading"));
    }

    private void startCompass() {
        if (sensorMgr == null) sensorMgr = (android.hardware.SensorManager) getSystemService(Context.SENSOR_SERVICE);
        android.hardware.Sensor rv = sensorMgr == null ? null
                : sensorMgr.getDefaultSensor(android.hardware.Sensor.TYPE_ROTATION_VECTOR);
        if (rv == null) {
            compassOn = false;
            styleToggles();
            toast(S.t("لا يوجد مستشعر بوصلة في هذا الجهاز", "No compass sensor on this device"));
            return;
        }
        if (sensorLis == null) {
            sensorLis = new android.hardware.SensorEventListener() {
                public void onSensorChanged(android.hardware.SensorEvent e) {
                    float[] v = e.values.length > 4 ? java.util.Arrays.copyOf(e.values, 4) : e.values;
                    android.hardware.SensorManager.getRotationMatrixFromVector(rotM, v);
                    android.hardware.SensorManager.getOrientation(rotM, oriV);
                    float az = (float) ((Math.toDegrees(oriV[0]) + 360.0) % 360.0);
                    if (compassFirst) {
                        compassSmooth = az;
                        compassApplied = -999f;
                        compassFirst = false;
                    } else {
                        float diff = ((az - compassSmooth + 540f) % 360f) - 180f;
                        compassSmooth = (compassSmooth + diff * 0.2f + 360f) % 360f;
                    }
                    float dd = ((compassSmooth - compassApplied + 540f) % 360f) - 180f;
                    if (Math.abs(dd) >= 1.0f && map != null) {
                        compassApplied = compassSmooth;
                        map.setMapOrientation(-compassSmooth);
                    }
                }

                public void onAccuracyChanged(android.hardware.Sensor sensor, int accuracy) {
                }
            };
        }
        sensorMgr.unregisterListener(sensorLis);
        sensorMgr.registerListener(sensorLis, rv, android.hardware.SensorManager.SENSOR_DELAY_UI);
    }

    private void pauseCompass() {
        if (sensorMgr != null && sensorLis != null) sensorMgr.unregisterListener(sensorLis);
    }

    void stopCompass(boolean say) {
        compassOn = false;
        pauseCompass();
        if (map != null) {
            map.setMapOrientation(0f);
            map.invalidate();
        }
        styleToggles();
        if (say) toast(S.t("تم إيقاف البوصلة", "Compass off"));
    }

    private void compassMenu() {
        Ui.popupAbove(this, compassBtn, new String[]{"▶", "■", "⬆"},
                new String[]{S.t("تشغيل البوصلة", "Turn compass on"), S.t("إيقاف البوصلة", "Turn compass off"),
                        S.t("توجيه الخريطة نحو الشمال", "Orient map to north")},
                new Runnable[]{new Runnable() {
                    public void run() {
                        if (!compassOn) startCompassUser();
                    }
                }, new Runnable() {
                    public void run() {
                        if (compassOn) stopCompass(true);
                    }
                }, new Runnable() {
                    public void run() {
                        map.setMapOrientation(0f);
                        map.invalidate();
                        toast(S.t("الخريطة موجّهة نحو الشمال", "Map oriented to north"));
                    }
                }});
    }

    private void downloadTap() {
        if (progressCancel != null) progressCancel.run();
        else download();
    }

    private void downloadMenu() {
        Ui.popupAbove(this, dlBtn, new String[]{"▶", "■"},
                new String[]{S.t("بدء التحميل", "Start download"), S.t("إيقاف التحميل", "Stop download")},
                new Runnable[]{new Runnable() {
                    public void run() {
                        if (progressCancel == null) download();
                        else toast(S.t("هناك عملية تحميل جارية", "A download is already running"));
                    }
                }, new Runnable() {
                    public void run() {
                        if (progressCancel != null) progressCancel.run();
                        else toast(S.t("لا يوجد تحميل جارٍ", "No download is running"));
                    }
                }});
    }

    // ------------------------------------------------------------------ online maps

    /** Selects the base map: an index of BaseMaps.ALL, or "c:id" for a map added by the user. */
    void setBase(String key, boolean save) {
        if (key != null && key.startsWith("c:")) {
            MapSources.Item it = MapSources.find(prefs, key.substring(2));
            if (it != null && !it.overlay) {
                map.setTileSource(MapSources.source(it));
                map.getOverlayManager().getTilesOverlay().setColorFilter(null);
                if (attrView != null) attrView.setText(it.name);
                if (save) prefs.put("basemap", key);
                map.invalidate();
                return;
            }
            key = "0";
        }
        int i = 0;
        try {
            i = Integer.parseInt(key == null ? "0" : key.trim());
        } catch (NumberFormatException ignored) {
            // default map
        }
        setBaseMap(Math.max(0, Math.min(BaseMaps.ALL.length - 1, i)), save);
    }

    /** Rebuilds the view-only overlay layers drawn above the base map. */
    void applyMapOverlays() {
        if (map == null) return;
        for (TilesOverlay o : customOv) {
            map.getOverlays().remove(o);
            o.onDetach(map);
        }
        customOv.clear();
        ovById.clear();
        int at = 0;
        for (MapSources.Item it : MapSources.load(prefs)) {
            if (!it.overlay || !it.visible) continue;
            MapTileProviderBasic prov = new MapTileProviderBasic(getApplicationContext(), MapSources.source(it));
            TilesOverlay to = new TilesOverlay(prov, this);
            to.setLoadingBackgroundColor(Color.TRANSPARENT);
            to.setLoadingLineColor(Color.TRANSPARENT);
            to.setColorFilter(MapSources.opacityFilter(it.opacity));
            map.getOverlays().add(at++, to);
            customOv.add(to);
            ovById.put(it.id, to);
        }
        map.invalidate();
    }

    void updateOverlayOpacity(String id, int percent) {
        TilesOverlay o = ovById.get(id);
        if (o != null) {
            o.setColorFilter(MapSources.opacityFilter(percent));
            map.invalidate();
        }
    }

    void tileDownloadDialog(final MapSources.Item it) {
        if (MapSources.bulkBlocked(it.url)) {
            message(S.t("التنزيل غير متاح", "Download not available"),
                    S.t("شروط استخدام هذا الخادم (OpenStreetMap / Google) تمنع التنزيل الجماعي للبلاطات. أضف مصدراً آخر يسمح بذلك (مثل Esri أو CARTO أو خادمك الخاص).",
                            "This server's terms (OpenStreetMap / Google) forbid bulk tile downloads. Add another source that allows it (e.g. Esri, CARTO or your own server)."),
                    null, null);
            return;
        }
        if (progressCancel != null) {
            toast(S.t("هناك عملية جارية، انتظر انتهاءها", "Another operation is running"));
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("تنزيل «", "Download \u201c") + it.name + S.t("» للعمل دون إنترنت", "\u201d for offline use"), 17, Theme.text, true));
        box.addView(Ui.text(this, S.t("المنطقة", "Area"), 13, Theme.sub, false), Ui.lp(-2, -2, 0, this, 0, 10, 0, 4));
        final int[] src = {0};
        final android.widget.EditText zmin = Ui.field(this, "min", android.text.InputType.TYPE_CLASS_NUMBER);
        final android.widget.EditText zmax = Ui.field(this, "max", android.text.InputType.TYPE_CLASS_NUMBER);
        final TextView est = Ui.text(this, "", 12.5f, Theme.sub, false);
        final Runnable recalc = new Runnable() {
            public void run() {
                try {
                    int z1 = Integer.parseInt(zmin.getText().toString().trim());
                    int z2 = Integer.parseInt(zmax.getText().toString().trim());
                    z1 = Math.max(it.minZ, Math.min(it.maxZ, z1));
                    z2 = Math.max(z1, Math.min(it.maxZ, z2));
                    long n = MapSources.countTiles(tileArea(src[0]), z1, z2);
                    est.setTextColor(n > MapSources.MAX_TILES ? Theme.danger : Theme.sub);
                    est.setText(S.t("عدد البلاطات: ", "Tiles: ") + n + S.t("  •  الحجم التقريبي: ", "  •  approx. size: ")
                            + MapSources.fmtBytes(n * 20L * 1024)
                            + (n > MapSources.MAX_TILES ? S.t("  — كثير جداً (الحد ", "  — too many (limit ") + MapSources.MAX_TILES + ")" : ""));
                } catch (Exception e) {
                    est.setText("");
                }
            }
        };
        box.addView(Ui.chips(this, new String[]{S.t("الشاشة الحالية", "Current screen"), S.t("المنطقة المحددة", "Selected area")}, 0,
                new Ui.OnPick() {
                    public void pick(int i) {
                        src[0] = i;
                        recalc.run();
                    }
                }), new LinearLayout.LayoutParams(-1, -2));
        box.addView(Ui.text(this, S.t("مستويات التقريب (من – إلى)", "Zoom levels (from – to)"), 13, Theme.sub, false),
                Ui.lp(-2, -2, 0, this, 0, 10, 0, 4));
        int z0 = Math.max(it.minZ, Math.min(it.maxZ, (int) Math.round(map.getZoomLevelDouble())));
        zmin.setText(String.valueOf(z0));
        zmax.setText(String.valueOf(Math.min(it.maxZ, z0 + 3)));
        zmin.setGravity(Gravity.CENTER);
        zmax.setGravity(Gravity.CENTER);
        LinearLayout zr = Ui.row(this);
        zr.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        zr.addView(zmin, Ui.lp(0, -2, 1f, this, 0, 0, 6, 0));
        zr.addView(zmax, Ui.lp(0, -2, 1f, this, 6, 0, 0, 0));
        box.addView(zr);
        android.text.TextWatcher tw = new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            public void afterTextChanged(android.text.Editable e) {
                recalc.run();
            }
        };
        zmin.addTextChangedListener(tw);
        zmax.addTextChangedListener(tw);
        est.setPadding(0, Ui.dp(this, 8), 0, 0);
        box.addView(est);
        recalc.run();
        final Dialog d = card(box);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 12, 4, 0));
        r.addView(Ui.button(this, S.t("⬇ ابدأ التنزيل", "⬇ Start"), true, new Runnable() {
            public void run() {
                int z1, z2;
                try {
                    z1 = Integer.parseInt(zmin.getText().toString().trim());
                    z2 = Integer.parseInt(zmax.getText().toString().trim());
                } catch (Exception e) {
                    toast(S.t("أدخل مستويات تقريب صحيحة", "Enter valid zoom levels"));
                    return;
                }
                z1 = Math.max(it.minZ, Math.min(it.maxZ, z1));
                z2 = Math.max(z1, Math.min(it.maxZ, z2));
                double[] bb = tileArea(src[0]);
                if (MapSources.countTiles(bb, z1, z2) > MapSources.MAX_TILES) {
                    toast(S.t("عدد البلاطات كبير جداً: قلّل المنطقة أو مستويات التقريب", "Too many tiles: reduce the area or zoom range"));
                    return;
                }
                d.dismiss();
                startTileDownload(it, bb, z1, z2);
            }
        }), Ui.lp(0, -2, 1f, this, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    /** {south, west, north, east} of the current screen (0) or the selected area (1). */
    private double[] tileArea(int which) {
        if (which == 1) {
            AreaSpec a = area();
            if (a.circle) return Geo.rectAround(a.clat, a.clon, a.radius * 2, a.radius * 2);
            return new double[]{a.south, a.west, a.north, a.east};
        }
        BoundingBox b = map.getProjection().getBoundingBox();
        return new double[]{b.getLatSouth(), b.getLonWest(), b.getLatNorth(), b.getLonEast()};
    }

    private void startTileDownload(final MapSources.Item it, double[] bb, int z1, int z2) {
        final MapSources.Job job = new MapSources.Job();
        showProgress("⬇ " + it.name, new Runnable() {
            public void run() {
                job.cancel = true;
                updateProgress(S.t("جارٍ الإلغاء…", "Cancelling…"), -1);
            }
        });
        MapSources.download(it, bb, z1, z2, job, new MapSources.Progress() {
            public void update(final int done, final int total, final int failed) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        updateProgress("⬇ " + it.name + "  " + done + " / " + total
                                + (failed > 0 ? "  (✖ " + failed + ")" : ""), total == 0 ? 0 : (int) (done * 100L / total));
                    }
                });
            }

            public void finished(final boolean cancelled, final int done, final int failed, final int total) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        hideProgress();
                        message(cancelled ? S.t("أُوقف التنزيل", "Download stopped") : S.t("اكتمل التنزيل", "Download complete"),
                                S.t("البلاطات المنزّلة: ", "Tiles downloaded: ") + (done - failed) + " / " + total
                                        + (failed > 0 ? "\n" + S.t("فشل: ", "Failed: ") + failed : "")
                                        + "\n\n" + S.t("تعمل الخريطة الآن في هذه المنطقة دون إنترنت.", "The map now works offline in this area."),
                                null, null);
                        refreshPage("maps");
                    }
                });
            }
        });
    }

    void clearTileCache() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    MapSources.writer().purgeCache();
                } catch (Throwable ignored) {
                    // nothing to purge
                }
                runOnUiThread(new Runnable() {
                    public void run() {
                        toast(S.t("تم مسح الخرائط المخزنة", "Cached maps cleared"));
                        refreshPage("maps");
                        if (map != null) map.invalidate();
                    }
                });
            }
        }).start();
    }

    // ------------------------------------------------------------------ reset

    private static void deleteTree(File f) {
        if (f == null) return;
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteTree(x);
        f.delete();
    }

    /** Wipes everything the app stores and returns it to its first-run state. */
    void resetApp() {
        try {
            stopGps(false);
        } catch (Exception ignored) {
            // continue wiping
        }
        try {
            stopCompass(false);
        } catch (Exception ignored) {
            // continue wiping
        }
        cancel = true;
        DATA = new ArrayList<>();
        LIB = new ArrayList<>();
        DL = new ArrayList<>();
        HIDDEN.clear();
        ACTIVE = null;
        DRAFT = null;
        libLoaded = false;
        RESTORE_PAGE = null;
        getSharedPreferences("settings", MODE_PRIVATE).edit().clear().commit();
        deleteTree(getFilesDir());
        deleteTree(getCacheDir());
        deleteTree(getExternalCacheDir());
        deleteTree(getExternalFilesDir(null));
        try {
            for (android.content.UriPermission up : getContentResolver().getPersistedUriPermissions()) {
                getContentResolver().releasePersistableUriPermission(up.getUri(),
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            }
        } catch (Exception ignored) {
            // no persisted folder grants
        }
        toast(S.t("تمت إعادة ضبط البرنامج", "The app has been reset"));
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null && am.clearApplicationUserData()) return; // the system closes the app
        } catch (Exception ignored) {
            // fall back to restarting
        }
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }
        finish();
    }

    // ------------------------------------------------------------------ dialogs & helpers

    Dialog card(View content) {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        box.setBackground(Ui.round(Theme.card, 22, this));
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 18), Ui.dp(this, 20), Ui.dp(this, 18));
        box.addView(content, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int sw = getResources().getDisplayMetrics().widthPixels;
            w.setLayout(Math.min(sw - Ui.dp(this, 32), Ui.dp(this, 420)), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        box.setScaleX(0.92f);
        box.setScaleY(0.92f);
        box.setAlpha(0f);
        d.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            public void onShow(android.content.DialogInterface di) {
                box.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start();
            }
        });
        return d;
    }

    void message(String title, String msg, String extraLabel, final Runnable extra) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, title, 18, Theme.text, true));
        ScrollView sv = new ScrollView(this);
        TextView t = Ui.text(this, msg, 14, Theme.sub, false);
        t.setTextIsSelectable(true);
        t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        sv.addView(t);
        box.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        final Dialog d = card(box);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إغلاق", "Close"), extra == null, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 6, 4, 0));
        if (extra != null) {
            r.addView(Ui.button(this, extraLabel, true, new Runnable() {
                public void run() {
                    d.dismiss();
                    extra.run();
                }
            }), Ui.lp(0, -2, 1f, this, 4, 6, 0, 0));
        }
        box.addView(r);
        d.show();
    }

    void showFeature(final Feature f, final LayerData layer) {
        marks.featureSheet(f, layer);
    }

    void about() {
        message(S.t("حول التطبيق", "About"),
                S.t("مصدّر المعالم v2.0\nيجلب المعالم والطرق والأنهار والبحيرات والسدود والحدود الإدارية من OpenStreetMap ويصدّرها إلى Shapefile / KML / KMZ.\n\nالبيانات © مساهمو OpenStreetMap (ترخيص ODbL).\nحدود الناحية/القضاء/المحافظة تُحدَّد من مستويات admin_level (الافتراضي 4/5/6) ويمكن تعديلها من «الطبقات والتحميل».",
                        "POI Exporter v2.0\nDownloads landmarks, roads, rivers, lakes, dams and administrative boundaries from OpenStreetMap and exports Shapefile / KML / KMZ.\n\nData © OpenStreetMap contributors (ODbL).\nNahiya/qadaa/governorate come from admin_level (default 4/5/6), editable in Layers & download."),
                null, null);
    }

    void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("coords", text));
        toast(S.t("تم النسخ", "Copied"));
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
