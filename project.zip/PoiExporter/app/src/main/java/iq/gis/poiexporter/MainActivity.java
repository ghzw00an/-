package iq.gis.poiexporter;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.IConfigurationProvider;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.TilesOverlay;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Catalog;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.Kml;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.Pipeline;
import iq.gis.poiexporter.core.ShapeWriter;

public class MainActivity extends Activity {
    static final int REQ_IMPORT = 11, REQ_FOLDER = 12;
    static List<LayerData> DATA = new ArrayList<>();
    static String RESTORE_PAGE;

    Prefs prefs;
    Pages pages;
    MapView map;
    FeatureOverlay fo;
    AreaOverlay ao;
    private FrameLayout root, pageHolder;
    private LinearLayout drawer;
    private View scrim;
    private TextView title, summary;
    private boolean drawerOpen;
    private String page;
    private float edgeX = -1;
    private volatile boolean cancel;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        S.ar = prefs.arabic();
        int th = prefs.theme();
        boolean night = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        Theme.apply(th == 2 || (th == 0 && night));
        IConfigurationProvider cfg = org.osmdroid.config.Configuration.getInstance();
        cfg.setUserAgentValue("PoiExporter/2.0 (" + getPackageName() + ")");
        cfg.setOsmdroidBasePath(new File(getCacheDir(), "osmdroid"));
        cfg.setOsmdroidTileCache(new File(getCacheDir(), "osmdroid/tiles"));
        pages = new Pages(this);
        buildUi();
        String r = RESTORE_PAGE;
        RESTORE_PAGE = null;
        if (r != null) showPage(r);
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleIntent(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (map != null) map.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (map != null) map.onPause();
    }

    @Override
    public void onBackPressed() {
        if (drawerOpen) closeDrawer();
        else if (page != null) showMap();
        else super.onBackPressed();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        float edge = Ui.dp(this, 20);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                edgeX = e.getX() < edge && !drawerOpen ? e.getX() : -1;
                break;
            case MotionEvent.ACTION_MOVE:
                if (edgeX >= 0 && e.getX() - edgeX > Ui.dp(this, 48)) {
                    edgeX = -1;
                    openDrawer();
                }
                break;
            default:
                edgeX = -1;
                break;
        }
        return super.dispatchTouchEvent(e);
    }

    // ------------------------------------------------------------------ UI shell

    private void buildUi() {
        root = new FrameLayout(this);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setBackgroundColor(Theme.bg);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(Theme.card);
        top.setElevation(Ui.dp(this, 4));
        top.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4));

        TextView menu = Ui.text(this, "☰", 26, Theme.text, true);
        menu.setGravity(Gravity.CENTER);
        menu.setClickable(true);
        menu.setContentDescription("menu");
        Ui.pressable(menu);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDrawer();
            }
        });
        top.addView(menu, new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 48)));

        title = Ui.text(this, S.t("مصدّر المعالم", "POI Exporter"), 18, Theme.text, true);
        title.setSingleLine(true);
        title.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView conv = Ui.text(this, "⇄", 24, Theme.primary, true);
        conv.setGravity(Gravity.CENTER);
        conv.setClickable(true);
        Ui.pressable(conv);
        conv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage("converter");
            }
        });
        top.addView(conv, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        content.addView(top, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout body = new FrameLayout(this);
        body.addView(buildMapBox(), new FrameLayout.LayoutParams(-1, -1));
        pageHolder = new FrameLayout(this);
        pageHolder.setBackgroundColor(Theme.bg);
        pageHolder.setClickable(true);
        pageHolder.setVisibility(View.GONE);
        body.addView(pageHolder, new FrameLayout.LayoutParams(-1, -1));
        content.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        scrim = new View(this);
        scrim.setBackgroundColor(0x88000000);
        scrim.setAlpha(0f);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
            }
        });
        root.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        drawer = buildDrawer();
        FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(Ui.dp(this, 300), -1, Gravity.LEFT);
        drawer.setTranslationX(-Ui.dp(this, 310));
        root.addView(drawer, dl);

        setContentView(root);
        getWindow().setStatusBarColor(Theme.card);
        getWindow().setNavigationBarColor(Theme.bg);
        int flags = 0;
        if (!Theme.dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (!Theme.dark && android.os.Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
        updateSummary();
    }

    private View buildMapBox() {
        FrameLayout box = new FrameLayout(this);
        float density = getResources().getDisplayMetrics().density;
        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.setMinZoomLevel(3.0);
        map.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER);
        if (Theme.dark) map.getOverlayManager().getTilesOverlay().setColorFilter(TilesOverlay.INVERT_COLORS);
        fo = new FeatureOverlay();
        fo.setData(DATA, density);
        fo.setTap(new FeatureOverlay.Tap() {
            @Override
            public void onFeature(Feature f, String layer) {
                showFeature(f, layer);
            }
        });
        ao = new AreaOverlay(density);
        ao.onMoved(new AreaOverlay.Moved() {
            @Override
            public void to(double lat, double lon) {
                setCenter(lat, lon);
            }
        });
        map.getOverlays().add(fo);
        map.getOverlays().add(ao);
        double[] c = prefs.center();
        map.getController().setZoom(13.0);
        map.getController().setCenter(new GeoPoint(c[0], c[1]));
        box.addView(map, new FrameLayout.LayoutParams(-1, -1));

        // attribution
        TextView attr = Ui.text(this, "© OpenStreetMap", 10, Color.parseColor("#333333"), false);
        attr.setBackgroundColor(0xAAFFFFFF);
        attr.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
        FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        ap.bottomMargin = Ui.dp(this, 128);
        box.addView(attr, ap);

        // floating tools on the right
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.VERTICAL);
        tools.addView(roundBtn("+", new Runnable() {
            public void run() {
                map.getController().zoomIn();
            }
        }));
        tools.addView(roundBtn("−", new Runnable() {
            public void run() {
                map.getController().zoomOut();
            }
        }));
        tools.addView(roundBtn("⌖", new Runnable() {
            public void run() {
                org.osmdroid.api.IGeoPoint g = map.getMapCenter();
                setCenter(g.getLatitude(), g.getLongitude());
                toast(S.t("تم وضع مركز المنطقة في مركز الخريطة", "Area centre set to map centre"));
            }
        }));
        tools.addView(roundBtn("⛶", new Runnable() {
            public void run() {
                zoomToArea();
            }
        }));
        tools.addView(roundBtn("▣", new Runnable() {
            public void run() {
                zoomToData();
            }
        }));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT | Gravity.TOP);
        tp.topMargin = Ui.dp(this, 12);
        tp.rightMargin = Ui.dp(this, 10);
        box.addView(tools, tp);

        // bottom bar
        LinearLayout bar = Ui.card(this);
        bar.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        summary = Ui.text(this, "", 13, Theme.text, false);
        bar.addView(summary);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("⬇ تحميل المعالم", "⬇ Download"), true, new Runnable() {
            public void run() {
                download();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 8, 4, 0));
        r.addView(Ui.button(this, S.t("⤴ تصدير", "⤴ Export"), false, new Runnable() {
            public void run() {
                exportDialog();
            }
        }), Ui.lp(0, -2, 1f, this, 4, 8, 0, 0));
        bar.addView(r);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bp.setMargins(Ui.dp(this, 10), 0, Ui.dp(this, 10), Ui.dp(this, 8));
        box.addView(bar, bp);

        ao.set(area());
        return box;
    }

    private View roundBtn(String label, final Runnable r) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(Theme.text);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.stroke(Theme.card, Theme.line, 24, this));
        t.setElevation(Ui.dp(this, 3));
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46));
        lp.bottomMargin = Ui.dp(this, 8);
        t.setLayoutParams(lp);
        return t;
    }

    private LinearLayout buildDrawer() {
        LinearLayout d = new LinearLayout(this);
        d.setOrientation(LinearLayout.VERTICAL);
        d.setBackgroundColor(Theme.card);
        d.setElevation(Ui.dp(this, 16));
        d.setClickable(true);
        d.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setBackgroundColor(Theme.primary);
        head.setPadding(Ui.dp(this, 18), Ui.dp(this, 36), Ui.dp(this, 18), Ui.dp(this, 18));
        head.addView(Ui.text(this, "🌍", 34, Theme.onPrimary, false));
        head.addView(Ui.text(this, S.t("مصدّر المعالم", "POI Exporter"), 20, Theme.onPrimary, true));
        head.addView(Ui.text(this, S.t("OpenStreetMap • Shapefile • KML", "OpenStreetMap • Shapefile • KML"), 12,
                Theme.onPrimary, false));
        d.addView(head, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        list.addView(item("🗺", S.t("الخريطة", "Map"), new Runnable() {
            public void run() {
                showMap();
            }
        }));
        list.addView(item("▭", S.t("المنطقة المحددة (يدوي)", "Selected area (manual)"), new Runnable() {
            public void run() {
                showPage("area");
            }
        }));
        list.addView(item("☰", S.t("الطبقات والتحميل", "Layers & download"), new Runnable() {
            public void run() {
                showPage("layers");
            }
        }));
        list.addView(item("⇄", S.t("محول الإحداثيات", "Coordinate converter"), new Runnable() {
            public void run() {
                showPage("converter");
            }
        }));
        list.addView(item("⇅", S.t("استيراد / تصدير (KML • بيني كويست)", "Import / export (KML • PineQuest)"),
                new Runnable() {
                    public void run() {
                        showPage("kml");
                    }
                }));
        list.addView(item("⚙", S.t("الإعدادات", "Settings"), new Runnable() {
            public void run() {
                showPage("settings");
            }
        }));
        list.addView(item("ⓘ", S.t("حول التطبيق", "About"), new Runnable() {
            public void run() {
                about();
            }
        }));
        sv.addView(list);
        d.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return d;
    }

    private View item(String icon, String label, final Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        row.setClickable(true);
        row.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x333DB8A5), null,
                Ui.round(Color.WHITE, 12, this)));
        TextView i = Ui.text(this, icon, 20, Theme.primary, true);
        i.setGravity(Gravity.CENTER);
        row.addView(i, new LinearLayout.LayoutParams(Ui.dp(this, 34), -2));
        TextView t = Ui.text(this, label, 15, Theme.text, false);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.setMargins(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        row.addView(t, tl);
        Ui.pressable(row);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                r.run();
            }
        });
        return row;
    }

    void openDrawer() {
        if (drawerOpen) return;
        drawerOpen = true;
        scrim.setVisibility(View.VISIBLE);
        scrim.animate().alpha(1f).setDuration(220).start();
        drawer.animate().translationX(0).setDuration(240).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
    }

    void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        scrim.animate().alpha(0f).setDuration(200).withEndAction(new Runnable() {
            public void run() {
                if (!drawerOpen) scrim.setVisibility(View.GONE);
            }
        }).start();
        drawer.animate().translationX(-Ui.dp(this, 310)).setDuration(220).start();
    }

    void showMap() {
        page = null;
        pageHolder.setVisibility(View.GONE);
        pageHolder.removeAllViews();
        title.setText(S.t("مصدّر المعالم", "POI Exporter"));
        updateSummary();
        map.invalidate();
    }

    void showPage(String key) {
        View v;
        String t;
        switch (key) {
            case "settings":
                v = pages.settings();
                t = S.t("الإعدادات", "Settings");
                break;
            case "area":
                v = pages.area();
                t = S.t("المنطقة المحددة", "Selected area");
                break;
            case "layers":
                v = pages.layers();
                t = S.t("الطبقات والتحميل", "Layers & download");
                break;
            case "kml":
                v = pages.kml();
                t = S.t("استيراد / تصدير KML", "Import / export KML");
                break;
            case "converter":
                v = pages.converter();
                t = S.t("محول الإحداثيات", "Coordinate converter");
                break;
            default:
                showMap();
                return;
        }
        ScrollView sv = new ScrollView(this);
        sv.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        sv.setFillViewport(false);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 40));
        wrap.addView(v, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(wrap, new ViewGroup.LayoutParams(-1, -2));
        pageHolder.removeAllViews();
        pageHolder.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        pageHolder.setAlpha(0f);
        pageHolder.setVisibility(View.VISIBLE);
        pageHolder.animate().alpha(1f).setDuration(180).start();
        title.setText(t);
        page = key;
        closeDrawer();
    }

    // ------------------------------------------------------------------ area

    CoordFmt.Fmt fmt() {
        return CoordFmt.Fmt.values()[Math.max(0, Math.min(3, prefs.fmt()))];
    }

    AreaSpec area() {
        double[] c = prefs.center();
        double w = prefs.width(), h = prefs.height();
        switch (prefs.shape()) {
            case 1:
                return AreaSpec.centered(c[0], c[1], w, w);
            case 2:
                return AreaSpec.circle(c[0], c[1], w);
            default:
                return AreaSpec.centered(c[0], c[1], w, h);
        }
    }

    void setCenter(double lat, double lon) {
        lat = Math.max(-84, Math.min(84, lat));
        lon = ((lon + 540) % 360) - 180;
        prefs.center(lat, lon);
        applyArea(false);
    }

    void applyArea(boolean zoom) {
        ao.set(area());
        map.invalidate();
        updateSummary();
        pages.onAreaChanged();
        if (zoom) zoomToArea();
    }

    void zoomToArea() {
        AreaSpec a = area();
        double s = a.south, n = a.north, w = a.west, e = a.east;
        if (a.circle) {
            double[] r = Geo.rectAround(a.clat, a.clon, a.radius * 2, a.radius * 2);
            s = r[0];
            w = r[1];
            n = r[2];
            e = r[3];
        }
        final BoundingBox bb = new BoundingBox(n, e, s, w);
        map.post(new Runnable() {
            public void run() {
                map.zoomToBoundingBox(bb, true, Ui.dp(MainActivity.this, 40));
            }
        });
    }

    void zoomToData() {
        double[] b = fo.bounds();
        if (b == null) {
            toast(S.t("لا توجد بيانات محمّلة بعد", "No data loaded yet"));
            return;
        }
        double padLat = Math.max(0.0005, (b[3] - b[1]) * 0.05), padLon = Math.max(0.0005, (b[2] - b[0]) * 0.05);
        final BoundingBox bb = new BoundingBox(Math.min(85, b[3] + padLat), b[2] + padLon, Math.max(-85, b[1] - padLat), b[0] - padLon);
        map.post(new Runnable() {
            public void run() {
                map.zoomToBoundingBox(bb, true, Ui.dp(MainActivity.this, 30));
            }
        });
    }

    void updateSummary() {
        if (summary == null) return;
        AreaSpec a = area();
        String dim = a.circle
                ? S.t("دائرة نصف قطرها ", "Circle, radius ") + fmtLen(a.radius)
                : fmtLen(a.widthM()) + " × " + fmtLen(a.heightM());
        int n = 0;
        for (LayerData l : DATA) n += l.features.size();
        summary.setText(S.t("المنطقة: ", "Area: ") + dim + String.format(Locale.US, " (%.2f km²)", a.areaKm2())
                + "\n" + S.t("المحمّل: ", "Loaded: ") + n + S.t(" عنصر في ", " features in ") + DATA.size()
                + S.t(" طبقة • طويلاً على الخريطة لنقل المنطقة", " layers • long-press the map to move the area"));
    }

    static String fmtLen(double m) {
        return m >= 1000 ? String.format(Locale.US, "%.2f km", m / 1000) : String.format(Locale.US, "%.0f m", m);
    }

    // ------------------------------------------------------------------ selection state

    Set<String> csv(String key, String def) {
        Set<String> s = new LinkedHashSet<>();
        String v = prefs.get(key, def);
        if (v != null) for (String p : v.split(",")) if (!p.trim().isEmpty()) s.add(p.trim());
        return s;
    }

    void saveCsv(String key, Set<String> s) {
        StringBuilder b = new StringBuilder();
        for (String x : s) b.append(b.length() > 0 ? "," : "").append(x);
        prefs.put(key, b.toString());
    }

    String allPoi() {
        StringBuilder b = new StringBuilder();
        for (Catalog.PoiCat c : Catalog.POI) b.append(b.length() > 0 ? "," : "").append(c.id);
        return b.toString();
    }

    // ------------------------------------------------------------------ download

    private String stepLabel(String key) {
        if ("admin".equals(key)) return S.t("جلب الحدود الإدارية…", "Fetching administrative boundaries…");
        if ("poi".equals(key)) return S.t("جلب المعالم…", "Fetching landmarks…");
        Catalog.LayerDef d = Catalog.layer(key);
        return S.t("جلب: ", "Fetching: ") + (d != null ? d.label(S.ar) : key);
    }

    void download() {
        final AreaSpec a = area();
        if (a.areaKm2() > 5000) {
            message(S.t("المنطقة كبيرة جداً", "Area too large"),
                    S.t("المساحة تتجاوز 5000 كم². صغّر المنطقة (يمكنك تعديل الطول والعرض يدوياً).",
                            "The area exceeds 5000 km². Please reduce it (width/height can be edited manually)."),
                    null, null);
            return;
        }
        final Pipeline.Params p = new Pipeline.Params();
        p.area = a;
        p.poiCats.addAll(csv("poi", allPoi()));
        p.layerIds.addAll(csv("layers", ""));
        p.layerIds.addAll(csv("adm", ""));
        p.fillAdmin = prefs.flag("fillAdmin", true);
        p.includeUnnamed = prefs.flag("unnamed", false);
        p.custom = prefs.get("custom", "");
        p.arabic = S.ar;
        int[] lv = {4, 5, 6};
        for (int i = 0; i < 3; i++) {
            try {
                lv[i] = Integer.parseInt(prefs.get("lv" + (i + 4), String.valueOf(i + 4)).trim());
            } catch (NumberFormatException ignored) {
                // keep default
            }
        }
        p.adminLevels = lv;
        if (p.poiCats.isEmpty() && p.layerIds.isEmpty() && p.custom.trim().isEmpty()) {
            toast(S.t("اختر طبقة واحدة على الأقل من «الطبقات والتحميل»", "Select at least one layer in Layers & download"));
            showPage("layers");
            return;
        }
        cancel = false;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("جارٍ التحميل", "Downloading"), 18, Theme.text, true));
        final TextView msg = Ui.text(this, S.t("جارٍ الاتصال…", "Connecting…"), 14, Theme.sub, false);
        msg.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        box.addView(msg);
        final ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        pb.setIndeterminate(true);
        pb.setIndeterminateTintList(ColorStateList.valueOf(Theme.primary));
        pb.setProgressTintList(ColorStateList.valueOf(Theme.primary));
        box.addView(pb, new LinearLayout.LayoutParams(-1, Ui.dp(this, 8)));
        final Dialog dlg = card(box);
        box.addView(Ui.button(this, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                cancel = true;
                msg.setText(S.t("جارٍ الإلغاء…", "Cancelling…"));
            }
        }), Ui.lp(-1, -2, 0, this, 0, 14, 0, 0));
        dlg.setCancelable(false);
        dlg.show();
        new Thread(new Runnable() {
            public void run() {
                Pipeline.Result res;
                try {
                    res = Pipeline.run(p, new Net(), new Pipeline.Progress() {
                        public void update(final String m, final int step, final int steps) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    msg.setText(stepLabel(m) + "  (" + step + "/" + steps + ")");
                                    pb.setIndeterminate(false);
                                    pb.setProgress(Math.max(5, (step - 1) * 100 / Math.max(1, steps)));
                                }
                            });
                        }

                        public boolean cancelled() {
                            return cancel;
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            dlg.dismiss();
                            message(S.t("فشل التحميل", "Download failed"), String.valueOf(t.getMessage()), null, null);
                        }
                    });
                    return;
                }
                final Pipeline.Result r = res;
                runOnUiThread(new Runnable() {
                    public void run() {
                        dlg.dismiss();
                        onDownloaded(r);
                    }
                });
            }
        }).start();
    }

    private void onDownloaded(Pipeline.Result r) {
        if (r.cancelled) {
            toast(S.t("أُلغي التحميل", "Download cancelled"));
            return;
        }
        DATA = new ArrayList<>(r.layers);
        fo.setData(DATA, getResources().getDisplayMetrics().density);
        map.invalidate();
        updateSummary();
        StringBuilder sb = new StringBuilder();
        sb.append(S.t("تم تحميل ", "Loaded ")).append(r.featureCount()).append(S.t(" عنصر:\n", " features:\n"));
        for (LayerData l : r.layers) sb.append("• ").append(l.label).append(": ").append(l.features.size()).append('\n');
        if (!r.warnings.isEmpty()) {
            sb.append('\n').append(S.t("تنبيهات:\n", "Warnings:\n"));
            for (String w : r.warnings) {
                int k = w.indexOf(':');
                String key = k > 0 ? w.substring(0, k) : w, rest = k > 0 ? w.substring(k + 1) : "";
                if ("admin".equals(key) && "none".equals(rest))
                    sb.append("• ").append(S.t("لم تُوجد حدود إدارية في هذه المنطقة؛ تُركت حقول الناحية/القضاء/المحافظة فارغة.",
                            "No administrative boundaries found here; NAHIYA/QADAA/GOVERNORAT left empty.")).append('\n');
                else sb.append("• ").append(stepLabel(key)).append(' ').append(rest).append('\n');
            }
        }
        zoomToData();
        final boolean any = r.featureCount() > 0;
        message(S.t("اكتمل التحميل", "Download complete"), sb.toString(), any ? S.t("تصدير الآن", "Export now") : null,
                any ? new Runnable() {
                    public void run() {
                        exportDialog();
                    }
                } : null);
    }

    // ------------------------------------------------------------------ export / import

    void exportDialog() {
        if (DATA.isEmpty()) {
            toast(S.t("لا توجد بيانات؛ حمّل المعالم أولاً أو استورد ملف KML", "No data; download or import first"));
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("تصدير البيانات", "Export data"), 18, Theme.text, true));
        TextView hint = Ui.text(this, S.t("سيُحفظ الملف في: ", "Saved to: ") + saveWhere(), 12, Theme.sub, false);
        hint.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
        box.addView(hint);
        final Dialog d = card(box);
        box.addView(Ui.button(this, "Shapefile (ZIP)", true, new Runnable() {
            public void run() {
                d.dismiss();
                export("shp");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        box.addView(Ui.button(this, "KML (" + S.t("بيني كويست", "PineQuest") + ")", false, new Runnable() {
            public void run() {
                d.dismiss();
                export("kml");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        box.addView(Ui.button(this, "KMZ", false, new Runnable() {
            public void run() {
                d.dismiss();
                export("kmz");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        d.show();
    }

    String saveWhere() {
        String f = prefs.folder();
        if (f == null) return "Downloads/PoiExporter";
        return Pages.folderName(f);
    }

    void export(final String kind) {
        if (DATA.isEmpty()) {
            toast(S.t("لا توجد بيانات", "No data"));
            return;
        }
        final List<LayerData> snap = new ArrayList<>(DATA);
        final CoordFmt.Fmt f = fmt();
        final String base = "poi_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        final String name, mime;
        if (kind.equals("shp")) {
            name = base + "_shp.zip";
            mime = "application/zip";
        } else if (kind.equals("kmz")) {
            name = base + ".kmz";
            mime = "application/vnd.google-earth.kmz";
        } else {
            name = base + ".kml";
            mime = "application/vnd.google-earth.kml+xml";
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("جارٍ التصدير…", "Exporting…"), 16, Theme.text, true));
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminateTintList(ColorStateList.valueOf(Theme.primary));
        box.addView(pb);
        final Dialog busy = card(box);
        busy.setCancelable(false);
        busy.show();
        new Thread(new Runnable() {
            public void run() {
                try {
                    final Storage.Saved sv = Storage.save(MainActivity.this, prefs, name, mime, new Storage.Writer() {
                        public void write(java.io.OutputStream os) throws java.io.IOException {
                            if (kind.equals("shp")) ShapeWriter.writeZip(snap, f, os);
                            else Kml.write(snap, "PoiExporter", f, kind.equals("kmz"), os);
                        }
                    });
                    runOnUiThread(new Runnable() {
                        public void run() {
                            busy.dismiss();
                            message(S.t("تم الحفظ ✔", "Saved ✔"), sv.where, S.t("مشاركة / فتح", "Share / open"),
                                    new Runnable() {
                                        public void run() {
                                            Storage.share(MainActivity.this, sv.uri, mime);
                                        }
                                    });
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            busy.dismiss();
                            message(S.t("فشل التصدير", "Export failed"), String.valueOf(t.getMessage()), null, null);
                        }
                    });
                }
            }
        }).start();
    }

    void pickImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    void pickFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_FOLDER);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        if (req == REQ_FOLDER) {
            try {
                getContentResolver().takePersistableUriPermission(u,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {
                // some providers do not offer persistable grants
            }
            prefs.folder(u.toString());
            showPage("settings");
        } else if (req == REQ_IMPORT) {
            importFrom(u);
        }
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        else if (Intent.ACTION_SEND.equals(i.getAction())) u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u != null) importFrom(u);
        setIntent(new Intent());
    }

    private String displayName(Uri u) {
        Cursor c = null;
        try {
            c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
            // fall through
        } finally {
            if (c != null) c.close();
        }
        String s = u.getLastPathSegment();
        return s == null ? "import.kml" : s;
    }

    void importFrom(final Uri u) {
        final String nm = displayName(u);
        toast(S.t("جارٍ استيراد ", "Importing ") + nm);
        new Thread(new Runnable() {
            public void run() {
                try {
                    InputStream in = getContentResolver().openInputStream(u);
                    if (in == null) throw new java.io.IOException("cannot open");
                    final List<LayerData> got;
                    try {
                        got = Kml.read(in, nm);
                    } finally {
                        in.close();
                    }
                    runOnUiThread(new Runnable() {
                        public void run() {
                            List<LayerData> all = new ArrayList<>(DATA);
                            all.addAll(got);
                            DATA = all;
                            fo.setData(DATA, getResources().getDisplayMetrics().density);
                            int n = 0;
                            for (LayerData l : got) n += l.features.size();
                            showMap();
                            zoomToData();
                            message(S.t("تم الاستيراد", "Imported"),
                                    n + S.t(" عنصر في ", " features in ") + got.size() + S.t(" طبقة من ", " layers from ") + nm,
                                    null, null);
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            message(S.t("تعذّر الاستيراد", "Import failed"), String.valueOf(t.getMessage()), null, null);
                        }
                    });
                }
            }
        }).start();
    }

    void clearData() {
        DATA = new ArrayList<>();
        fo.setData(DATA, getResources().getDisplayMetrics().density);
        map.invalidate();
        updateSummary();
    }

    // ------------------------------------------------------------------ dialogs & helpers

    Dialog card(View content) {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        box.setBackground(Ui.round(Theme.card, 22, this));
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 18), Ui.dp(this, 20), Ui.dp(this, 18));
        box.addView(content, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int sw = getResources().getDisplayMetrics().widthPixels;
            w.setLayout(Math.min(sw - Ui.dp(this, 32), Ui.dp(this, 420)), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        box.setScaleX(0.92f);
        box.setScaleY(0.92f);
        box.setAlpha(0f);
        d.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            public void onShow(android.content.DialogInterface di) {
                box.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start();
            }
        });
        return d;
    }

    void message(String title, String msg, String extraLabel, final Runnable extra) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, title, 18, Theme.text, true));
        ScrollView sv = new ScrollView(this);
        TextView t = Ui.text(this, msg, 14, Theme.sub, false);
        t.setTextIsSelectable(true);
        t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        sv.addView(t);
        box.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        final Dialog d = card(box);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إغلاق", "Close"), extra == null, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 6, 4, 0));
        if (extra != null) {
            r.addView(Ui.button(this, extraLabel, true, new Runnable() {
                public void run() {
                    d.dismiss();
                    extra.run();
                }
            }), Ui.lp(0, -2, 1f, this, 4, 6, 0, 0));
        }
        box.addView(r);
        d.show();
    }

    void showFeature(final Feature f, String layer) {
        StringBuilder sb = new StringBuilder();
        sb.append(S.t("الطبقة: ", "Layer: ")).append(layer).append('\n');
        sb.append("NAME: ").append(f.name).append('\n');
        sb.append("TYPE: ").append(f.type).append('\n');
        sb.append("CATEGORY: ").append(f.category).append('\n');
        sb.append("NAHIYA: ").append(f.nahiya).append('\n');
        sb.append("QADAA: ").append(f.qadaa).append('\n');
        sb.append("GOVERNORAT: ").append(f.governorate).append('\n');
        final String c = CoordFmt.format(fmt(), f.lat, f.lon);
        sb.append(S.t("الإحداثيات: ", "Coordinates: ")).append(c);
        message(f.name.isEmpty() ? S.t("(بدون اسم)", "(unnamed)") : f.name, sb.toString(),
                S.t("نسخ الإحداثيات", "Copy coordinates"), new Runnable() {
                    public void run() {
                        copy(c);
                    }
                });
    }

    void about() {
        message(S.t("حول التطبيق", "About"),
                S.t("مصدّر المعالم v2.0\nيجلب المعالم والطرق والأنهار والبحيرات والسدود والحدود الإدارية من OpenStreetMap ويصدّرها إلى Shapefile / KML / KMZ.\n\nالبيانات © مساهمو OpenStreetMap (ترخيص ODbL).\nحدود الناحية/القضاء/المحافظة تُحدَّد من مستويات admin_level (الافتراضي 4/5/6) ويمكن تعديلها من «الطبقات والتحميل».",
                        "POI Exporter v2.0\nDownloads landmarks, roads, rivers, lakes, dams and administrative boundaries from OpenStreetMap and exports Shapefile / KML / KMZ.\n\nData © OpenStreetMap contributors (ODbL).\nNahiya/qadaa/governorate come from admin_level (default 4/5/6), editable in Layers & download."),
                null, null);
    }

    void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("coords", text));
        toast(S.t("تم النسخ", "Copied"));
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
