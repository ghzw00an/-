package iq.gis.poiexporter;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.IConfigurationProvider;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.TilesOverlay;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Catalog;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.Kml;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.Pipeline;
import iq.gis.poiexporter.core.ShapeWriter;

public class MainActivity extends Activity {
    static final int REQ_IMPORT = 11, REQ_FOLDER = 12, REQ_BATCH = 13, REQ_HUB = 14, REQ_RESTORE = 15, REQ_OFFLINE = 16, REQ_RASTER = 18, REQ_WORLD = 19, REQ_HUB_MANY = 20;
    static List<LayerData> DATA = new ArrayList<>();
    static String RESTORE_PAGE;
    static List<LayerData> LIB = new ArrayList<>(); // saved groups (the open project's layers)
    static iq.gis.poiexporter.core.db.Workspace WS;
    static final List<LayerData> REF = new ArrayList<>(); // reference boundaries shown on the map (not user data)
    static boolean crsMissing;
    ConverterPage conv;
    HubPage hub;
    ManagePages manage;
    AdminPage admin;
    ToolsPage tools;
    QualityPage quality;
    ReportPage report;
    OfflinePage offline;
    MapElements elements;
    AttributeTablePage attrTable;
    AnalysisPage analysis;
    MeasureTool measure;
    FrameLayout mapRoot;
    final QuickEntry quick = new QuickEntry(this);
    final AppLock lock = new AppLock(this);
    RasterStore rasters;
    RasterPage rasterPage;
    static List<LayerData> DL = new ArrayList<>(); // downloaded layers
    static final Set<String> HIDDEN = new LinkedHashSet<>();
    static String ACTIVE;
    static boolean libLoaded;

    Prefs prefs;
    Pages pages;
    MapView map;
    FeatureOverlay fo;
    AreaOverlay ao;
    private FrameLayout root, pageHolder;
    private LinearLayout drawer;
    private View scrim;
    private TextView title, summary;
    private View topBar;
    private boolean drawerOpen;
    String page;
    private float edgeX = -1;
    private volatile boolean cancel;
    private boolean bigOk;
    LocationDot dot;
    private LocationManager lm;
    private LocationListener ll;
    private Location lastLoc;
    private boolean tracking, centerOnFix, areaOnFix;
    private TextView editBtn, addBtn;
    private TextView areaBtn;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        S.ar = prefs.arabic();
        int th = prefs.theme();
        boolean night = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        Theme.apply(th == 2 || (th == 0 && night));
        IConfigurationProvider cfg = org.osmdroid.config.Configuration.getInstance();
        cfg.setUserAgentValue("PoiExporter/2.0 (" + getPackageName() + ")");
        cfg.setOsmdroidBasePath(new File(getCacheDir(), "osmdroid"));
        cfg.setOsmdroidTileCache(new File(getCacheDir(), "osmdroid/tiles"));
        if (!libLoaded) {
            WS = Store.open(this);
            AdminFetch.restore(this);
            LIB = WS.layers();
            GpkgAndroid.install();
            try {
                if (!iq.gis.poiexporter.core.crs.Crs.available()) crsMissing = true;
            } catch (Throwable t) {
                crsMissing = true;
            }
            libLoaded = true;
            HIDDEN.addAll(csv("hidden", ""));
            ACTIVE = prefs.get("active", null);
        }
        if (prefs.flag("awake", true)) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        pages = new Pages(this);
        conv = new ConverterPage(this);
        hub = new HubPage(this);
        manage = new ManagePages(this);
        admin = new AdminPage(this);
        tools = new ToolsPage(this);
        quality = new QualityPage(this);
        report = new ReportPage(this);
        offline = new OfflinePage(this);
        analysis = new AnalysisPage(this);
        attrTable = new AttributeTablePage(this);
        measure = new MeasureTool(this);
        rasters = new RasterStore(this);
        rasterPage = new RasterPage(this);
        buildUi();
        rebuild();
        String r = RESTORE_PAGE;
        RESTORE_PAGE = null;
        if (r != null) showPage(r);
        else if (b == null && prefs.flag("startHome", false)) showPage("home");
        handleIntent(getIntent());
        applyWindowFlags();
        if (b == null) lock.onStart();
        if (b == null) Splash.show(this, "3.9");
        if (crsMissing) {
            crsMissing = false;
            message(S.t("تنبيه", "Notice"), S.t("تعذّر تحميل قاعدة أنظمة الإحداثيات (EPSG). ستعمل أنظمة WGS84 وUTM الأساسية فقط.",
                    "The EPSG coordinate-system database could not be loaded. Only basic WGS84 / UTM will work."), null, null);
        }
    }

    /** Keep-screen-on and hide-from-screenshots settings. */
    void applyWindowFlags() {
        if (prefs.flag("awake", true)) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (prefs.flag("secureScreen", false)) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleIntent(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (map != null) map.onResume();
        if (tracking) startLocation();
        lock.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (map != null) map.onPause();
        lock.onPause();
        Store.flush();
        AutoBackup.maybe(this);
        stopLocation();
    }

    @Override
    public void onBackPressed() {
        if (drawerOpen) closeDrawer();
        else if (page != null) showMap();
        else if (prefs.flag("exitConfirm", true)) confirmExit();
        else {
            WS.flush();
            finish();
        }
    }

    private boolean exitAsked;

    /** Asks before leaving the app; a second back press within 3 seconds while the dialog is open also confirms. */
    void confirmExit() {
        if (exitAsked) return;
        exitAsked = true;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("الخروج من التطبيق", "Exit the app"), 19, Theme.text, true));
        TextView m = Ui.text(this, S.t("هل تريد حقاً الخروج من PoiExporter؟ بياناتك محفوظة تلقائياً.", "Do you really want to exit PoiExporter? Your data is saved automatically."), 14, Theme.sub, false);
        m.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 6));
        box.addView(m);
        final Dialog d = card(box);
        d.setOnDismissListener(di -> exitAsked = false);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إلغاء", "Cancel"), false, d::dismiss), Ui.lp(0, -2, 1f, this, 0, 10, 4, 0));
        r.addView(Ui.button(this, S.t("تأكيد الخروج", "Exit"), true, () -> {
            d.dismiss();
            WS.flush();
            finish();
        }), Ui.lp(0, -2, 1f, this, 4, 10, 0, 0));
        box.addView(r);
        d.show();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent e) {
        float edge = Ui.dp(this, 20);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                edgeX = e.getX() < edge && !drawerOpen ? e.getX() : -1;
                break;
            case MotionEvent.ACTION_MOVE:
                if (edgeX >= 0 && e.getX() - edgeX > Ui.dp(this, 48)) {
                    edgeX = -1;
                    openDrawer();
                }
                break;
            default:
                edgeX = -1;
                break;
        }
        return super.dispatchTouchEvent(e);
    }

    // ------------------------------------------------------------------ UI shell

    private void buildUi() {
        root = new FrameLayout(this);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setBackgroundColor(Theme.bg);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(Theme.card);
        top.setElevation(Ui.dp(this, 4));
        top.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4));

        TextView menu = Ui.text(this, "☰", 26, Theme.text, true);
        menu.setGravity(Gravity.CENTER);
        menu.setClickable(true);
        menu.setContentDescription("menu");
        Ui.pressable(menu);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDrawer();
            }
        });
        top.addView(menu, new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 48)));

        title = Ui.text(this, S.t("مصدّر المعالم", "POI Exporter"), 18, Theme.text, true);
        title.setSingleLine(true);
        title.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView conv = Ui.text(this, "⇄", 24, Theme.primary, true);
        conv.setGravity(Gravity.CENTER);
        conv.setClickable(true);
        Ui.pressable(conv);
        conv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPage("converter");
            }
        });
        top.addView(conv, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        topBar = top;
        top.setVisibility(View.GONE);
        content.addView(top, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout body = new FrameLayout(this);
        body.addView(buildMapBox(), new FrameLayout.LayoutParams(-1, -1));
        pageHolder = new FrameLayout(this);
        pageHolder.setBackgroundColor(Theme.bg);
        pageHolder.setClickable(true);
        pageHolder.setVisibility(View.GONE);
        body.addView(pageHolder, new FrameLayout.LayoutParams(-1, -1));
        content.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        scrim = new View(this);
        scrim.setBackgroundColor(0x88000000);
        scrim.setAlpha(0f);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
            }
        });
        root.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        drawer = buildDrawer();
        FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(Ui.dp(this, 300), -1, Gravity.LEFT);
        drawer.setTranslationX(-Ui.dp(this, 310));
        root.addView(drawer, dl);

        setContentView(root);
        getWindow().setStatusBarColor(Theme.card);
        getWindow().setNavigationBarColor(Theme.bg);
        int flags = 0;
        if (!Theme.dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (!Theme.dark && android.os.Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
        updateSummary();
    }

    private View buildMapBox() {
        FrameLayout box = new FrameLayout(this);
        float density = getResources().getDisplayMetrics().density;
        map = new MapView(this);
        map.setMultiTouchControls(true);
        map.setMinZoomLevel(3.0);
        map.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.NEVER);
        fo = new FeatureOverlay();
        fo.setData(DATA, density);
        fo.setTap(new FeatureOverlay.Tap() {
            @Override
            public void onFeature(Feature f, LayerData layer) {
                showFeature(f, layer);
            }
        });
        ao = new AreaOverlay(density);
        ao.onMoved(new AreaOverlay.Moved() {
            @Override
            public void to(double lat, double lon) {
                setCenter(lat, lon);
            }
        });
        org.osmdroid.views.overlay.gestures.RotationGestureOverlay rg =
                new org.osmdroid.views.overlay.gestures.RotationGestureOverlay(map);
        rg.setEnabled(true);
        map.getOverlays().add(rg);
        map.getOverlays().add(new RasterOverlay(rasters));
        map.getOverlays().add(fo);
        dot = new LocationDot(density);
        map.getOverlays().add(dot);
        map.getOverlays().add(ao);
        ScaleOverlay sbar = new ScaleOverlay(density, 150, 14);
        map.getOverlays().add(sbar);
        final ScaleView scaleView = new ScaleView(this, map);
        sbar.attach(scaleView);
        FrameLayout.LayoutParams svp = new FrameLayout.LayoutParams(scaleView.widthPx(), scaleView.heightPx(), Gravity.BOTTOM | Gravity.RIGHT);
        svp.bottomMargin = Ui.dp(this, 140);
        svp.rightMargin = Ui.dp(this, 10);
        box.addView(scaleView, svp);
        map.addMapListener(new org.osmdroid.events.MapListener() {
            public boolean onScroll(org.osmdroid.events.ScrollEvent e) {
                scaleView.update();
                return false;
            }

            public boolean onZoom(org.osmdroid.events.ZoomEvent e) {
                scaleView.update();
                return false;
            }
        });
        map.post(scaleView::update);
        elements = new MapElements(this);
        elements.install(map, sbar);
        map.getOverlays().add(new org.osmdroid.views.overlay.Overlay() {
            private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

            {
                p.setColor(0xFF000000);
                p.setStrokeWidth(2f * density);
            }

            @Override
            public boolean onSingleTapConfirmed(android.view.MotionEvent e, MapView mv) {
                float cx = mv.getWidth() / 2f, cy = mv.getHeight() / 2f;
                if (Math.hypot(e.getX() - cx, e.getY() - cy) <= 36 * density) {
                    addAtCenter();
                    return true;
                }
                return false;
            }

            @Override
            public void draw(android.graphics.Canvas c, MapView mv, boolean shadow) {
                if (shadow) return;
                float x = c.getWidth() / 2f, y = c.getHeight() / 2f, r = 12f * density;
                c.drawLine(x - r, y, x + r, y, p);
                c.drawLine(x, y - r, x, y + r, p);
            }
        });
        ao.onEdited(new AreaOverlay.Edited() {
            @Override
            public void changed(double clat, double clon, double wM, double hM, boolean circle, double rot) {
                prefs.rot(circle ? 0 : rot);
                int shape = prefs.shape();
                if (circle) {
                    if (shape != 2) prefs.shape(2);
                    prefs.size(wM, wM);
                } else if (shape == 1) {
                    prefs.size(Math.max(wM, hM), Math.max(wM, hM));
                } else {
                    prefs.size(wM, hM);
                }
                setCenter(clat, clon);
            }
        });
        double[] c = prefs.center();
        map.getController().setZoom(13.0);
        map.getController().setCenter(new GeoPoint(c[0], c[1]));
        box.addView(map, new FrameLayout.LayoutParams(-1, -1));
        map.addMapListener(new org.osmdroid.events.MapListener() {
            public boolean onScroll(org.osmdroid.events.ScrollEvent e) {
                updateCard();
                return false;
            }

            public boolean onZoom(org.osmdroid.events.ZoomEvent e) {
                return false;
            }
        });

        // coordinate card (top-left), like Locus/Orux style
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        card.setBackground(Ui.round(0xF2FFFFFF, 6, this));
        card.setElevation(Ui.dp(this, 4));
        card.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 6));
        coordLine1 = Ui.text(this, "", 17, 0xFF111111, true);
        coordLine1.setSingleLine(true);
        coordLine2 = Ui.text(this, "", 13, 0xFF1F57D6, false);
        coordLine2.setSingleLine(true);
        summary = Ui.text(this, "", 11, 0xFF666666, false);
        card.addView(coordLine1);
        card.addView(coordLine2);
        card.addView(summary);
        card.setClickable(true);
        card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                copy(coordLine1.getText().toString());
            }
        });
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        cp.setMargins(Ui.dp(this, 8), Ui.dp(this, 8), 0, 0);
        box.addView(card, cp);

        // attribution
        TextView attr = Ui.text(this, "", 10, Color.parseColor("#333333"), false);
        attrView = attr;
        attr.setBackgroundColor(0xAAFFFFFF);
        attr.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
        FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        ap.bottomMargin = Ui.dp(this, 72);
        box.addView(attr, ap);

        // small area tools (right side)
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.VERTICAL);
        tools.addView(roundBtn("⚡", new Runnable() {
            public void run() {
                quick.quickAdd();
            }
        }));
        tools.addView(roundBtn("⌖", new Runnable() {
            public void run() {
                org.osmdroid.api.IGeoPoint g = map.getMapCenter();
                setCenter(g.getLatitude(), g.getLongitude());
                toast(S.t("تم وضع مركز المنطقة في مركز الخريطة", "Area centre set to map centre"));
            }
        }));
        editBtn = (TextView) roundBtn("✥", new Runnable() {
            public void run() {
                ao.setEditable(!ao.isEditable());
                styleEdit();
                map.invalidate();
                toast(ao.isEditable() ? S.t("تحريك/تغيير حجم المنطقة بالسحب: مفعّل", "Drag to move/resize area: ON")
                        : S.t("تحريك المنطقة بالسحب: متوقف (للتنقل بالخريطة)", "Drag to move area: OFF (map panning)"));
            }
        });
        tools.addView(editBtn);
        styleEdit();
        areaBtn = (TextView) roundBtn("👁", new Runnable() {
            public void run() {
                boolean v = !ao.isVisible2();
                ao.setVisible2(v);
                prefs.setFlag("areaVis", v);
                if (v) {
                    org.osmdroid.api.IGeoPoint mc = map.getMapCenter();
                    setCenter(mc.getLatitude(), mc.getLongitude());
                }
                areaBtn.setText(v ? "👁" : "🚫");
                map.invalidate();
                toast(v ? S.t("تم إظهار مستطيل التحديد", "Selection shown") : S.t("تم إخفاء مستطيل التحديد", "Selection hidden"));
            }
        });
        tools.addView(areaBtn);
        ao.setVisible2(prefs.flag("areaVis", true));
        areaBtn.setText(ao.isVisible2() ? "👁" : "🚫");
        tools.addView(roundBtn("⛶", new Runnable() {
            public void run() {
                zoomToArea();
            }
        }));
        tools.addView(roundBtn("▣", new Runnable() {
            public void run() {
                zoomToData();
            }
        }));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT | Gravity.TOP);
        tp.topMargin = Ui.dp(this, 90);
        tp.rightMargin = Ui.dp(this, 10);
        box.addView(tools, tp);

        // big zoom buttons (bottom-right)
        LinearLayout zoom = new LinearLayout(this);
        zoom.setOrientation(LinearLayout.VERTICAL);
        zoom.addView(zoomBtn("+", new Runnable() {
            public void run() {
                map.getController().zoomIn();
            }
        }));
        zoom.addView(zoomBtn("−", new Runnable() {
            public void run() {
                map.getController().zoomOut();
            }
        }));
        FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT | Gravity.BOTTOM);
        zp.rightMargin = Ui.dp(this, 8);
        zp.bottomMargin = Ui.dp(this, 8);
        box.addView(zoom, zp);

        // bottom toolbar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        bar.setBackground(Ui.round(Theme.dark ? 0xE61A2733 : 0xE6263238, 28, this));
        bar.setElevation(Ui.dp(this, 10));
        bar.setPadding(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        bar.addView(barBtn("☰", new Runnable() {
            public void run() {
                openDrawer();
            }
        }, v -> menuMain(v)), new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        bar.addView(barBtn("🗺", new Runnable() {
            public void run() {
                mapTypeDialog();
            }
        }, v -> menuMaps(v)), new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        addBtn = (TextView) barBtn("⚑", new Runnable() {
            public void run() {
                addAtCenter();
            }
        }, v -> menuAdd(v));
        bar.addView(addBtn, new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        bar.addView(barBtn("◎", new Runnable() {
            public void run() {
                centerOnFix = true;
                locationOn();
            }
        }, v -> menuLocation(v)), new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        bar.addView(barBtn("🧭", new Runnable() {
            public void run() {
                map.setMapOrientation(0f);
                map.invalidate();
                toast(S.t("الخريطة موجّهة نحو الشمال", "Map oriented to north"));
            }
        }, v -> menuCompass(v)), new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        bar.addView(barBtn("⬇", new Runnable() {
            public void run() {
                download();
            }
        }, v -> menuDownload(v)), new LinearLayout.LayoutParams(0, Ui.dp(this, 56), 1f));
        int sw = getResources().getDisplayMetrics().widthPixels;
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams((int) (sw * 0.76f), -2, Gravity.BOTTOM | Gravity.LEFT);
        bp.setMargins(Ui.dp(this, 6), 0, 0, Ui.dp(this, 8));
        box.addView(bar, bp);

        setBaseMap(baseIndex(), false);
        OfflinePage.apply(this);
        if (prefs.flag("night", false)) toggleNight();
        ao.set(area());
        ao.setSquare(prefs.shape() == 1);
        updateCard();
        mapRoot = box;
        return box;
    }


    // ------------------------------------------------------------------ long-press menus

    private boolean multiAdd;
    private final TapOverlay tapper = new TapOverlay();
    private boolean tapperAdded;

    Location lastLocation() {
        return lastLoc;
    }

    void toggleSectorColors() {
        boolean v = !prefs.flag("sectorColors", true);
        prefs.setFlag("sectorColors", v);
        fo.colorBySector = v;
        map.invalidate();
        toast(v ? S.t("تلوين المعالم حسب القطاع: مفعّل", "Colour by sector: on") : S.t("تلوين المعالم حسب القطاع: متوقف", "Colour by sector: off"));
    }

    void locationOn() {
        dot.setShown(true);
        locate();
    }

    void locationOff() {
        tracking = false;
        centerOnFix = false;
        stopLocation();
        dot.setShown(false);
        map.invalidate();
        toast(S.t("تم إيقاف الموقع", "Location turned off"));
    }

    boolean locationRunning() {
        return tracking;
    }

    private void addAtMyLocation() {
        if (lastLoc == null) {
            toast(S.t("الموقع غير متاح بعد. شغّله أولاً.", "No location yet. Turn it on first."));
            if (!tracking) locationOn();
            return;
        }
        addDialog(lastLoc.getLatitude(), lastLoc.getLongitude());
    }

    /** Tap-to-add mode: every tap on the map opens the add form for that point; the mode stays on until switched off. */
    void setMultiAdd(boolean on) {
        multiAdd = on;
        if (!tapperAdded) {
            map.getOverlays().add(tapper);
            tapperAdded = true;
        }
        tapper.setEnabled2(on, new TapOverlay.Tapped() {
            public void at(double lat, double lon) {
                addDialog(lat, lon);
            }
        });
        toast(on ? S.t("وضع إضافة عدة معالم: المس الخريطة لإضافة معلم. أوقفه من ضغط ⚑ مطولاً.", "Multi-add mode: tap the map to add a landmark. Turn it off from long-press on ⚑.")
                : S.t("تم إيقاف وضع إضافة المعالم المتعددة", "Multi-add mode off"));
        if (addBtn != null) addBtn.setText(on ? "⚐" : "⚑");
    }

    private void menuAdd(View v) {
        Popover p = new Popover(this);
        p.add("📍 " + S.t("إضافة معلم عند منتصف الشاشة", "Add landmark at screen centre"), this::addAtCenter);
        p.add("📌 " + S.t("إضافة معلم عند موقعي", "Add landmark at my location"), this::addAtMyLocation);
        p.add(multiAdd ? "⏹ " + S.t("إيقاف إضافة عدة معالم", "Stop multi-add") : "➕ " + S.t("إضافة عدة معالم (المس الخريطة)", "Add several (tap the map)"),
                () -> setMultiAdd(!multiAdd));
        p.add("⚡ " + S.t("إضافة سريعة عند مركز الخريطة (+)", "Quick add at the map centre (+)"), () -> quick.quickAdd());
        p.add((quick.templatesOn() ? "☑ " : "☐ ") + S.t("تطبيق القوالب", "Apply templates"), () -> {
            boolean on = !quick.templatesOn();
            prefs.setFlag("tplOn", on);
            toast(on ? S.t("القوالب: تعمل", "Templates: on") : S.t("القوالب: متوقفة", "Templates: off"));
        });
        p.add("📋 " + S.t("قوالب الإدخال", "Entry templates") + (quick.active() != null ? " (" + quick.active().name + ")" : ""), () -> quick.templatesDialog());
        p.add((prefs.flag("autoNumber", false) ? "☑ " : "☐ ") + S.t("ترقيم تلقائي للمعالم بلا اسم (P-1, P-2…)", "Auto-number unnamed landmarks (P-1, P-2…)"),
                () -> {
                    boolean an = !prefs.flag("autoNumber", false);
                    prefs.setFlag("autoNumber", an);
                    toast(an ? S.t("الترقيم التلقائي: مفعّل", "Auto-numbering: on") : S.t("الترقيم التلقائي: متوقف", "Auto-numbering: off"));
                });
        p.add("🔤 " + S.t("مربع نص", "Text box"), () -> elements.addText());
        p.add("🖼 " + S.t("صورة صغيرة", "Small picture"), () -> elements.pickImage());
        p.add("📐 " + S.t("قياس طول/مساحة", "Measure length/area"), () -> measure.start(mapRoot));
        p.add("🧭 " + (elements.arrowOn() ? S.t("إخفاء سهم الشمال", "Hide north arrow") : S.t("إظهار سهم الشمال", "Show north arrow")), () -> elements.toggleArrow());
        p.add("📏 " + (elements.scaleOn() ? S.t("إخفاء مقياس الرسم", "Hide scale bar") : S.t("إظهار مقياس الرسم", "Show scale bar")), () -> elements.toggleScale());
        p.add("🖨 " + S.t("طباعة وتقارير", "Print & reports"), () -> showPage("report"));
        p.show(v);
    }

    private void menuLocation(View v) {
        Popover p = new Popover(this);
        p.add(tracking ? "⏻ " + S.t("إيقاف الموقع", "Turn location off") : "⏻ " + S.t("تشغيل الموقع", "Turn location on"),
                () -> {
                    if (tracking) locationOff();
                    else locationOn();
                });
        p.add("🎯 " + S.t("توسيط الخريطة على موقعي", "Centre map on me"), () -> {
            centerOnFix = true;
            locationOn();
        });
        p.add("📌 " + S.t("إضافة معلم عند موقعي", "Add landmark at my location"), this::addAtMyLocation);
        p.add("🔲 " + S.t("وضع مستطيل التحديد على موقعي", "Put selection area on me"), () -> {
            areaOnFix = true;
            locationOn();
        });
        p.show(v);
    }

    private void menuCompass(View v) {
        Popover p = new Popover(this);
        p.add("⬆ " + S.t("الشمال للأعلى", "North up"), () -> {
            map.setMapOrientation(0f);
            map.invalidate();
        });
        p.add("🧭 " + (elements.arrowOn() ? S.t("إخفاء سهم الشمال", "Hide north arrow") : S.t("إظهار سهم الشمال", "Show north arrow")), () -> elements.toggleArrow());
        p.add("📏 " + (elements.scaleOn() ? S.t("إخفاء مقياس الرسم", "Hide scale bar") : S.t("إظهار مقياس الرسم", "Show scale bar")), () -> elements.toggleScale());
        p.show(v);
    }

    private void menuMaps(View v) {
        Popover p = new Popover(this);
        int cur = baseIndex();
        for (int i = 0; i < BaseMaps.ALL.length; i++) {
            final int idx = i;
            p.add((i == cur ? "✔ " : "   ") + BaseMaps.ALL[i].label(), () -> setBaseMap(idx, true));
        }
        p.add("🔤 " + S.t("أسماء النقاط على الخريطة (تبديل)", "Map labels (cycle)"), this::cycleLabels);
        p.add((prefs.flag("sectorColors", true) ? "☑ " : "☐ ") + "🎨 " + S.t("تلوين المعالم حسب القطاع", "Colour landmarks by sector"), this::toggleSectorColors);
        p.add("🌙 " + S.t("وضع ليلي أحمر", "Red night mode"), this::toggleNight);
        p.add("🖨 " + S.t("طباعة/حفظ/مشاركة الخريطة المعروضة (أفقي)", "Print / save / share the map as shown (landscape)"), () -> {
            report.presetSnapshot();
            showPage("report");
        });
        p.add("🏛 " + S.t("الحدود الإدارية", "Admin boundaries"), () -> showPage("admin"));
        p.show(v);
    }

    private void menuDownload(View v) {
        Popover p = new Popover(this);
        p.add("⬇ " + S.t("تنزيل ضمن المنطقة", "Download area"), this::download);
        p.add("⛶ " + S.t("تقريب إلى المنطقة", "Zoom to area"), this::zoomToArea);
        p.add("▣ " + S.t("تقريب إلى كل البيانات", "Zoom to all data"), this::zoomToData);
        p.add("☰ " + S.t("طبقات وتحميل", "Layers & download"), () -> showPage("layers"));
        p.add("⇩ " + S.t("استيراد ملف", "Import file"), this::pickImport);
        p.show(v);
    }

    private void menuMain(View v) {
        Popover p = new Popover(this);
        p.add("▦ " + S.t("جدول الخصائص", "Attribute table"), () -> showPage("attrs"));
        p.add("≣ " + S.t("إدارة الطبقات", "Layer manager"), () -> showPage("manage"));
        p.add("✂ " + S.t("أدوات المنطقة والتحليل", "Area & analysis tools"), () -> showPage("tools"));
        p.add("🛰 " + S.t("صور جوية", "Aerial images"), () -> showPage("raster"));
        p.add("📐 " + S.t("قياس طول/مساحة", "Measure length/area"), () -> measure.start(mapRoot));
        p.add("✔ " + S.t("جودة البيانات", "Data quality"), () -> showPage("quality"));
        p.add("🖨 " + S.t("طباعة وتقارير", "Print & reports"), () -> showPage("report"));
        p.add("⇩ " + S.t("أوفلاين وسجل الأخطاء", "Offline & error log"), () -> showPage("offline"));
        p.add("↶ " + S.t("تراجع", "Undo") + (WS.canUndo() ? " — " + WS.undoLabel() : ""), () -> {
            if (WS.canUndo()) {
                WS.undo();
                rebuild();
            } else toast(S.t("لا شيء للتراجع عنه", "Nothing to undo"));
        });
        p.add("↷ " + S.t("إعادة", "Redo") + (WS.canRedo() ? " — " + WS.redoLabel() : ""), () -> {
            if (WS.canRedo()) {
                WS.redo();
                rebuild();
            } else toast(S.t("لا شيء لإعادته", "Nothing to redo"));
        });
        p.show(v);
    }

    private TextView coordLine1, coordLine2;

    void updateCard() {
        if (coordLine1 == null || map == null) return;
        org.osmdroid.api.IGeoPoint g = map.getMapCenter();
        double lat = g.getLatitude(), lon = g.getLongitude();
        String l1 = CoordFmt.format(fmt(), lat, lon);
        if (lastLoc != null && lastLoc.hasAltitude()) l1 += "  ↑" + Math.round(lastLoc.getAltitude()) + " m";
        coordLine1.setText(l1);
        coordLine2.setText(CoordFmt.dd(lat, lon) + "  WGS84");
    }

    private View barBtn(String glyph, final Runnable r) {
        return barBtn(glyph, r, null);
    }

    private View barBtn(String glyph, final Runnable r, final java.util.function.Consumer<View> longPress) {
        TextView t = new TextView(this);
        t.setText(glyph);
        t.setTextSize(24);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                r.run();
            }
        });
        if (longPress != null) {
            t.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    longPress.accept(v);
                    return true;
                }
            });
        }
        return t;
    }

    private View zoomBtn(String glyph, final Runnable r) {
        TextView t = new TextView(this);
        t.setText(glyph);
        t.setTextSize(34);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.round(0xCC5F6368, 10, this));
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                r.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 52));
        lp.topMargin = Ui.dp(this, 6);
        t.setLayoutParams(lp);
        return t;
    }

    void mapTypeDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("نوع الخريطة", "Map type"), 18, Theme.text, true));
        final Dialog d = card(box);
        int cur = baseIndex();
        for (int i = 0; i < BaseMaps.ALL.length; i++) {
            final int idx = i;
            box.addView(Ui.button(this, (i == cur ? "✔  " : "") + BaseMaps.ALL[i].label(), i == cur, new Runnable() {
                public void run() {
                    setBaseMap(idx, true);
                    d.dismiss();
                }
            }), Ui.lp(-1, -2, 0, this, 0, 6, 0, 0));
        }
        d.show();
    }

    void searchDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("بحث عن مكان أو إحداثيات", "Search a place or coordinates"), 18, Theme.text, true));
        final android.widget.EditText q = Ui.field(this, S.t("اسم مكان أو إحداثيات بأي صيغة", "Place name or coordinates"),
                android.text.InputType.TYPE_CLASS_TEXT);
        box.addView(q, Ui.lp(-1, -2, 0, this, 0, 10, 0, 0));
        final Dialog d = card(box);
        box.addView(Ui.button(this, S.t("بحث", "Search"), true, new Runnable() {
            public void run() {
                d.dismiss();
                search(q.getText().toString());
            }
        }), Ui.lp(-1, -2, 0, this, 0, 12, 0, 0));
        d.show();
    }

    private int baseIndex() {
        try {
            return Math.max(0, Math.min(BaseMaps.ALL.length - 1, Integer.parseInt(prefs.get("basemap", "3"))));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private TextView[] mapChips;
    private TextView attrView;

    private static int parseIntSafe(String v, int def) {
        try {
            return Integer.parseInt(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** Cycles the on-map name labels: automatic → from zoom 10 → off. */
    void cycleLabels() {
        int m = (parseIntSafe(prefs.get("labelMode", "1"), 1) + 1) % 3;
        prefs.put("labelMode", String.valueOf(m));
        fo.labelMode = m;
        map.invalidate();
        toast(m == 0 ? S.t("أسماء النقاط: مخفية", "Labels: off") : m == 1 ? S.t("أسماء النقاط: تلقائي (تقريب 14+)", "Labels: auto (zoom 14+)")
                : S.t("أسماء النقاط: من تقريب 10", "Labels: from zoom 10"));
    }

    private org.osmdroid.views.overlay.Overlay nightOverlay;

    /** Red night-vision filter over the map (keeps night vision and saves battery on OLED). */
    void toggleNight() {
        if (nightOverlay == null) {
            nightOverlay = new org.osmdroid.views.overlay.Overlay() {
                @Override
                public void draw(android.graphics.Canvas c, MapView mv, boolean shadow) {
                    if (shadow) return;
                    c.drawColor(0xFFFF3A3A, android.graphics.PorterDuff.Mode.MULTIPLY);
                }
            };
            map.getOverlays().add(nightOverlay);
            prefs.setFlag("night", true);
            toast(S.t("الوضع الليلي الأحمر: مفعّل", "Red night mode: on"));
        } else {
            map.getOverlays().remove(nightOverlay);
            nightOverlay = null;
            prefs.setFlag("night", false);
            toast(S.t("الوضع الليلي الأحمر: متوقف", "Red night mode: off"));
        }
        map.invalidate();
    }

    /** Flash + zoom: pans the map to the feature, zooms in and pulses it so the eye finds it at once. */
    void flashTo(Feature f) {
        showMap();
        double zoom = f.geom == Feature.POINT ? 18.0 : 16.0;
        if (f.geom != Feature.POINT) {
            double[] b = iq.gis.poiexporter.core.Geo.bbox(f);
            org.osmdroid.util.BoundingBox bb = new org.osmdroid.util.BoundingBox(b[3], b[2], b[1], b[0]);
            try {
                map.zoomToBoundingBox(bb.increaseByScale(1.4f), true);
            } catch (RuntimeException e) {
                map.getController().animateTo(new GeoPoint(f.lat, f.lon));
            }
        } else {
            map.getController().setZoom(Math.max(map.getZoomLevelDouble(), zoom));
            map.getController().animateTo(new GeoPoint(f.lat, f.lon));
        }
        final Feature ff = f;
        map.postDelayed(() -> fo.flash(ff, map), 700);
    }

    void setBaseMap(int i, boolean save) {
        BaseMaps.Def d = BaseMaps.ALL[i];
        map.setTileSource(BaseMaps.source(d, S.ar));
        map.getOverlayManager().getTilesOverlay().setColorFilter(Theme.dark && d.isOsm() ? TilesOverlay.INVERT_COLORS : null);
        if (attrView != null) {
            String t = d.isOsm() ? "© OpenStreetMap" : d.kind.equals("esri") ? "© Esri" : "Google";
            attrView.setText(t);
        }
        fo.lightLabels = d.kind.equals("esri") || (d.kind.startsWith("g") && (d.param.equals("lyrs=s") || d.param.equals("lyrs=y"))) || Theme.dark && d.isOsm();
        fo.labelMode = parseIntSafe(prefs.get("labelMode", "1"), 1);
        fo.colorBySector = prefs.flag("sectorColors", true);
        if (save) prefs.put("basemap", String.valueOf(i));
        if (mapChips != null) for (int k = 0; k < mapChips.length; k++) Ui.setChip(mapChips[k], k == i);
        map.invalidate();
    }

    private View buildSearchAndMaps() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), 0);
        col.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.stroke(Theme.card, Theme.line, 24, this));
        bar.setElevation(Ui.dp(this, 4));
        bar.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 4), 0);
        final android.widget.EditText q = new android.widget.EditText(this);
        q.setHint(S.t("ابحث عن مكان أو إحداثيات…", "Search a place or coordinates…"));
        q.setSingleLine(true);
        q.setTextSize(14.5f);
        q.setTextColor(Theme.text);
        q.setHintTextColor(Theme.sub);
        q.setBackground(null);
        q.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        bar.addView(q, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f));
        final Runnable go = new Runnable() {
            public void run() {
                search(q.getText().toString());
            }
        };
        q.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int a, android.view.KeyEvent e) {
                go.run();
                return true;
            }
        });
        TextView sb = Ui.text(this, "🔍", 20, Theme.primary, true);
        sb.setGravity(Gravity.CENTER);
        sb.setClickable(true);
        Ui.pressable(sb);
        sb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                go.run();
            }
        });
        bar.addView(sb, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));
        col.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        mapChips = new TextView[BaseMaps.ALL.length];
        for (int i = 0; i < BaseMaps.ALL.length; i++) {
            final int idx = i;
            mapChips[i] = Ui.chip(this, BaseMaps.ALL[i].label());
            mapChips[i].setElevation(Ui.dp(this, 2));
            mapChips[i].setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    setBaseMap(idx, true);
                }
            });
            chips.addView(mapChips[i], Ui.lp(-2, -2, 0, this, 3, 8, 3, 0));
        }
        hs.addView(chips);
        col.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        return col;
    }

    void search(final String text) {
        final String t = text == null ? "" : text.trim();
        if (t.isEmpty()) return;
        try {
            CoordFmt.Parsed ps = CoordFmt.parse(t);
            map.getController().setZoom(16.0);
            map.getController().animateTo(new GeoPoint(ps.lat, ps.lon));
            return;
        } catch (Exception ignored) {
            // not coordinates: search by name
        }
        if (searchLocal(t)) return;
        searchOnline(t);
    }

    /** Offline search over the open project (name, type, category, qadaa, nahia…, Arabic-aware). True if it showed a list. */
    private boolean searchLocal(final String t) {
        final List<Feature> hits;
        try {
            hits = WS.search(t, 30);
        } catch (RuntimeException e) {
            ErrorLog.add("search", e);
            return false;
        }
        if (hits == null || hits.isEmpty()) return false;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("نتائج في المشروع (" + hits.size() + ")", "Project results (" + hits.size() + ")"), 18, Theme.text, true));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        final Dialog d = card(box);
        for (final Feature f : hits) {
            LayerData l = WS.layerOfFeature(f.id);
            String line = (f.name.isEmpty() ? "—" : f.name) + (f.type.isEmpty() ? "" : "  •  " + f.type)
                    + (l == null ? "" : "\n" + l.label);
            TextView tv = Ui.text(this, line, 15, Theme.text, false);
            tv.setPadding(Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8));
            final LayerData fl = l;
            tv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    d.dismiss();
                    flashTo(f);
                    if (fl != null) showFeature(f, fl);
                }
            });
            list.addView(tv);
        }
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(-1, Ui.dp(this, 360)));
        box.addView(Ui.button(this, S.t("بحث على الإنترنت بدلاً من ذلك", "Search online instead"), false, new Runnable() {
            public void run() {
                d.dismiss();
                searchOnline(t);
            }
        }), Ui.lp(-1, -2, 0, this, 0, 8, 0, 0));
        d.show();
        return true;
    }

    private void searchOnline(final String t) {
        toast(S.t("جارٍ البحث…", "Searching…"));
        new Thread(new Runnable() {
            public void run() {
                try {
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(
                            "https://nominatim.openstreetmap.org/search?format=json&limit=1&q="
                                    + java.net.URLEncoder.encode(t, "UTF-8")).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(20000);
                    c.setRequestProperty("User-Agent", "PoiExporter/2.2 (iq.gis.poiexporter)");
                    InputStream in = c.getInputStream();
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                    in.close();
                    org.json.JSONArray arr = new org.json.JSONArray(bo.toString("UTF-8"));
                    if (arr.length() == 0) throw new java.io.IOException("none");
                    final double lat = arr.getJSONObject(0).getDouble("lat"), lon = arr.getJSONObject(0).getDouble("lon");
                    runOnUiThread(new Runnable() {
                        public void run() {
                            map.getController().setZoom(15.0);
                            map.getController().animateTo(new GeoPoint(lat, lon));
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            toast(S.t("لم يتم العثور على نتائج", "No results found"));
                        }
                    });
                }
            }
        }).start();
    }

    int[] adminLevels() {
        int[] lv = {4, 5, 6};
        for (int i = 0; i < 3; i++) {
            try {
                lv[i] = Integer.parseInt(prefs.get("lv" + (i + 4), String.valueOf(i + 4)).trim());
            } catch (NumberFormatException ignored) {
                // keep default
            }
        }
        return lv;
    }

    void addAtCenter() {
        org.osmdroid.api.IGeoPoint g = map.getMapCenter();
        addDialog(g.getLatitude(), g.getLongitude());
    }

    private LayerData groupByLabel(String name) {
        for (LayerData l : LIB) if (l.label.equalsIgnoreCase(name)) return l;
        return null;
    }

    private void addDialog(final double lat, final double lon) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("إضافة معلم", "Add landmark"), 20, Theme.text, true));
        final iq.gis.poiexporter.core.Utm.Result utm = iq.gis.poiexporter.core.Utm.fromLatLon(lat, lon);
        TextView c = Ui.text(this, CoordFmt.format(fmt(), lat, lon) + "   (" + utm.zoneLabel() + ")", 12, Theme.sub, false);
        c.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        box.addView(c);
        // Field names are fixed by the data format: name, type, Gategory, gathaa, Nahia, mohafadha, x, y, link
        final String[] names = iq.gis.poiexporter.core.LandmarkFields.NAMES;
        final android.widget.EditText[] ed = new android.widget.EditText[names.length];
        final String xs = String.format(Locale.US, "%.2f", utm.easting), ys = String.format(Locale.US, "%.2f", utm.northing);
        for (int i = 0; i < names.length; i++) {
            boolean num = i == 6 || i == 7;
            ed[i] = Ui.field(this, names[i], num ? (android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
                    : android.text.InputType.TYPE_CLASS_TEXT);
            ed[i].setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            ed[i].setGravity(Gravity.START);
            if (i == 6) ed[i].setText(xs);
            if (i == 7) ed[i].setText(ys);
            box.addView(ed[i], Ui.lp(-1, -2, 0, this, 0, i == 0 ? 10 : 8, 0, 0));
            if (i == 2) box.addView(SectorPicker.build(this, ed[2], ed[1]));
        }
        iq.gis.poiexporter.core.admin.AdminRef.Hit adminHit = null;
        try {
            iq.gis.poiexporter.core.admin.AdminRef ar0 = iq.gis.poiexporter.core.admin.AdminRef.get();
            if (ar0 != null) adminHit = ar0.locate(lat, lon);
        } catch (RuntimeException ignored) {
            // no offline boundaries
        }
        if (adminHit != null && adminHit.found()) {
            if (!adminHit.qadaa(true).isEmpty()) ed[3].setText(adminHit.qadaa(true));
            if (!adminHit.governorate(true).isEmpty()) ed[5].setText(adminHit.governorate(true));
            if (adminHit.boundaryM >= 0 && adminHit.boundaryM < 1000) {
                TextView w = Ui.text(this, S.t("⚠ الموقع قريب من حد القضاء (نحو " + Math.round(adminHit.boundaryM) + " م): راجع gathaa وmohafadha.",
                        "⚠ Near a district border (about " + Math.round(adminHit.boundaryM) + " m): check gathaa and mohafadha."), 12, Theme.danger, false);
                box.addView(w, Ui.lp(-2, -2, 0, this, 0, 6, 0, 0));
            }
        }
        box.addView(Ui.text(this, S.t("x و y إحداثيات UTM للنقطة (المنطقة " + utm.zoneLabel() + ") ويمكن تعديلها. gathaa وmohafadha تُملآن من الحدود المرجعية غير الرسمية (راجعهما قرب الحدود)، وNahia من الإنترنت عند توفره. link يُترك فارغاً.",
                "x and y are UTM coordinates (zone " + utm.zoneLabel() + ") and can be edited. gathaa and mohafadha come from the bundled unofficial boundaries (check near borders); Nahia is filled online when available. Leave link empty."),
                11.5f, Theme.sub, false), Ui.lp(-2, -2, 0, this, 0, 6, 0, 0));

        iq.gis.poiexporter.core.EntryTemplates.Template tpl = quick.inAddForm() ? quick.active() : null;
        if (tpl != null) {
            if (!tpl.type.isEmpty()) ed[1].setText(tpl.type);
            if (!tpl.category.isEmpty()) ed[2].setText(tpl.category);
            if (!tpl.qadaa.isEmpty()) ed[3].setText(tpl.qadaa);
            if (!tpl.nahiya.isEmpty()) ed[4].setText(tpl.nahiya);
            if (!tpl.governorate.isEmpty()) ed[5].setText(tpl.governorate);
            box.addView(Ui.text(this, "📋 " + S.t("قالب: ", "Template: ") + tpl.name, 12.5f, Theme.primary, true), Ui.lp(-2, -2, 0, this, 0, 6, 0, 0));
        }
        box.addView(Ui.text(this, S.t("المجموعة", "Group"), 13, Theme.sub, false), Ui.lp(-2, -2, 0, this, 0, 12, 0, 2));
        String def = S.t("معالمي", "My landmarks");
        for (LayerData l : LIB) if (l.id.equals(ACTIVE)) def = l.label;
        final android.widget.EditText grp = Ui.field(this, S.t("اسم المجموعة (جديد أو موجود)", "Group name (new or existing)"),
                android.text.InputType.TYPE_CLASS_TEXT);
        grp.setText(def);
        box.addView(grp, Ui.lp(-1, -2, 0, this, 0, 0, 0, 0));
        if (!LIB.isEmpty()) {
            android.widget.HorizontalScrollView gs = new android.widget.HorizontalScrollView(this);
            gs.setHorizontalScrollBarEnabled(false);
            LinearLayout gl = new LinearLayout(this);
            for (final LayerData l : LIB) {
                TextView ch = Ui.chip(this, l.label);
                ch.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        grp.setText(l.label);
                    }
                });
                gl.addView(ch, Ui.lp(-2, -2, 0, this, 3, 8, 3, 0));
            }
            gs.addView(gl);
            box.addView(gs);
        }
        ScrollView sc = new ScrollView(this);
        sc.addView(box);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.addView(sc, new LinearLayout.LayoutParams(-1, Ui.dp(this, 480)));
        final Dialog d = card(outer);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 12, 4, 0));
        r.addView(Ui.button(this, S.t("حفظ", "Save"), true, new Runnable() {
            public void run() {
                double la = lat, lo = lon;
                String xt = ed[6].getText().toString().trim(), yt = ed[7].getText().toString().trim();
                if (!xt.equals(xs) || !yt.equals(ys)) {
                    try {
                        double e = Double.parseDouble(xt), n = Double.parseDouble(yt);
                        double[] ll = iq.gis.poiexporter.core.Utm.toLatLon(utm.zone, utm.north, e, n);
                        la = ll[0];
                        lo = ll[1];
                    } catch (RuntimeException ex) {
                        toast(S.t("قيمة x أو y غير صالحة", "Invalid x or y"));
                        return;
                    }
                }
                Feature f = Feature.point(la, lo);
                f.name = ed[0].getText().toString().trim();
                f.type = ed[1].getText().toString().trim();
                f.category = ed[2].getText().toString().trim();
                f.qadaa = ed[3].getText().toString().trim();
                f.nahiya = ed[4].getText().toString().trim();
                f.governorate = ed[5].getText().toString().trim();
                iq.gis.poiexporter.core.LandmarkFields.setLink(f, ed[8].getText().toString().trim());
                quick.remember(f);
                f.updated = java.time.LocalDate.now().toString();
                String gname = grp.getText().toString().trim();
                if (gname.isEmpty()) gname = S.t("معالمي", "My landmarks");
                d.dismiss();
                addToGroup(f, gname);
            }
        }), Ui.lp(0, -2, 1f, this, 4, 12, 0, 0));
        outer.addView(r);
        d.show();
    }

    void addToGroup(final Feature f, String gname) {
        final LayerData g;
        LayerData ex = groupByLabel(gname);
        if (ex == null) {
            g = WS.addLayer(gname, Feature.POINT, "user");
        } else {
            g = ex;
        }
        ACTIVE = g.id;
        prefs.put("active", g.id);
        if (f.name.isEmpty() && prefs.flag("autoNumber", false)) f.name = "P-" + (g.features.size() + 1);
        WS.addFeature(g.id, f);
        HIDDEN.remove(g.id);
        saveCsv("hidden", HIDDEN);
        rebuild();
        map.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        toast(S.t("أُضيف إلى المجموعة: ", "Added to group: ") + g.label);
        if (prefs.flag("fillAdmin", true)) {
            new Thread(new Runnable() {
                public void run() {
                    try {
                        List<Feature> one = new ArrayList<>();
                        one.add(f);
                        Pipeline.fillAdminFor(one, adminLevels(), new Net());
                        runOnUiThread(new Runnable() {
                            public void run() {
                                WS.saveSilently(f);
                            }
                        });
                    } catch (Exception ignored) {
                        // offline: admin fields stay empty
                    }
                }
            }).start();
        }
    }

    /** Saved groups are written through by the workspace; kept for older call sites. */
    void persist(LayerData g) {
        for (Feature f : g.features) WS.saveSilently(f);
    }

    /** Rebuilds the visible layer list and redraws. */
    void rebuild() {
        List<LayerData> all = new ArrayList<>();
        for (LayerData l : LIB) if (!HIDDEN.contains(l.id) && l.visible) all.add(l);
        for (LayerData l : DL) if (!HIDDEN.contains(l.id)) all.add(l);
        all.addAll(0, REF);
        DATA = all;
        if (fo != null) {
            fo.setData(DATA, getResources().getDisplayMetrics().density);
            map.invalidate();
        }
        updateSummary();
    }

    void zoomToLayer(LayerData l) {
        double[] r = null;
        for (Feature f : l.features) {
            double[] b = f.geom == Feature.POINT ? new double[]{f.lon, f.lat, f.lon, f.lat} : Geo.bbox(f);
            if (r == null) r = b.clone();
            else {
                r[0] = Math.min(r[0], b[0]);
                r[1] = Math.min(r[1], b[1]);
                r[2] = Math.max(r[2], b[2]);
                r[3] = Math.max(r[3], b[3]);
            }
        }
        if (r == null) {
            toast(S.t("المجموعة فارغة", "Empty"));
            return;
        }
        if (r[2] - r[0] < 1e-4 && r[3] - r[1] < 1e-4) {
            map.getController().setZoom(17.0);
            map.getController().setCenter(new GeoPoint(r[1], r[0]));
            return;
        }
        double pl = Math.max(0.0005, (r[3] - r[1]) * 0.08), po = Math.max(0.0005, (r[2] - r[0]) * 0.08);
        final BoundingBox bb = new BoundingBox(Math.min(85, r[3] + pl), r[2] + po, Math.max(-85, r[1] - pl), r[0] - po);
        map.post(new Runnable() {
            public void run() {
                map.zoomToBoundingBox(bb, true, Ui.dp(MainActivity.this, 40));
            }
        });
    }

    void previewDialog(final LayerData l) {
        HIDDEN.remove(l.id);
        saveCsv("hidden", HIDDEN);
        rebuild();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, l.label + "  (" + l.features.size() + ")", 18, Theme.text, true));
        ScrollView sv = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        final Dialog d = card(box);
        int shown = 0;
        for (final Feature f : new ArrayList<>(l.features)) {
            if (shown++ >= 300) break;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            String label = (f.name.isEmpty() ? S.t("(بدون اسم)", "(unnamed)") : f.name) + (f.type.isEmpty() ? "" : " • " + f.type);
            TextView t = Ui.text(this, label, 14, Theme.text, false);
            t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    d.dismiss();
                    showMap();
                    map.getController().setZoom(18.0);
                    map.getController().setCenter(new GeoPoint(f.lat, f.lon));
                }
            });
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            final View rowF = row;
            TextView del = Ui.text(this, "🗑", 18, Theme.danger, false);
            del.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 4), 0);
            del.setClickable(true);
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    deleteFeature(f, l);
                    rowF.setVisibility(View.GONE);
                }
            });
            row.addView(del);
            list.addView(row);
        }
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 320));
        box.addView(sv, sp);
        box.addView(Ui.button(this, S.t("إغلاق", "Close"), true, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(-1, -2, 0, this, 0, 10, 0, 0));
        d.show();
        zoomToLayer(l);
    }

    void deleteFeature(Feature f, LayerData l) {
        if (WS.layer(l.id) != null) {
            WS.deleteFeatures(l.id, java.util.Collections.singletonList(f.id), S.t("حذف ", "Delete ") + (f.name.isEmpty() ? f.type : f.name));
        } else {
            l.features.remove(f);
            if (l.features.isEmpty()) DL.remove(l);
        }
        rebuild();
    }

    void deleteLayer(final LayerData l) {
        message(S.t("حذف", "Delete"), S.t("حذف «", "Delete \u201c") + l.label + S.t("» ونقاطه (" + l.features.size() + ")؟",
                "\u201d with " + l.features.size() + " items?"), S.t("حذف", "Delete"), new Runnable() {
            public void run() {
                if (WS.layer(l.id) != null) {
                    WS.deleteLayer(l.id);
                    if (l.id.equals(ACTIVE)) ACTIVE = null;
                } else {
                    DL.remove(l);
                }
                HIDDEN.remove(l.id);
                rebuild();
                if ("library".equals(page)) showPage("library");
            }
        });
    }

    void saveAsGroup(LayerData l) {
        LayerData g = new LayerData(Library.newId(), l.label, l.geom);
        for (Feature f : l.features) g.features.add(f.copy());
        WS.addLayerWithFeatures(g);
        toast(S.t("حُفظت في المعالم المحفوظة: ", "Saved to library: ") + l.label);
        if ("library".equals(page)) showPage("library");
    }

    void shareDialog(final LayerData l) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("مشاركة: ", "Share: ") + l.label, 18, Theme.text, true));
        final Dialog d = card(box);
        String[] kinds = {"kml", "kmz", "shp"};
        String[] names = {"KML (" + S.t("بيني كويست", "PineQuest") + ")", "KMZ", "Shapefile (ZIP)"};
        for (int i = 0; i < 3; i++) {
            final String k = kinds[i];
            box.addView(Ui.button(this, names[i], i == 0, new Runnable() {
                public void run() {
                    d.dismiss();
                    List<LayerData> one = new ArrayList<>();
                    one.add(l);
                    exportLayers(one, k, l.label);
                }
            }), Ui.lp(-1, -2, 0, this, 0, 8, 0, 0));
        }
        d.show();
    }

    private void styleEdit() {
        boolean on = ao.isEditable();
        editBtn.setTextColor(on ? Theme.onPrimary : Theme.text);
        editBtn.setBackground(Ui.stroke(on ? Theme.primary : Theme.card, Theme.line, 24, this));
    }

    private View roundBtn(String label, final Runnable r) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(Theme.text);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.stroke(Theme.card, Theme.line, 24, this));
        t.setElevation(Ui.dp(this, 3));
        t.setClickable(true);
        Ui.pressable(t);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                r.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46));
        lp.bottomMargin = Ui.dp(this, 8);
        t.setLayoutParams(lp);
        return t;
    }

    private LinearLayout buildDrawer() {
        LinearLayout d = new LinearLayout(this);
        d.setOrientation(LinearLayout.VERTICAL);
        d.setBackgroundColor(Theme.card);
        d.setElevation(Ui.dp(this, 16));
        d.setClickable(true);
        d.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setBackgroundColor(Theme.primary);
        head.setPadding(Ui.dp(this, 18), Ui.dp(this, 36), Ui.dp(this, 18), Ui.dp(this, 18));
        head.addView(Ui.text(this, "🌍", 34, Theme.onPrimary, false));
        head.addView(Ui.text(this, S.t("مصدّر المعالم", "POI Exporter"), 20, Theme.onPrimary, true));
        head.addView(Ui.text(this, S.t("OpenStreetMap • Shapefile • KML", "OpenStreetMap • Shapefile • KML"), 12,
                Theme.onPrimary, false));
        d.addView(head, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        list.addView(section(S.t("الخريطة والمنطقة", "Map & area")));
        list.addView(item("🗺", S.t("الخريطة", "Map"), new Runnable() {
            public void run() {
                showMap();
            }
        }));
        list.addView(item("🏠", S.t("لوحة المعلومات", "Dashboard"), new Runnable() {
            public void run() {
                showPage("home");
            }
        }));
        list.addView(item("▭", S.t("المنطقة المحددة (يدوي)", "Selected area (manual)"), new Runnable() {
            public void run() {
                showPage("area");
            }
        }));
        list.addView(item("☰", S.t("الطبقات والتحميل", "Layers & download"), new Runnable() {
            public void run() {
                showPage("layers");
            }
        }));
        list.addView(item("🔍", S.t("بحث", "Search"), new Runnable() {
            public void run() {
                searchDialog();
            }
        }));
        list.addView(item("🏛", S.t("الحدود الإدارية (العراق)", "Admin boundaries (Iraq)"), new Runnable() {
            public void run() {
                showPage("admin");
            }
        }));
        list.addView(item("🛰", S.t("صور جوية (TIFF / GeoTIFF)", "Aerial images (TIFF / GeoTIFF)"), new Runnable() {
            public void run() {
                showPage("raster");
            }
        }));
        list.addView(section(S.t("بياناتي", "My data")));
        list.addView(item("📁", S.t("المعالم المحفوظة والطبقات", "Saved landmarks & layers"), new Runnable() {
            public void run() {
                showPage("library");
            }
        }));
        list.addView(item("≣", S.t("إدارة الطبقات", "Layer manager"), new Runnable() {
            public void run() {
                showPage("manage");
            }
        }));
        list.addView(item("▦", S.t("جدول الخصائص (Attribute table)", "Attribute table"), new Runnable() {
            public void run() {
                showPage("attrs");
            }
        }));
        list.addView(item("🗂", S.t("المشاريع", "Projects"), new Runnable() {
            public void run() {
                showPage("projects");
            }
        }));
        list.addView(item("💾", S.t("النسخ الاحتياطي", "Backups"), new Runnable() {
            public void run() {
                showPage("backups");
            }
        }));
        list.addView(section(S.t("التحليل والجودة", "Analysis & quality")));
        list.addView(item("✂", S.t("أدوات المنطقة والتحليل (28 أداة)", "Area & analysis tools (28)"), new Runnable() {
            public void run() {
                showPage("tools");
            }
        }));
        list.addView(item("✔", S.t("جودة البيانات", "Data quality"), new Runnable() {
            public void run() {
                showPage("quality");
            }
        }));
        list.addView(section(S.t("استيراد وتصدير وطباعة", "Import, export & print")));
        list.addView(item("⇵", S.t("استيراد وتصدير (كل الصيغ)", "Import & export (all formats)"), new Runnable() {
            public void run() {
                showPage("hub");
            }
        }));
        list.addView(item("⤴", S.t("تصدير البيانات", "Export data"), new Runnable() {
            public void run() {
                exportDialog();
            }
        }));
        list.addView(item("⇅", S.t("استيراد / تصدير (KML • بيني كويست)", "Import / export (KML • PineQuest)"),
                new Runnable() {
                    public void run() {
                        showPage("kml");
                    }
                }));
        list.addView(item("⇄", S.t("محول الإحداثيات", "Coordinate converter"), new Runnable() {
            public void run() {
                showPage("converter");
            }
        }));
        list.addView(item("🖨", S.t("طباعة وتقارير (PDF/PNG)", "Print & reports (PDF/PNG)"), new Runnable() {
            public void run() {
                showPage("report");
            }
        }));
        list.addView(section(S.t("النظام", "System")));
        list.addView(item("⇩", S.t("أوفلاين وسجل الأخطاء", "Offline & error log"), new Runnable() {
            public void run() {
                showPage("offline");
            }
        }));
        list.addView(item("⚙", S.t("الإعدادات", "Settings"), new Runnable() {
            public void run() {
                showPage("settings");
            }
        }));
        list.addView(item("ⓘ", S.t("حول التطبيق", "About"), new Runnable() {
            public void run() {
                about();
            }
        }));
        sv.addView(list);
        d.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return d;
    }

    private View section(String label) {
        TextView t = Ui.text(this, label, 12, Theme.sub, true);
        t.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 4));
        t.setAllCaps(false);
        return t;
    }

    private View item(String icon, String label, final Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        row.setClickable(true);
        row.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf((Theme.primary & 0x00FFFFFF) | 0x33000000), null,
                Ui.round(Color.WHITE, 12, this)));
        TextView i = Ui.text(this, icon, 20, Theme.primary, true);
        i.setGravity(Gravity.CENTER);
        row.addView(i, new LinearLayout.LayoutParams(Ui.dp(this, 34), -2));
        TextView t = Ui.text(this, label, 15, Theme.text, false);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.setMargins(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        row.addView(t, tl);
        Ui.pressable(row);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
                r.run();
            }
        });
        return row;
    }

    void openDrawer() {
        if (drawerOpen) return;
        drawerOpen = true;
        scrim.setVisibility(View.VISIBLE);
        scrim.animate().alpha(1f).setDuration(220).start();
        drawer.animate().translationX(0).setDuration(240).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
    }

    void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        scrim.animate().alpha(0f).setDuration(200).withEndAction(new Runnable() {
            public void run() {
                if (!drawerOpen) scrim.setVisibility(View.GONE);
            }
        }).start();
        drawer.animate().translationX(-Ui.dp(this, 310)).setDuration(220).start();
    }

    void showMap() {
        page = null;
        topBar.setVisibility(View.GONE);
        pageHolder.setVisibility(View.GONE);
        pageHolder.removeAllViews();
        title.setText(S.t("مصدّر المعالم", "POI Exporter"));
        updateSummary();
        map.invalidate();
    }

    void showPage(String key) {
        View v;
        String t;
        switch (key) {
            case "home":
                v = new DashboardPage(this).build();
                t = S.t("لوحة المعلومات", "Dashboard");
                break;
            case "settings":
                v = pages.settings();
                t = S.t("الإعدادات", "Settings");
                break;
            case "area":
                v = pages.area();
                t = S.t("المنطقة المحددة", "Selected area");
                break;
            case "layers":
                v = pages.layers();
                t = S.t("الطبقات والتحميل", "Layers & download");
                break;
            case "kml":
                v = pages.kml();
                t = S.t("استيراد / تصدير KML", "Import / export KML");
                break;
            case "library":
                v = pages.library();
                t = S.t("المعالم المحفوظة والطبقات", "Saved landmarks & layers");
                break;
            case "converter":
                v = conv.build();
                t = S.t("محول الإحداثيات", "Coordinate converter");
                break;
            case "hub":
                v = hub.build();
                t = S.t("استيراد وتصدير", "Import & export");
                break;
            case "admin":
                v = admin.build();
                t = S.t("الحدود الإدارية", "Administrative boundaries");
                break;
            case "manage":
                v = manage.layers();
                t = S.t("إدارة الطبقات", "Layer manager");
                break;
            case "raster":
                v = rasterPage.build();
                t = S.t("صور جوية وفضائية", "Aerial & satellite images");
                break;
            case "analysis":
                v = analysis.build(1);
                t = S.t("تحليل متقدم", "Advanced analysis");
                break;
            case "attrs":
                v = attrTable.build();
                t = S.t("جدول الخصائص", "Attribute table");
                break;
            case "offline":
                v = offline.build();
                t = S.t("أوفلاين وسجل الأخطاء", "Offline & error log");
                break;
            case "report":
                v = report.build();
                t = S.t("طباعة وتقارير", "Print & reports");
                break;
            case "quality":
                v = quality.build();
                t = S.t("جودة البيانات", "Data quality");
                break;
            case "tools":
                v = tools.build();
                t = S.t("أدوات المنطقة والتحليل", "Area & analysis tools");
                break;
            case "backups":
                v = new BackupPage(this).build();
                t = S.t("النسخ الاحتياطي", "Backups");
                break;
            case "projects":
                v = manage.projects();
                t = S.t("المشاريع", "Projects");
                break;
            default:
                showMap();
                return;
        }
        ScrollView sv = new ScrollView(this);
        sv.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        sv.setFillViewport(false);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 40));
        wrap.addView(v, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(wrap, new ViewGroup.LayoutParams(-1, -2));
        pageHolder.removeAllViews();
        pageHolder.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        pageHolder.setAlpha(0f);
        pageHolder.setVisibility(View.VISIBLE);
        pageHolder.animate().alpha(1f).setDuration(180).start();
        title.setText(t);
        topBar.setVisibility(View.VISIBLE);
        page = key;
        closeDrawer();
    }

    // ------------------------------------------------------------------ GPS

    void locate() {
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION}, 21);
            return;
        }
        tracking = true;
        startLocation();
        if (lastLoc != null) onFix(lastLoc);
        else toast(S.t("جارٍ تحديد الموقع…", "Getting location…"));
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == 21) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) locate();
            else toast(S.t("لم يُمنح إذن الموقع", "Location permission denied"));
        }
    }

    private void onFix(Location l) {
        lastLoc = l;
        updateCard();
        dot.set(l.getLatitude(), l.getLongitude(), l.getAccuracy());
        if (centerOnFix) {
            centerOnFix = false;
            if (map.getZoomLevelDouble() < 15) map.getController().setZoom(16.0);
            map.getController().animateTo(new GeoPoint(l.getLatitude(), l.getLongitude()));
        }
        if (areaOnFix) {
            areaOnFix = false;
            setCenter(l.getLatitude(), l.getLongitude());
            zoomToArea();
        }
        map.invalidate();
    }

    void useLocationAsCenter() {
        if (lastLoc != null) {
            areaOnFix = true;
            onFix(lastLoc);
        } else {
            areaOnFix = true;
            locate();
        }
    }

    @SuppressWarnings("MissingPermission")
    private void startLocation() {
        try {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                return;
            if (lm == null) lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (ll == null) {
                ll = new LocationListener() {
                    public void onLocationChanged(Location l) {
                        onFix(l);
                    }

                    public void onProviderEnabled(String p) {
                    }

                    public void onProviderDisabled(String p) {
                    }

                    public void onStatusChanged(String p, int st, Bundle b) {
                    }
                };
            }
            lm.removeUpdates(ll);
            boolean any = false;
            for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                if (lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, 1000, 0f, ll);
                    Location k = lm.getLastKnownLocation(p);
                    if (k != null && lastLoc == null) lastLoc = k;
                    any = true;
                }
            }
            if (!any) toast(S.t("فعّل GPS من إعدادات الجهاز", "Turn on GPS in device settings"));
        } catch (SecurityException ignored) {
            // permission revoked
        }
    }

    private void stopLocation() {
        if (lm != null && ll != null) lm.removeUpdates(ll);
    }

    // ------------------------------------------------------------------ area

    CoordFmt.Fmt fmt() {
        return CoordFmt.Fmt.values()[Math.max(0, Math.min(3, prefs.fmt()))];
    }

    AreaSpec area() {
        double[] c = prefs.center();
        double w = prefs.width(), h = prefs.height();
        switch (prefs.shape()) {
            case 1:
                return AreaSpec.rotated(c[0], c[1], w, w, prefs.rot());
            case 2:
                return AreaSpec.circle(c[0], c[1], w);
            default:
                return AreaSpec.rotated(c[0], c[1], w, h, prefs.rot());
        }
    }

    void setCenter(double lat, double lon) {
        lat = Math.max(-84, Math.min(84, lat));
        lon = ((lon + 540) % 360) - 180;
        prefs.center(lat, lon);
        applyArea(false);
    }

    void applyArea(boolean zoom) {
        ao.set(area());
        ao.setSquare(prefs.shape() == 1);
        map.invalidate();
        updateSummary();
        pages.onAreaChanged();
        if (zoom) zoomToArea();
    }

    void zoomToArea() {
        AreaSpec a = area();
        double s = a.south, n = a.north, w = a.west, e = a.east;
        if (a.circle) {
            double[] r = Geo.rectAround(a.clat, a.clon, a.radius * 2, a.radius * 2);
            s = r[0];
            w = r[1];
            n = r[2];
            e = r[3];
        }
        final BoundingBox bb = new BoundingBox(n, e, s, w);
        map.post(new Runnable() {
            public void run() {
                map.zoomToBoundingBox(bb, true, Ui.dp(MainActivity.this, 40));
            }
        });
    }

    void zoomToData() {
        double[] b = fo.bounds();
        if (b == null) {
            toast(S.t("لا توجد بيانات محمّلة بعد", "No data loaded yet"));
            return;
        }
        double padLat = Math.max(0.0005, (b[3] - b[1]) * 0.05), padLon = Math.max(0.0005, (b[2] - b[0]) * 0.05);
        final BoundingBox bb = new BoundingBox(Math.min(85, b[3] + padLat), b[2] + padLon, Math.max(-85, b[1] - padLat), b[0] - padLon);
        map.post(new Runnable() {
            public void run() {
                map.zoomToBoundingBox(bb, true, Ui.dp(MainActivity.this, 30));
            }
        });
    }

    void updateSummary() {
        if (summary == null) return;
        AreaSpec a = area();
        String dim = a.circle
                ? S.t("دائرة نق ", "Circle r ") + fmtLen(a.radius)
                : fmtLen(a.widthM()) + " × " + fmtLen(a.heightM());
        int n = 0;
        for (LayerData l : DATA) n += l.features.size();
        summary.setText(S.t("المنطقة: ", "Area: ") + dim + String.format(Locale.US, " (%.2f km²)", a.areaKm2())
                + " • " + n + S.t(" عنصر", " items"));
        updateCard();
    }

    static String fmtLen(double m) {
        return m >= 1000 ? String.format(Locale.US, "%.2f km", m / 1000) : String.format(Locale.US, "%.0f m", m);
    }

    // ------------------------------------------------------------------ selection state

    Set<String> csv(String key, String def) {
        Set<String> s = new LinkedHashSet<>();
        String v = prefs.get(key, def);
        if (v != null) for (String p : v.split(",")) if (!p.trim().isEmpty()) s.add(p.trim());
        return s;
    }

    void saveCsv(String key, Set<String> s) {
        StringBuilder b = new StringBuilder();
        for (String x : s) b.append(b.length() > 0 ? "," : "").append(x);
        prefs.put(key, b.toString());
    }

    String allPoi() {
        StringBuilder b = new StringBuilder();
        for (Catalog.PoiCat c : Catalog.POI) b.append(b.length() > 0 ? "," : "").append(c.id);
        return b.toString();
    }

    // ------------------------------------------------------------------ download

    private String stepLabel(String key) {
        if ("admin".equals(key)) return S.t("جلب الحدود الإدارية…", "Fetching administrative boundaries…");
        if ("poi".equals(key)) return S.t("جلب المعالم…", "Fetching landmarks…");
        Catalog.LayerDef d = Catalog.layer(key);
        return S.t("جلب: ", "Fetching: ") + (d != null ? d.label(S.ar) : key);
    }

    void download() {
        final AreaSpec a = area();
        if (a.areaKm2() > 1500 && !bigOk) {
            message(S.t("منطقة كبيرة", "Large area"),
                    S.t("مساحة المنطقة " + String.format(Locale.US, "%.0f", a.areaKm2())
                                    + " كم². لا يوجد حد للمساحة، لكن التحميل قد يطول أو يفشل إذا كانت البيانات ضخمة (يُنصح بتقليل الطبقات). هل تريد المتابعة؟",
                            "Area is " + String.format(Locale.US, "%.0f", a.areaKm2())
                                    + " km². There is no limit, but the download may be slow or fail with huge data (try fewer layers). Continue?"),
                    S.t("متابعة", "Continue"), new Runnable() {
                        public void run() {
                            bigOk = true;
                            download();
                        }
                    });
            return;
        }
        bigOk = false;
        final Pipeline.Params p = new Pipeline.Params();
        p.area = a;
        p.poiCats.addAll(csv("poi", allPoi()));
        p.layerIds.addAll(csv("layers", ""));
        p.layerIds.addAll(csv("adm", ""));
        p.fillAdmin = prefs.flag("fillAdmin", true);
        p.includeUnnamed = prefs.flag("unnamed", false);
        p.custom = prefs.get("custom", "");
        p.arabic = S.ar;
        int[] lv = {4, 5, 6};
        for (int i = 0; i < 3; i++) {
            try {
                lv[i] = Integer.parseInt(prefs.get("lv" + (i + 4), String.valueOf(i + 4)).trim());
            } catch (NumberFormatException ignored) {
                // keep default
            }
        }
        p.adminLevels = lv;
        if (p.poiCats.isEmpty() && p.layerIds.isEmpty() && p.custom.trim().isEmpty()) {
            toast(S.t("اختر طبقة واحدة على الأقل من «الطبقات والتحميل»", "Select at least one layer in Layers & download"));
            showPage("layers");
            return;
        }
        cancel = false;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("جارٍ التحميل", "Downloading"), 18, Theme.text, true));
        final TextView msg = Ui.text(this, S.t("جارٍ الاتصال…", "Connecting…"), 14, Theme.sub, false);
        msg.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        box.addView(msg);
        final ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        pb.setIndeterminate(true);
        pb.setIndeterminateTintList(ColorStateList.valueOf(Theme.primary));
        pb.setProgressTintList(ColorStateList.valueOf(Theme.primary));
        box.addView(pb, new LinearLayout.LayoutParams(-1, Ui.dp(this, 8)));
        final Dialog dlg = card(box);
        box.addView(Ui.button(this, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                cancel = true;
                msg.setText(S.t("جارٍ الإلغاء…", "Cancelling…"));
            }
        }), Ui.lp(-1, -2, 0, this, 0, 14, 0, 0));
        dlg.setCancelable(false);
        dlg.show();
        final long t0 = System.currentTimeMillis();
        new Thread(new Runnable() {
            public void run() {
                Pipeline.Result res;
                try {
                    res = Pipeline.run(p, new Net(), new Pipeline.Progress() {
                        public void update(final String m, final int step, final int steps) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    msg.setText(stepLabel(m) + "  (" + step + "/" + steps + ")  •  " + (System.currentTimeMillis() - t0) / 1000 + S.t(" ث", " s"));
                                    pb.setIndeterminate(false);
                                    pb.setProgress(Math.max(5, (step - 1) * 100 / Math.max(1, steps)));
                                }
                            });
                        }

                        public boolean cancelled() {
                            return cancel;
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            dlg.dismiss();
                            message(S.t("فشل التحميل", "Download failed"), String.valueOf(t.getMessage()), null, null);
                        }
                    });
                    return;
                }
                final Pipeline.Result r = res;
                runOnUiThread(new Runnable() {
                    public void run() {
                        dlg.dismiss();
                        onDownloaded(r);
                    }
                });
            }
        }).start();
    }

    private void onDownloaded(Pipeline.Result r) {
        if (r.cancelled) {
            toast(S.t("أُلغي التحميل", "Download cancelled"));
            return;
        }
        DL = new ArrayList<>(r.layers);
        HIDDEN.removeAll(java.util.Collections.singleton("poi"));
        for (LayerData l : r.layers) HIDDEN.remove(l.id);
        rebuild();
        StringBuilder sb = new StringBuilder();
        sb.append(S.t("تم تحميل ", "Loaded ")).append(r.featureCount()).append(S.t(" عنصر:\n", " features:\n"));
        for (LayerData l : r.layers) sb.append("• ").append(l.label).append(": ").append(l.features.size()).append('\n');
        if (!r.warnings.isEmpty()) {
            sb.append('\n').append(S.t("تنبيهات:\n", "Warnings:\n"));
            for (String w : r.warnings) {
                int k = w.indexOf(':');
                String key = k > 0 ? w.substring(0, k) : w, rest = k > 0 ? w.substring(k + 1) : "";
                if ("admin".equals(key) && "none".equals(rest))
                    sb.append("• ").append(S.t("لم تُوجد حدود إدارية في هذه المنطقة؛ تُركت حقول الناحية/القضاء/المحافظة فارغة.",
                            "No administrative boundaries found here; NAHIYA/QADAA/GOVERNORAT left empty.")).append('\n');
                else sb.append("• ").append(stepLabel(key)).append(' ').append(rest).append('\n');
            }
        }
        zoomToData();
        final boolean any = r.featureCount() > 0;
        message(S.t("اكتمل التحميل", "Download complete"), sb.toString(), any ? S.t("تصدير الآن", "Export now") : null,
                any ? new Runnable() {
                    public void run() {
                        exportDialog();
                    }
                } : null);
    }

    // ------------------------------------------------------------------ export / import

    void exportDialog() {
        if (DATA.isEmpty()) {
            toast(S.t("لا توجد بيانات؛ حمّل المعالم أولاً أو استورد ملف KML", "No data; download or import first"));
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("تصدير البيانات", "Export data"), 18, Theme.text, true));
        TextView hint = Ui.text(this, S.t("سيُحفظ الملف في: ", "Saved to: ") + saveWhere(), 12, Theme.sub, false);
        hint.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
        box.addView(hint);
        final Dialog d = card(box);
        box.addView(Ui.button(this, "Shapefile (ZIP)", true, new Runnable() {
            public void run() {
                d.dismiss();
                export("shp");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        box.addView(Ui.button(this, "KML (" + S.t("بيني كويست", "PineQuest") + ")", false, new Runnable() {
            public void run() {
                d.dismiss();
                export("kml");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        box.addView(Ui.button(this, "KMZ", false, new Runnable() {
            public void run() {
                d.dismiss();
                export("kmz");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        box.addView(Ui.button(this, "CSV (Excel)", false, new Runnable() {
            public void run() {
                d.dismiss();
                export("csv");
            }
        }), Ui.lp(-1, -2, 0, this, 0, 4, 0, 4));
        d.show();
    }

    String saveWhere() {
        String f = prefs.folder();
        if (f == null) return "Downloads/PoiExporter";
        return Pages.folderName(f);
    }

    void export(final String kind) {
        if (DATA.isEmpty()) {
            toast(S.t("لا توجد بيانات", "No data"));
            return;
        }
        exportLayers(new ArrayList<>(DATA), kind, "poi");
    }

    void exportLayers(final List<LayerData> snap, final String kind, String prefix) {
        final CoordFmt.Fmt f = fmt();
        String safe = iq.gis.poiexporter.core.ShapeWriter.safeName(prefix);
        final String base = (safe.isEmpty() ? "poi" : safe) + "_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        final String name, mime;
        if (kind.equals("shp")) {
            name = base + "_shp.zip";
            mime = "application/zip";
        } else if (kind.equals("csv")) {
            name = base + ".csv";
            mime = "text/csv";
        } else if (kind.equals("kmz")) {
            name = base + ".kmz";
            mime = "application/vnd.google-earth.kmz";
        } else {
            name = base + ".kml";
            mime = "application/vnd.google-earth.kml+xml";
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("جارٍ التصدير…", "Exporting…"), 16, Theme.text, true));
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminateTintList(ColorStateList.valueOf(Theme.primary));
        box.addView(pb);
        final Dialog busy = card(box);
        busy.setCancelable(false);
        busy.show();
        new Thread(new Runnable() {
            public void run() {
                try {
                    final Storage.Saved sv = Storage.save(MainActivity.this, prefs, name, mime, new Storage.Writer() {
                        public void write(java.io.OutputStream os) throws java.io.IOException {
                            if (kind.equals("shp")) ShapeWriter.writeZip(snap, f, os);
                            else if (kind.equals("csv")) iq.gis.poiexporter.core.CsvWriter.write(snap, os);
                            else Kml.write(snap, "PoiExporter", f, kind.equals("kmz"), os);
                        }
                    });
                    runOnUiThread(new Runnable() {
                        public void run() {
                            busy.dismiss();
                            message(S.t("تم الحفظ ✔", "Saved ✔"), sv.where, S.t("مشاركة / فتح", "Share / open"),
                                    new Runnable() {
                                        public void run() {
                                            Storage.share(MainActivity.this, sv.uri, mime);
                                        }
                                    });
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            busy.dismiss();
                            message(S.t("فشل التصدير", "Export failed"), String.valueOf(t.getMessage()), null, null);
                        }
                    });
                }
            }
        }).start();
    }

    void pickImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    void pickBatch() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_BATCH);
    }

    void pickRestore() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        startActivityForResult(i, REQ_RESTORE);
    }

    void pickOffline() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_OFFLINE);
    }

    void pickRaster() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_RASTER);
    }

    void pickWorld() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_WORLD);
    }

    void pickHub() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_HUB);
    }

    void pickHubMany() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, REQ_HUB_MANY);
    }

    void pickFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_FOLDER);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res == RESULT_OK && data != null && req == REQ_HUB_MANY) {
            java.util.List<Uri> us = new java.util.ArrayList<>();
            java.util.List<String> ns = new java.util.ArrayList<>();
            if (data.getClipData() != null) {
                for (int k = 0; k < data.getClipData().getItemCount(); k++) us.add(data.getClipData().getItemAt(k).getUri());
            } else if (data.getData() != null) {
                us.add(data.getData());
            }
            for (Uri x : us) ns.add(displayName(x));
            if (!us.isEmpty()) hub.pickedMany(us, ns);
            return;
        }
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        if (req == REQ_FOLDER) {
            try {
                getContentResolver().takePersistableUriPermission(u,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {
                // some providers do not offer persistable grants
            }
            prefs.folder(u.toString());
            showPage("settings");
        } else if (req == REQ_IMPORT) {
            importFrom(u);
        } else if (req == REQ_BATCH) {
            conv.batchPicked(u, displayName(u));
        } else if (req == REQ_RESTORE) {
            manage.restorePicked(u);
        } else if (req == REQ_RASTER) {
            rasterPage.picked(u, displayName(u));
        } else if (req == REQ_WORLD) {
            rasterPage.worldPicked(u);
        } else if (req == MapElements.REQ_IMAGE) {
            elements.imagePicked(u);
        } else if (req == REQ_OFFLINE) {
            offline.picked(u, displayName(u));
        } else if (req == REQ_HUB) {
            hub.picked(u, displayName(u));
        }
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) {
            u = i.getData();
            if (u != null && isLinkScheme(u.getScheme())) {
                handleLink(u.toString());
                u = null;
            }
        } else if (Intent.ACTION_SEND.equals(i.getAction())) {
            u = i.getParcelableExtra(Intent.EXTRA_STREAM);
            String txt = i.getStringExtra(Intent.EXTRA_TEXT);
            if (u == null && txt != null) handleLink(iq.gis.poiexporter.core.MapLink.extractLink(txt));
        }
        if (u != null) importFrom(u);
        setIntent(new Intent());
    }

    private static boolean isLinkScheme(String s) {
        return "geo".equals(s) || "http".equals(s) || "https".equals(s);
    }

    /** A coordinate or map link arrived from another app: read the position, resolving short links on the network if needed. */
    void handleLink(final String link) {
        iq.gis.poiexporter.core.MapLink.Pos p = iq.gis.poiexporter.core.MapLink.parse(link);
        if (p != null) {
            linkDialog(p);
            return;
        }
        String kml = iq.gis.poiexporter.core.MapLink.myMapsKmlUrl(link);
        if (kml != null) {
            downloadMyMap(kml);
            return;
        }
        if (iq.gis.poiexporter.core.MapLink.isList(link)) {
            listLinkMessage();
            return;
        }
        if (!iq.gis.poiexporter.core.MapLink.isShort(link)) {
            message(S.t("لا توجد إحداثيات", "No coordinates"), S.t("لم أجد إحداثيات في هذا النص:\n", "No coordinates found in:\n") + link, null, null);
            return;
        }
        toast(S.t("جارٍ قراءة الرابط…", "Reading the link…"));
        new Thread(() -> {
            String cur = link;
            iq.gis.poiexporter.core.MapLink.Pos found = null;
            boolean net = false, list = false;
            String kmlUrl = null;
            try {
                for (int hop = 0; hop < 8 && found == null && !list && kmlUrl == null; hop++) {
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(cur).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(10000);
                    c.setReadTimeout(10000);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) PoiExporter");
                    c.setRequestProperty("Accept-Language", "en");
                    int code = c.getResponseCode();
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    net = true;
                    if (code / 100 != 3 || loc == null) break;
                    cur = iq.gis.poiexporter.core.MapLink.unwrapConsent(new java.net.URL(new java.net.URL(cur), loc).toString());
                    found = iq.gis.poiexporter.core.MapLink.parse(cur);
                    list = found == null && iq.gis.poiexporter.core.MapLink.isList(cur);
                    kmlUrl = iq.gis.poiexporter.core.MapLink.myMapsKmlUrl(cur);
                }
            } catch (Exception ignored) {
                // reported below
            }
            final iq.gis.poiexporter.core.MapLink.Pos res = found;
            final boolean isList = list, online = net;
            final String kmlFinal = kmlUrl;
            runOnUiThread(() -> {
                if (res != null) linkDialog(res);
                else if (kmlFinal != null) downloadMyMap(kmlFinal);
                else if (isList) listLinkMessage();
                else message(online ? S.t("لا توجد إحداثيات في الرابط", "No coordinates in the link") : S.t("تعذّر قراءة الرابط", "Could not read the link"),
                        online ? S.t("هذا الرابط لا يحمل إحداثيات. افتحه في تطبيق الخرائط وشارك «الإحداثيات» أو موقع مكان واحد.",
                                "This link carries no coordinates. Open it in the maps app and share the coordinates or a single place.")
                                : S.t("لم أستطع الاتصال بالإنترنت لقراءة الرابط المختصر.", "Could not go online to read the short link."), null, null);
            });
        }).start();
    }

    /** A shared Google saved-places list holds only a list id. Google gives no public way to read its places, so say so and offer what works. */
    private void listLinkMessage() {
        message(S.t("هذا رابط «قائمة أماكن» من Google", "This is a Google saved-places list"),
                S.t("روابط القوائم المحفوظة لا تحتوي إحداثيات، بل رمز القائمة فقط، ولا توفّر Google طريقة عامة لقراءة أماكنها داخل تطبيق آخر.\n\n"
                                + "الحلول المتاحة:\n• شارك مكاناً واحداً من القائمة (يعمل مباشرة).\n"
                                + "• انقل الأماكن إلى «خرائطي My Maps» من Google ثم شارك رابط الخريطة، أو صدّرها KML وافتح الملف هنا.\n"
                                + "• من Google Takeout يمكن تصدير «الأماكن المحفوظة».",
                        "A saved-list link holds only a list id, and Google offers no public way to read its places from another app.\n\n"
                                + "What works:\n• Share a single place from the list.\n"
                                + "• Copy the places into Google My Maps and share that map's link, or export KML and open the file here.\n"
                                + "• Export “Saved places” with Google Takeout."), null, null);
    }

    /** Shared Google My Maps map: its public KML export is downloaded and imported like any KML file. */
    private void downloadMyMap(final String kmlUrl) {
        toast(S.t("جارٍ تنزيل الخريطة (KML)…", "Downloading the map (KML)…"));
        new Thread(() -> {
            File out = new File(getCacheDir(), "mymap_" + System.currentTimeMillis() + ".kml");
            boolean ok = false;
            try {
                java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(kmlUrl).openConnection();
                c.setConnectTimeout(12000);
                c.setReadTimeout(20000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) PoiExporter");
                if (c.getResponseCode() == 200) {
                    try (InputStream in = c.getInputStream(); java.io.FileOutputStream fo2 = new java.io.FileOutputStream(out)) {
                        byte[] buf = new byte[16384];
                        int n;
                        long tot = 0;
                        while ((n = in.read(buf)) > 0 && tot < 30_000_000) {
                            fo2.write(buf, 0, n);
                            tot += n;
                        }
                        ok = tot > 100;
                    }
                }
                c.disconnect();
            } catch (Exception ignored) {
                // reported below
            }
            final boolean good = ok;
            runOnUiThread(() -> {
                if (good) importFrom(Uri.fromFile(out));
                else message(S.t("تعذّر تنزيل الخريطة", "Could not download the map"),
                        S.t("الخريطة غير مشتركة للعامة أو لا يوجد اتصال. اجعلها «أي شخص لديه الرابط» ثم أعد المحاولة.",
                                "The map is not shared publicly, or you are offline. Set it to “anyone with the link” and try again."), null, null);
            });
        }).start();
    }

    private void linkDialog(final iq.gis.poiexporter.core.MapLink.Pos p) {
        showMap();
        map.getController().setZoom(Math.max(map.getZoomLevelDouble(), 17.0));
        map.getController().setCenter(new org.osmdroid.util.GeoPoint(p.lat, p.lon));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, "📍 " + S.t("موقع من رابط", "Position from a link"), 19, Theme.text, true));
        if (!p.label.isEmpty()) box.addView(Ui.text(this, p.label, 15, Theme.primary, true));
        TextView c = Ui.text(this, CoordFmt.format(fmt(), p.lat, p.lon), 13, Theme.sub, false);
        c.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        c.setTextIsSelectable(true);
        box.addView(c, Ui.lp(-2, -2, 0, this, 0, 6, 0, 6));
        final Dialog d = card(box);
        box.addView(Ui.button(this, S.t("＋ إضافة معلم هنا", "＋ Add a landmark here"), true, () -> {
            d.dismiss();
            addDialog(p.lat, p.lon);
        }), Ui.lp(-1, -2, 0, this, 0, 8, 0, 0));
        box.addView(Ui.button(this, "📋 " + S.t("إضافة بقالب (الاسم فقط)", "Add with a template (name only)"), false, () -> {
            d.dismiss();
            quick.addByTemplate(p.lat, p.lon, p.label);
        }), Ui.lp(-1, -2, 0, this, 0, 8, 0, 0));
        box.addView(Ui.button(this, S.t("إغلاق", "Close"), false, d::dismiss), Ui.lp(-1, -2, 0, this, 0, 8, 0, 0));
        d.show();
    }

    private String displayName(Uri u) {
        Cursor c = null;
        try {
            c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
            // fall through
        } finally {
            if (c != null) c.close();
        }
        String s = u.getLastPathSegment();
        return s == null ? "import.kml" : s;
    }

    void importFrom(final Uri u) {
        final String nm = displayName(u);
        toast(S.t("جارٍ استيراد ", "Importing ") + nm);
        new Thread(new Runnable() {
            public void run() {
                try {
                    InputStream in = UriIO.open(MainActivity.this, u);
                    if (in == null) throw new java.io.IOException("cannot open");
                    final List<LayerData> got = new ArrayList<>();
                    try {
                        for (LayerData l : Kml.read(in, nm)) {
                            if (l.features.isEmpty()) continue;
                            LayerData g = new LayerData(Library.newId(), l.label, l.geom);
                            g.features.addAll(l.features);
                            got.add(g);
                        }
                    } finally {
                        in.close();
                    }
                    runOnUiThread(new Runnable() {
                        public void run() {
                            List<LayerData> added = new ArrayList<>();
                            for (LayerData g : got) added.add(WS.addLayerWithFeatures(g));
                            got.clear();
                            got.addAll(added);
                            int n = 0;
                            for (LayerData l : got) n += l.features.size();
                            rebuild();
                            showMap();
                            if (!got.isEmpty()) zoomToLayer(got.get(0));
                            message(S.t("تم الاستيراد والحفظ", "Imported & saved"),
                                    n + S.t(" عنصر في ", " features in ") + got.size() + S.t(" مجموعة (في «المعالم المحفوظة») من ", " groups (in Saved landmarks) from ") + nm,
                                    null, null);
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            ErrorLog.add("import", t);
                            message(S.t("تعذّر الاستيراد", "Import failed"), String.valueOf(t.getMessage()),
                                    t instanceof UriIO.NoAccess ? S.t("اختيار الملف", "Choose file") : null,
                                    t instanceof UriIO.NoAccess ? new Runnable() {
                                        public void run() {
                                            pickImport();
                                        }
                                    } : null);
                        }
                    });
                }
            }
        }).start();
    }

    void clearData() {
        DL = new ArrayList<>();
        rebuild();
    }

    // ------------------------------------------------------------------ dialogs & helpers

    Dialog card(View content) {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(S.ar ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        box.setBackground(Ui.round(Theme.card, 22, this));
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 18), Ui.dp(this, 20), Ui.dp(this, 18));
        box.addView(content, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int sw = getResources().getDisplayMetrics().widthPixels;
            w.setLayout(Math.min(sw - Ui.dp(this, 32), Ui.dp(this, 420)), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        box.setScaleX(0.92f);
        box.setScaleY(0.92f);
        box.setAlpha(0f);
        d.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            public void onShow(android.content.DialogInterface di) {
                box.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start();
            }
        });
        return d;
    }

    /** Dialog whose primary button runs {@code yes}; the other button just closes it. */
    void messageConfirm(String title, String msg, String yesLabel, final Runnable yes) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, title, 18, Theme.text, true));
        ScrollView sv = new ScrollView(this);
        sv.addView(Ui.text(this, msg, 14, Theme.sub, false));
        box.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        final Dialog d = card(box);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 12, 4, 0));
        r.addView(Ui.button(this, yesLabel, true, new Runnable() {
            public void run() {
                d.dismiss();
                yes.run();
            }
        }), Ui.lp(0, -2, 1f, this, 4, 12, 0, 0));
        box.addView(r);
        d.show();
    }

    void message(String title, String msg, String extraLabel, final Runnable extra) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, title, 18, Theme.text, true));
        ScrollView sv = new ScrollView(this);
        TextView t = Ui.text(this, msg, 14, Theme.sub, false);
        t.setTextIsSelectable(true);
        t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        sv.addView(t);
        box.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        final Dialog d = card(box);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إغلاق", "Close"), extra == null, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 6, 4, 0));
        if (extra != null) {
            r.addView(Ui.button(this, extraLabel, true, new Runnable() {
                public void run() {
                    d.dismiss();
                    extra.run();
                }
            }), Ui.lp(0, -2, 1f, this, 4, 6, 0, 0));
        }
        box.addView(r);
        d.show();
    }

    void showFeature(final Feature f, final LayerData layer) {
        StringBuilder sb = new StringBuilder();
        sb.append(S.t("الطبقة: ", "Layer: ")).append(layer.label).append('\n');
        String[] t9 = iq.gis.poiexporter.core.LandmarkFields.text(f);
        String[] n9 = iq.gis.poiexporter.core.LandmarkFields.NAMES;
        for (int i = 0; i < t9.length; i++) sb.append(n9[i]).append(": ").append(t9[i]).append('\n');
        double[] xy = iq.gis.poiexporter.core.LandmarkFields.xy(f, null);
        sb.append("x: ").append(iq.gis.poiexporter.core.LandmarkFields.num(xy[0], 2)).append('\n');
        sb.append("y: ").append(iq.gis.poiexporter.core.LandmarkFields.num(xy[1], 2)).append('\n');
        sb.append("link: ").append(iq.gis.poiexporter.core.LandmarkFields.link(f)).append('\n');
        for (java.util.Map.Entry<String, String> e : f.attrs.entrySet())
            if (!iq.gis.poiexporter.core.LandmarkFields.isStd(e.getKey())) sb.append(e.getKey()).append(": ").append(e.getValue()).append('\n');
        if (layer.kind.equals("reference") && !layer.source.isEmpty())
            sb.append('\n').append(S.t("المصدر: ", "Source: ")).append(layer.source).append('\n').append(layer.accuracyNote).append('\n');
        final String c = CoordFmt.format(fmt(), f.lat, f.lon);
        sb.append(S.t("الإحداثيات: ", "Coordinates: ")).append(c);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout gb = new LinearLayout(this);
        gb.setOrientation(LinearLayout.HORIZONTAL);
        gb.setGravity(Gravity.CENTER_VERTICAL);
        gb.setBackground(Ui.round(Theme.field, 12, this));
        gb.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 6), Ui.dp(this, 8));
        LinearLayout gt = new LinearLayout(this);
        gt.setOrientation(LinearLayout.VERTICAL);
        gt.addView(Ui.text(this, "📁 " + layer.label, 16.5f, Theme.primary, true));
        gt.addView(Ui.text(this, layer.features.size() + S.t(" عنصر في المجموعة", " items in this group"), 11.5f, Theme.sub, false));
        gb.addView(gt, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView sg = Ui.text(this, "⤴ " + S.t("إرسال المجموعة", "Send group"), 13, Theme.onPrimary, true);
        sg.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        sg.setBackground(Ui.round(Theme.primary, 12, this));
        sg.setClickable(true);
        Ui.pressable(sg);
        sg.setOnClickListener(v -> shareDialog(layer));
        gb.addView(sg);
        box.addView(gb, Ui.lp(-1, -2, 0, this, 0, 0, 0, 8));
        box.addView(Ui.text(this, "📍 " + (f.name.isEmpty() ? S.t("(بدون اسم)", "(unnamed)") : f.name), 18, Theme.text, true));
        ScrollView sv = new ScrollView(this);
        TextView t = Ui.text(this, sb.toString(), 14, Theme.sub, false);
        t.setTextIsSelectable(true);
        t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        sv.addView(t);
        box.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        final Dialog d = card(box);
        LinearLayout r1 = Ui.row(this);
        r1.addView(Ui.button(this, S.t("نسخ", "Copy"), false, new Runnable() {
            public void run() {
                copy(c);
            }
        }), Ui.lp(0, -2, 1f, this, 0, 6, 4, 0));
        r1.addView(Ui.button(this, S.t("مشاركة", "Share"), false, new Runnable() {
            public void run() {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, (f.name.isEmpty() ? "" : f.name + "\n") + (f.type.isEmpty() ? "" : f.type + "\n")
                        + c + "\nhttps://www.openstreetmap.org/?mlat=" + f.lat + "&mlon=" + f.lon + "#map=18/" + f.lat + "/" + f.lon);
                startActivity(Intent.createChooser(i, S.t("مشاركة", "Share")));
            }
        }), Ui.lp(0, -2, 1f, this, 4, 6, 0, 0));
        box.addView(r1);
        LinearLayout r1b = Ui.row(this);
        r1b.addView(Ui.button(this, "🔍 Zoom to", false, () -> {
            d.dismiss();
            flashTo(f);
        }), Ui.lp(0, -2, 1f, this, 0, 6, 4, 0));
        r1b.addView(Ui.button(this, "📊 " + S.t("عرض الجدول", "Show table"), false, () -> {
            d.dismiss();
            attrTable.openFor(layer, f);
        }), Ui.lp(0, -2, 1f, this, 4, 6, 0, 0));
        box.addView(r1b);
        LinearLayout r2 = Ui.row(this);
        final boolean saved = WS.layer(layer.id) != null;
        if (saved) {
            r2.addView(Ui.button(this, S.t("✎ تعديل", "✎ Edit"), false, new Runnable() {
                public void run() {
                    d.dismiss();
                    editDialog(f, layer);
                }
            }), Ui.lp(0, -2, 1f, this, 0, 6, 4, 0));
        }
        if (!layer.kind.equals("reference")) {
            r2.addView(Ui.button(this, S.t("🗑 حذف", "🗑 Delete"), false, new Runnable() {
                public void run() {
                    d.dismiss();
                    deleteFeature(f, layer);
                    toast(S.t("تم الحذف (يمكن التراجع من إدارة الطبقات)", "Deleted (undo from the layer manager)"));
                }
            }), Ui.lp(0, -2, 1f, this, saved ? 4 : 0, 6, 4, 0));
        }
        r2.addView(Ui.button(this, S.t("إغلاق", "Close"), true, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 4, 6, 0, 0));
        box.addView(r2);
        d.show();
    }

    /** Edits a saved landmark with the same nine fields as the add form. One undo step. */
    void editDialog(final Feature f, final LayerData layer) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(Ui.text(this, S.t("تعديل معلم", "Edit landmark"), 20, Theme.text, true));
        final iq.gis.poiexporter.core.Utm.Result utm = iq.gis.poiexporter.core.Utm.fromLatLon(f.lat, f.lon);
        final String[] names = iq.gis.poiexporter.core.LandmarkFields.NAMES;
        final android.widget.EditText[] ed = new android.widget.EditText[names.length];
        final String xs = String.format(Locale.US, "%.2f", utm.easting), ys = String.format(Locale.US, "%.2f", utm.northing);
        String[] cur = iq.gis.poiexporter.core.LandmarkFields.text(f);
        for (int i = 0; i < names.length; i++) {
            boolean num = i == 6 || i == 7;
            ed[i] = Ui.field(this, names[i], num ? (android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
                    : android.text.InputType.TYPE_CLASS_TEXT);
            ed[i].setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            ed[i].setGravity(Gravity.START);
            ed[i].setText(i < 6 ? cur[i] : i == 6 ? xs : i == 7 ? ys : iq.gis.poiexporter.core.LandmarkFields.link(f));
            box.addView(ed[i], Ui.lp(-1, -2, 0, this, 0, i == 0 ? 10 : 8, 0, 0));
            if (i == 2) box.addView(SectorPicker.build(this, ed[2], ed[1]));
        }
        box.addView(Ui.text(this, S.t("x وy إحداثيات UTM (المنطقة " + utm.zoneLabel() + "). تغييرهما ينقل النقطة.",
                "x and y are UTM (zone " + utm.zoneLabel() + "). Changing them moves the point."), 11.5f, Theme.sub, false), Ui.lp(-2, -2, 0, this, 0, 6, 0, 0));
        ScrollView sc = new ScrollView(this);
        sc.addView(box);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.addView(sc, new LinearLayout.LayoutParams(-1, Ui.dp(this, 460)));
        final Dialog d = card(outer);
        LinearLayout r = Ui.row(this);
        r.addView(Ui.button(this, S.t("إلغاء", "Cancel"), false, new Runnable() {
            public void run() {
                d.dismiss();
            }
        }), Ui.lp(0, -2, 1f, this, 0, 12, 4, 0));
        r.addView(Ui.button(this, S.t("حفظ", "Save"), true, new Runnable() {
            public void run() {
                Feature before = f.copy();
                Feature after = f.copy();
                String xt = ed[6].getText().toString().trim(), yt = ed[7].getText().toString().trim();
                if (!xt.equals(xs) || !yt.equals(ys)) {
                    if (f.geom != Feature.POINT) {
                        toast(S.t("تعديل x وy متاح للنقاط فقط", "x/y editing is for points only"));
                        return;
                    }
                    try {
                        double[] ll = iq.gis.poiexporter.core.Utm.toLatLon(utm.zone, utm.north, Double.parseDouble(xt), Double.parseDouble(yt));
                        after.parts.set(0, new double[]{ll[1], ll[0]});
                        after.lat = ll[0];
                        after.lon = ll[1];
                    } catch (RuntimeException ex) {
                        toast(S.t("قيمة x أو y غير صالحة", "Invalid x or y"));
                        return;
                    }
                }
                after.name = ed[0].getText().toString().trim();
                after.type = ed[1].getText().toString().trim();
                after.category = ed[2].getText().toString().trim();
                after.qadaa = ed[3].getText().toString().trim();
                after.nahiya = ed[4].getText().toString().trim();
                after.governorate = ed[5].getText().toString().trim();
                iq.gis.poiexporter.core.LandmarkFields.setLink(after, ed[8].getText().toString().trim());
                after.updated = java.time.LocalDate.now().toString();
                d.dismiss();
                WS.updateFeature(before, after, S.t("تعديل ", "Edit ") + (after.name.isEmpty() ? after.type : after.name));
                rebuild();
                toast(S.t("تم الحفظ", "Saved"));
            }
        }), Ui.lp(0, -2, 1f, this, 4, 12, 0, 0));
        outer.addView(r);
        d.show();
    }

    void about() {
        message(S.t("حول التطبيق", "About"),
                S.t("مصدّر المعالم v2.0\nيجلب المعالم والطرق والأنهار والبحيرات والسدود والحدود الإدارية من OpenStreetMap ويصدّرها إلى Shapefile / KML / KMZ.\n\nالبيانات © مساهمو OpenStreetMap (ترخيص ODbL).\nحدود الناحية/القضاء/المحافظة تُحدَّد من مستويات admin_level (الافتراضي 4/5/6) ويمكن تعديلها من «الطبقات والتحميل».",
                        "POI Exporter v2.0\nDownloads landmarks, roads, rivers, lakes, dams and administrative boundaries from OpenStreetMap and exports Shapefile / KML / KMZ.\n\nData © OpenStreetMap contributors (ODbL).\nNahiya/qadaa/governorate come from admin_level (default 4/5/6), editable in Layers & download."),
                null, null);
    }

    void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("coords", text));
        toast(S.t("تم النسخ", "Copied"));
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
