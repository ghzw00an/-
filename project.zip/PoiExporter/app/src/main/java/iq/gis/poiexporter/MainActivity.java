package iq.gis.poiexporter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import iq.gis.poiexporter.core.AdminIndex;
import iq.gis.poiexporter.core.Poi;
import iq.gis.poiexporter.core.ShapefileWriter;
import iq.gis.poiexporter.core.Utm;

import org.osmdroid.config.Configuration;
import org.osmdroid.config.IConfigurationProvider;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polygon;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private MapView map;
    private EditText customEt, gridEt, govEt, qadaaEt, nahiyaEt;
    private CheckBox adminCb, unnamedCb;
    private Button catBtn, fetchBtn, exportBtn;
    private TextView status;
    private SharedPreferences prefs;
    private boolean[] sel;

    private final List<Poi> results = new ArrayList<>();
    private Polygon areaOverlay;
    private final List<Marker> markers = new ArrayList<>();
    private volatile boolean cancel;
    private Thread worker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("poi_exporter", MODE_PRIVATE);

        sel = new boolean[OverpassApi.CATEGORIES.length];
        for (String s : prefs.getString("cats", "0,2,5").split(",")) {
            try {
                int i = Integer.parseInt(s.trim());
                if (i >= 0 && i < sel.length) sel[i] = true;
            } catch (NumberFormatException ignored) {
            }
        }

        IConfigurationProvider cfg = Configuration.getInstance();
        cfg.load(this, getSharedPreferences("osmdroid", MODE_PRIVATE));
        cfg.setUserAgentValue(getPackageName());
        cfg.setOsmdroidBasePath(new File(getCacheDir(), "osmdroid"));
        cfg.setOsmdroidTileCache(new File(getCacheDir(), "osmdroid/tiles"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.getController().setZoom(13.0);
        map.getController().setCenter(new GeoPoint(33.3152, 44.3661));
        root.addView(map, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 5f));

        ScrollView sv = new ScrollView(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int p = dp(10);
        panel.setPadding(p, p, p, p);
        sv.addView(panel);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 4f));

        catBtn = new Button(this);
        catBtn.setOnClickListener(v -> showCategories());
        panel.addView(catBtn);
        updateCatLabel();

        customEt = new EditText(this);
        customEt.setHint("مرشح مخصص اختياري بصيغة key=value مثل amenity=marketplace");
        customEt.setSingleLine(true);
        customEt.setText(prefs.getString("custom", ""));
        panel.addView(customEt);

        gridEt = new EditText(this);
        gridEt.setHint("تقسيم المنطقة إلى شبكة (1-8)، مثال 2 = 2×2");
        gridEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        gridEt.setText(prefs.getString("grid", "1"));
        panel.addView(gridEt);

        unnamedCb = new CheckBox(this);
        unnamedCb.setText("تضمين المعالم بلا اسم");
        unnamedCb.setChecked(prefs.getBoolean("unnamed", false));
        panel.addView(unnamedCb);

        adminCb = new CheckBox(this);
        adminCb.setText("تحديد الناحية والقضاء والمحافظة من حدود OpenStreetMap");
        adminCb.setChecked(prefs.getBoolean("admin", true));
        panel.addView(adminCb);

        TextView lvTitle = new TextView(this);
        lvTitle.setText("مستويات الحدود في OSM (المحافظة / القضاء / الناحية):");
        panel.addView(lvTitle);
        LinearLayout lv = new LinearLayout(this);
        lv.setOrientation(LinearLayout.HORIZONTAL);
        govEt = levelField(lv, "gov", "4");
        qadaaEt = levelField(lv, "qadaa", "5");
        nahiyaEt = levelField(lv, "nahiya", "6");
        panel.addView(lv);

        fetchBtn = new Button(this);
        fetchBtn.setText("جلب المعالم من المنطقة الظاهرة على الخريطة");
        fetchBtn.setOnClickListener(v -> onFetchClicked());
        panel.addView(fetchBtn);

        exportBtn = new Button(this);
        exportBtn.setText("تصدير Shapefile");
        exportBtn.setOnClickListener(v -> onExportClicked());
        panel.addView(exportBtn);

        Button convBtn = new Button(this);
        convBtn.setText("محوّل الإحداثيات (UTM ↔ خطوط الطول والعرض)");
        convBtn.setOnClickListener(v -> showConverter());
        panel.addView(convBtn);

        status = new TextView(this);
        status.setText("حرّك الخريطة وكبّرها حتى تغطي المنطقة المطلوبة ثم اضغط جلب.\nالبيانات: © مساهمو OpenStreetMap");
        status.setPadding(0, dp(8), 0, 0);
        panel.addView(status);

        setContentView(root);
    }

    private EditText levelField(LinearLayout row, String prefKey, String def) {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setSingleLine(true);
        e.setText(prefs.getString("lv_" + prefKey, def));
        row.addView(e, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return e;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void updateCatLabel() {
        int n = 0;
        for (boolean b : sel) if (b) n++;
        catBtn.setText("اختيار الفئات (" + n + " مختارة)");
    }

    private void showCategories() {
        String[] names = new String[OverpassApi.CATEGORIES.length];
        for (int i = 0; i < names.length; i++) names[i] = OverpassApi.CATEGORIES[i].label;
        final boolean[] tmp = sel.clone();
        new AlertDialog.Builder(this)
                .setTitle("الفئات")
                .setMultiChoiceItems(names, tmp, (d, which, checked) -> tmp[which] = checked)
                .setPositiveButton("تم", (d, w) -> {
                    sel = tmp;
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < sel.length; i++) if (sel[i]) sb.append(sb.length() > 0 ? "," : "").append(i);
                    prefs.edit().putString("cats", sb.toString()).apply();
                    updateCatLabel();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        map.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        map.onPause();
    }

    @Override
    protected void onDestroy() {
        cancel = true;
        super.onDestroy();
    }

    private void setStatus(final String s) {
        runOnUiThread(() -> status.setText(s));
    }

    // ------------------------------------------------------------------ fetching

    private int intOr(EditText e, int def) {
        try {
            return Integer.parseInt(normalize(e.getText().toString()));
        } catch (NumberFormatException ex) {
            return def;
        }
    }

    private void onFetchClicked() {
        if (worker != null && worker.isAlive()) {
            cancel = true;
            setStatus("جارٍ الإيقاف...");
            return;
        }
        boolean any = false;
        for (boolean b : sel) any |= b;
        final String custom = customEt.getText().toString().trim();
        if (!any && custom.isEmpty()) {
            Toast.makeText(this, "اختر فئة واحدة على الأقل", Toast.LENGTH_LONG).show();
            return;
        }
        final int grid = Math.max(1, Math.min(8, intOr(gridEt, 1)));
        final boolean admin = adminCb.isChecked();
        final boolean unnamed = unnamedCb.isChecked();
        final int[] levels = {intOr(govEt, 4), intOr(qadaaEt, 5), intOr(nahiyaEt, 6)};
        prefs.edit().putString("custom", custom).putString("grid", String.valueOf(grid))
                .putBoolean("admin", admin).putBoolean("unnamed", unnamed)
                .putString("lv_gov", String.valueOf(levels[0])).putString("lv_qadaa", String.valueOf(levels[1]))
                .putString("lv_nahiya", String.valueOf(levels[2])).apply();

        BoundingBox bb = map.getBoundingBox();
        final double south = bb.getLatSouth(), north = bb.getLatNorth();
        final double west = bb.getLonWest(), east = bb.getLonEast();
        showArea(south, west, north, east);
        startFetch(sel.clone(), custom, grid, admin, unnamed, levels, south, west, north, east);
    }

    private void showArea(double s, double w, double n, double e) {
        if (areaOverlay != null) map.getOverlays().remove(areaOverlay);
        areaOverlay = new Polygon();
        List<GeoPoint> pts = new ArrayList<>();
        pts.add(new GeoPoint(n, w));
        pts.add(new GeoPoint(n, e));
        pts.add(new GeoPoint(s, e));
        pts.add(new GeoPoint(s, w));
        pts.add(new GeoPoint(n, w));
        areaOverlay.setPoints(pts);
        areaOverlay.getFillPaint().setColor(0x2200AAFF);
        areaOverlay.getOutlinePaint().setColor(Color.BLUE);
        areaOverlay.getOutlinePaint().setStrokeWidth(4f);
        map.getOverlays().add(areaOverlay);
        map.invalidate();
    }

    private void startFetch(final boolean[] cats, final String custom, final int grid, final boolean admin,
                            final boolean unnamed, final int[] levels,
                            final double south, final double west, final double north, final double east) {
        cancel = false;
        fetchBtn.setText("إيقاف");
        worker = new Thread(() -> {
            Map<String, Poi> found = new LinkedHashMap<>();
            String error = null;
            String note = "";
            double dLat = (north - south) / grid, dLon = (east - west) / grid;
            int cell = 0, cells = grid * grid;
            outer:
            for (int gi = 0; gi < grid; gi++) {
                for (int gj = 0; gj < grid; gj++) {
                    cell++;
                    if (cancel) break outer;
                    double s = south + gi * dLat, w = west + gj * dLon;
                    setStatus("جلب المعالم: المربع " + cell + "/" + cells + " — " + found.size() + " معلم حتى الآن");
                    try {
                        for (Poi poi : OverpassApi.fetchPois(s, w, s + dLat, w + dLon, cats, custom, unnamed)) {
                            if (!found.containsKey(poi.id)) found.put(poi.id, poi);
                        }
                    } catch (IOException ex) {
                        error = ex.getMessage();
                        break outer;
                    }
                }
            }
            final List<Poi> list = new ArrayList<>(found.values());

            if (admin && !cancel && error == null && !list.isEmpty()) {
                setStatus("جلب الحدود الإدارية...");
                try {
                    AdminIndex idx = OverpassApi.fetchAdmin(south, west, north, east, levels);
                    if (idx.size() == 0) {
                        note = "لم تُعثر حدود إدارية بهذه المستويات، راجع أرقام المستويات.";
                    } else {
                        for (Poi poi : list) {
                            poi.governorate = idx.find(levels[0], poi.lat, poi.lon);
                            poi.qadaa = idx.find(levels[1], poi.lat, poi.lon);
                            poi.nahiya = idx.find(levels[2], poi.lat, poi.lon);
                        }
                    }
                } catch (IOException ex) {
                    note = "تعذّر جلب الحدود الإدارية (" + ex.getMessage() + ")، ستكون حقولها فارغة.";
                }
            }

            final String err = error;
            final String fnote = note;
            final boolean wasCancelled = cancel;
            runOnUiThread(() -> {
                results.clear();
                results.addAll(list);
                showMarkers();
                fetchBtn.setText("جلب المعالم من المنطقة الظاهرة على الخريطة");
                String msg = "تم جلب " + list.size() + " معلم";
                if (wasCancelled) msg += " (أُوقف الجلب)";
                if (err != null) msg += "\nتوقف بسبب خطأ: " + err;
                if (!fnote.isEmpty()) msg += "\n" + fnote;
                if (!list.isEmpty()) msg += "\nاضغط «تصدير Shapefile» لحفظها.";
                msg += "\nالبيانات: © مساهمو OpenStreetMap";
                status.setText(msg);
            });
        });
        worker.start();
    }

    private void showMarkers() {
        for (Marker m : markers) map.getOverlays().remove(m);
        markers.clear();
        int max = Math.min(results.size(), 500); // keep the map responsive
        for (int i = 0; i < max; i++) {
            Poi poi = results.get(i);
            Marker m = new Marker(map);
            m.setPosition(new GeoPoint(poi.lat, poi.lon));
            m.setTitle(poi.name.isEmpty() ? "(بلا اسم)" : poi.name);
            m.setSubDescription(poi.category);
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            map.getOverlays().add(m);
            markers.add(m);
        }
        map.invalidate();
    }

    // ------------------------------------------------------------------ export

    private void onExportClicked() {
        if (results.isEmpty()) {
            Toast.makeText(this, "لا توجد معالم لتصديرها. اجلبها أولاً.", Toast.LENGTH_LONG).show();
            return;
        }
        final List<Poi> snapshot = new ArrayList<>(results);
        final String base = "poi_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        status.setText("جارٍ التصدير...");
        new Thread(() -> {
            try {
                File dir = new File(getCacheDir(), base);
                ShapefileWriter.write(dir, base, snapshot);

                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, base + ".zip");
                v.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                final Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new IOException("تعذّر إنشاء الملف في التنزيلات");
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) throw new IOException("تعذّر فتح الملف للكتابة");
                try {
                    ShapefileWriter.zipParts(dir, base, os);
                } finally {
                    os.close();
                }
                for (File f : dir.listFiles()) f.delete();
                dir.delete();

                runOnUiThread(() -> {
                    status.setText("حُفظ " + snapshot.size() + " معلم في: التنزيلات/" + base + ".zip");
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("تم التصدير")
                            .setMessage("الملف: Downloads/" + base + ".zip\nيحتوي shp و shx و dbf و prj و cpg.")
                            .setPositiveButton("مشاركة", (d, w) -> {
                                Intent send = new Intent(Intent.ACTION_SEND);
                                send.setType("application/zip");
                                send.putExtra(Intent.EXTRA_STREAM, uri);
                                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                startActivity(Intent.createChooser(send, "مشاركة الملف"));
                            })
                            .setNegativeButton("إغلاق", null)
                            .show();
                });
            } catch (IOException ex) {
                setStatus("فشل التصدير: " + ex.getMessage());
            }
        }).start();
    }

    // ------------------------------------------------------------------ converter

    /** Accepts Arabic-Indic digits and the Arabic decimal separator. */
    private static String normalize(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.trim().toCharArray()) {
            if (c >= '٠' && c <= '٩') sb.append((char) ('0' + (c - '٠')));
            else if (c >= '۰' && c <= '۹') sb.append((char) ('0' + (c - '۰')));
            else if (c == '٫' || c == '،' || c == ',') sb.append('.');
            else sb.append(c);
        }
        return sb.toString();
    }

    private static double num(EditText e) {
        return Double.parseDouble(normalize(e.getText().toString()));
    }

    private EditText field(LinearLayout parent, String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        parent.addView(e);
        return e;
    }

    private void showConverter() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        box.setPadding(p, p, p, 0);

        final EditText latEt = field(box, "خط العرض (Lat) بالدرجات العشرية");
        final EditText lonEt = field(box, "خط الطول (Lon) بالدرجات العشرية");
        Button toUtm = new Button(this);
        toUtm.setText("تحويل إلى UTM ↓");
        box.addView(toUtm);

        final EditText zoneEt = field(box, "المنطقة (Zone) مثال 38");
        final CheckBox southCb = new CheckBox(this);
        southCb.setText("النصف الجنوبي (غير محدد = شمال)");
        box.addView(southCb);
        final EditText eEt = field(box, "X (Easting) بالمتر");
        final EditText nEt = field(box, "Y (Northing) بالمتر");
        Button toLl = new Button(this);
        toLl.setText("تحويل إلى Lat/Lon ↑");
        box.addView(toLl);

        toUtm.setOnClickListener(v -> {
            try {
                Utm.Result r = Utm.fromLatLon(num(latEt), num(lonEt));
                zoneEt.setText(String.valueOf(r.zone));
                southCb.setChecked(!r.north);
                eEt.setText(String.format(Locale.US, "%.2f", r.easting));
                nEt.setText(String.format(Locale.US, "%.2f", r.northing));
            } catch (NumberFormatException ex) {
                Toast.makeText(this, "تحقق من القيم المدخلة", Toast.LENGTH_SHORT).show();
            }
        });
        toLl.setOnClickListener(v -> {
            try {
                int zone = (int) num(zoneEt);
                if (zone < 1 || zone > 60) throw new NumberFormatException();
                double[] ll = Utm.toLatLon(zone, !southCb.isChecked(), num(eEt), num(nEt));
                latEt.setText(String.format(Locale.US, "%.8f", ll[0]));
                lonEt.setText(String.format(Locale.US, "%.8f", ll[1]));
            } catch (NumberFormatException ex) {
                Toast.makeText(this, "تحقق من القيم المدخلة", Toast.LENGTH_SHORT).show();
            }
        });

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this).setTitle("محوّل الإحداثيات (WGS84)").setView(sv)
                .setPositiveButton("إغلاق", null).show();
    }
}
