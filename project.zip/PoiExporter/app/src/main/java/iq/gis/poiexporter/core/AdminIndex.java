package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Local point-in-polygon lookup over administrative boundaries.
 * Each area is stored as the union of its outer ways; an even-odd crossing test over all
 * segments gives the right answer even when a ring is split across several ways.
 */
public final class AdminIndex {
    private static final class Area {
        int level;
        String name;
        List<double[]> ways; // each way: lat0, lon0, lat1, lon1, ...
        double minLat = 1e9, maxLat = -1e9, minLon = 1e9, maxLon = -1e9;
    }

    private final List<Area> areas = new ArrayList<>();

    /** @param ways each array is interleaved lat,lon pairs. */
    public void add(int level, String name, List<double[]> ways) {
        Area a = new Area();
        a.level = level;
        a.name = name;
        a.ways = ways;
        for (double[] w : ways) {
            for (int i = 0; i + 1 < w.length; i += 2) {
                a.minLat = Math.min(a.minLat, w[i]);
                a.maxLat = Math.max(a.maxLat, w[i]);
                a.minLon = Math.min(a.minLon, w[i + 1]);
                a.maxLon = Math.max(a.maxLon, w[i + 1]);
            }
        }
        areas.add(a);
    }

    public int size() {
        return areas.size();
    }

    /** Name of the first area of the given level containing the point, or "". */
    public String find(int level, double lat, double lon) {
        for (Area a : areas) {
            if (a.level != level) continue;
            if (lat < a.minLat || lat > a.maxLat || lon < a.minLon || lon > a.maxLon) continue;
            if (contains(a, lat, lon)) return a.name;
        }
        return "";
    }

    private static boolean contains(Area a, double y, double x) {
        boolean inside = false;
        for (double[] w : a.ways) {
            for (int i = 0; i + 3 < w.length; i += 2) {
                double yi = w[i], xi = w[i + 1], yj = w[i + 2], xj = w[i + 3];
                if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside;
            }
        }
        return inside;
    }
}
