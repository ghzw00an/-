package iq.gis.poiexporter.core;

import java.util.ArrayList;
import java.util.List;

/** Local lookup of the administrative area containing a point. */
public final class AdminIndex {
    public static final class Entry {
        public final int level;
        public final Feature polygon;
        final double minX, minY, maxX, maxY;

        Entry(int level, Feature polygon) {
            this.level = level;
            this.polygon = polygon;
            double[] b = Geo.bbox(polygon);
            minX = b[0];
            minY = b[1];
            maxX = b[2];
            maxY = b[3];
        }
    }

    private final List<Entry> entries = new ArrayList<>();

    public void add(int level, Feature polygon) {
        if (polygon.geom == Feature.POLYGON && !polygon.parts.isEmpty()) entries.add(new Entry(level, polygon));
    }

    public int size() {
        return entries.size();
    }

    /** Name of the first area of that level containing the point, or "". */
    public String find(int level, double lat, double lon) {
        for (Entry e : entries) {
            if (e.level != level) continue;
            if (lon < e.minX || lon > e.maxX || lat < e.minY || lat > e.maxY) continue;
            if (Geo.inPolygon(e.polygon, lon, lat)) return e.polygon.name;
        }
        return "";
    }
}
