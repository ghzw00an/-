package iq.gis.poiexporter.core.geo;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Statistics of the features that fall inside an area. */
public final class Stats {
    private Stats() {
    }

    /** Simple table of strings, ready for CSV export or a report page. */
    public static final class Table {
        public final List<String> header = new ArrayList<>();
        public final List<String[]> rows = new ArrayList<>();

        public String toCsv() {
            StringBuilder b = new StringBuilder();
            line(b, header.toArray(new String[0]));
            for (String[] r : rows) line(b, r);
            return b.toString();
        }

        private static void line(StringBuilder b, String[] cells) {
            for (int i = 0; i < cells.length; i++) {
                if (i > 0) b.append(',');
                String c = cells[i] == null ? "" : cells[i];
                if (c.indexOf(',') >= 0 || c.indexOf('"') >= 0 || c.indexOf('\n') >= 0) c = "\"" + c.replace("\"", "\"\"") + "\"";
                b.append(c);
            }
            b.append("\r\n");
        }
    }

    /** What to group by. */
    public enum By { TYPE, CATEGORY, GOVERNORATE, QADAA, NAHIYA, LAYER }

    public static final class Result {
        public int points, lines, polygons;
        public double lengthM, areaM2;
        public final Map<String, Integer> counts = new LinkedHashMap<>();

        public int total() {
            return points + lines + polygons;
        }
    }

    private static String key(Feature f, LayerData l, By by) {
        String k;
        switch (by) {
            case TYPE: k = f.type; break;
            case CATEGORY: k = f.category; break;
            case GOVERNORATE: k = f.governorate; break;
            case QADAA: k = f.qadaa; break;
            case NAHIYA: k = f.nahiya; break;
            default: k = l == null ? "" : l.label;
        }
        return k == null || k.trim().isEmpty() ? S.t("(غير محدد)", "(unspecified)") : k.trim();
    }

    /**
     * Counts the features of the layers inside (or touching, per mode) the polygon; area==null means no spatial filter.
     * Totals: number of points/lines/polygons, summed line length and polygon area (ellipsoidal, whole features).
     */
    public static Result compute(List<LayerData> layers, Feature area, GeoOps.Mode mode, By by) {
        Result r = new Result();
        Map<String, Integer> m = new LinkedHashMap<>();
        for (LayerData l : layers) {
            List<Feature> fs = area == null ? l.features : GeoOps.select(l.features, area, mode);
            for (Feature f : fs) {
                if (f.geom == Feature.POINT) r.points++;
                else if (f.geom == Feature.LINE) {
                    r.lines++;
                    r.lengthM += Geodesy.length(f);
                } else {
                    r.polygons++;
                    r.areaM2 += Geodesy.area(f);
                }
                String k = key(f, l, by);
                Integer c = m.get(k);
                m.put(k, c == null ? 1 : c + 1);
            }
        }
        List<Map.Entry<String, Integer>> es = new ArrayList<>(m.entrySet());
        Collections.sort(es, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                int c = b.getValue().compareTo(a.getValue());
                return c != 0 ? c : a.getKey().compareTo(b.getKey());
            }
        });
        for (Map.Entry<String, Integer> e : es) r.counts.put(e.getKey(), e.getValue());
        return r;
    }

    /** Result as a table: group, count, share. A totals row is appended. */
    public static Table table(Result r, By by) {
        Table t = new Table();
        String g;
        switch (by) {
            case TYPE: g = S.t("النوع", "Type"); break;
            case CATEGORY: g = S.t("الفئة", "Category"); break;
            case GOVERNORATE: g = S.t("المحافظة", "Governorate"); break;
            case QADAA: g = S.t("القضاء", "Qadaa"); break;
            case NAHIYA: g = S.t("الناحية", "Nahiya"); break;
            default: g = S.t("الطبقة", "Layer");
        }
        t.header.add(g);
        t.header.add(S.t("العدد", "Count"));
        t.header.add(S.t("النسبة %", "Share %"));
        int tot = Math.max(1, r.total());
        for (Map.Entry<String, Integer> e : r.counts.entrySet())
            t.rows.add(new String[]{e.getKey(), String.valueOf(e.getValue()),
                    String.format(Locale.US, "%.1f", 100.0 * e.getValue() / tot)});
        t.rows.add(new String[]{S.t("المجموع", "Total"), String.valueOf(r.total()), "100.0"});
        return t;
    }
}
