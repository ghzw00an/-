package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.core.crs.Crs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Side information collected by readers while they stream. */
public final class ReadInfo {
    /** CRS of the whole file when declared, else null (unknown). */
    public Crs crs;
    /** Per layer CRS (GeoPackage); falls back to crs. */
    public final Map<String, Crs> layerCrs = new HashMap<>();
    public final List<String> warnings = new ArrayList<>();
    /** Records the reader could not parse at all (counted as bad). */
    public long unreadable;
    public final List<String> messages = new ArrayList<>();
    /** Set by the caller to cancel. */
    public volatile boolean cancel;

    public Crs crsFor(String layer) {
        Crs c = layerCrs.get(layer);
        return c != null ? c : crs;
    }
}
