package iq.gis.poiexporter.core.io;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.Kml;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.table.PointTable;
import iq.gis.poiexporter.core.table.RowReport;
import iq.gis.poiexporter.core.table.TableReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

/**
 * Single entry point for importing geographic files: {@link #preview} shows what is inside (layers, fields, CRS) and
 * {@link #load} reads the chosen layers, reprojects to WGS84, validates and reports.
 */
public final class ImportHub {
    private ImportHub() {
    }

    /** Opens GeoPackage files (Android SQLite); set by the app at start-up. */
    public interface GpkgOpener {
        Gpkg.Source open(File f) throws IOException;
    }

    public static GpkgOpener gpkgOpener;

    public static final class LayerInfo {
        public String key; // layer name | geometry type
        public String name;
        public int geom;
        public long count;
        public final List<String> fields = new ArrayList<>();
        public final List<Map<String, String>> sample = new ArrayList<>();
        /** Detected CRS, or null when the file does not say. */
        public Crs crs;
        public double[] bbox; // minLon, minLat, maxLon, maxLat of the raw coordinates
        public String displayGeom(boolean ar) {
            return geom == Feature.POINT ? (ar ? "نقاط" : "points") : geom == Feature.LINE ? (ar ? "خطوط" : "lines") : (ar ? "مضلعات" : "polygons");
        }
    }

    public static final class Preview {
        public GeoFormat format = GeoFormat.UNKNOWN;
        public final List<LayerInfo> layers = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        /** For CSV/TXT/XLSX: header, guessed mapping and sample rows. */
        public List<String> header;
        public PointTable.Guess guess;
        public List<String[]> tableSample;
        public List<String> sheets;
        public String name;

        public boolean crsKnown() {
            for (LayerInfo l : layers) if (l.crs == null) return false;
            return !layers.isEmpty();
        }
    }

    public static final class Options {
        /** Indices into Preview.layers, null = all. */
        public Set<Integer> layers;
        /** Overrides the detected CRS (needed when the file does not declare one and is not WGS84). */
        public Crs sourceCrs;
        public boolean skipDuplicates;
        public double dupMeters = 25;
        public boolean fixGeometry = true;
        public boolean makeValid = false;
        public PointTable.Mapping csv;
        public int sheet;
    }

    public interface Progress {
        void update(long n);

        boolean cancelled();
    }

    public static final class Result {
        public final List<LayerData> layers = new ArrayList<>();
        public final ImportReport report = new ImportReport();
    }

    private static byte[] head(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            byte[] b = new byte[4096];
            int n = in.read(b);
            return n <= 0 ? new byte[0] : java.util.Arrays.copyOf(b, n);
        } finally {
            in.close();
        }
    }

    private static String today() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date());
    }

    private static String baseName(String name) {
        String n = name == null ? "import" : name;
        int sl = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (sl >= 0) n = n.substring(sl + 1);
        return n.replaceAll("\\.[A-Za-z0-9]+$", "");
    }

    // ------------------------------------------------------------------ reading dispatch

    /** Streams all records of the file (or only the layers allowed by the filter) to the visitor. */
    private static void stream(File f, String name, GeoFormat fmt, Visitor v, ReadInfo info, Preview pv) throws IOException {
        String base = baseName(name);
        switch (fmt) {
            case GEOJSON:
                GeoJson.read(f, base, v, info);
                break;
            case GPX:
                Gpx.read(f, v, info);
                break;
            case DXF:
                Dxf.read(f, v, info);
                break;
            case SHP_ZIP:
                for (ShapeReader.Item it : ShapeReader.list(f)) {
                    info.layerCrs.put(it.name, it.crs);
                    ShapeReader.read(f, it, v, info);
                }
                break;
            case KML:
            case KMZ: {
                info.crs = Crs.wgs84();
                InputStream in = new FileInputStream(f);
                try {
                    for (LayerData l : Kml.read(in, name)) {
                        for (Feature ft : l.features) {
                            if (ft.id.isEmpty()) ft.id = Feature.newId();
                            if (!v.feature(l.label, ft)) return;
                        }
                    }
                } finally {
                    in.close();
                }
                break;
            }
            case GPKG: {
                if (gpkgOpener == null) throw new IOException(S.t("قراءة GeoPackage غير متاحة في هذه البيئة", "GeoPackage reading is not available here"));
                Gpkg.Source src = gpkgOpener.open(f);
                for (Gpkg.TableInfo t : Gpkg.tables(src)) {
                    info.layerCrs.put(t.identifier, t.crs);
                    Gpkg.read(src, t, v, info);
                }
                break;
            }
            default:
                throw new IOException(S.t("صيغة غير مدعومة", "Unsupported format"));
        }
    }

    // ------------------------------------------------------------------ preview

    public static Preview preview(File f, String displayName) throws IOException {
        final Preview pv = new Preview();
        pv.name = displayName;
        pv.format = GeoFormat.detect(displayName, head(f));
        if (pv.format == GeoFormat.UNKNOWN)
            throw new IOException(S.t("صيغة الملف غير معروفة. المدعوم: GeoJSON، KML/KMZ، GPX، Shapefile (ZIP)، CSV/TXT، Excel، GeoPackage، DXF.",
                    "Unknown file format. Supported: GeoJSON, KML/KMZ, GPX, Shapefile (ZIP), CSV/TXT, Excel, GeoPackage, DXF."));
        if (pv.format == GeoFormat.CSV || pv.format == GeoFormat.XLSX) {
            TableReader r = TableReader.open(f, displayName);
            try {
                pv.header = new ArrayList<>(r.header());
                pv.sheets = r.sheetNames();
                pv.guess = PointTable.guess(pv.header);
                pv.tableSample = new ArrayList<>();
                String[] row;
                long n = 0;
                while ((row = r.next()) != null) {
                    n++;
                    if (pv.tableSample.size() < 5) pv.tableSample.add(row);
                }
                LayerInfo li = new LayerInfo();
                li.name = baseName(displayName);
                li.key = li.name + "|" + Feature.POINT;
                li.geom = Feature.POINT;
                li.count = n;
                li.fields.addAll(pv.header);
                pv.layers.add(li);
                if (pv.guess.x < 0 && pv.guess.combined < 0)
                    pv.warnings.add(S.t("لم أتعرف على أعمدة الإحداثيات؛ حدّدها يدوياً.", "Coordinate columns not recognised; choose them manually."));
            } finally {
                r.close();
            }
            return pv;
        }
        final ReadInfo info = new ReadInfo();
        final Map<String, LayerInfo> map = new LinkedHashMap<>();
        stream(f, displayName, pv.format, new Visitor() {
            public boolean feature(String layer, Feature ft) {
                String key = layer + "|" + ft.geom;
                LayerInfo li = map.get(key);
                if (li == null) {
                    li = new LayerInfo();
                    li.key = key;
                    li.name = layer;
                    li.geom = ft.geom;
                    li.crs = info.crsFor(layer);
                    map.put(key, li);
                }
                li.count++;
                if (li.sample.size() < 5) {
                    Map<String, String> row = new LinkedHashMap<>();
                    row.put("name", ft.name);
                    if (!ft.type.isEmpty()) row.put("type", ft.type);
                    row.putAll(ft.attrs);
                    li.sample.add(row);
                }
                for (String k : new ArrayList<>(ft.attrs.keySet())) if (!li.fields.contains(k)) li.fields.add(k);
                double[] bb = iq.gis.poiexporter.core.GeomCodec.bbox(ft);
                if (li.bbox == null) li.bbox = bb;
                else {
                    li.bbox[0] = Math.min(li.bbox[0], bb[0]);
                    li.bbox[1] = Math.min(li.bbox[1], bb[1]);
                    li.bbox[2] = Math.max(li.bbox[2], bb[2]);
                    li.bbox[3] = Math.max(li.bbox[3], bb[3]);
                }
                return true;
            }
        }, info, pv);
        pv.layers.addAll(map.values());
        for (LayerInfo li : pv.layers) if (li.crs == null) li.crs = info.crsFor(li.name);
        pv.warnings.addAll(info.warnings);
        if (info.unreadable > 0)
            pv.warnings.add(S.t(info.unreadable + " سجل غير مقروء سيُتجاهل", info.unreadable + " unreadable records will be skipped"));
        for (LayerInfo li : pv.layers) {
            if (li.crs == null) {
                boolean geo = li.bbox != null && li.bbox[0] >= -180 && li.bbox[2] <= 180 && li.bbox[1] >= -90 && li.bbox[3] <= 90;
                if (geo) {
                    li.crs = null;
                    pv.warnings.add(S.t("«" + li.name + "»: لم يُحدَّد نظام الإحداثيات، القيم تبدو WGS84 (درجات).",
                            "\"" + li.name + "\": CRS not declared, values look like WGS84 degrees."));
                } else {
                    pv.warnings.add(S.t("«" + li.name + "»: نظام الإحداثيات غير معروف والقيم ليست درجات. اختر النظام الصحيح (مثل UTM 38N) قبل الاستيراد.",
                            "\"" + li.name + "\": unknown CRS and values are not degrees. Pick the right CRS (e.g. UTM 38N) before importing."));
                }
            }
        }
        if (pv.layers.isEmpty()) pv.warnings.add(S.t("لا توجد سجلات صالحة في الملف.", "No usable records in the file."));
        return pv;
    }

    // ------------------------------------------------------------------ load

    /** Reads the chosen layers into new LayerData objects (kind "import"), reprojected to WGS84. */
    public static Result load(File f, String displayName, Preview pv, Options o, Progress pr) throws IOException {
        final Result res = new Result();
        final ImportReport rep = res.report;
        final String stamp = today();
        final String src = displayName == null ? f.getName() : displayName;
        if (pv.format == GeoFormat.CSV || pv.format == GeoFormat.XLSX) {
            if (o.csv == null) throw new IOException(S.t("حدّد أعمدة الإحداثيات أولاً", "Choose the coordinate columns first"));
            RowReport rr = new RowReport();
            LayerData l = PointTable.toLayer(f, displayName, o.csv, o.sourceCrs, rr);
            rep.read = rr.read;
            rep.badCoordinates = rr.bad;
            for (String m : rr.messages) rep.add(m);
            finish(l, o, rep, src, stamp);
            if (!l.features.isEmpty()) res.layers.add(l);
            return res;
        }
        final Map<String, LayerData> out = new LinkedHashMap<>();
        final Map<String, Crs.Tx> txCache = new LinkedHashMap<>();
        final ReadInfo info = new ReadInfo();
        final Options oo = o;
        final Progress prog = pr;
        final Preview pview = pv;
        final Crs wgs = Crs.wgs84();
        stream(f, displayName, pv.format, new Visitor() {
            long n;

            public boolean feature(String layer, Feature ft) {
                String key = layer + "|" + ft.geom;
                if (oo.layers != null) {
                    int idx = -1;
                    for (int i = 0; i < pview.layers.size(); i++) if (pview.layers.get(i).key.equals(key)) idx = i;
                    if (idx < 0 || !oo.layers.contains(idx)) return true;
                }
                rep.read++;
                if (prog != null) {
                    if ((++n & 1023) == 0) prog.update(n);
                    if (prog.cancelled()) {
                        info.cancel = true;
                        return false;
                    }
                }
                Crs c = oo.sourceCrs != null ? oo.sourceCrs : info.crsFor(layer);
                if (c != null && c.epsg != 4326) {
                    Crs.Tx tx = txCache.get(c.code());
                    if (tx == null) {
                        tx = c.to(wgs);
                        txCache.put(c.code(), tx);
                    }
                    try {
                        double[] o2 = new double[2];
                        for (double[] p : ft.parts)
                            for (int i = 0; i + 1 < p.length; i += 2) {
                                tx.apply(p[i], p[i + 1], o2);
                                p[i] = o2[0];
                                p[i + 1] = o2[1];
                            }
                        Geo.setRepresentative(ft);
                    } catch (IllegalArgumentException e) {
                        rep.badCoordinates++;
                        rep.add(S.t("سجل " + rep.read + ": فشل إسقاط الإحداثيات (" + c.code() + ")", "Record " + rep.read + ": projection failed (" + c.code() + ")"));
                        return true;
                    }
                } else if (c == null) {
                    for (double[] p : ft.parts)
                        for (int i = 0; i + 1 < p.length; i += 2)
                            if (Math.abs(p[i]) > 180 || Math.abs(p[i + 1]) > 90) {
                                rep.badCoordinates++;
                                if (rep.messages.size() < 3)
                                    rep.add(S.t("إحداثيات ليست درجات وبلا نظام مرجعي — اختر النظام الصحيح", "Coordinates are not degrees and no CRS is set — choose the right CRS"));
                                return true;
                            }
                }
                LayerData l = out.get(key);
                if (l == null) {
                    String label = layer + (hasMixed(pview, layer) ? " (" + (ft.geom == Feature.POINT ? S.t("نقاط", "points") : ft.geom == Feature.LINE ? S.t("خطوط", "lines") : S.t("مضلعات", "polygons")) + ")" : "");
                    l = new LayerData("imp_" + Long.toHexString(System.nanoTime()) + "_" + out.size(), label, ft.geom);
                    l.kind = "import";
                    l.source = src;
                    l.sourceDate = stamp;
                    out.put(key, l);
                }
                if (ft.id.isEmpty()) ft.id = Feature.newId();
                l.features.add(ft);
                return true;
            }
        }, info, pv);
        rep.badCoordinates += info.unreadable;
        for (String m : info.messages) rep.add(m);
        for (LayerData l : out.values()) {
            finish(l, o, rep, src, stamp);
            if (!l.features.isEmpty()) res.layers.add(l);
        }
        return res;
    }

    private static boolean hasMixed(Preview pv, String layer) {
        int n = 0;
        for (LayerInfo li : pv.layers) if (li.name.equals(layer)) n++;
        return n > 1;
    }

    /** Validation, repair, duplicate removal and bookkeeping of one imported layer. */
    private static void finish(LayerData l, Options o, ImportReport rep, String src, String stamp) {
        List<Feature> keep = new ArrayList<>(l.features.size());
        for (Feature f : l.features) {
            f.source = f.source.isEmpty() ? src : f.source;
            f.updated = stamp;
            List<String> issues = GeomCheck.check(f, l.geom);
            if (!issues.isEmpty()) {
                boolean fatal = issues.contains(GeomCheck.EMPTY) || issues.contains(GeomCheck.TOO_FEW_POINTS);
                if (issues.contains(GeomCheck.OUT_OF_RANGE)) {
                    rep.badCoordinates++;
                    rep.add(S.t("«" + f.name + "»: " + GeomCheck.message(GeomCheck.OUT_OF_RANGE, true), "\"" + f.name + "\": " + GeomCheck.message(GeomCheck.OUT_OF_RANGE, false)));
                    continue;
                }
                if (fatal) {
                    rep.skippedNoGeometry++;
                    if (rep.messages.size() < 50)
                        rep.add(S.t("«" + f.name + "»: " + GeomCheck.describe(issues, true), "\"" + f.name + "\": " + GeomCheck.describe(issues, false)));
                    continue;
                }
                if (o.fixGeometry) {
                    boolean fixedSomething = GeomCheck.fix(f);
                    List<String> left = GeomCheck.check(f, l.geom);
                    if (left.contains(GeomCheck.SELF_INTERSECTION)) {
                        if (o.makeValid) {
                            Feature v = GeomCheck.makeValid(f);
                            if (v != null) {
                                f = v;
                                fixedSomething = true;
                                left = GeomCheck.check(f, l.geom);
                            }
                        }
                        if (left.contains(GeomCheck.SELF_INTERSECTION)) {
                            rep.invalidKept++;
                            rep.add(S.t("«" + f.name + "»: " + GeomCheck.message(GeomCheck.SELF_INTERSECTION, true), "\"" + f.name + "\": " + GeomCheck.message(GeomCheck.SELF_INTERSECTION, false)));
                        }
                    }
                    if (fixedSomething) rep.invalidFixed++;
                } else {
                    rep.invalidKept++;
                }
            }
            keep.add(f);
        }
        if (o.skipDuplicates && l.geom == Feature.POINT && keep.size() > 1) {
            List<DupFinder.Group> gs = DupFinder.find(keep, o.dupMeters, true);
            java.util.Set<Feature> drop = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<Feature, Boolean>());
            for (DupFinder.Group g : gs) for (int i = 1; i < g.members.size(); i++) drop.add(g.members.get(i));
            if (!drop.isEmpty()) {
                List<Feature> k2 = new ArrayList<>();
                for (Feature f : keep) if (!drop.contains(f)) k2.add(f);
                rep.duplicatesSkipped += keep.size() - k2.size();
                keep = k2;
            }
        }
        l.features.clear();
        l.features.addAll(keep);
        rep.imported += keep.size();
    }
}
