import iq.gis.poiexporter.core.AdminIndex;
import java.util.*;

public class AdminTest {
    static int fails = 0;
    static void eq(String n, String got, String want) {
        boolean ok = got.equals(want); if (!ok) fails++;
        System.out.println((ok ? "PASS " : "FAIL ") + n + " got='" + got + "' want='" + want + "'");
    }
    public static void main(String[] a) {
        AdminIndex idx = new AdminIndex();
        // Governorate "G": square 0..10, ring split across two ways
        idx.add(4, "G", Arrays.asList(
                new double[]{0,0, 0,10, 10,10},
                new double[]{10,10, 10,0, 0,0}));
        // Two districts side by side inside G
        idx.add(5, "D1", Collections.singletonList(new double[]{0,0, 0,5, 10,5, 10,0, 0,0}));
        idx.add(5, "D2", Collections.singletonList(new double[]{0,5, 0,10, 10,10, 10,5, 0,5}));
        // Sub-district inside D2
        idx.add(6, "N", Collections.singletonList(new double[]{2,6, 2,8, 4,8, 4,6, 2,6}));
        eq("gov inside", idx.find(4, 5, 5), "G");
        eq("gov outside", idx.find(4, 11, 5), "");
        eq("district 1", idx.find(5, 3, 2), "D1");
        eq("district 2", idx.find(5, 3, 7), "D2");
        eq("nahiya inside", idx.find(6, 3, 7), "N");
        eq("nahiya outside", idx.find(6, 3, 2), "");
        eq("missing level", idx.find(7, 3, 7), "");
        System.out.println(fails == 0 ? "ADMIN OK" : fails + " FAILURES");
        System.exit(fails == 0 ? 0 : 1);
    }
}
