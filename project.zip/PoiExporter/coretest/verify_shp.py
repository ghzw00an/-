import struct, sys, os
d, base = sys.argv[1], "poi_test"
shp = open(f"{d}/{base}.shp","rb").read(); shx = open(f"{d}/{base}.shx","rb").read(); dbf = open(f"{d}/{base}.dbf","rb").read()
ok = True
def chk(n, c):
    global ok
    print(("PASS " if c else "FAIL ") + n); ok &= bool(c)
code, = struct.unpack(">i", shp[:4]); flen, = struct.unpack(">i", shp[24:28]); ver, st = struct.unpack("<ii", shp[28:36])
chk("shp code 9994", code == 9994); chk("shp length matches", flen*2 == len(shp)); chk("version 1000, type point", (ver, st) == (1000, 1))
xmin, ymin, xmax, ymax = struct.unpack("<4d", shp[36:68])
n = (len(shx)-100)//8
chk("shx length", struct.unpack(">i", shx[24:28])[0]*2 == len(shx)); chk("3 records", n == 3)
pts = []
for i in range(n):
    off, cl = struct.unpack(">ii", shx[100+8*i:108+8*i])
    rn, cl2 = struct.unpack(">ii", shp[off*2:off*2+8]); t, x, y = struct.unpack("<idd", shp[off*2+8:off*2+28])
    chk(f"record {i+1} index consistent", rn == i+1 and cl == cl2 == 10 and t == 1); pts.append((x, y))
chk("bbox", (xmin, ymin, xmax, ymax) == (min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts)))
nrec, hlen, rlen = struct.unpack("<IHH", dbf[4:12]); nf = (hlen-33)//32
fields = []
for i in range(nf):
    f = dbf[32+32*i:64+32*i]; fields.append((f[:11].split(b"\0")[0].decode(), chr(f[11]), f[16], f[17]))
print(fields)
chk("dbf size", len(dbf) == hlen + nrec*rlen + 1 and nrec == 3 and dbf[hlen-1] == 0x0D and dbf[-1] == 0x1A)
chk("record len", rlen == 1 + sum(f[2] for f in fields))
rows = []
for r in range(nrec):
    rec = dbf[hlen+r*rlen: hlen+(r+1)*rlen]; pos = 1; row = {}
    for nm, ty, ln, dc in fields:
        row[nm] = rec[pos:pos+ln].decode("utf-8").strip(); pos += ln
    rows.append(row)
for r in rows: print(r)
chk("arabic name roundtrip", rows[0]["NAME"] == "مستشفى اليرموك التعليمي" and rows[0]["GOVERNORAT"] == "بغداد")
chk("long name truncated cleanly (valid utf-8, <=200B)", len(rows[1]["NAME"].encode()) <= 200)
chk("zone 38N / 37N", rows[0]["UTM_ZONE"] == "38N" and rows[2]["UTM_ZONE"] == "37N")
chk("X,Y numeric", all(float(r["X"]) > 0 and float(r["Y"]) > 0 for r in rows))
chk("prj/cpg exist", os.path.exists(f"{d}/{base}.prj") and open(f"{d}/{base}.cpg").read() == "UTF-8")
print("SHAPEFILE OK" if ok else "SHAPEFILE PROBLEMS"); sys.exit(0 if ok else 1)
