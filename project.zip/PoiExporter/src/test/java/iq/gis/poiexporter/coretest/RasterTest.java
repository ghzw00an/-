package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.raster.Georef;
import iq.gis.poiexporter.core.raster.TiffReader;

import java.io.File;

public class RasterTest {
    static final int W = 64, H = 48;

    static int rgb(int x, int y) {
        return 0xFF000000 | (((x * 4) % 256) << 16) | (((y * 5) % 256) << 8) | (((x + y) * 2) % 256);
    }

    static void exact(String f, String label) throws Exception {
        TiffReader.Image im = TiffReader.read(new File("src/test/resources/raster/" + f), 4096);
        T.eq(im.w + "x" + im.h, W + "x" + H, label + " size");
        int bad = 0;
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) if (im.argb[y * W + x] != rgb(x, y)) bad++;
        T.eq(bad, 0, label + " every pixel identical");
    }

    public static void main(String[] a) throws Exception {
        exact("rgb_none.tif", "uncompressed");
        exact("rgb_lzw.tif", "LZW");
        exact("rgb_packbits.tif", "PackBits");
        exact("rgb_deflate.tif", "Deflate");
        exact("rgb_tiled_zlib.tif", "tiled Deflate");
        exact("rgb_tiled_pred.tif", "tiled Deflate + predictor");
        // RGBA keeps alpha
        TiffReader.Image ra = TiffReader.read(new File("src/test/resources/raster/rgba.tif"), 4096);
        T.eq(ra.argb[5 * W + 7] >>> 24, 200, "alpha kept");
        T.eq(ra.argb[5 * W + 7] & 0xFFFFFF, rgb(7, 5) & 0xFFFFFF, "alpha image colour");
        // palette
        TiffReader.Image pa = TiffReader.read(new File("src/test/resources/raster/palette.tif"), 4096);
        int idx = (3 / 8) + (9 / 8) * 8; // pixel (3,9)
        T.eq(pa.argb[9 * W + 3], 0xFF000000 | (idx << 16) | ((255 - idx) << 8) | ((idx * 7) % 256), "palette lookup");
        // 16-bit gray: stretched, monotonic along x
        TiffReader.Image g = TiffReader.read(new File("src/test/resources/raster/gray16_geo.tif"), 4096);
        int v0 = g.argb[10 * W + 1] & 0xFF, v1 = g.argb[10 * W + 20] & 0xFF;
        T.ok(v1 > v0, "16-bit gradient increases (" + v0 + " < " + v1 + ")");
        T.eq(g.epsg, 4326, "geographic EPSG read");
        T.near(g.affine[0], 0.001, 1e-12, "pixel size x");
        T.near(g.affine[2], 44.0, 1e-9, "origin x");
        T.near(g.affine[5], 33.1, 1e-9, "origin y");
        // float
        TiffReader.Image fl = TiffReader.read(new File("src/test/resources/raster/float32.tif"), 4096);
        T.ok((fl.argb[40 * W + 60] & 0xFF) > (fl.argb[1 * W + 1] & 0xFF), "float values stretched");
        // GeoTIFF projected
        TiffReader.Image p = TiffReader.read(new File("src/test/resources/raster/rgb_none.tif"), 4096);
        T.eq(p.epsg, 32638, "projected EPSG");
        T.eq(p.affine == null, false, "affine present");
        T.near(p.affine[0], 10, 1e-9, "scale x");
        T.near(p.affine[4], -10, 1e-9, "scale y negative");
        T.near(p.affine[2], 500000, 1e-6, "origin E");
        T.near(p.affine[5], 3700000, 1e-6, "origin N");
        double[] c = Georef.corners(p.affine, W, H, p.epsg);
        T.ok(c[0] > 44.9 && c[0] < 45.1 && c[1] > 33.0 && c[1] < 34.0, "UTM 38N corner lands in Iraq: " + c[0] + "," + c[1]);
        T.ok(c[2] > c[0] && c[5] < c[1], "TR east of TL, BL south of TL");
        // 640 m x 480 m: check the size in metres between TL and TR
        double dx = (c[2] - c[0]) * 111320 * Math.cos(Math.toRadians(c[1]));
        T.near(dx, 640, 3, "image width on the ground");
        // model transformation (rotated)
        TiffReader.Image t = TiffReader.read(new File("src/test/resources/raster/rgb_transform.tif"), 4096);
        T.near(t.affine[1], 0.2, 1e-12, "rotation term b");
        T.near(t.affine[3], 0.2, 1e-12, "rotation term d");
        // subsampling keeps the extent
        TiffReader.Image s = TiffReader.read(new File("src/test/resources/raster/rgb_lzw.tif"), 32);
        T.eq(s.step, 2, "step for max side 32");
        T.eq(s.w, 32, "subsampled width");
        T.eq(s.argb[3 * s.w + 5], rgb(10, 6), "subsampled pixel = every 2nd pixel");
        T.eq(s.srcW, W, "source width reported");
        // errors
        try {
            TiffReader.read(new File("src/test/resources/raster/meta.json"), 100);
            T.ok(false, "non-TIFF rejected");
        } catch (java.io.IOException e) {
            T.ok(true, "non-TIFF rejected");
        }
        // world file
        double[] wf = Georef.parseWorldFile("0.5\n0\n0\n-0.5\n1000.25\n2000.75\n");
        T.near(wf[2], 1000.0, 1e-9, "world file corner x");
        T.near(wf[5], 2001.0, 1e-9, "world file corner y");
        try {
            Georef.parseWorldFile("1\n2\nabc");
            T.ok(false, "bad world file rejected");
        } catch (IllegalArgumentException e) {
            T.ok(true, "bad world file rejected");
        }
        double[] fb = Georef.fromBounds(44, 33, 45, 34, 100, 50);
        double[] cb = Georef.corners(fb, 100, 50, 0);
        T.near(cb[4], 45, 1e-9, "bounds BR lon");
        T.near(cb[5], 33, 1e-9, "bounds BR lat");
        T.done("RasterTest");
    }
}
