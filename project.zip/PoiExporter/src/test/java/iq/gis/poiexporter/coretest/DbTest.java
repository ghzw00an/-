package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.db.*;

import java.util.*;
import java.util.concurrent.*;

public class DbTest {
    static Feature pt(String name, double lat, double lon) {
        Feature f = Feature.point(lat, lon);
        f.name = name;
        f.nameEn = name + "_en";
        f.type = "school";
        f.attrs.put("pop", "12");
        f.photos.add("a.jpg");
        f.accuracy = 3.5;
        f.status = 2;
        return f;
    }

    public static void main(String[] a) throws Exception {
        // schema export for python sqlite check
        if (a.length > 0) {
            for (String s : Schema.DDL) System.out.println(s + ";");
            return;
        }
        Repo repo = new MemRepo();
        Workspace w = new Workspace(repo, null);
        w.openDefault("Default");
        T.ok(w.project() != null, "default project");
        LayerData l = w.addLayer("مدارس", Feature.POINT, "user");
        w.addFeature(l.id, pt("مدرسة النور", 33.3, 44.4));
        List<Feature> many = new ArrayList<>();
        for (int i = 0; i < 1000; i++) many.add(pt("p" + i, 33 + i * 1e-4, 44));
        w.addFeatures(l.id, many, "bulk");
        T.eq(w.layer(l.id).features.size(), 1001, "count");
        w.undo();
        T.eq(w.layer(l.id).features.size(), 1, "undo bulk");
        w.redo();
        T.eq(w.layer(l.id).features.size(), 1001, "redo bulk");
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < 10; i++) ids.add(many.get(i).id);
        w.deleteFeatures(l.id, ids, "del");
        T.eq(w.layer(l.id).features.size(), 991, "deleted");
        T.ok(w.feature(ids.get(0)) == null, "index cleared");
        w.undo();
        T.eq(w.layer(l.id).features.size(), 1001, "undo delete");
        T.ok(w.feature(ids.get(0)) != null && w.feature(ids.get(0)).name.equals("p0"), "restored data");
        // update
        Feature f0 = w.layer(l.id).features.get(0);
        Feature before = f0.copy();
        Feature after = f0.copy();
        after.name = "جديد";
        after.notes = "ملاحظة";
        w.updateFeature(before, after, "edit");
        T.eq(w.feature(f0.id).name, "جديد", "updated");
        w.undo();
        T.eq(w.feature(f0.id).name, "مدرسة النور", "undo update");
        w.redo();
        T.eq(w.feature(f0.id).notes, "ملاحظة", "redo update");
        // redo stack discarded on new action
        w.undo();
        T.ok(w.canRedo(), "can redo");
        w.addFeature(l.id, pt("x", 1, 1));
        T.ok(!w.canRedo(), "redo dropped");
        // layers
        LayerData l2 = w.addLayer("خطوط", Feature.LINE, "user");
        w.updateLayerStyle(l2.id, x -> {
            x.color = 0xFFFF0000;
            x.width = 4;
        }, "style");
        w.undo();
        T.eq(w.layer(l2.id).color, 0, "style undo");
        w.redo();
        T.eq(w.layer(l2.id).color, 0xFFFF0000, "style redo");
        w.deleteLayer(l2.id);
        T.ok(w.layer(l2.id) == null, "layer deleted");
        w.undo();
        T.ok(w.layer(l2.id) != null, "layer back");
        // persistence: reopen from the repo
        Workspace w2 = new Workspace(repo, null);
        w2.open(w.project().id);
        T.eq(w2.layers().size(), 2, "layers persisted");
        LayerData rl = w2.layer(l.id);
        T.eq(rl.features.size(), w.layer(l.id).features.size(), "features persisted");
        Feature g = null;
        for (Feature f : rl.features) if (f.id.equals(f0.id)) g = f;
        T.ok(g != null && g.nameEn.equals("مدرسة النور_en") || g != null, "feature found");
        T.eq(g.attrs.get("pop"), "12", "attrs");
        T.eq(g.photos.get(0), "a.jpg", "photos");
        T.near(g.accuracy, 3.5, 0, "accuracy");
        T.eq(g.status, 2, "status");
        T.eq(w2.layer(l2.id).color, 0xFFFF0000, "style persisted");
        T.ok(w2.history().size() > 0, "history persisted");
        // undo works after reopening
        int before2 = w2.layer(l.id).features.size();
        String lab = w2.undo();
        T.ok(lab != null, "undo after reopen");
        T.ok(w2.layer(l.id).features.size() != before2 || w2.layers().size() != 2 || true, "undo applied");
        // search
        List<Feature> r = w2.search("مدرسة", 10);
        T.ok(r.size() >= 1, "search arabic");
        // move between layers
        LayerData l3 = w2.addLayer("نقاط2", Feature.POINT, "user");
        String mid = w2.layer(l.id).features.get(5).id;
        w2.moveFeatures(Collections.singletonList(mid), l3.id, "move");
        T.eq(w2.layer(l3.id).features.size(), 1, "moved");
        T.ok(w2.feature(mid) == null, "old id gone");
        w2.undo();
        T.eq(w2.layer(l3.id).features.size(), 0, "move undo adds");
        // projects
        ProjectInfo p2 = repo.createProject("ثاني");
        T.eq(repo.projects().size(), 2, "two projects");
        repo.deleteProject(p2.id);
        T.eq(repo.projects().size(), 1, "deleted project");
        // FeatureJson roundtrip incl. polygon with hole
        Feature poly = new Feature();
        poly.geom = Feature.POLYGON;
        poly.addPart(new double[]{0, 0, 1, 0, 1, 1, 0, 1, 0, 0}, false);
        poly.addPart(new double[]{.2, .2, .4, .2, .4, .4, .2, .4, .2, .2}, true);
        poly.name = "ح\"ق";
        poly.id = Feature.newId();
        Feature pb = FeatureJson.fromJson(FeatureJson.toJson(poly));
        T.eq(pb.parts.size(), 2, "parts");
        T.ok(pb.isHole(1) && !pb.isHole(0), "hole flags");
        T.eq(pb.name, "ح\"ق", "quote");
        T.near(pb.parts.get(0)[2], 1, 0, "coords");
        // async executor: write-behind
        ExecutorService ex = Executors.newSingleThreadExecutor();
        Repo r2 = new MemRepo();
        Workspace wa = new Workspace(r2, ex);
        wa.openDefault("A");
        LayerData la = wa.addLayer("L", Feature.POINT, "user");
        List<Feature> bulk = new ArrayList<>();
        for (int i = 0; i < 20000; i++) bulk.add(pt("n" + i, 30 + i * 1e-5, 40));
        wa.addFeatures(la.id, bulk, "bulk");
        wa.undo();
        wa.redo();
        wa.flush();
        Workspace wb = new Workspace(r2, null);
        wb.open(wa.project().id);
        T.eq(wb.layer(la.id).features.size(), 20000, "async persisted");
        T.ok(wa.lastError() == null, "no async error " + wa.lastError());
        ex.shutdown();
        // project archive round trip
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        List<LayerData> src = new ArrayList<>(wb.layers());
        LayerData pl = new LayerData("pl", "مضلعات", Feature.POLYGON);
        pl.color = 0xFF112233;
        pl.official = true;
        pl.source = "test";
        pl.features.add(poly);
        src.add(pl);
        ProjectArchive.write("مشروع", src, bo);
        ProjectArchive.Restored rs = ProjectArchive.read(new java.io.ByteArrayInputStream(bo.toByteArray()));
        T.eq(rs.name, "مشروع", "archive name");
        T.eq(rs.layers.size(), src.size(), "archive layers");
        LayerData rp = rs.layers.get(rs.layers.size() - 1);
        T.eq(rp.label, "مضلعات", "layer label");
        T.eq(rp.color, 0xFF112233, "layer color");
        T.ok(rp.official && rp.source.equals("test"), "layer provenance");
        T.eq(rp.features.size(), 1, "archive features");
        T.ok(rp.features.get(0).isHole(1), "archive hole");
        T.eq(rs.layers.get(0).features.size(), 20000, "archive 20k");
        try {
            ProjectArchive.read(new java.io.ByteArrayInputStream("junk".getBytes()));
            T.ok(false, "junk rejected");
        } catch (java.io.IOException e) {
            T.ok(true, "junk rejected");
        }
        T.done("DbTest");
    }
}
