package iq.gis.poiexporter.coretest;

/** Minimal assertion helper shared by the test mains. */
final class T {
    static int pass, fail;

    static void ok(boolean c, String msg) {
        if (c) pass++;
        else {
            fail++;
            System.out.println("FAIL: " + msg);
        }
    }

    static void near(double a, double b, double tol, String msg) {
        ok(Math.abs(a - b) <= tol, msg + " expected " + b + " got " + a + " (tol " + tol + ")");
    }

    static void eq(Object a, Object b, String msg) {
        ok(a == null ? b == null : a.equals(b), msg + " expected [" + b + "] got [" + a + "]");
    }

    static void done(String name) {
        System.out.println(name + ": " + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
