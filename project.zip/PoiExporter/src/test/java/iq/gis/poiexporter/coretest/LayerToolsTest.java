package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.*;
import iq.gis.poiexporter.core.geo.*;

import java.util.*;

public class LayerToolsTest {
    static Feature pt(double lat, double lon, String name, String type, String cat) {
        Feature f = Feature.point(lat, lon);
        f.name = name;
        f.type = type;
        f.category = cat;
        return f;
    }

    static LayerData pts(Feature... fs) {
        LayerData l = new LayerData("p", "pts", Feature.POINT);
        l.features.addAll(Arrays.asList(fs));
        return l;
    }

    static Feature square(double lat, double lon, double deg, String name) {
        Feature f = new Feature();
        f.geom = Feature.POLYGON;
        f.parts.add(new double[]{lon, lat, lon + deg, lat, lon + deg, lat + deg, lon, lat + deg, lon, lat});
        Geo.setRepresentative(f);
        f.name = name;
        return f;
    }

    static LayerData polys(Feature... fs) {
        LayerData l = new LayerData("g", "polys", Feature.POLYGON);
        l.features.addAll(Arrays.asList(fs));
        return l;
    }

    static Feature line(double... lonlat) {
        Feature f = new Feature();
        f.geom = Feature.LINE;
        f.parts.add(lonlat);
        Geo.setRepresentative(f);
        return f;
    }

    public static void main(String[] a) {
        // multi ring
        LayerData rings = LayerTools.multiRing(pts(pt(33, 44, "x", "", "")), new double[]{300, 100, 200, 100});
        T.eq(rings.features.size(), 3, "3 distinct distances -> 3 rings");
        double a1 = Geodesy.area(rings.features.get(0)), a2 = Geodesy.area(rings.features.get(1)), a3 = Geodesy.area(rings.features.get(2));
        T.near(a1, Math.PI * 100 * 100, Math.PI * 1e4 * 0.02, "inner disc 100 m");
        T.near(a2, Math.PI * (200 * 200 - 100 * 100), Math.PI * 3e4 * 0.02, "ring 100-200");
        T.near(a3, Math.PI * (300 * 300 - 200 * 200), Math.PI * 5e4 * 0.02, "ring 200-300");
        T.eq(rings.features.get(1).attrs.get("ring_m"), "200", "ring attr");
        try {
            LayerTools.multiRing(pts(pt(33, 44, "", "", "")), new double[]{-5, 0});
            T.ok(false, "no positive distance");
        } catch (IllegalArgumentException e) {
            T.ok(true, "no positive distance");
        }
        // along lines: 1 km line, every 250 m -> 0,250,500,750,1000 (5 points)
        double dLon = 1000 / (111320.0 * Math.cos(Math.toRadians(33)));
        LayerData ln = new LayerData("l", "l", Feature.LINE);
        ln.features.add(line(44, 33, 44 + dLon, 33));
        LayerData al = LayerTools.alongLines(ln, 250, false);
        T.eq(al.features.size(), 5, "points along 1 km every 250 m");
        T.eq(al.features.get(2).attrs.get("dist_m"), "500", "distance attr");
        T.near(Geodesy.distance(al.features.get(0).lat, al.features.get(0).lon, al.features.get(4).lat, al.features.get(4).lon), 1000, 8, "span");
        LayerData al2 = LayerTools.alongLines(ln, 300, true);
        T.eq(al2.features.size(), 5, "0,300,600,900 + end");
        T.eq(LayerTools.alongLines(ln, 300, false).features.size(), 4, "no end point");
        // vertices / boundaries / explode
        LayerData sq = polys(square(33, 44, 0.01, "s"));
        T.eq(LayerTools.vertices(sq).features.size(), 4, "square has 4 vertices");
        LayerData bd = LayerTools.boundaries(sq);
        T.eq(bd.geom, Feature.LINE, "boundary lines");
        T.eq(bd.features.size(), 1, "one ring");
        Feature multi = square(33, 44, 0.01, "m");
        multi.parts.add(new double[]{44.1, 33.1, 44.11, 33.1, 44.11, 33.11, 44.1, 33.11, 44.1, 33.1});
        LayerData ex = LayerTools.explode(polys(multi));
        T.eq(ex.features.size(), 2, "multipart split in two");
        // random points
        LayerData rp = LayerTools.randomPoints(sq, 200, 5);
        T.eq(rp.features.size(), 200, "200 random points");
        boolean inside = true;
        for (Feature f : rp.features) if (f.lon < 44 || f.lon > 44.01 || f.lat < 33 || f.lat > 33.01) inside = false;
        T.eq(inside, true, "all inside");
        LayerData rp2 = LayerTools.randomPoints(sq, 200, 5);
        T.eq(rp.features.get(10).lon, rp2.features.get(10).lon, "same seed, same points");
        // regular points: 1.1 km square, spacing 500 m -> 2x2 = 4 (+ edge)
        LayerData rg = LayerTools.regularPoints(sq, 500);
        T.ok(rg.features.size() >= 4 && rg.features.size() <= 9, "regular grid size " + rg.features.size());
        // dissolve / hull by field
        Feature s1 = square(33, 44, 0.01, "a"), s2 = square(33, 44.01, 0.01, "b"), s3 = square(33.5, 44.5, 0.01, "c");
        s1.governorate = "X";
        s2.governorate = "X";
        s3.governorate = "Y";
        LayerData dis = LayerTools.dissolveBy(polys(s1, s2, s3), 5);
        T.eq(dis.features.size(), 2, "two groups");
        Feature xg = dis.features.get(0).name.equals("X") ? dis.features.get(0) : dis.features.get(1);
        T.near(Geodesy.area(xg), Geodesy.area(s1) + Geodesy.area(s2), 5, "union area = sum of touching squares");
        T.eq(xg.attrs.get("count"), "2", "count attr");
        Feature p1 = pt(33, 44, "1", "", ""), p2 = pt(33, 44.01, "2", "", ""), p3 = pt(33.01, 44, "3", "", ""), p4 = pt(33.5, 44.5, "4", "", "");
        p1.category = "S1";
        p2.category = "S1";
        p3.category = "S1";
        p4.category = "S2";
        LayerData hb = LayerTools.hullBy(pts(p1, p2, p3, p4), 2);
        T.eq(hb.features.size(), 1, "only the 3-point group gets a hull");
        T.eq(hb.features.get(0).name, "S1", "hull name");
        // mean centre
        LayerTools.Centre c = LayerTools.meanCentre(pts(pt(33, 44, "", "", ""), pt(33, 44.002, "", "", "")));
        T.near(c.lon, 44.001, 1e-6, "mean lon");
        T.near(c.stdDistM, 0.001 * 111320 * Math.cos(Math.toRadians(33)), 3, "std distance");
        T.eq(LayerTools.meanCentreLayers(pts(pt(33, 44, "", "", ""), pt(33, 44.002, "", "", ""))).size(), 2, "point + circle");
        // erase / intersect
        LayerData big = polys(square(33, 44, 0.02, "big"));
        LayerData hole = polys(square(33.005, 44.005, 0.01, "hole"));
        LayerData er = LayerTools.erase(big, hole);
        T.near(Geodesy.area(er.features.get(0)), Geodesy.area(big.features.get(0)) - Geodesy.area(hole.features.get(0)), 20, "erase area");
        LayerData is = LayerTools.intersect(big, hole);
        T.eq(is.features.size(), 1, "one intersection");
        T.near(Geodesy.area(is.features.get(0)), Geodesy.area(hole.features.get(0)), 20, "intersection area");
        T.eq(is.features.get(0).attrs.get("b_name"), "hole", "b_name attr");
        T.eq(LayerTools.intersect(big, polys(square(40, 40, 0.01, "far"))).features.size(), 0, "no overlap");
        // count in polygons
        LayerData cp = LayerTools.countInPolygons(pts(pt(33.001, 44.001, "", "", ""), pt(33.002, 44.002, "", "", ""), pt(33.5, 44.5, "", "", "")), polys(square(33, 44, 0.01, "z"), square(34, 44, 0.01, "empty")));
        T.eq(cp.features.get(0).attrs.get("count"), "2", "two inside");
        T.eq(cp.features.get(1).attrs.get("count"), "0", "none inside");
        // nearest join / within
        LayerData A = pts(pt(33, 44, "a", "", ""), pt(33.1, 44, "b", "", ""));
        LayerData B = pts(pt(33.001, 44, "near", "", ""), pt(33.3, 44, "far", "", ""));
        LayerData nj = LayerTools.nearestJoin(A, B);
        T.eq(nj.features.get(0).attrs.get("nearest_name"), "near", "nearest name");
        T.near(Double.parseDouble(nj.features.get(0).attrs.get("nearest_m")), 111, 2, "nearest m");
        LayerData wd = LayerTools.withinDistanceOf(A, B, 500);
        T.eq(wd.features.size(), 1, "only a is within 500 m of B");
        // bulk edits
        Feature m1 = pt(33, 44, "m1", "مسجد", ""), m2 = pt(33, 44, "m2", "مدرسة", "قطاع آخر"), m3 = pt(33, 44, "m3", "مخزن", ""), m4 = pt(33, 44, "m4", "شيء غريب", "");
        LayerTools.Edits as = LayerTools.autoSector(Arrays.asList(m1, m2, m3, m4), false);
        T.eq(as.pairs.size(), 1, "only mosque classified (school already has a category, مخزن is ambiguous)");
        T.eq(as.pairs.get(0)[1].category, "القطاع الديني", "sector assigned");
        T.eq(as.pairs.get(0)[0].category, "", "before copy untouched");
        T.eq(as.skipped, 2, "skipped: ambiguous + unknown");
        T.eq(LayerTools.autoSector(Arrays.asList(m2), true).pairs.get(0)[1].category, "القطاع التربوي والتعليم", "overwrite");
        LayerTools.Edits sf = LayerTools.setField(Arrays.asList(m1, m2), 3, "بغداد", true);
        T.eq(sf.pairs.size(), 2, "both empty -> both set");
        T.eq(LayerTools.setField(Arrays.asList(m1), 3, "", true).pairs.size(), 0, "no change");
        Feature r1 = pt(33, 44, "مدرسة النور", "", "");
        LayerTools.Edits rt = LayerTools.replaceText(Arrays.asList(r1, m1), 0, "مدرسة", "ثانوية");
        T.eq(rt.pairs.size(), 1, "one replaced");
        T.eq(rt.pairs.get(0)[1].name, "ثانوية النور", "replaced");
        T.eq(LayerTools.cleanString("  مكتبـة   الكتب   كُلية ى "), "مكتبة الكتب كُلية ي", "clean string");
        Feature dirty = pt(33, 44, "مدرسه  النور ", "مسجد ", "");
        T.eq(LayerTools.cleanText(Arrays.asList(dirty, m1)).pairs.size(), 1, "one dirty");
        Feature pg = square(33, 44, 0.01, "poly");
        LayerTools.Edits am = LayerTools.addMeasures(Arrays.asList(pg, m1));
        T.eq(am.pairs.size(), 1, "polygon measured, point skipped");
        T.near(Double.parseDouble(am.pairs.get(0)[1].attrs.get("area_m2")), Geodesy.area(pg), 1, "area attr");
        T.eq(am.skipped, 1, "skipped point");
        T.done("LayerToolsTest");
    }
}
