package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.*;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.io.*;
import iq.gis.poiexporter.core.table.PointTable;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public class FieldsTest {
    static final String[] EXPECT = {"name", "type", "Gategory", "gathaa", "Nahia", "mohafadha", "x", "y", "link"};

    static Feature mk(String n, double lat, double lon) {
        Feature f = Feature.point(lat, lon);
        f.id = Feature.newId();
        f.name = n;
        f.type = "مدرسة ابتدائية";
        f.category = "القطاع التربوي التعليمي";
        f.qadaa = "الكرخ";
        f.nahiya = "الكاظمية";
        f.governorate = "بغداد";
        return f;
    }

    static List<String> dbfNames(byte[] zip) throws IOException {
        ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(zip));
        ZipEntry e;
        while ((e = z.getNextEntry()) != null) {
            if (!e.getName().endsWith(".dbf")) continue;
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            z.transferTo(b);
            byte[] d = b.toByteArray();
            int hl = (d[8] & 0xFF) | ((d[9] & 0xFF) << 8);
            List<String> r = new ArrayList<>();
            for (int p = 32; p < hl - 1; p += 32) {
                int n = 0;
                while (n < 11 && d[p + n] != 0) n++;
                r.add(new String(d, p, n, StandardCharsets.US_ASCII));
            }
            return r;
        }
        return null;
    }

    public static void main(String[] a) throws Exception {
        Feature f = mk("مدرسة النور", 33.3152, 44.3661);
        f.attrs.put("link", "");
        Feature g = mk("B", 36.19, 44.01);
        LandmarkFields.setLink(g, "https://example.org/x");
        g.attrs.put("pop", "5");
        LayerData l = new LayerData("L1", "test", Feature.POINT);
        l.features.add(f);
        l.features.add(g);
        List<LayerData> ls = Collections.singletonList(l);

        // legacy shapefile writer
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ShapeWriter.writeZip(ls, CoordFmt.Fmt.DD, bo);
        T.eq(dbfNames(bo.toByteArray()), Arrays.asList(EXPECT), "legacy dbf names");
        // generic shapefile, default (UTM x/y)
        bo = new ByteArrayOutputStream();
        ShapeWriter.writeZipGeneric(ls, null, true, bo);
        List<String> gn = dbfNames(bo.toByteArray());
        T.eq(gn.subList(0, 9), Arrays.asList(EXPECT), "generic dbf names");
        T.eq(gn.size(), 10, "custom attr appended (link not duplicated)");
        T.eq(gn.get(9), "POP", "custom name");
        // x,y values: check with python shapefile reader through shp_tools (read_shp prints JSON attrs)
        File dir = java.nio.file.Files.createTempDirectory("fields").toFile();
        File zf = new File(dir, "s.zip");
        try (FileOutputStream os = new FileOutputStream(zf)) {
            os.write(bo.toByteArray());
        }
        // read back with our own reader and compare UTM
        List<ShapeReader.Item> items = ShapeReader.list(zf);
        T.eq(items.size(), 1, "one layer");
        final List<Feature> got = new ArrayList<>();
        ShapeReader.read(zf, items.get(0), new Visitor() {
            public boolean feature(String layer, Feature ft) {
                got.add(ft);
                return true;
            }
        }, new ReadInfo());
        T.eq(got.size(), 2, "2 read back");
        T.eq(got.get(0).qadaa, "الكرخ", "gathaa -> qadaa");
        T.eq(got.get(0).nahiya, "الكاظمية", "Nahia -> nahiya");
        T.eq(got.get(0).governorate, "بغداد", "mohafadha -> governorate");
        T.eq(got.get(0).category, "القطاع التربوي التعليمي", "Gategory");
        T.eq(LandmarkFields.link(got.get(1)), "https://example.org/x", "link kept");
        T.eq(got.get(1).attrs.get("POP") != null || got.get(1).attrs.get("pop") != null, true, "custom kept");
        T.ok(!got.get(0).attrs.containsKey("x") && !got.get(0).attrs.containsKey("X"), "x not an attribute");

        // CSV default
        bo = new ByteArrayOutputStream();
        ExportHub.write(ls, GeoFormat.CSV, new ExportOptions(), bo);
        String csv = bo.toString("UTF-8");
        String[] lines = csv.replace("﻿", "").split("\r\n");
        T.eq(lines[0], "name,type,Gategory,gathaa,Nahia,mohafadha,x,y,link,pop", "csv header");
        Utm.Result u = Utm.fromLatLon(33.3152, 44.3661);
        T.ok(lines[1].contains(String.format(Locale.US, "%.3f,%.3f,", u.easting, u.northing)), "csv utm x,y: " + lines[1]);
        // legacy CSV
        bo = new ByteArrayOutputStream();
        CsvWriter.write(ls, bo);
        T.eq(bo.toString("UTF-8").replace("﻿", "").split("\r\n")[0], "name,type,Gategory,gathaa,Nahia,mohafadha,x,y,link", "legacy csv header");
        // XLSX checked with openpyxl
        File xf = new File(dir, "t.xlsx");
        try (FileOutputStream os = new FileOutputStream(xf)) {
            ExportHub.write(ls, GeoFormat.XLSX, new ExportOptions(), os);
        }
        Process pr = new ProcessBuilder("python3", "-I", "-c",
                "import openpyxl,sys;ws=openpyxl.load_workbook(sys.argv[1]).active;h=[c.value for c in ws[1]];print(h);"
                        + "assert h[:9]==['name','type','Gategory','gathaa','Nahia','mohafadha','x','y','link'],h;"
                        + "assert isinstance(ws.cell(2,7).value,float)", xf.getAbsolutePath()).inheritIO().start();
        T.eq(pr.waitFor(), 0, "xlsx header via openpyxl");
        // explicit WGS84 target -> x,y are lon/lat
        ExportOptions o = new ExportOptions();
        o.target = Crs.wgs84();
        bo = new ByteArrayOutputStream();
        ExportHub.write(ls, GeoFormat.CSV, o, bo);
        T.ok(bo.toString("UTF-8").split("\r\n")[1].contains("44.366100000,33.315200000"), "wgs84 x,y are lon,lat");
        // projected target
        o.target = Crs.of(32638);
        bo = new ByteArrayOutputStream();
        ExportHub.write(ls, GeoFormat.CSV, o, bo);
        String row = bo.toString("UTF-8").split("\r\n")[1];
        T.ok(row.contains(String.format(Locale.US, "%.3f", u.easting)), "utm target x");

        // CSV round trip through ImportHub keeps the fields
        File cf = new File(dir, "r.csv");
        try (FileOutputStream os = new FileOutputStream(cf)) {
            os.write(csv.getBytes(StandardCharsets.UTF_8));
        }
        ImportHub.Preview pv = ImportHub.preview(cf, "r.csv");
        ImportHub.Options io = new ImportHub.Options();
        PointTable.Mapping m = new PointTable.Mapping(pv.guess);
        io.csv = m;
        io.sourceCrs = Crs.of(32638);
        ImportHub.Result rr = ImportHub.load(cf, "r.csv", pv, io, null);
        T.eq(rr.layers.size(), 1, "csv layer");
        Feature c0 = rr.layers.get(0).features.get(0);
        T.eq(c0.qadaa, "الكرخ", "csv gathaa back");
        T.eq(c0.governorate, "بغداد", "csv mohafadha back");
        T.near(c0.lat, 33.3152, 1e-5, "csv x/y back to lat");
        // KML round trip
        bo = new ByteArrayOutputStream();
        Kml.write(ls, "t", CoordFmt.Fmt.DD, false, bo);
        T.ok(bo.toString("UTF-8").contains("name=\"Gategory\"") && bo.toString("UTF-8").contains("name=\"gathaa\""), "kml data names");
        List<LayerData> kl = Kml.read(new ByteArrayInputStream(bo.toByteArray()), "t.kml");
        Feature k0 = kl.get(0).features.get(0);
        T.eq(k0.qadaa, "الكرخ", "kml gathaa back");
        T.eq(k0.nahiya, "الكاظمية", "kml Nahia back");
        T.eq(LandmarkFields.link(kl.get(0).features.get(1)), "https://example.org/x", "kml link back");
        // GeoJSON
        bo = new ByteArrayOutputStream();
        ExportHub.write(ls, GeoFormat.GEOJSON, new ExportOptions(), bo);
        String gj = bo.toString("UTF-8");
        T.ok(gj.indexOf("\"name\"") < gj.indexOf("\"Gategory\"") && gj.indexOf("\"Gategory\"") < gj.indexOf("\"gathaa\"")
                && gj.indexOf("\"mohafadha\"") < gj.indexOf("\"x\"") && gj.indexOf("\"y\"") < gj.indexOf("\"link\""), "geojson order");
        T.done("FieldsTest");
    }
}
