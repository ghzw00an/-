package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.geo.Topology;

public class TopoTest {
    static Feature sq(double e, double n, double w, double h, String name) {
        Feature f = GeoTest.utmRect(e, n, w, h);
        f.name = name;
        return f;
    }

    static LayerData layer(Feature... fs) {
        LayerData l = new LayerData("t", "t", Feature.POLYGON);
        for (Feature f : fs) l.features.add(f);
        return l;
    }

    public static void main(String[] a) {
        // clean: 2x2 mosaic of adjacent squares sharing exact edges
        double e = 440000, n = 3680000, s = 1000;
        LayerData clean = layer(sq(e, n, s, s, "A"), sq(e + s, n, s, s, "B"), sq(e, n + s, s, s, "C"), sq(e + s, n + s, s, s, "D"));
        // utm squares converted to lon/lat share vertices exactly only if computed identically (they are)
        Topology.Report r = Topology.report(clean);
        T.eq(r.overlaps.size(), 0, "clean overlaps " + r.text(false));
        T.eq(r.gaps.size(), 0, "clean gaps");
        T.eq(r.selfIntersections.size(), 0, "clean self");
        T.eq(r.duplicates.size(), 0, "clean dup");
        T.ok(r.clean(), "clean flag");
        // gap: ring of 8 squares around a missing centre of 100 x 100 m (use 3x3 grid of blocks with a smaller centre hole)
        LayerData gap = layer(sq(e, n, 1000, 1000, "W"), sq(e + 1000, n, 400, 1000, "M1"), sq(e + 1500, n, 500, 1000, "M2"),
                sq(e + 1000, n, 500, 400, "S"), sq(e + 1000, n + 600, 500, 400, "N"), sq(e + 1500, n, 500, 1000, "E"));
        // above: W at left, centre column M1 (x 1000-1400) full height; so build a clean hole differently:
        LayerData g2 = layer(sq(e, n, 1000, 1000, "L"), sq(e + 1200, n, 800, 1000, "R"), sq(e + 1000, n, 200, 400, "B"),
                sq(e + 1000, n + 600, 200, 400, "T"));
        Topology.Report rg = Topology.report(g2);
        T.eq(rg.gaps.size(), 1, "gap count " + rg.text(false));
        T.near(rg.gaps.get(0).areaM2, 200 * 200, 40, "gap area 200x200");
        T.eq(rg.overlaps.size(), 0, "gap layer has no overlaps");
        // overlap
        LayerData ov = layer(sq(e, n, 1000, 1000, "A"), sq(e + 800, n, 1000, 1000, "B"));
        Topology.Report ro = Topology.report(ov);
        T.eq(ro.overlaps.size(), 1, "overlap count");
        T.near(ro.overlaps.get(0).areaM2, 200 * 1000, 200 * 1000 * 2e-3, "overlap area");
        T.ok(ro.overlaps.get(0).describe(true).contains("A") && ro.overlaps.get(0).describe(true).contains("تداخل"), "overlap text");
        // min area filters slivers: 0.5 m overlap -> 500 m2
        LayerData sl = layer(sq(e, n, 1000, 1000, "A"), sq(e + 999.5, n, 1000, 1000, "B"));
        T.eq(Topology.overlaps(sl, 1000).size(), 0, "sliver filtered");
        T.eq(Topology.overlaps(sl, 100).size(), 1, "sliver reported");
        // self-intersection (bow tie)
        Feature bow = new Feature();
        bow.geom = Feature.POLYGON;
        bow.name = "bow";
        bow.addPart(new double[]{44, 33, 44.01, 33.01, 44.01, 33, 44, 33.01, 44, 33}, false);
        LayerData bl = layer(bow);
        Topology.Report rb = Topology.report(bl);
        T.eq(rb.selfIntersections.size(), 1, "bow-tie detected");
        T.ok(rb.selfIntersections.get(0).geometry != null, "location point");
        T.ok(rb.text(true).contains("تقاطعات ذاتية: 1"), "arabic summary");
        T.ok(rb.all().size() >= 1, "all issues");
        // duplicate geometry (same shape different start vertex & order)
        Feature d1 = sq(e, n, 500, 500, "D1");
        Feature d2 = new Feature();
        d2.geom = Feature.POLYGON;
        d2.name = "D2";
        double[] r1 = d1.parts.get(0);
        double[] rot = new double[r1.length];
        // start at vertex 2, drop closing, re-close
        int cnt = r1.length / 2 - 1;
        for (int i = 0; i < cnt; i++) {
            rot[2 * i] = r1[2 * ((i + 2) % cnt)];
            rot[2 * i + 1] = r1[2 * ((i + 2) % cnt) + 1];
        }
        rot[2 * cnt] = rot[0];
        rot[2 * cnt + 1] = rot[1];
        d2.addPart(rot, false);
        Topology.Report rd = Topology.report(layer(d1, d2, sq(e + 5000, n, 100, 100, "other")));
        T.eq(rd.duplicates.size(), 1, "duplicate geometry");
        T.eq(Topology.duplicateGeometries(layer(d1, sq(e + 5000, n, 100, 100, "o"))).size(), 0, "no false duplicate");
        // empty / non polygon layer
        try {
            Topology.report(new LayerData("x", "x", Feature.POINT));
            T.ok(false, "point layer must throw");
        } catch (IllegalArgumentException ex) {
            T.ok(true, "point layer rejected");
        }
        // scale: 400 polygons grid performance
        LayerData grid = new LayerData("g", "g", Feature.POLYGON);
        for (int i = 0; i < 20; i++) for (int j = 0; j < 20; j++) grid.features.add(sq(e + i * 100, n + j * 100, 100, 100, "c" + i + "_" + j));
        long t0 = System.nanoTime();
        Topology.Report rr = Topology.report(grid);
        System.out.println("400-polygon topology: " + (System.nanoTime() - t0) / 1e9 + " s -> " + rr.total() + " issues");
        T.eq(rr.overlaps.size(), 0, "grid overlaps");
        T.eq(rr.gaps.size(), 0, "grid gaps");
        T.done("TopoTest");
    }
}
