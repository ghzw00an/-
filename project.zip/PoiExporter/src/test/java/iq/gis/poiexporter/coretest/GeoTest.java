package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.geo.GeoOps;
import iq.gis.poiexporter.core.geo.Geodesy;
import iq.gis.poiexporter.core.geo.Measure;
import iq.gis.poiexporter.core.geo.Stats;

import java.util.List;
import java.util.Random;

public class GeoTest {
    static double[] dms(double d, double m, double s) {
        return new double[]{d + m / 60 + s / 3600};
    }

    /** Polygon from a UTM38N rectangle (metres), converted to lon/lat; outer clockwise. */
    static Feature utmRect(double e, double n, double w, double h) {
        Crs.Tx inv = Crs.of(32638).to(Crs.wgs84());
        double[][] c = {{e, n}, {e, n + h}, {e + w, n + h}, {e + w, n}, {e, n}};
        double[] r = new double[10];
        for (int i = 0; i < 5; i++) {
            double[] p = inv.apply(c[i][0], c[i][1]);
            r[2 * i] = p[0];
            r[2 * i + 1] = p[1];
        }
        Feature f = new Feature();
        f.geom = Feature.POLYGON;
        f.addPart(r, false);
        f.id = Feature.newId();
        return f;
    }

    static Feature hole(Feature f, double e, double n, double w, double h) {
        Feature x = utmRect(e, n, w, h);
        f.addPart(iq.gis.poiexporter.core.Geo.oriented(x.parts.get(0), false), true);
        return f;
    }

    static Feature line(double... lonlat) {
        Feature f = new Feature();
        f.geom = Feature.LINE;
        f.addPart(lonlat, false);
        f.id = Feature.newId();
        return f;
    }

    public static void main(String[] a) {
        // ---- Vincenty known value: Flinders Peak -> Buninyong
        double lat1 = -(37 + 57 / 60.0 + 3.72030 / 3600), lon1 = 144 + 25 / 60.0 + 29.52440 / 3600;
        double lat2 = -(37 + 39 / 60.0 + 10.15610 / 3600), lon2 = 143 + 55 / 60.0 + 35.38390 / 3600;
        Geodesy.Inverse inv = Geodesy.inverse(lat1, lon1, lat2, lon2);
        T.near(inv.distance, 54972.271, 0.001, "vincenty distance");
        T.near(inv.azimuth1, 306 + 52 / 60.0 + 5.37 / 3600, 1e-5, "vincenty azimuth");
        double[] d = Geodesy.destination(lat1, lon1, inv.azimuth1, inv.distance);
        T.near(d[0], lat2, 1e-8, "direct lat");
        T.near(d[1], lon2, 1e-8, "direct lon");
        T.near(Geodesy.distance(0, 0, 1, 0), 110574, 1.0, "1 deg lat at equator");
        T.near(Geodesy.distance(0, 0, 0, 1), 111319.49, 0.5, "1 deg lon at equator");
        T.near(Geodesy.distance(0, 0, 0.5, 179.7), 19936288.0, 30000, "near antipodal fallback (sane)");
        T.near(Geodesy.distance(33.3, 44.4, 33.3, 44.4), 0, 0, "zero distance");
        // ---- area: 1 km UTM square
        Feature sq = utmRect(440000, 3680000, 1000, 1000);
        double ar = Geodesy.area(sq);
        // UTM scale factor ~0.9996..1.0004, so ground area differs by up to ~8e-4 from grid area: compare with grid area loosely
        T.near(ar / 1e6, 1.0, 1.2e-3, "1km utm square area");
        // exact check against independent formula: ground area = grid area / k^2, k at centre of the square
        Crs.Tx inv2 = Crs.of(32638).to(Crs.wgs84());
        double[] c = inv2.apply(440500, 3680500);
        double lamDiff = Math.toRadians(c[0] - 45), phi = Math.toRadians(c[1]);
        double k = 0.9996 * (1 + (lamDiff * lamDiff) * Math.pow(Math.cos(phi), 2) / 2);
        T.near(ar, 1e6 / (k * k), 1e6 * 5e-5, "area vs scale-factor formula");
        // hole subtracts
        Feature sh = hole(utmRect(440000, 3680000, 1000, 1000), 440200, 3680200, 400, 400);
        T.near(Geodesy.area(sh) / ar, 0.84, 5e-4, "hole subtracted");
        // large polygon vs spherical excess (1 deg x 1 deg at 33N): sphere area formula
        Feature big = new Feature();
        big.geom = Feature.POLYGON;
        big.addPart(new double[]{44, 33, 44, 34, 45, 34, 45, 33, 44, 33}, false);
        double sphere = Math.pow(6371008.8, 2) * Math.toRadians(1) * (Math.sin(Math.toRadians(34)) - Math.sin(Math.toRadians(33)));
        T.near(Geodesy.area(big) / sphere, 1.0, 0.01, "1deg cell vs sphere (ellipsoid ~0.3% diff)");
        T.near(Geodesy.perimeter(sq), 4000 / k, 2.0, "perimeter");
        double[] sides = Geodesy.sideLengths(sq.parts.get(0));
        T.eq(sides.length, 4, "4 sides");
        // ---- Measure
        Measure.AreaText at = Measure.area(1234567, false);
        T.ok(at.m2.startsWith("1,234,567") && at.ha.contains("123.4567") && at.km2.contains("1.234567"), "measure " + at.all());
        T.ok(Measure.length(850, false).equals("850.0 m") || Measure.length(850, false).startsWith("850"), "len " + Measure.length(850, false));
        T.ok(Measure.length(1250, false).startsWith("1.25"), "len km " + Measure.length(1250, false));
        T.ok(Measure.area(5, true).m2.contains("٥"), "arabic digits");
        // ---- buffer
        Feature pt = Feature.point(33.3152, 44.3661);
        for (int seg : new int[]{16, 32, 64}) {
            Feature b = GeoOps.buffer(pt, 1000, seg);
            double tol = seg == 16 ? 0.006 : seg == 32 ? 0.0015 : 0.0004;
            T.near(Geodesy.area(b) / (Math.PI * 1e6), 1.0, tol + 0.0005, "buffer area seg " + seg);
        }
        Feature ln = line(44.0, 33.0, 44.01, 33.0);
        Feature lb = GeoOps.buffer(ln, 100, 16);
        double lenM = Geodesy.length(ln);
        T.near(Geodesy.area(lb), lenM * 200 + Math.PI * 1e4, (lenM * 200 + Math.PI * 1e4) * 0.01, "line buffer area");
        Feature pb = GeoOps.buffer(sq, 100, 16);
        T.ok(Geodesy.area(pb) > ar + 4 * 1000 * 100, "polygon buffer grows");
        Feature neg = GeoOps.buffer(sq, -100, 16);
        T.near(Geodesy.area(neg) / ar, 0.64, 0.005, "negative buffer");
        T.ok(GeoOps.buffer(sq, -600, 16) == null, "buffer shrunk away -> null");
        try {
            GeoOps.buffer(pt, -5, 8);
            T.ok(false, "neg point buffer must throw");
        } catch (IllegalArgumentException e) {
            T.ok(e.getMessage() != null && !e.getMessage().isEmpty(), "neg buffer message");
        }
        // ---- union / intersection / difference
        Feature s1 = utmRect(440000, 3680000, 1000, 1000), s2 = utmRect(440500, 3680000, 1000, 1000);
        Feature u = GeoOps.union(java.util.Arrays.asList(s1, s2));
        T.near(Geodesy.area(u) / Geodesy.area(s1), 1.5, 1e-3, "union area");
        GeoOps.Overlap ov = GeoOps.intersection(s1, s2);
        T.near(ov.areaM2 / Geodesy.area(s1), 0.5, 1e-3, "overlap area");
        Feature df = GeoOps.difference(s1, s2);
        T.near(Geodesy.area(df) / Geodesy.area(s1), 0.5, 1e-3, "difference area");
        Feature far = utmRect(450000, 3680000, 100, 100);
        T.ok(GeoOps.intersection(s1, far) == null, "disjoint -> null");
        // ---- split with hole
        Feature donut = hole(utmRect(440000, 3680000, 1000, 1000), 440400, 3680400, 200, 200);
        Feature cut = line(inv2.apply(440500, 3679900)[0], inv2.apply(440500, 3679900)[1],
                inv2.apply(440500, 3681100)[0], inv2.apply(440500, 3681100)[1]);
        List<Feature> parts = GeoOps.split(donut, cut);
        T.eq(parts.size(), 2, "split parts");
        double tot = 0;
        for (Feature p : parts) tot += Geodesy.area(p);
        T.near(tot, Geodesy.area(donut), 1.0, "split area preserved");
        for (Feature p : parts) T.near(Geodesy.area(p) / Geodesy.area(donut), 0.5, 2e-3, "split halves");
        Feature miss = line(inv2.apply(450000, 3680000)[0], inv2.apply(450000, 3680000)[1],
                inv2.apply(450000, 3681000)[0], inv2.apply(450000, 3681000)[1]);
        try {
            GeoOps.split(donut, miss);
            T.ok(false, "split miss must throw");
        } catch (IllegalArgumentException e) {
            T.ok(true, "split miss");
        }
        // ---- select / clip
        LayerData pts = new LayerData("p", "pts", Feature.POINT);
        Crs.Tx fwdInv = Crs.of(32638).to(Crs.wgs84());
        double[] e0 = sq.parts.get(0);
        double[] bnd = {e0[0], e0[1]}; // a vertex lies exactly on the boundary
        double[][] tp = {{440500, 3680500}, {-1, -1} /*on boundary (lon/lat edge midpoint)*/, {439000, 3680500}, {440999, 3680999}};
        for (double[] p : tp) {
            double[] ll = p[0] < 0 ? bnd : fwdInv.apply(p[0], p[1]);
            Feature f = Feature.point(ll[1], ll[0]);
            f.name = "n" + p[0];
            pts.features.add(f);
        }
        T.eq(GeoOps.select(pts, sq, GeoOps.Mode.INSIDE).size(), 2, "inside excludes boundary pt (and outside)");
        T.eq(GeoOps.select(pts, sq, GeoOps.Mode.INTERSECTS).size(), 3, "intersects includes boundary");
        T.eq(GeoOps.select(pts, sq, GeoOps.Mode.BOUNDARY_INCLUDED).size(), 3, "covers includes boundary");
        LayerData cl = GeoOps.clip(pts, sq, false);
        T.eq(cl.features.size(), 2, "clip points");
        T.ok(!cl.features.get(0).id.equals(pts.features.get(0).id), "clip new ids");
        T.eq(cl.features.get(0).name, "n440500.0", "clip keeps attrs");
        LayerData lines = new LayerData("l", "lines", Feature.LINE);
        double[] la = fwdInv.apply(439500, 3680500), lbb = fwdInv.apply(440500, 3680500);
        Feature road = line(la[0], la[1], lbb[0], lbb[1]);
        road.name = "road";
        lines.features.add(road);
        LayerData cl2 = GeoOps.clip(lines, sq, true);
        T.eq(cl2.features.size(), 1, "clipped line count");
        T.near(Geodesy.length(cl2.features.get(0)), 500, 1.0, "clipped line length");
        T.eq(cl2.features.get(0).name, "road", "clipped line attrs");
        LayerData polys = new LayerData("g", "polys", Feature.POLYGON);
        polys.features.add(s2);
        LayerData cl3 = GeoOps.clip(polys, sq, true);
        T.near(Geodesy.area(cl3.features.get(0)) / Geodesy.area(s1), 0.5, 1e-3, "clipped polygon area");
        T.eq(GeoOps.clip(polys, far, true).features.size(), 0, "clip empty result");
        // ---- nearest
        LayerData cities = new LayerData("c", "c", Feature.POINT);
        double[][] cs = {{33.3152, 44.3661}, {36.34, 43.13}, {30.5, 47.78}, {32.6, 44.02}};
        for (double[] p : cs) cities.features.add(Feature.point(p[0], p[1]));
        List<GeoOps.Hit> hits = GeoOps.nearest(cities, 33.0, 44.4, 2);
        T.eq(hits.size(), 2, "k nearest");
        T.near(hits.get(0).lat, 33.3152, 1e-9, "nearest first");
        T.near(hits.get(0).distanceM, Geodesy.distance(33.0, 44.4, 33.3152, 44.3661), 1e-6, "nearest geodesic distance");
        T.ok(hits.get(0).distanceM < hits.get(1).distanceM, "sorted");
        Feature l2 = line(44.0, 33.0, 44.0, 34.0);
        LayerData mixed = new LayerData("m", "m", Feature.LINE);
        mixed.features.add(l2);
        GeoOps.Hit lh = GeoOps.nearest(mixed, 33.5, 44.1, 1).get(0);
        T.near(lh.lon, 44.0, 1e-5, "nearest point on line lon");
        T.near(lh.distanceM, Geodesy.distance(33.5, 44.1, 33.5, 44.0), 5, "distance to line");
        // ---- grids
        List<Feature> pg = GeoOps.pointGrid(sq, 100);
        T.eq(pg.size(), 100, "point grid 10x10");
        List<Feature> sg = GeoOps.squareGrid(sq, 250, true);
        T.ok(sg.size() >= 16 && sg.size() <= 25, "square grid cells " + sg.size());
        double sum = 0;
        for (Feature f : sg) sum += Geodesy.area(f);
        T.near(sum / ar, 1.0, 1e-3, "grid covers polygon");
        List<Feature> sg2 = GeoOps.squareGrid(sq, 300, true);
        double sum2 = 0;
        for (Feature f : sg2) sum2 += Geodesy.area(f);
        T.near(sum2 / ar, 1.0, 2e-3, "clipped grid area equals polygon");
        T.ok(GeoOps.squareGrid(sq, 300, false).size() >= 16, "unclipped grid whole cells");
        try {
            GeoOps.pointGrid(sq, 0.0001);
            T.ok(false, "huge grid must throw");
        } catch (IllegalArgumentException e) {
            T.ok(true, "grid limit");
        }
        // ---- centroid, representative, vertices, hull, simplify
        double[] ce = GeoOps.centroid(sq);
        double[] cc = fwdInv.apply(440500, 3680500);
        T.near(ce[0], cc[0], 2e-6, "centroid lon");
        T.near(ce[1], cc[1], 2e-6, "centroid lat");
        Feature cshape = new Feature();
        cshape.geom = Feature.POLYGON;
        cshape.addPart(new double[]{44, 33, 44, 33.1, 44.1, 33.1, 44.1, 33.09, 44.01, 33.09, 44.01, 33.01, 44.1, 33.01, 44.1, 33, 44, 33}, false);
        double[] rp = GeoOps.representativePoint(cshape);
        T.ok(iq.gis.poiexporter.core.Geo.inPolygon(cshape, rp[0], rp[1]), "representative point inside concave");
        T.eq(GeoOps.vertices(sq).size(), 4, "vertices omit closing");
        Feature hull = GeoOps.convexHull(java.util.Arrays.asList(cshape));
        T.ok(Geodesy.area(hull) > Geodesy.area(cshape), "hull larger");
        Feature simp = GeoOps.simplify(line(44, 33, 44.001, 33.00001, 44.002, 33, 44.003, 33.00001, 44.01, 33), 50);
        T.eq(simp.parts.get(0).length / 2, 2, "simplify");
        // ---- stats
        LayerData sl = new LayerData("s", "s", Feature.POINT);
        for (int i = 0; i < 6; i++) {
            Feature f = Feature.point(33.3152 + i * 1e-6, 44.3661);
            f.type = i < 4 ? "مدرسة" : "مسجد";
            f.governorate = "بغداد";
            sl.features.add(f);
        }
        Feature outside = Feature.point(10, 10);
        outside.type = "مدرسة";
        sl.features.add(outside);
        Feature area = GeoOps.buffer(Feature.point(33.3152, 44.3661), 500, 16);
        Stats.Result sr = Stats.compute(java.util.Arrays.asList(sl), area, GeoOps.Mode.INSIDE, Stats.By.TYPE);
        T.eq(sr.total(), 6, "stats total in area");
        T.eq(sr.counts.get("مدرسة"), 4, "stats school count");
        Stats.Table tb = Stats.table(sr, Stats.By.TYPE);
        T.ok(tb.toCsv().contains("مدرسة,4,66.7"), "stats csv " + tb.toCsv());
        // ---- performance: 1M points
        Random rnd = new Random(1);
        int N = 1_000_000;
        double[] arr = new double[2 * N];
        int expected = 0;
        for (int i = 0; i < N; i++) {
            arr[2 * i] = 44.0 + rnd.nextDouble() * 0.1;
            arr[2 * i + 1] = 33.0 + rnd.nextDouble() * 0.1;
        }
        Feature big2 = new Feature();
        big2.geom = Feature.POLYGON;
        big2.addPart(new double[]{44.02, 33.02, 44.02, 33.08, 44.08, 33.08, 44.08, 33.02, 44.02, 33.02}, false);
        for (int i = 0; i < N; i++)
            if (arr[2 * i] > 44.02 && arr[2 * i] < 44.08 && arr[2 * i + 1] > 33.02 && arr[2 * i + 1] < 33.08) expected++;
        long t0 = System.nanoTime();
        int[] sel = GeoOps.selectIndices(arr, big2, GeoOps.Mode.INSIDE);
        double sec = (System.nanoTime() - t0) / 1e9;
        System.out.println("select 1M points: " + sec + " s, selected " + sel.length);
        T.eq(sel.length, expected, "1M selection count");
        T.ok(sec < 15, "1M selection speed");
        T.done("GeoTest");
    }
}
