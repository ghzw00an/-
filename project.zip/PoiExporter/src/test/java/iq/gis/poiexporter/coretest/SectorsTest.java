package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.Sectors;

public class SectorsTest {
    public static void main(String[] a) {
        T.eq(Sectors.ALL.length, 15, "15 sectors");
        int items = 0;
        for (Sectors.Sector s : Sectors.ALL) items += s.items.length;
        T.eq(items, 12 + 4 + 11 + 4 + 15 + 3 + 10 + 4 + 5 + 1 + 11 + 6 + 9 + 3 + 7, "item count as supplied");
        T.eq(Sectors.ALL[0].name, "قطاع المواصلات", "first sector verbatim");
        T.eq(Sectors.ALL[0].items[9], "طريق نيسمي", "verbatim item kept");
        T.eq(Sectors.find("القطاع الصحي").items[0], "مستشفى", "find by name");
        T.eq(Sectors.find("القطاع الصحي ").name, "القطاع الصحي", "trailing space ok");
        T.eq(Sectors.find("القطاع الصحى").name, "القطاع الصحي", "yaa variant ok");
        T.eq(Sectors.find("غير موجود") == null, true, "unknown sector");
        T.eq(Sectors.ofItem("مسجد").name, "القطاع الديني", "item to sector");
        T.eq(Sectors.allOfItem("مخزن").size(), 2, "مخزن in two sectors");
        T.eq(Sectors.allOfItem("شركة").size(), 2, "شركة in two sectors");
        T.eq(Sectors.allOfItem("xyz").size(), 0, "unknown item");
        T.done("SectorsTest");
    }
}
