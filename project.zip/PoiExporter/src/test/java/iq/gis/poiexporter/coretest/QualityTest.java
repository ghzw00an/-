package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.*;
import iq.gis.poiexporter.core.admin.AdminRef;
import iq.gis.poiexporter.core.db.*;
import iq.gis.poiexporter.core.io.GeomCheck;

import java.util.*;

public class QualityTest {
    static Feature pt(String n, double lat, double lon) {
        Feature f = Feature.point(lat, lon);
        f.id = Feature.newId();
        f.name = n;
        return f;
    }

    public static void main(String[] a) throws Exception {
        Workspace w = new Workspace(new MemRepo(), null);
        w.openDefault("t");
        LayerData l = w.addLayer("L", Feature.POINT, "user");
        List<Feature> fs = new ArrayList<>();
        Feature a1 = pt("مدرسة النور", 33.3152, 44.3661);
        a1.type = "مدرسة";
        Feature a2 = pt("مدرسة النور", 33.31521, 44.36611); // duplicate (same name, ~1 m)
        Feature a3 = pt("مدرسة اخرى", 33.30, 44.30);
        Feature far = pt("بعيد", 51.5, -0.12); // London: outside Iraq
        Feature none = pt("", 36.19, 44.01);
        fs.addAll(Arrays.asList(a1, a2, a3, far, none));
        w.addFeatures(l.id, fs, "add");
        AdminRef ref = AdminRef.get();
        T.ok(ref != null, "admin data available");
        Quality.Report r = Quality.analyze(w.layer(l.id), 25, ref);
        System.out.println(r.toText(true));
        T.eq(r.total, 5, "total");
        T.eq(r.emptyName, 1, "empty name");
        T.eq(r.emptyType, 4, "empty type");
        T.eq(r.outsideIraq.size(), 1, "outside Iraq");
        T.eq(r.duplicates.size(), 1, "one duplicate group");
        T.eq(r.duplicateExtra, 1, "one removable");
        T.eq(r.missingAdmin.size(), 4, "four fillable (London excluded)");
        // fill admin as one undo step
        List<Feature[]> fill = Quality.fillAdmin(r.missingAdmin, ref);
        List<Feature> before = new ArrayList<>(), after = new ArrayList<>();
        for (Feature[] p : fill) {
            before.add(p[0]);
            after.add(p[1]);
        }
        int steps = w.history().size();
        w.updateFeatures(l.id, before, after, "fill");
        T.eq(w.history().size(), steps + 1, "one history step for bulk update");
        T.eq(w.feature(a1.id).governorate, "بغداد", "filled governorate");
        T.ok(!w.feature(a1.id).qadaa.isEmpty(), "filled qadaa");
        w.undo();
        T.eq(w.feature(a1.id).governorate, "", "undo restores empty");
        w.redo();
        T.eq(w.feature(a1.id).governorate, "بغداد", "redo");
        // remove duplicates
        List<String> rm = Quality.duplicateIdsToRemove(Quality.analyze(w.layer(l.id), 25, null).duplicates);
        T.eq(rm.size(), 1, "one id to remove");
        w.deleteFeatures(l.id, rm, "dups");
        T.eq(w.layer(l.id).features.size(), 4, "removed");
        T.eq(Quality.analyze(w.layer(l.id), 25, null).duplicates.size(), 0, "clean after removal");
        // geometry repair: open ring + repeated vertex
        Feature poly = new Feature();
        poly.geom = Feature.POLYGON;
        poly.id = Feature.newId();
        poly.name = "p";
        poly.addPart(new double[]{44, 33, 44.01, 33, 44.01, 33, 44.01, 33.01, 44, 33.01}, false); // open + dup vertex
        LayerData pl = w.addLayer("P", Feature.POLYGON, "user");
        w.addFeature(pl.id, poly);
        Quality.Report pr = Quality.analyze(w.layer(pl.id), 25, null);
        T.eq(pr.invalidGeometry.size(), 1, "invalid polygon found");
        List<Feature[]> fx = Quality.repairGeometry(pr.invalidGeometry, false);
        T.eq(fx.size(), 1, "repaired");
        T.ok(GeomCheck.check(fx.get(0)[1], 0).isEmpty(), "repaired polygon is clean");
        // bow-tie needs makeValid
        Feature bow = new Feature();
        bow.geom = Feature.POLYGON;
        bow.id = Feature.newId();
        bow.name = "bow";
        bow.addPart(new double[]{44, 33, 44.02, 33.02, 44.02, 33, 44, 33.02, 44, 33}, false);
        w.addFeature(pl.id, bow);
        Quality.Report pr2 = Quality.analyze(w.layer(pl.id), 25, null);
        T.ok(pr2.geometryCodes.containsKey(GeomCheck.SELF_INTERSECTION), "self intersection reported");
        List<Feature[]> fx2 = Quality.repairGeometry(Collections.singletonList(bow), true);
        T.eq(fx2.size(), 1, "bow-tie repaired");
        T.ok(GeomCheck.check(fx2.get(0)[1], 0).isEmpty(), "bow-tie valid after makeValid");
        T.done("QualityTest");
    }
}
