package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.admin.AdminRef;

public class AdminTest {
    public static void main(String[] a) throws Exception {
        AdminRef r = AdminRef.get();
        T.ok(r != null, "bundled data loads");
        T.eq(r.units(1).size(), 18, "18 governorates");
        T.eq(r.units(2).size(), 101, "101 districts");
        for (AdminRef.Unit g : r.units(1)) T.ok(!g.nameAr.isEmpty(), "arabic " + g.nameEn);
        for (AdminRef.Unit d : r.units(2)) T.ok(!d.nameAr.isEmpty() && !d.parentAr.isEmpty(), "arabic+parent " + d.nameEn);
        Object[][] c = {
                {"الموصل", 36.335, 43.119, "نينوى"}, {"تكريت", 34.600, 43.678, "صلاح الدين"}, {"بعقوبة", 33.7466, 44.643, "ديالى"}, {"الفلوجة", 33.353, 43.786, "الأنبار"},
                {"سامراء", 34.198, 43.874, "صلاح الدين"}, {"الكوت", 32.5128, 45.8182, "واسط"}, {"الحلة", 32.4637, 44.4196, "بابل"}, {"الكوفة", 32.0328, 44.4017, "النجف"},
                {"النجف", 32.0, 44.336, "النجف"}, {"كربلاء", 32.616, 44.0249, "كربلاء"}, {"الديوانية", 31.9886, 44.925, "القادسية"}, {"السماوة", 31.319, 45.287, "المثنى"},
                {"الناصرية", 31.058, 46.2573, "ذي قار"}, {"البصرة", 30.5085, 47.7835, "البصرة"}, {"الزبير", 30.3908, 47.7113, "البصرة"}, {"الفاو", 29.9747, 48.4719, "البصرة"},
                {"زاخو", 37.1436, 42.6817, "دهوك"}, {"دهوك", 36.867, 42.9885, "دهوك"}, {"أربيل", 36.1911, 44.0092, "أربيل"}, {"السليمانية", 35.5613, 45.4329, "السليمانية"},
                {"كركوك", 35.4681, 44.3922, "كركوك"}, {"الرمادي", 33.4258, 43.2994, "الأنبار"}, {"حديثة", 34.1389, 42.3772, "الأنبار"}, {"هيت", 33.6411, 42.8283, "الأنبار"},
                {"الرطبة", 33.0333, 40.2833, "الأنبار"}, {"القائم", 34.3803, 41.0306, "الأنبار"}, {"عانة", 34.3657, 41.9791, "الأنبار"}, {"سنجار", 36.3217, 41.8767, "نينوى"},
                {"تلعفر", 36.3667, 42.45, "نينوى"}, {"الحويجة", 35.3228, 43.7735, "كركوك"}, {"الشرقاط", 35.5189, 43.2606, "صلاح الدين"}, {"بيجي", 34.9306, 43.4936, "صلاح الدين"},
                {"بلد", 34.0133, 44.1458, "صلاح الدين"}, {"خانقين", 34.3452, 45.3869, "ديالى"}, {"كلار", 34.6286, 45.3203, "السليمانية"}, {"حلبجة", 35.1778, 45.9861, "السليمانية"},
                {"رانية", 36.2511, 44.8836, "السليمانية"}, {"كويسنجق", 36.0833, 44.6333, "أربيل"}, {"العمادية", 37.0942, 43.4882, "دهوك"}, {"عقرة", 36.7447, 43.8903, "دهوك"},
                {"شقلاوة", 36.4, 44.3167, "أربيل"}, {"مخمور", 35.7667, 43.5833, "أربيل"}, {"الحمدانية", 36.2667, 43.3833, "نينوى"}, {"العمارة", 31.8358, 47.144, "ميسان"},
                {"الحي", 32.1739, 46.0436, "واسط"}, {"الشطرة", 31.4119, 46.1706, "ذي قار"}, {"سوق الشيوخ", 30.8864, 46.5011, "ذي قار"}, {"المسيب", 32.7833, 44.2833, "بابل"},
                {"المحمودية", 33.0667, 44.3667, "بغداد"}, {"الخالص", 33.8458, 44.5319, "ديالى"}, {"المقدادية", 33.9786, 44.9314, "ديالى"}, {"طوز خورماتو", 34.8883, 44.6358, "صلاح الدين"},
                {"كفري", 34.6956, 44.9672, "ديالى"}, {"قلعة صالح", 31.5253, 47.2689, "ميسان"}, {"الرميثة", 31.5222, 45.2056, "المثنى"}, {"بغداد-الكرخ", 33.3152, 44.3661, "بغداد"}};
        int govBad = 0, distBad = 0;
        for (Object[] x : c) {
            AdminRef.Hit h = r.locate((Double) x[1], (Double) x[2]);
            String g = h.governorate(true);
            if (!g.equals(x[3])) {
                govBad++;
                System.out.println("GOVERNORATE MISMATCH " + x[0] + " expected " + x[3] + " got " + g);
            }
            if (!h.qadaa(true).equals(x[0])) {
                distBad++;
                System.out.println("district differs: " + x[0] + " got " + h.qadaa(true));
            }
        }
        System.out.println("points " + c.length + ", governorate mismatches " + govBad + ", district-name differences " + distBad);
        T.ok(govBad <= 1, "governorate of known cities (mismatches " + govBad + ")");
        T.ok(distBad <= 4, "district of known cities (differences " + distBad + ")");
        // outside Iraq / Gulf
        T.ok(!r.locate(35.69, 51.39).found(), "Tehran not in Iraq");
        T.ok(!r.locate(29.5, 49.5).found(), "Gulf not in Iraq");
        // fill keeps typed values
        Feature k = Feature.point(33.3152, 44.3661);
        k.qadaa = "مكتوب";
        r.fill(k, true);
        T.eq(k.qadaa, "مكتوب", "typed qadaa kept");
        T.eq(k.governorate, "بغداد", "governorate filled");
        LayerData l1 = r.layer(1, true, null);
        T.eq(l1.features.size(), 18, "layer adm1");
        T.ok(l1.kind.equals("reference") && !l1.official && !l1.source.isEmpty() && !l1.accuracyNote.isEmpty(), "layer provenance");
        T.ok(r.layer(2, true, "Baghdad").features.size() >= 4, "Baghdad districts");
        T.ok(r.accuracyNote(true).contains("غير رسمية"), "unofficial note");
        T.done("AdminTest");
    }
}
