package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.Annotations;

public class AnnotationsTest {
    public static void main(String[] x) {
        Annotations a = new Annotations();
        Annotations.Item t = new Annotations.Item();
        t.lat = 33.3;
        t.lon = 44.4;
        t.text = "مرحبا \"quote\"\nline2";
        t.sizeSp = 18;
        t.color = 0xFFFF0000;
        a.items().add(t);
        Annotations.Item im = new Annotations.Item();
        im.kind = Annotations.IMAGE;
        im.lat = 33.31;
        im.lon = 44.41;
        im.file = "logo.png";
        im.widthDp = 120;
        a.items().add(im);
        Annotations b = Annotations.fromJson(a.toJson());
        T.eq(b.items().size(), 2, "two items");
        T.eq(b.items().get(0).text, t.text, "text with quotes, newline and Arabic");
        T.eq(b.items().get(0).color, 0xFFFF0000, "color argb");
        T.eq(b.items().get(0).background, 0xE6FFFFFF, "default background");
        T.near(b.items().get(0).sizeSp, 18, 1e-6, "size");
        T.eq(b.items().get(1).kind, Annotations.IMAGE, "kind");
        T.eq(b.items().get(1).file, "logo.png", "file");
        T.eq(b.items().get(1).widthDp, 120, "width");
        T.eq(b.find(t.id) != null, true, "find");
        Annotations.Item n = b.nearest(33.3001, 44.4001, 50);
        T.eq(n != null && n.id.equals(t.id), true, "nearest within 50 m");
        T.eq(b.nearest(33.5, 44.4, 50) == null, true, "nothing near");
        T.eq(b.remove(t.id), true, "remove");
        T.eq(b.items().size(), 1, "one left");
        T.eq(Annotations.fromJson("{broken").items().size(), 0, "damaged json -> empty");
        T.eq(Annotations.fromJson("").items().size(), 0, "empty");
        T.eq(Annotations.fromJson("{\"items\":[{\"lat\":999,\"lon\":0}]}").items().size(), 0, "out-of-range dropped");
        T.done("AnnotationsTest");
    }
}
