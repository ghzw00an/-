package iq.gis.poiexporter.coretest;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.LockSecret;
import iq.gis.poiexporter.core.io.Dxf;
import iq.gis.poiexporter.core.io.ExportOptions;
import iq.gis.poiexporter.core.io.GeoFormat;
import iq.gis.poiexporter.core.io.ReadInfo;
import iq.gis.poiexporter.core.io.Visitor;

public class DxfLockTest {
    public static void main(String[] a) throws Exception {
        // ---- lock secret
        String salt = LockSecret.newSalt();
        String h = LockSecret.hash(salt, "1234");
        T.eq(LockSecret.verify(salt, h, "1234"), true, "right pin verifies");
        T.eq(LockSecret.verify(salt, h, "1235"), false, "wrong pin fails");
        T.eq(LockSecret.verify(salt, h, ""), false, "empty fails");
        T.eq(LockSecret.verify(LockSecret.newSalt(), h, "1234"), false, "other salt fails");
        T.eq(LockSecret.hash(salt, "1234").equals(h), true, "hash is deterministic");
        T.eq(LockSecret.validPin("1234"), true, "4 digits ok");
        T.eq(LockSecret.validPin("123"), false, "3 digits rejected");
        T.eq(LockSecret.validPin("123456789"), false, "9 digits rejected");
        T.eq(LockSecret.validPin("12a4"), false, "letters rejected");
        T.eq(LockSecret.validPattern("0-1-2-5"), true, "pattern ok");
        T.eq(LockSecret.validPattern("0-1-2"), false, "3 dots rejected");
        T.eq(LockSecret.validPattern("0-1-1-2"), false, "repeated dot rejected");
        T.eq(LockSecret.validPattern("0-1-2-9"), false, "dot 9 rejected");
        T.eq(LockSecret.waitSeconds(4), 0, "no wait for 4 fails");
        T.eq(LockSecret.waitSeconds(5), 30, "30 s at 5 fails");
        T.eq(LockSecret.waitSeconds(50), 3600, "capped at 1 hour");

        // ---- DXF round trip
        LayerData l = new LayerData("x", "Schools", Feature.POINT);
        Feature p = Feature.point(33.3, 44.4);
        p.name = "مدرسة 1";
        l.features.add(p);
        Feature ln = new Feature();
        ln.geom = Feature.LINE;
        ln.addPart(new double[]{44.4, 33.3, 44.41, 33.31, 44.42, 33.3}, false);
        ln.lon = 44.4;
        ln.lat = 33.3;
        l.features.add(ln);
        Feature pg = new Feature();
        pg.geom = Feature.POLYGON;
        pg.addPart(new double[]{44.4, 33.3, 44.41, 33.3, 44.41, 33.31, 44.4, 33.3}, false);
        pg.lon = 44.4;
        pg.lat = 33.3;
        l.features.add(pg);
        List<LayerData> ls = new ArrayList<>();
        ls.add(l);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ExportOptions o = new ExportOptions();
        Dxf.Result r = Dxf.write(ls, o, bo);
        String dxf = new String(bo.toByteArray(), StandardCharsets.US_ASCII);
        T.eq(r.points, 1, "1 point written");
        T.eq(r.lines, 1, "1 line written");
        T.eq(r.polygons, 1, "1 polygon written");
        T.eq(r.texts, 1, "1 name text");
        T.eq(r.crs.epsg, 32638, "UTM 38N chosen for Baghdad");
        T.eq(dxf.contains("\\U+0645"), true, "Arabic escaped");
        T.eq(dxf.contains("EOF"), true, "ends with EOF");
        T.eq(dxf.contains("SCHOOLS_PT"), true, "ascii layer name");
        for (int i = 0; i < dxf.length(); i++) if (dxf.charAt(i) > 127) T.eq(true, false, "non-ascii byte in dxf");

        File f = File.createTempFile("tst", ".dxf");
        Files.write(f.toPath(), bo.toByteArray());
        T.eq(GeoFormat.detect("a.dxf", Files.readAllBytes(f.toPath())), GeoFormat.DXF, "detected as DXF");
        final List<Feature> got = new ArrayList<>();
        final List<String> layers = new ArrayList<>();
        ReadInfo info = new ReadInfo();
        Dxf.read(f, new Visitor() {
            public boolean feature(String layer, Feature ft) {
                got.add(ft);
                layers.add(layer);
                return true;
            }
        }, info);
        T.eq(got.size(), 3, "3 entities read back (text ignored)");
        int pt = 0, lnN = 0, pgN = 0;
        for (Feature ft : got) {
            if (ft.geom == Feature.POINT) pt++;
            else if (ft.geom == Feature.LINE) lnN++;
            else pgN++;
        }
        T.eq(pt + "," + lnN + "," + pgN, "1,1,1", "geometry kinds read back");
        Feature pr = null;
        for (Feature ft : got) if (ft.geom == Feature.POINT) pr = ft;
        T.eq(pr.parts.get(0)[0] > 400000 && pr.parts.get(0)[0] < 500000, true, "point easting in UTM range");
        Feature pgr = null;
        for (Feature ft : got) if (ft.geom == Feature.POLYGON) pgr = ft;
        double[] ring = pgr.parts.get(0);
        T.eq(ring.length, 8, "polygon closed again (4 vertices)");
        T.eq(ring[0] == ring[6] && ring[1] == ring[7], true, "ring closed");
        T.eq(info.crs == null, true, "CRS unknown after reading DXF");

        // hand-made DXF with LWPOLYLINE, CIRCLE and LINE
        String hand = "0\nSECTION\n2\nENTITIES\n0\nLWPOLYLINE\n8\nROADS\n70\n1\n10\n0\n20\n0\n10\n10\n20\n0\n10\n10\n20\n10\n"
                + "0\nCIRCLE\n8\nC\n10\n5\n20\n5\n40\n2\n0\nLINE\n8\nL\n10\n0\n20\n0\n30\n0\n11\n3\n21\n4\n31\n0\n0\nENDSEC\n0\nEOF\n";
        File f2 = File.createTempFile("hnd", ".dxf");
        Files.write(f2.toPath(), hand.getBytes(StandardCharsets.US_ASCII));
        final List<Feature> g2 = new ArrayList<>();
        Dxf.read(f2, new Visitor() {
            public boolean feature(String layer, Feature ft) {
                g2.add(ft);
                return true;
            }
        }, new ReadInfo());
        T.eq(g2.size(), 3, "hand-made dxf: 3 entities");
        T.eq(g2.get(0).geom, Feature.POLYGON, "closed LWPOLYLINE is a polygon");
        T.eq(g2.get(1).geom, Feature.POLYGON, "circle is a polygon");
        T.eq(g2.get(2).geom, Feature.LINE, "line");
        T.eq(g2.get(2).parts.get(0).length, 4, "line has 2 points");
        T.eq(g2.get(2).parts.get(0)[2], 3.0, "line end x");
        T.eq(g2.get(2).parts.get(0)[3], 4.0, "line end y");
        T.done("DxfLockTest");
    }
}
