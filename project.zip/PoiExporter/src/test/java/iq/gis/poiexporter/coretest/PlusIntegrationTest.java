package iq.gis.poiexporter.coretest;

import java.util.Arrays;

import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.PlusCode;
import iq.gis.poiexporter.core.coord.CoordService;
import iq.gis.poiexporter.core.table.PointTable;

public class PlusIntegrationTest {
    public static void main(String[] a) {
        String code = PlusCode.encode(33.3152, 44.3661);
        CoordFmt.Parsed p = CoordFmt.parse(code);
        T.eq(p.fmt, CoordFmt.Fmt.PLUS, "format detected");
        T.near(p.lat, 33.3152, 1e-4, "lat");
        T.near(p.lon, 44.3661, 1e-4, "lon");
        T.eq(CoordFmt.format(CoordFmt.Fmt.PLUS, 33.3152, 44.3661), code, "format back");
        T.eq(CoordFmt.parse("DD 33.3152, 44.3661").fmt != CoordFmt.Fmt.PLUS, true, "dd stays dd");
        T.eq(CoordFmt.parse("+33.3152, +44.3661").fmt != CoordFmt.Fmt.PLUS, true, "signed dd stays dd");
        // short code needs the reference
        String sh = PlusCode.shorten(code, 33.32, 44.37);
        PlusCode.setReference(33.32, 44.37);
        CoordFmt.Parsed ps = CoordFmt.parse(sh + " بغداد");
        T.near(ps.lat, 33.3152, 1e-4, "short lat");
        // converter
        CoordService.Result r = CoordService.convert(code, null, true, null);
        T.eq(r.detectedFormat, "PLUS", "service detects plus");
        T.near(r.lat, 33.3152, 1e-4, "service lat");
        T.ok(r.plus != null && r.plus.length() >= 11, "service re-encodes " + r.plus);
        T.ok(r.copyText(true).contains("Plus Code"), "copy text has plus code");
        CoordService.Result r2 = CoordService.convert("33.3152 44.3661", null, true, null);
        T.eq(PlusCode.encode(33.3152, 44.3661, 12).startsWith(r2.plus.substring(0, 9)), true, "dd to plus");
        // table column guess
        PointTable.Guess g = PointTable.guess(Arrays.asList("name", "Plus Code"));
        T.eq(g.combined, 1, "plus code column found");
        g = PointTable.guess(Arrays.asList("الاسم", "plus_code", "notes"));
        T.eq(g.combined, 1, "plus_code column found");
        T.done("PlusIntegrationTest");
    }
}
