package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.*;
import iq.gis.poiexporter.core.geo.Analysis;

import java.util.*;

public class AnalysisTest {
    static Feature pt(double lat, double lon, String name, String type, String cat) {
        Feature f = Feature.point(lat, lon);
        f.name = name;
        f.type = type;
        f.category = cat;
        return f;
    }

    static LayerData layer(Feature... fs) {
        LayerData l = new LayerData("t", "test", Feature.POINT);
        l.features.addAll(Arrays.asList(fs));
        return l;
    }

    public static void main(String[] a) {
        // filter
        LayerData l = layer(pt(33, 44, "مدرسة النور", "مدرسة", "القطاع التربوي والتعليم"), pt(33, 44.001, "مدرسه الأمل", "مدرسه", "القطاع التربوي والتعليم"),
                pt(33, 44.002, "مسجد", "مسجد", "القطاع الديني"), pt(33, 44.003, "", "", ""));
        T.eq(Analysis.filter(l, 1, "مدرسة", Analysis.Match.EQUALS).features.size(), 2, "equals ignores taa marbuta variant");
        T.eq(Analysis.filter(l, 0, "نور", Analysis.Match.CONTAINS).features.size(), 1, "contains");
        T.eq(Analysis.filter(l, 0, "", Analysis.Match.EMPTY).features.size(), 1, "empty");
        T.eq(Analysis.filter(l, 0, "", Analysis.Match.NOT_EMPTY).features.size(), 3, "not empty");
        try {
            Analysis.filter(l, 0, "  ", Analysis.Match.CONTAINS);
            T.ok(false, "blank text rejected");
        } catch (IllegalArgumentException e) {
            T.ok(true, "blank text rejected");
        }
        T.eq(Analysis.filter(l, 0, "نور", Analysis.Match.CONTAINS).features.get(0).id.equals(l.features.get(0).id), false, "copies get new ids");
        // summary
        LinkedHashMap<String, Integer> s = Analysis.summarize(l, 2);
        T.eq(s.get("القطاع التربوي والتعليم"), 2, "summary count");
        T.eq(s.get(""), 1, "empty group");
        T.eq(s.keySet().iterator().next(), "القطاع التربوي والتعليم", "largest first");
        T.ok(Analysis.summaryText(l, 2, true).contains("50.0%"), "percent");
        // radius
        LayerData r = Analysis.withinRadius(layer(pt(33, 44, "a", "", ""), pt(33.001, 44, "b", "", ""), pt(33.01, 44, "c", "", "")), 33, 44, 200);
        T.eq(r.features.size(), 2, "within 200 m");
        T.eq(r.features.get(0).name, "a", "sorted by distance");
        T.eq(r.features.get(1).attrs.get("dist_m"), "111", "dist attr");
        // centroids
        LayerData pg = new LayerData("p", "p", Feature.POLYGON);
        Feature sq = new Feature();
        sq.geom = Feature.POLYGON;
        sq.parts.add(new double[]{44, 33, 44.01, 33, 44.01, 33.01, 44, 33.01, 44, 33});
        Geo.setRepresentative(sq);
        sq.name = "sq";
        pg.features.add(sq);
        LayerData c = Analysis.centroids(pg);
        T.eq(c.geom, Feature.POINT, "centroid layer is points");
        T.near(c.features.get(0).lon, 44.005, 1e-4, "centroid lon");
        T.near(c.features.get(0).lat, 33.005, 1e-4, "centroid lat");
        T.eq(c.features.get(0).name, "sq", "centroid keeps name");
        // density grid
        LayerData dg = layer(pt(33, 44, "1", "", ""), pt(33.0001, 44.0001, "2", "", ""), pt(33.0002, 44.0001, "3", "", ""), pt(33.02, 44.02, "4", "", ""));
        LayerData g = Analysis.densityGrid(dg, 500, false);
        int tot = 0, max = 0;
        for (Feature f : g.features) {
            int n = Integer.parseInt(f.attrs.get("count"));
            tot += n;
            max = Math.max(max, n);
        }
        T.eq(tot, 4, "all points counted once");
        T.eq(max, 3, "three in one cell");
        T.eq(g.features.size(), 2, "empty cells dropped");
        T.ok(Analysis.densityGrid(dg, 500, true).features.size() > 2, "empty cells kept on request");
        try {
            Analysis.densityGrid(dg, 0.01, false);
            T.ok(false, "huge grid rejected");
        } catch (IllegalArgumentException e) {
            T.ok(true, "huge grid rejected");
        }
        // thiessen
        LayerData th = Analysis.thiessen(layer(pt(33, 44, "w", "", ""), pt(33, 44.01, "e", "", ""), pt(33.01, 44, "n", "", ""), pt(33.01, 44.01, "ne", "", "")));
        T.eq(th.features.size(), 4, "one cell per point");
        Set<String> names = new HashSet<>();
        for (Feature f : th.features) names.add(f.name);
        T.eq(names.size(), 4, "cells carry their site's name");
        double a1 = 0;
        for (Feature f : th.features) a1 += iq.gis.poiexporter.core.geo.Geodesy.area(f);
        double[] ex = Analysis.extent(th);
        T.ok(a1 > 0 && ex[0] < 44 && ex[2] > 44.01, "cells cover the points (area " + (long) a1 + ")");
        // clusters
        List<Feature> pts = new ArrayList<>();
        Random rnd = new Random(7);
        for (int i = 0; i < 10; i++) pts.add(pt(33 + rnd.nextDouble() * 0.0005, 44 + rnd.nextDouble() * 0.0005, "a" + i, "", ""));
        for (int i = 0; i < 6; i++) pts.add(pt(33.05 + rnd.nextDouble() * 0.0005, 44.05 + rnd.nextDouble() * 0.0005, "b" + i, "", ""));
        pts.add(pt(33.2, 44.2, "noise1", "", ""));
        pts.add(pt(33.3, 44.3, "noise2", "", ""));
        List<Analysis.Cluster> cl = Analysis.clusters(layer(pts.toArray(new Feature[0])), 100, 3);
        T.eq(cl.size(), 2, "two clusters");
        T.eq(cl.get(0).members.size(), 10, "biggest first");
        T.eq(cl.get(1).members.size(), 6, "second");
        List<LayerData> cls = Analysis.clusterLayers(layer(pts.toArray(new Feature[0])), 100, 3, true);
        T.eq(cls.size(), 2, "points + hulls");
        T.eq(cls.get(0).features.size(), 2, "two centres");
        // nearest neighbour
        List<Feature> reg = new ArrayList<>();
        for (int i = 0; i < 10; i++) for (int j = 0; j < 10; j++) reg.add(pt(33 + i * 0.001, 44 + j * 0.001, "", "", ""));
        Analysis.NN nn = Analysis.nearestNeighbour(layer(reg.toArray(new Feature[0])));
        T.ok(nn.ratio > 1.5 && nn.z > 1.96, "regular grid is dispersed: R=" + nn.ratio);
        T.eq(nn.verdict(false), "Dispersed", "verdict dispersed");
        List<Feature> clu = new ArrayList<>();
        double[][] centres = {{33, 44}, {33.05, 44.05}, {33, 44.05}, {33.05, 44}, {33.025, 44.025}};
        for (double[] ce : centres) for (int i = 0; i < 20; i++) clu.add(pt(ce[0] + rnd.nextDouble() * 0.0005, ce[1] + rnd.nextDouble() * 0.0005, "", "", ""));
        Analysis.NN nc = Analysis.nearestNeighbour(layer(clu.toArray(new Feature[0])));
        T.ok(nc.ratio < 0.5 && nc.z < -1.96, "blob plus outliers is clustered: R=" + nc.ratio);
        List<Feature> rd = new ArrayList<>();
        for (int i = 0; i < 400; i++) rd.add(pt(33 + rnd.nextDouble() * 0.05, 44 + rnd.nextDouble() * 0.05, "", "", ""));
        Analysis.NN nr = Analysis.nearestNeighbour(layer(rd.toArray(new Feature[0])));
        T.ok(nr.ratio > 0.8 && nr.ratio < 1.25, "uniform random is near 1: R=" + nr.ratio);
        // bounding rectangle: a 100 m x 40 m rectangle rotated 30 degrees, as 4 points
        double k = 111320.0 * Math.cos(Math.toRadians(33));
        double ang = Math.toRadians(30);
        double[][] cs = {{0, 0}, {100, 0}, {100, 40}, {0, 40}};
        List<Feature> rp = new ArrayList<>();
        for (double[] q : cs) {
            double x = q[0] * Math.cos(ang) - q[1] * Math.sin(ang), y = q[0] * Math.sin(ang) + q[1] * Math.cos(ang);
            rp.add(pt(33 + y / 111320.0, 44 + x / k, "", "", ""));
        }
        LayerData mbr = Analysis.boundingRectangles(layer(rp.toArray(new Feature[0])), false);
        T.eq(mbr.features.size(), 1, "one rectangle");
        T.near(Double.parseDouble(mbr.features.get(0).attrs.get("area_m2")), 4000, 60, "MBR area is 100x40");
        // path
        LayerData path = Analysis.pointPath(layer(pt(33, 44, "b", "", ""), pt(33, 44.001, "a", "", ""), pt(33.001, 44.001, "c", "", "")), false, false);
        T.eq(path.geom, Feature.LINE, "line");
        T.near(Double.parseDouble(path.features.get(0).attrs.get("length_m")), 93 + 111, 3, "line length");
        LayerData poly = Analysis.pointPath(layer(pt(33, 44, "", "", ""), pt(33, 44.01, "", "", ""), pt(33.01, 44.01, "", "", "")), true, false);
        double[] ring = poly.features.get(0).parts.get(0);
        T.eq(ring[0] == ring[ring.length - 2] && ring[1] == ring[ring.length - 1], true, "polygon ring closed");
        // simplify
        LayerData ln = new LayerData("l", "l", Feature.LINE);
        Feature lf = new Feature();
        lf.geom = Feature.LINE;
        lf.parts.add(new double[]{44, 33, 44.001, 33.00001, 44.002, 33, 44.003, 33.00001, 44.004, 33});
        Geo.setRepresentative(lf);
        ln.features.add(lf);
        LayerData sl = Analysis.simplifyLayer(ln, 10);
        T.eq(sl.features.get(0).parts.get(0).length / 2, 2, "wiggles under 10 m removed");
        T.eq(Analysis.simplifyLayer(ln, 0).features.get(0).parts.get(0).length / 2 >= 2, true, "zero tolerance keeps shape");
        // merge
        LayerData m = Analysis.merge(Arrays.asList(layer(pt(1, 1, "x", "", "")), layer(pt(2, 2, "y", "", ""))), "m");
        T.eq(m.features.size(), 2, "merged");
        try {
            Analysis.merge(Arrays.asList(layer(pt(1, 1, "x", "", "")), ln), "m");
            T.ok(false, "mixed geometry rejected");
        } catch (IllegalArgumentException e) {
            T.ok(true, "mixed geometry rejected");
        }
        T.done("AnalysisTest");
    }
}
