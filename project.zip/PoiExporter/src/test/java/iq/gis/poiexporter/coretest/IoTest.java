package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Geo;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.MiniJson;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.io.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

public class IoTest {
    static final String AR = "بغداد", AR2 = "مدرسة الأمل";
    static File dir;

    static File f(String n) {
        return new File(dir, n);
    }

    static int py(String... args) throws Exception {
        List<String> cmd = new ArrayList<>(Arrays.asList("python3", "-I", "src/test/python/shp_tools.py"));
        cmd.addAll(Arrays.asList(args));
        return new ProcessBuilder(cmd).inheritIO().start().waitFor();
    }

    static List<LayerData> sample() {
        LayerData pts = new LayerData("a", "points layer", Feature.POINT);
        Feature p1 = Feature.point(33.3152, 44.3661);
        p1.id = "id-1";
        p1.name = AR;
        p1.nameEn = "Baghdad";
        p1.type = "city";
        p1.attrs.put("pop", "7000000");
        p1.attrs.put("الحالة", "جيد");
        p1.accuracy = 3.5;
        p1.status = Feature.STATUS_VERIFIED;
        Feature p2 = Feature.point(30.5, 47.8);
        p2.id = "id-2";
        p2.name = AR2;
        pts.features.add(p1);
        pts.features.add(p2);
        LayerData ln = new LayerData("b", "lines", Feature.LINE);
        Feature l1 = new Feature();
        l1.geom = Feature.LINE;
        l1.id = "id-3";
        l1.name = "road";
        l1.addPart(new double[]{44.0, 33.0, 44.1, 33.1, 44.2, 33.05}, false);
        l1.addPart(new double[]{44.5, 33.5, 44.6, 33.6}, false);
        Geo.setRepresentative(l1);
        ln.features.add(l1);
        LayerData pg = new LayerData("c", "polys", Feature.POLYGON);
        Feature g1 = new Feature();
        g1.geom = Feature.POLYGON;
        g1.id = "id-4";
        g1.name = "park";
        g1.addPart(Geo.oriented(new double[]{44, 33, 44, 33.2, 44.2, 33.2, 44.2, 33, 44, 33}, true), false);
        g1.addPart(Geo.oriented(new double[]{44.05, 33.05, 44.05, 33.1, 44.1, 33.1, 44.1, 33.05, 44.05, 33.05}, false), true);
        Geo.setRepresentative(g1);
        pg.features.add(g1);
        return new ArrayList<>(Arrays.asList(pts, ln, pg));
    }

    static ImportHub.Result roundTrip(File file, String name) throws Exception {
        ImportHub.Preview pv = ImportHub.preview(file, name);
        ImportHub.Options o = new ImportHub.Options();
        return ImportHub.load(file, name, pv, o, null);
    }

    static double[] ring(LayerData l, int feat, int part) {
        return l.features.get(feat).parts.get(part);
    }

    static LayerData byGeom(ImportHub.Result r, int geom) {
        for (LayerData l : r.layers) if (l.geom == geom) return l;
        return null;
    }

    static void checkSample(ImportHub.Result r, String tag, boolean attrs) {
        LayerData p = byGeom(r, Feature.POINT), l = byGeom(r, Feature.LINE), g = byGeom(r, Feature.POLYGON);
        T.ok(p != null && p.features.size() == 2, tag + " points");
        T.ok(l != null && l.features.size() == 1, tag + " lines");
        T.ok(g != null && g.features.size() == 1, tag + " polys");
        if (p == null || l == null || g == null) return;
        Feature a = null;
        for (Feature f : p.features) if (f.name.equals(AR)) a = f;
        T.ok(a != null, tag + " arabic name");
        if (a != null) {
            T.near(a.lat, 33.3152, 1e-7, tag + " lat");
            T.near(a.lon, 44.3661, 1e-7, tag + " lon");
            if (attrs) { String pv = a.attrs.get("pop") != null ? a.attrs.get("pop") : a.attrs.get("POP"); T.eq(pv, "7000000", tag + " attr"); }
        }
        T.eq(l.features.get(0).parts.size(), 2, tag + " multipart line");
        Feature poly = g.features.get(0);
        long holes = 0;
        for (int i = 0; i < poly.parts.size(); i++) if (poly.isHole(i)) holes++;
        T.eq(holes, 1L, tag + " hole kept");
        T.eq(r.report.badCoordinates, 0L, tag + " no bad coords");
    }

    public static void main(String[] a) throws Exception {
        S.ar = true;
        dir = new File(System.getProperty("java.io.tmpdir"), "io_" + System.nanoTime());
        dir.mkdirs();
        List<LayerData> layers = sample();
        ExportOptions eo = new ExportOptions();

        // ---- GeoJSON
        File gj = f("s.geojson");
        try (OutputStream os = new FileOutputStream(gj)) { ExportHub.write(layers, GeoFormat.GEOJSON, eo, os); }
        int rc = new ProcessBuilder("python3", "-I", "-c", "import json,sys;d=json.load(open(sys.argv[1],encoding='utf8'));assert len(d['features'])==4;print('geojson json ok')", gj.getAbsolutePath()).inheritIO().start().waitFor();
        T.eq(rc, 0, "geojson valid json");
        ImportHub.Result r = roundTrip(gj, "s.geojson");
        checkSample(r, "geojson", true);
        // ---- GPX
        File gpx = f("s.gpx");
        try (OutputStream os = new FileOutputStream(gpx)) { ExportHub.write(layers, GeoFormat.GPX, eo, os); }
        r = roundTrip(gpx, "s.gpx");
        T.eq(byGeom(r, Feature.POINT).features.size(), 2, "gpx pts");
        T.ok(byGeom(r, Feature.LINE) != null && byGeom(r, Feature.LINE).features.size() >= 2, "gpx lines (tracks incl. polygon outline)");
        int rcx = new ProcessBuilder("python3", "-I", "-c", "from lxml import etree;import sys;t=etree.parse(sys.argv[1]);print('gpx wellformed', len(t.getroot()))", gpx.getAbsolutePath()).inheritIO().start().waitFor();
        T.eq(rcx, 0, "gpx lxml");
        // ---- KML / KMZ
        for (GeoFormat fm : new GeoFormat[]{GeoFormat.KML, GeoFormat.KMZ}) {
            File k = f("s." + fm.ext);
            try (OutputStream os = new FileOutputStream(k)) { ExportHub.write(layers, fm, eo, os); }
            r = roundTrip(k, k.getName());
            checkSample(r, fm.name(), false);
        }
        // ---- Shapefile WGS84
        File sz = f("s_wgs.zip");
        try (OutputStream os = new FileOutputStream(sz)) { ExportHub.write(layers, GeoFormat.SHP_ZIP, eo, os); }
        File js = f("s_wgs.json");
        T.eq(py("read_shp", sz.getAbsolutePath(), js.getAbsolutePath()), 0, "python reads our shapefile");
        Map<String, Object> pj = MiniJson.obj(new String(Files.readAllBytes(js.toPath()), StandardCharsets.UTF_8));
        T.eq(pj.size(), 3, "3 shapefiles in zip " + pj.keySet());
        r = roundTrip(sz, "s_wgs.zip");
        checkSample(r, "shp-wgs", true);
        T.ok(r.layers.get(0).features.get(0).source.length() > 0, "source set");
        // ---- Shapefile UTM 38N reprojected export then import back
        ExportOptions utm = new ExportOptions();
        utm.target = Crs.of(32638);
        File su = f("s_utm.zip");
        try (OutputStream os = new FileOutputStream(su)) { ExportHub.write(layers, GeoFormat.SHP_ZIP, utm, os); }
        File ju = f("s_utm.json");
        T.eq(py("read_shp", su.getAbsolutePath(), ju.getAbsolutePath()), 0, "python reads utm shapefile");
        String ut = new String(Files.readAllBytes(ju.toPath()), StandardCharsets.UTF_8);
        T.ok(ut.contains("UTM_Zone_38N"), "prj has UTM zone");
        // independent check of the first point's UTM coordinates
        Crs.Tx tx = Crs.wgs84().to(Crs.of(32638));
        double[] e = tx.apply(44.3661, 33.3152);
        Map<String, Object> pu = MiniJson.obj(ut);
        boolean foundPt = false;
        for (Object o : pu.values()) {
            Map<String, Object> m = (Map<String, Object>) o;
            if (((Double) m.get("type")) == 1.0) {
                List<Object> rec0 = (List<Object>) ((List<Object>) m.get("records")).get(0);
                List<Object> geo = (List<Object>) rec0.get(0);
                T.near((Double) geo.get(0), e[0], 0.001, "utm shp x");
                T.near((Double) geo.get(1), e[1], 0.001, "utm shp y");
                foundPt = true;
            }
        }
        T.ok(foundPt, "point shapefile in utm zip");
        r = roundTrip(su, "s_utm.zip");
        T.ok(r.layers.get(0).features.size() > 0, "utm zip import (crs detected from prj)");
        checkSample(r, "shp-utm", true);
        ImportHub.Preview pvu = ImportHub.preview(su, "s_utm.zip");
        T.ok(pvu.crsKnown(), "prj crs detected");
        T.eq(pvu.layers.get(0).crs.epsg, 32638, "detected epsg");
        // unsupported projection gives a clear error before writing
        ExportOptions bad = new ExportOptions();
        bad.target = Crs.of(2767);
        T.ok(!ExportHub.preflight(layers, GeoFormat.SHP_ZIP, bad).isEmpty(), "preflight warns unsupported crs");
        // ---- independent python-written shapefile: cp1256 arabic, UTM prj, deleted-free
        File pz = f("py_cp1256.zip");
        String script = "import sys\nsys.path.insert(0,'src/test/python')\nimport shp_tools as s\n"
                + "recs=[((444000.0,3686000.0),['" + "\\u0628\\u063a\\u062f\\u0627\\u062f" + "','a'])]\n"
                + "s.write_shapefile(sys.argv[1],'pts',1,recs,[('NAME','C',30),('T','C',10)],'cp1256',prj='PROJCS[\"WGS_1984_UTM_Zone_38N\",GEOGCS[\"GCS_WGS_1984\"]]')\n";
        File sc = f("mk.py");
        Files.write(sc.toPath(), script.getBytes(StandardCharsets.UTF_8));
        T.eq(new ProcessBuilder("python3", "-I", sc.getAbsolutePath(), pz.getAbsolutePath()).directory(new File(".")).inheritIO().start().waitFor(), 0, "py wrote shp");
        r = roundTrip(pz, "py_cp1256.zip");
        T.eq(r.layers.size(), 1, "py shp layer");
        if (r.layers.size() == 1) {
            T.eq(r.layers.get(0).features.get(0).name, AR, "cp1256 decoded");
            double[] back = Crs.of(32638).to(Crs.wgs84()).apply(444000, 3686000);
            T.near(r.layers.get(0).features.get(0).lon, back[0], 1e-9, "py shp reprojected lon");
        }
        // ---- unknown CRS and projected values: reported, not silently wrong
        File pz2 = f("py_nocrs.zip");
        Files.write(sc.toPath(), script.replace(",prj='PROJCS[\"WGS_1984_UTM_Zone_38N\",GEOGCS[\"GCS_WGS_1984\"]]'", "").getBytes(StandardCharsets.UTF_8));
        py2(sc, pz2);
        ImportHub.Preview pn = ImportHub.preview(pz2, "py_nocrs.zip");
        T.ok(!pn.crsKnown() && !pn.warnings.isEmpty(), "no crs -> warning " + pn.warnings);
        ImportHub.Result rn = ImportHub.load(pz2, "py_nocrs.zip", pn, new ImportHub.Options(), null);
        T.eq(rn.report.badCoordinates, 1L, "projected values without crs counted bad");
        ImportHub.Options oc = new ImportHub.Options();
        oc.sourceCrs = Crs.of(32638);
        rn = ImportHub.load(pz2, "py_nocrs.zip", pn, oc, null);
        T.eq(rn.report.imported, 1L, "assigned crs imports");
        // ---- CSV via hub
        File csv = f("p.csv");
        Files.write(csv.toPath(), ("name,lat,lon\n" + AR + ",33.3,44.4\nx,200,44\n").getBytes(StandardCharsets.UTF_8));
        ImportHub.Preview pc = ImportHub.preview(csv, "p.csv");
        ImportHub.Options oc2 = new ImportHub.Options();
        oc2.csv = new iq.gis.poiexporter.core.table.PointTable.Mapping(pc.guess);
        ImportHub.Result rc2 = ImportHub.load(csv, "p.csv", pc, oc2, null);
        T.eq(rc2.report.imported, 1L, "csv imported");
        T.eq(rc2.report.badCoordinates, 1L, "csv bad");
        // ---- CSV/XLSX export of project with UTM columns
        File ce = f("e.csv");
        try (OutputStream os = new FileOutputStream(ce)) { ExportHub.write(layers, GeoFormat.CSV, utm, os); }
        String ctext = new String(Files.readAllBytes(ce.toPath()), StandardCharsets.UTF_8);
        T.ok(ctext.contains("x,y") && ctext.contains(AR), "csv export columns");
        File xe = f("e.xlsx");
        try (OutputStream os = new FileOutputStream(xe)) { ExportHub.write(layers, GeoFormat.XLSX, eo, os); }
        T.eq(new ProcessBuilder("python3", "-I", "-c", "import openpyxl,sys;ws=openpyxl.load_workbook(sys.argv[1]).active;rows=list(ws.iter_rows(values_only=True));assert len(rows)==5,len(rows);print(rows[0][:6])", xe.getAbsolutePath()).inheritIO().start().waitFor(), 0, "xlsx export readable");
        // ---- GeoPackage
        File sql = f("g.sql"), db = f("g.gpkg");
        try (ScriptSql ss = new ScriptSql(sql)) { ExportHub.writeGpkg(layers, eo, ss); }
        T.eq(py("sql", db.getAbsolutePath(), sql.getAbsolutePath()), 0, "sqlite executes our script");
        T.eq(py("gpkg_check", db.getAbsolutePath()), 0, "gpkg structure valid");
        File dump = f("g.json");
        T.eq(py("gpkg_dump", db.getAbsolutePath(), dump.getAbsolutePath()), 0, "dump");
        ImportHub.gpkgOpener = ff -> new DumpSource(dump);
        r = roundTrip(db, "g.gpkg");
        checkSample(r, "gpkg", true);
        // ---- DupFinder + GeomCheck
        List<Feature> pf = new ArrayList<>();
        for (String n : new String[]{"مدرسة الأمل", "مدرسه الامل", "other"}) {
            Feature x = Feature.point(33.3 + (n.equals("other") ? 0.0005 : 0.00005 * pf.size()), 44.4);
            x.name = n;
            pf.add(x);
        }
        List<DupFinder.Group> gs = DupFinder.find(pf, 25, true);
        T.eq(gs.size(), 1, "dup group by normalized arabic name");
        T.eq(gs.get(0).members.size(), 2, "dup members");
        Feature bow = new Feature();
        bow.geom = Feature.POLYGON;
        bow.addPart(new double[]{44, 33, 44.01, 33.01, 44.01, 33, 44, 33.01, 44, 33}, false);
        T.ok(GeomCheck.check(bow, Feature.POLYGON).contains(GeomCheck.SELF_INTERSECTION), "bowtie flagged");
        Feature fixed = GeomCheck.makeValid(bow);
        T.ok(fixed != null && GeomCheck.check(fixed, Feature.POLYGON).isEmpty(), "makeValid repairs");
        Feature open = new Feature();
        open.geom = Feature.POLYGON;
        open.addPart(new double[]{44, 33, 44.1, 33, 44.1, 33.1, 44, 33.1}, false);
        T.ok(GeomCheck.check(open, Feature.POLYGON).contains(GeomCheck.NOT_CLOSED), "open ring flagged");
        T.ok(GeomCheck.fix(open) && GeomCheck.check(open, Feature.POLYGON).isEmpty(), "ring closed+oriented");
        // ---- big geojson streaming under small heap
        File big = f("big.geojson");
        try (Writer w = new BufferedWriter(new FileWriter(big), 1 << 16)) {
            w.write("{\"type\":\"FeatureCollection\",\"features\":[");
            Random rnd = new Random(2);
            for (int i = 0; i < 200000; i++) {
                if (i > 0) w.write(",");
                w.write("{\"type\":\"Feature\",\"properties\":{\"name\":\"p" + i + "\",\"k\":" + i + "},\"geometry\":{\"type\":\"Point\",\"coordinates\":[" + (40 + rnd.nextDouble() * 8) + "," + (30 + rnd.nextDouble() * 6) + "]}}");
            }
            w.write("]}");
        }
        long t0 = System.nanoTime();
        ImportHub.Preview pb = ImportHub.preview(big, "big.geojson");
        T.eq(pb.layers.get(0).count, 200000L, "big preview count");
        ImportHub.Result rb = ImportHub.load(big, "big.geojson", pb, new ImportHub.Options(), null);
        T.eq(rb.report.imported, 200000L, "big imported");
        System.out.println("200k geojson preview+load: " + (System.nanoTime() - t0) / 1e9 + " s");
        T.done("IoTest");
    }

    static void py2(File sc, File z) throws Exception {
        T.eq(new ProcessBuilder("python3", "-I", sc.getAbsolutePath(), z.getAbsolutePath()).directory(new File(".")).inheritIO().start().waitFor(), 0, "py wrote");
    }

    /** Emits the SQL a SqlExec receives as a script that python's sqlite3 can execute. */
    static final class ScriptSql implements Gpkg.SqlExec, Closeable {
        final Writer w;

        ScriptSql(File f) throws IOException {
            w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8);
        }

        public void begin() throws IOException { w.write("BEGIN;\n"); }

        public void commit() throws IOException { w.write("COMMIT;\n"); }

        public void exec(String sql, Object... args) throws IOException {
            StringBuilder b = new StringBuilder();
            int ai = 0;
            for (int i = 0; i < sql.length(); i++) {
                char c = sql.charAt(i);
                if (c != '?') { b.append(c); continue; }
                Object o = args[ai++];
                if (o == null) b.append("NULL");
                else if (o instanceof byte[]) { b.append("X'"); for (byte x : (byte[]) o) b.append(String.format("%02x", x)); b.append("'"); }
                else if (o instanceof Number) b.append(o);
                else b.append("'").append(String.valueOf(o).replace("'", "''")).append("'");
            }
            w.write(b + ";\n");
        }

        public void close() throws IOException { w.close(); }
    }

    /** Gpkg.Source over a JSON dump produced by python (blobs as hex). */
    static final class DumpSource implements Gpkg.Source {
        final Map<String, Object> d;

        DumpSource(File f) throws IOException {
            d = MiniJson.obj(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
        }

        Map<String, Object> tables() { return (Map<String, Object>) d.get("tables"); }

        Object conv(Object o) {
            if (o instanceof String && ((String) o).startsWith("hex:")) {
                String h = ((String) o).substring(4);
                byte[] b = new byte[h.length() / 2];
                for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16);
                return b;
            }
            return o;
        }

        public List<Object[]> featureTables() {
            List<Object[]> out = new ArrayList<>();
            for (Object o : (List<Object>) d.get("contents")) {
                List<Object> r = (List<Object>) o;
                out.add(new Object[]{r.get(0), r.get(1), r.get(2)});
            }
            return out;
        }

        public String geometryColumn(String t) { return (String) ((Map<String, Object>) d.get("geomcol")).get(t); }

        public Object[] srs(long id) {
            List<Object> r = (List<Object>) ((Map<String, Object>) d.get("srs")).get(String.valueOf(id));
            return r == null ? null : new Object[]{r.get(0), r.get(1)};
        }

        public List<String> columns(String t) {
            List<String> out = new ArrayList<>();
            for (Object o : (List<Object>) ((Map<String, Object>) tables().get(t)).get("cols")) out.add((String) o);
            return out;
        }

        public long count(String t) { return ((List<Object>) ((Map<String, Object>) tables().get(t)).get("rows")).size(); }

        public List<Object[]> rows(String t, List<String> cols, long off, int limit) {
            Map<String, Object> tb = (Map<String, Object>) tables().get(t);
            List<String> all = columns(t);
            List<Object[]> out = new ArrayList<>();
            List<Object> rows = (List<Object>) tb.get("rows");
            for (long i = off; i < Math.min(rows.size(), off + limit); i++) {
                List<Object> r = (List<Object>) rows.get((int) i);
                Object[] x = new Object[cols.size()];
                for (int k = 0; k < x.length; k++) x[k] = conv(r.get(all.indexOf(cols.get(k))));
                out.add(x);
            }
            return out;
        }
    }
}
