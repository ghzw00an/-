package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.Jts;
import iq.gis.poiexporter.core.io.GeoJson;
import iq.gis.poiexporter.core.io.ReadInfo;
import iq.gis.poiexporter.core.io.Visitor;
import iq.gis.poiexporter.core.MiniJson;
import org.locationtech.jts.geom.Geometry;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Offline build tool (not shipped): combines geoBoundaries IRQ ADM1 + ADM2 into the app resource admin/iq_admin.json.
 * Usage: BuildAdmin adm1.geojson adm2.geojson out.json
 * Arabic names are NOT in the source data; they are added here from a hand-written table and flagged in the metadata.
 */
public class BuildAdmin {
    static final Map<String, String> AR1 = new LinkedHashMap<>();
    static final Map<String, String> AR2 = new LinkedHashMap<>();

    static {
        String[] a1 = {"Al-Anbar", "الأنبار", "Al-Basrah", "البصرة", "Al-Muthanna", "المثنى", "Al-Qadisiyah", "القادسية", "Al-Sulaimaniyah", "السليمانية",
                "An-Najaf", "النجف", "Babil", "بابل", "Baghdad", "بغداد", "Dhi Qar", "ذي قار", "Diyala", "ديالى", "Dohuk", "دهوك", "Erbil", "أربيل",
                "Karbala", "كربلاء", "Kirkuk", "كركوك", "Maysan", "ميسان", "Ninawa", "نينوى", "Salah al-Din", "صلاح الدين", "Wasit", "واسط"};
        for (int i = 0; i < a1.length; i += 2) AR1.put(a1[i], a1[i + 1]);
        String[] a2 = {"Abu Al-Khaseeb", "أبو الخصيب", "Afaq", "عفك", "Ain Al-Tamur", "عين التمر", "Al-Adhamiya", "الأعظمية", "Al-Amadiya", "العمادية",
                "Al-Amara", "العمارة", "Al-Baaj", "البعاج", "Al-Basrah", "البصرة", "Al-Chibayish", "الجبايش", "Al-Daur", "الدور", "Al-Diwaniya", "الديوانية",
                "Al-Falluja", "الفلوجة", "Al-Faw", "الفاو", "Al-Hai", "الحي", "Al-Hamdaniya", "الحمدانية", "Al-Hamza", "الحمزة", "Al-Hashimiya", "الهاشمية",
                "Al-Hatra", "الحضر", "Al-Hawiga", "الحويجة", "Al-Hilla", "الحلة", "Al-Hindiya", "الهندية", "Al-Kadhmiyah", "الكاظمية", "Al-Kahla", "الكحلاء",
                "Al-Kaim", "القائم", "Al-Karkh", "الكرخ", "Al-Khalis", "الخالص", "Al-Khidhir", "الخضر", "Al-Kufa", "الكوفة", "Al-Kut", "الكوت",
                "Al-Mada'in", "المدائن", "Al-Mahaweel", "المحاويل", "Al-Mahmoudiya", "المحمودية", "Al-Maimouna", "الميمونة", "Al-Manathera", "المناذرة",
                "Al-Mejar Al-Kabir", "المجر الكبير", "Al-Midaina", "المدينة", "Al-Mosul", "الموصل", "Al-Muqdadiya", "المقدادية", "Al-Mussyab", "المسيب",
                "Al-Najaf", "النجف", "Al-Namaniya", "النعمانية", "Al-Nasiriya", "الناصرية", "Al-Qurna", "القرنة", "Al-Ramadi", "الرمادي", "Al-Rifai", "الرفاعي",
                "Al-Risafa", "الرصافة", "Al-Rumaitha", "الرميثة", "Al-Rutba", "الرطبة", "Al-Salman", "السلمان", "Al-Samawa", "السماوة", "Al-Shamiya", "الشامية",
                "Al-Shatra", "الشطرة", "Al-Shikhan", "الشيخان", "Al-Shirqat", "الشرقاط", "Al-Sulaymaniyah", "السليمانية", "Al-Suwaira", "الصويرة",
                "Al-Thawra", "الثورة", "Al-Zibar", "الزيبار", "Al-Zubair", "الزبير", "Ali Al-Gharbi", "علي الغربي", "Ana", "عانة", "Aqra", "عقرة", "Badra", "بدرة",
                "Balad", "بلد", "Baladruz", "بلدروز", "Baquba", "بعقوبة", "Beygee", "بيجي", "Chamchamal", "جمجمال", "Daquq", "داقوق", "Derbendikhan", "دربندخان",
                "Dibis", "دبس", "Dokan", "دوكان", "Duhok", "دهوك", "Erbil", "أربيل", "Haditha", "حديثة", "Halabcha", "حلبجة", "Heet", "هيت", "Kalar", "كلار",
                "Kerbela", "كربلاء", "Khanaqin", "خانقين", "Kifri", "كفري", "Kirkuk", "كركوك", "Koysinjaq", "كويسنجق", "Makhmour", "مخمور", "Panjwin", "پنجوين",
                "Pshdar", "بشدر", "Qalat Saleh", "قلعة صالح", "Rania", "رانية", "Rawanduz", "رواندوز", "Samarra", "سامراء", "Shaqlawa", "شقلاوة",
                "Sharbazher", "شاربازير", "Shat Al-Arab", "شط العرب", "Sinjar", "سنجار", "Sumail", "سميل", "Suq Al-Shoyokh", "سوق الشيوخ", "Telafar", "تلعفر",
                "Tikrit", "تكريت", "Tilkaef", "تلكيف", "Tooz Khurmato", "طوزخورماتو", "Zakho", "زاخو"};
        for (int i = 0; i < a2.length; i += 2) AR2.put(a2[i], a2[i + 1]);
    }

    static final Map<String, String> PARENT = new LinkedHashMap<>();

    static {
        String[][] t = {
                {"Al-Basrah", "Abu Al-Khaseeb", "Al-Basrah", "Al-Faw", "Al-Midaina", "Al-Qurna", "Al-Zubair", "Shat Al-Arab"},
                {"Maysan", "Al-Amara", "Ali Al-Gharbi", "Al-Kahla", "Al-Maimouna", "Al-Mejar Al-Kabir", "Qalat Saleh"},
                {"Dhi Qar", "Al-Chibayish", "Al-Nasiriya", "Al-Rifai", "Al-Shatra", "Suq Al-Shoyokh"},
                {"Al-Muthanna", "Al-Rumaitha", "Al-Salman", "Al-Samawa", "Al-Khidhir"},
                {"Al-Qadisiyah", "Afaq", "Al-Diwaniya", "Al-Hamza", "Al-Shamiya"},
                {"An-Najaf", "Al-Kufa", "Al-Manathera", "Al-Najaf"},
                {"Babil", "Al-Hashimiya", "Al-Hilla", "Al-Mahaweel", "Al-Mussyab"},
                {"Karbala", "Al-Hindiya", "Ain Al-Tamur", "Kerbela"},
                {"Wasit", "Al-Hai", "Al-Kut", "Al-Namaniya", "Al-Suwaira", "Badra"},
                {"Baghdad", "Al-Adhamiya", "Al-Karkh", "Al-Kadhmiyah", "Al-Mahmoudiya", "Al-Mada'in", "Al-Risafa", "Al-Thawra"},
                {"Diyala", "Al-Khalis", "Al-Muqdadiya", "Baladruz", "Baquba", "Khanaqin", "Kifri"},
                {"Salah al-Din", "Al-Daur", "Al-Shirqat", "Balad", "Beygee", "Samarra", "Tikrit", "Tooz Khurmato"},
                {"Kirkuk", "Al-Hawiga", "Daquq", "Dibis", "Kirkuk"},
                {"Al-Anbar", "Al-Falluja", "Al-Kaim", "Al-Ramadi", "Al-Rutba", "Ana", "Haditha", "Heet"},
                {"Al-Sulaimaniyah", "Al-Sulaymaniyah", "Chamchamal", "Derbendikhan", "Dokan", "Halabcha", "Kalar", "Panjwin", "Pshdar", "Sharbazher", "Rania"},
                {"Erbil", "Erbil", "Koysinjaq", "Makhmour", "Rawanduz", "Shaqlawa"},
                {"Dohuk", "Al-Amadiya", "Duhok", "Zakho", "Sumail"},
                {"Ninawa", "Al-Baaj", "Al-Hamdaniya", "Al-Hatra", "Al-Mosul", "Al-Shikhan", "Sinjar", "Telafar", "Tilkaef", "Aqra"}};
        for (String[] r : t) for (int i = 1; i < r.length; i++) PARENT.put(r[i], r[0]);
    }

    static List<Feature> read(String path) throws Exception {
        final List<Feature> out = new ArrayList<>();
        GeoJson.read(new File(path), "x", new Visitor() {
            public boolean feature(String layer, Feature f) {
                out.add(f);
                return true;
            }
        }, new ReadInfo());
        return out;
    }

    static String nm(Feature f) {
        String v = f.attrs.get("shapeName");
        return v == null ? f.name : v;
    }

    static String esc(String s) {
        return MiniJson.quote(s);
    }

    static String r5(double v) {
        String s = String.format(Locale.US, "%.5f", v);
        int e = s.length();
        while (e > 0 && s.charAt(e - 1) == '0') e--;
        if (s.charAt(e - 1) == '.') e--;
        return s.substring(0, e);
    }

    public static void main(String[] a0) throws Exception {
        String[] a = {System.getProperty("adm1"), System.getProperty("adm2"), System.getProperty("out")};
        List<Feature> adm1 = read(a[0]);
        List<Feature> adm2 = read(a[1]);
        int missing = 0;
        for (Feature f : adm1) if (!AR1.containsKey(nm(f))) {
            System.out.println("no ar for ADM1 " + f.name);
            missing++;
        }
        List<Geometry> g1 = new ArrayList<>();
        for (Feature f : adm1) g1.add(Jts.toGeometry(f).buffer(0));
        try (Writer w = new OutputStreamWriter(new FileOutputStream(a[2]), StandardCharsets.UTF_8)) {
            w.write("{\"type\":\"FeatureCollection\",\"meta\":{");
            w.write("\"country\":\"Iraq\",\"unofficial\":true,\"built\":" + esc(java.time.LocalDate.now().toString()) + ",");
            w.write("\"adm1\":{\"source\":\"geoBoundaries gbOpen IRQ ADM1 (Wikimedia Commons)\",\"license\":\"CC0 1.0\",\"year\":\"2022\",\"units\":18,\"meanVertices\":227},");
            w.write("\"adm2\":{\"source\":\"geoBoundaries gbOpen IRQ ADM2 (Iraq Central Statistics Office, OCHA Iraq)\",\"license\":\"CC BY 3.0 IGO\",\"year\":\"2021\",\"units\":101,\"meanVertices\":207},");
            w.write("\"notes\":\"Unofficial, generalized boundaries. English names come from the source; Arabic names and the district-to-governorate assignment were added by hand (checked against the geometry) and are not part of the source data; districts that are administratively disputed follow the source. No sub-district (nahiya) boundaries are included.\"},\n\"features\":[\n");
            boolean first = true;
            for (int lvl = 1; lvl <= 2; lvl++) {
                List<Feature> src = lvl == 1 ? adm1 : adm2;
                for (Feature f : src) {
                    String en = nm(f);
                    String parent = "";
                    String info = "";
                    if (lvl == 2) {
                        Geometry g = Jts.toGeometry(f).buffer(0);
                        double best = 0;
                        for (int i = 0; i < adm1.size(); i++) {
                            double ar = g.intersection(g1.get(i)).getArea();
                            if (ar > best) {
                                best = ar;
                                parent = nm(adm1.get(i));
                            }
                        }
                        double ratio = best / g.getArea();
                        String hand = PARENT.get(en);
                        if (hand == null) System.out.println("NO PARENT in table (geometry used): " + en + " -> " + parent + " " + (int) (ratio * 100) + "%");
                        info = String.format(Locale.US, "%s: table=%s geometry=%s (%.0f%%)", en, hand, parent, ratio * 100);
                        if (hand != null && !hand.equals(parent)) System.out.println("DISAGREE " + info);
                        if (hand != null) parent = hand;
                        if (!AR2.containsKey(en)) {
                            System.out.println("no ar for ADM2 " + en);
                            missing++;
                        }
                    }
                    if (!first) w.write(",\n");
                    first = false;
                    w.write("{\"type\":\"Feature\",\"properties\":{\"level\":" + lvl + ",\"name_en\":" + esc(en) + ",\"name_ar\":" + esc((lvl == 1 ? AR1 : AR2).getOrDefault(en, ""))
                            + ",\"parent_en\":" + esc(parent) + ",\"parent_ar\":" + esc(parent.isEmpty() ? "" : AR1.getOrDefault(parent, "")) + "},\"geometry\":");
                    // polygons -> MultiPolygon with outer rings first, holes attached to the preceding outer ring
                    List<List<double[]>> polys = new ArrayList<>();
                    for (int i = 0; i < f.parts.size(); i++) {
                        if (!f.isHole(i) || polys.isEmpty()) {
                            polys.add(new ArrayList<>());
                        }
                        polys.get(polys.size() - 1).add(f.parts.get(i));
                    }
                    StringBuilder sb = new StringBuilder("{\"type\":\"MultiPolygon\",\"coordinates\":[");
                    for (int p = 0; p < polys.size(); p++) {
                        if (p > 0) sb.append(',');
                        sb.append('[');
                        for (int r = 0; r < polys.get(p).size(); r++) {
                            if (r > 0) sb.append(',');
                            double[] ring = polys.get(p).get(r);
                            sb.append('[');
                            for (int k = 0; k + 1 < ring.length; k += 2) {
                                if (k > 0) sb.append(',');
                                sb.append('[').append(r5(ring[k])).append(',').append(r5(ring[k + 1])).append(']');
                            }
                            sb.append(']');
                        }
                        sb.append(']');
                    }
                    w.write(sb.append("]}}").toString());
                }
            }
            w.write("\n]}\n");
        }
        System.out.println("built, missing arabic: " + missing + ", size " + new File(a[2]).length() / 1024 + " KB");
    }
}
