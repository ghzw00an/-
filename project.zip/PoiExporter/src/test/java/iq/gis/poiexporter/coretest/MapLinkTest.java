package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.MapLink;

public class MapLinkTest {
    static void at(String s, double lat, double lon, String msg) {
        MapLink.Pos p = MapLink.parse(s);
        T.ok(p != null, msg + " parsed");
        if (p != null) {
            T.near(p.lat, lat, 1e-6, msg + " lat");
            T.near(p.lon, lon, 1e-6, msg + " lon");
        }
    }

    public static void main(String[] a) {
        at("geo:33.3152,44.3661", 33.3152, 44.3661, "geo");
        at("geo:0,0?q=33.31,44.36(Baghdad)", 33.31, 44.36, "geo q");
        T.eq(MapLink.parse("geo:0,0?q=33.31,44.36(Baghdad)").label, "Baghdad", "label");
        at("https://www.google.com/maps/@33.3152,44.3661,15z", 33.3152, 44.3661, "google @");
        at("https://www.google.com/maps?q=33.5,44.5", 33.5, 44.5, "google q");
        at("https://www.google.com/maps/place/Name/@30.5,47.8,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x0!8m2!3d30.51!4d47.81", 30.51, 47.81, "google !3d wins");
        at("https://maps.google.com/?q=-1.5,-60.25", -1.5, -60.25, "negative");
        at("https://www.openstreetmap.org/?mlat=36.19&mlon=44.01#map=18/36.19/44.01", 36.19, 44.01, "osm mlat");
        at("https://www.openstreetmap.org/#map=12/32.6/44.0", 32.6, 44.0, "osm map");
        at("https://maps.apple.com/?ll=33.2,44.2&q=x", 33.2, 44.2, "apple ll");
        at("https://waze.com/ul?ll=33.1,44.1&navigate=yes", 33.1, 44.1, "waze");
        at("33.3152, 44.3661", 33.3152, 44.3661, "plain");
        at("https://www.google.com/maps/place/33.30,44.40", 33.30, 44.40, "place coords");
        T.eq(MapLink.parse("https://example.com/page") == null, true, "no coords");
        T.eq(MapLink.parse("91.0, 44.0") == null, true, "bad lat rejected");
        T.eq(MapLink.parse("0,0") == null, true, "null island rejected");
        T.eq(MapLink.parse("") == null, true, "empty");
        T.eq(MapLink.isShort("https://maps.app.goo.gl/abc123"), true, "short link");
        T.eq(MapLink.isShort("https://www.google.com/maps?q=1,2"), false, "long link");
        T.eq(MapLink.extractLink("شوف الموقع https://maps.app.goo.gl/xyz الآن"), "https://maps.app.goo.gl/xyz", "extract");
        String list = "https://www.google.com/maps/@/data=!4m3!11m2!2sFvBF1VvLajpd51HMOp55qfkLW3iOMw!3e3!18m1!1e1?g_st=ac&skid=892e0e07";
        T.eq(MapLink.isList(list), true, "saved list link");
        T.eq(MapLink.parse(list) == null, true, "list link has no coordinates");
        T.eq(MapLink.isList("https://www.google.com/maps/place/X/@30.5,47.8,17z"), false, "place is not a list");
        T.eq(MapLink.unwrapConsent("https://consent.google.com/m?continue=https%3A%2F%2Fwww.google.com%2Fmaps%2F%4033.3%2C44.4%2C15z&gl=IQ"),
                "https://www.google.com/maps/@33.3,44.4,15z", "consent unwrap");
        T.eq(MapLink.myMapsKmlUrl("https://www.google.com/maps/d/viewer?mid=1AbC-dEf_9&ll=1,2"), "https://www.google.com/maps/d/kml?mid=1AbC-dEf_9&forcekml=1", "my maps kml");
        T.eq(MapLink.myMapsKmlUrl("https://www.google.com/maps?q=1,2") == null, true, "not my maps");
        T.done("MapLinkTest");
    }
}
