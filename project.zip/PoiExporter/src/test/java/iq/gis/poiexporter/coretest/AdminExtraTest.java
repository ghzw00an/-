package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.*;
import iq.gis.poiexporter.core.admin.AdminRef;

public class AdminExtraTest {
    static Feature square(double w, double s, double e, double n) {
        Feature f = new Feature();
        f.geom = Feature.POLYGON;
        f.parts.add(new double[]{w, s, e, s, e, n, w, n, w, s});
        f.holes.add(Boolean.FALSE);
        Geo.setRepresentative(f);
        return f;
    }

    public static void main(String[] x) throws Exception {
        AdminRef r = AdminRef.load(AdminExtraTest.class.getResourceAsStream(AdminRef.RESOURCE));
        int before = r.units(2).size();
        // a made-up square around Abu Ghraib's rough location, used only to test the mechanism
        AdminRef.Hit h0 = r.locate(33.30, 44.19);
        AdminRef.Unit u = r.addExtra("Abu Ghraib", "أبو غريب", square(44.10, 33.25, 44.25, 33.38), "OpenStreetMap contributors (ODbL)");
        T.ok(u != null && u.extra, "added");
        T.eq(r.units(2).size(), before + 1, "one more district");
        AdminRef.Hit h = r.locate(33.30, 44.19);
        T.eq(h.district.nameEn, "Abu Ghraib", "smaller extra district wins at its location");
        T.eq(h.qadaa(true), "أبو غريب", "Arabic name used");
        T.eq(h.governorate(true), "بغداد", "governorate found from the polygon: " + u.parentEn);
        // replacing by name does not duplicate
        r.addExtra("Abu Ghraib", "أبو غريب", square(44.11, 33.26, 44.24, 33.37), "x");
        T.eq(r.units(2).size(), before + 1, "replaced, not duplicated");
        T.eq(r.extras().size(), 1, "one extra");
        // json round trip
        String js = r.extrasJson();
        AdminRef r2 = AdminRef.load(AdminExtraTest.class.getResourceAsStream(AdminRef.RESOURCE));
        r2.loadExtras(js);
        T.eq(r2.extras().size(), 1, "restored");
        T.eq(r2.locate(33.30, 44.19).district.nameAr, "أبو غريب", "restored locate");
        T.eq(r2.locate(33.30, 44.19).district.source, "x", "source kept");
        // damaged file leaves bundled data intact
        r2.loadExtras("{broken");
        T.eq(r2.extras().size(), 0, "damaged extras dropped");
        T.eq(r2.units(2).size(), before, "bundled intact");
        // hole handling
        Feature donut = square(44.0, 33.0, 44.4, 33.4);
        donut.addPart(new double[]{44.1, 33.1, 44.2, 33.1, 44.2, 33.2, 44.1, 33.2, 44.1, 33.1}, true);
        r2.addExtra("Donut", "", donut, "t");
        AdminRef r3 = AdminRef.load(AdminExtraTest.class.getResourceAsStream(AdminRef.RESOURCE));
        r3.loadExtras(r2.extrasJson());
        AdminRef.Unit d = null;
        for (AdminRef.Unit q : r3.extras()) d = q;
        T.eq(d.poly.parts.size(), 2, "hole ring kept");
        T.eq(d.poly.isHole(1), true, "hole flag kept");
        T.done("AdminExtraTest");
    }
}
