package iq.gis.poiexporter.coretest;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import iq.gis.poiexporter.core.EntryTemplates;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.SectorColors;
import iq.gis.poiexporter.core.Sectors;

public class ColorsTemplatesTest {
    public static void main(String[] a) {
        T.eq(SectorColors.count(), Sectors.ALL.length, "one colour per sector");
        HashSet<Integer> seen = new HashSet<>();
        for (int i = 0; i < SectorColors.count(); i++) seen.add(SectorColors.colorAt(i));
        T.eq(seen.size(), SectorColors.count(), "colours are distinct");
        T.eq(SectorColors.colorOf("القطاع الصحي") == SectorColors.colorAt(12), true, "health colour by name");
        T.eq(SectorColors.colorOf("القطاع الصحى") == SectorColors.colorAt(12), true, "yaa variant");
        T.eq(SectorColors.colorOf("شيء آخر"), 0, "unknown sector has no colour");
        T.eq(SectorColors.colorOf(""), 0, "empty has no colour");
        T.eq(SectorColors.colorOf(null), 0, "null has no colour");

        List<EntryTemplates.Template> l = new ArrayList<>();
        EntryTemplates.Template t = new EntryTemplates.Template();
        t.name = "جولة \"المدارس\"";
        t.category = "القطاع التربوي والتعليم";
        t.type = "مدرسة";
        t.governorate = "بغداد";
        l.add(t);
        EntryTemplates.Template t2 = new EntryTemplates.Template();
        t2.name = "ثانٍ";
        l.add(t2);
        String js = EntryTemplates.toJson(l);
        List<EntryTemplates.Template> back = EntryTemplates.fromJson(js);
        T.eq(back.size(), 2, "round trip count");
        T.eq(back.get(0).name, t.name, "name with quotes survives");
        T.eq(back.get(0).type, "مدرسة", "type survives");
        T.eq(back.get(0).governorate, "بغداد", "governorate survives");
        T.eq(EntryTemplates.fromJson("not json").size(), 0, "garbage gives empty list");
        T.eq(EntryTemplates.fromJson("").size(), 0, "empty gives empty list");
        T.eq(EntryTemplates.fromJson("[{\"type\":\"x\"}]").size(), 0, "nameless entry dropped");

        Feature f = Feature.point(33, 44);
        f.nahiya = "keep";
        f.category = "old";
        back.get(0).applyTo(f);
        T.eq(f.category, "القطاع التربوي والتعليم", "category applied");
        T.eq(f.type, "مدرسة", "type applied");
        T.eq(f.nahiya, "keep", "blank template value keeps field");
        T.done("ColorsTemplatesTest");
    }
}
