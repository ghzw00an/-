package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.admin.AdminRef;

public class KnownDistrictTest {
    public static void main(String[] a) {
        AdminRef r = AdminRef.get();
        T.ok(r != null, "bundled data present");
        T.eq(r.knowsDistrict("قضاء الفلوجة", "Fallujah District"), true, "Arabic with قضاء prefix");
        T.eq(r.knowsDistrict("الفلوجه", ""), true, "taa marbuta variant");
        T.eq(r.knowsDistrict("", "Al-Falluja"), true, "English exact");
        T.eq(r.knowsDistrict("", "Falluja"), true, "English without Al-");
        T.eq(r.knowsDistrict("أبو غريب", "Abu Ghraib"), false, "Abu Ghraib is not bundled");
        T.eq(r.knowsDistrict("الكرمة", "Al-Karma"), false, "Karma not bundled");
        T.eq(r.knowsDistrict("الحبانية", ""), false, "Habbaniyah not bundled");
        T.eq(r.knowsDistrict("", ""), false, "empty never known");
        T.eq(r.knowsDistrict("كربلاء", ""), true, "Karbala (district bundled)");
        T.done("KnownDistrictTest");
    }
}
