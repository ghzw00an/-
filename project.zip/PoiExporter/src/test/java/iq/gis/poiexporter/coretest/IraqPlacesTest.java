package iq.gis.poiexporter.coretest;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.IraqPlaces;
import iq.gis.poiexporter.core.PlusCode;

public class IraqPlacesTest {
    static boolean arabicOnly(String s) {
        return s != null && s.matches(".*[\\u0600-\\u06FF].*") && !s.matches(".*[A-Za-z].*");
    }

    public static void main(String[] a) {
        IraqPlaces.Data d = IraqPlaces.get();
        T.eq(d.governorates.size(), 19, "19 governorates");
        T.eq(d.districts.size(), 122, "122 districts");
        T.eq(d.cities.size(), 68, "68 cities");
        T.ok(d.source.contains("hoshmandent/iraqi-geography-data"), "source credited");
        T.ok(d.license.contains("MIT"), "licence recorded");
        T.eq(d.commit.length(), 40, "commit hash recorded");
        Set<String> slugs = new HashSet<>();
        for (IraqPlaces.Place p : d.cities) {
            T.ok(arabicOnly(p.ar), "city Arabic: " + p.en + " -> " + p.ar);
            T.ok(arabicOnly(p.districtAr) && arabicOnly(p.govAr), "city parents Arabic: " + p.en);
            T.ok(slugs.add(p.slug), "unique slug " + p.slug);
            T.ok(p.lat > 28.9 && p.lat < 37.5 && p.lon > 38.7 && p.lon < 48.9, "inside Iraq box: " + p.en + " " + p.lat + "," + p.lon);
            T.ok(p.pop > 0, "population " + p.en);
        }
        Set<String> dslugs = new HashSet<>();
        for (IraqPlaces.Place p : d.districts) {
            T.ok(arabicOnly(p.ar) && arabicOnly(p.govAr), "district Arabic: " + p.en);
            T.ok(dslugs.add(p.slug), "unique district slug " + p.slug);
        }
        for (IraqPlaces.Place p : d.governorates) {
            T.ok(arabicOnly(p.ar), "governorate Arabic: " + p.en);
            T.ok(IraqPlaces.districtsOf(p.ar).size() > 0, "governorate has districts: " + p.ar);
            T.ok(IraqPlaces.citiesOf(p.ar).size() > 0, "governorate has cities: " + p.ar);
            T.ok(IraqPlaces.approxCenter(p) != null, "approx centre " + p.ar);
        }
        // every city belongs to a district of the same governorate
        for (IraqPlaces.Place c : d.cities) {
            boolean ok = false;
            for (IraqPlaces.Place q : IraqPlaces.districtsOf(c.govAr)) if (q.ar.equals(c.districtAr)) ok = true;
            T.ok(ok, "district exists for city " + c.en + " / " + c.districtAr);
        }
        // search: Arabic, normalised Arabic, English, partial
        List<IraqPlaces.Place> r = IraqPlaces.search("الموصل", 10);
        T.ok(!r.isEmpty() && r.get(0).kind == IraqPlaces.Kind.CITY && r.get(0).en.equals("Mosul"), "search Mosul first is the city");
        T.ok(IraqPlaces.search("الديوانيه", 5).stream().anyMatch(p -> p.en.equals("Al Qadisiyah")), "ta marbuta variant");
        T.ok(IraqPlaces.search("baqubah", 5).stream().anyMatch(p -> p.ar.equals("بعقوبة")), "english search");
        T.ok(IraqPlaces.search("كرب", 10).stream().anyMatch(p -> p.ar.equals("كربلاء")), "prefix search");
        T.eq(IraqPlaces.search("", 5).size(), 0, "empty query");
        T.eq(IraqPlaces.search("xxxxqqq", 5).size(), 0, "no match");
        T.ok(IraqPlaces.search("بغداد", 10).size() >= 3, "Baghdad appears as city, district and governorate");
        // approx centre of Baghdad governorate lies in Baghdad
        IraqPlaces.Place bag = IraqPlaces.search("بغداد", 10).stream().filter(p -> p.kind == IraqPlaces.Kind.GOVERNORATE).findFirst().get();
        double[] c = IraqPlaces.approxCenter(bag);
        T.ok(c[0] > 33 && c[0] < 33.6 && c[1] > 44 && c[1] < 44.6, "Baghdad centre");
        // locality for short Plus Codes
        IraqPlaces.Place mosul = IraqPlaces.cityIn("7JVW+P8 الموصل، العراق");
        T.ok(mosul != null && mosul.en.equals("Mosul"), "city in text (Arabic)");
        T.ok(IraqPlaces.cityIn("near Erbil citadel") != null && IraqPlaces.cityIn("near Erbil citadel").en.equals("Erbil"), "city in text (English)");
        T.eq(IraqPlaces.cityIn("لا مدينة هنا") == null, true, "no city in text");
        T.ok(IraqPlaces.cityIn("بصره") != null && IraqPlaces.cityIn("بصره").ar.equals("البصرة"), "without al- and ta marbuta");
        // short code next to a named city, even if the map reference is elsewhere (Baghdad)
        PlusCode.setReference(33.3152, 44.3661);
        String full = PlusCode.encode(36.335, 43.1189);
        String sh = full.substring(4); // the usual "7JVW+P8 Mosul" form: 4 leading digits dropped
        double[] ll = IraqPlaces.resolvePlusCode(sh + " الموصل");
        T.ok(ll != null && Math.abs(ll[0] - 36.335) < 0.001 && Math.abs(ll[1] - 43.1189) < 0.001, "short code uses the named city, not the map reference");
        double[] wrong = IraqPlaces.resolvePlusCode(sh);
        T.ok(wrong != null && Math.abs(wrong[0] - 36.335) > 0.5, "without a city it falls back to the reference");
        // a 6-digit-dropped code keeps using the map reference
        PlusCode.setReference(36.34, 43.12);
        String vs = PlusCode.shorten(full, 36.34, 43.12);
        double[] v6 = IraqPlaces.resolvePlusCode(vs + " الموصل");
        T.ok(v6 != null && Math.abs(v6[0] - 36.335) < 0.001, "very short code resolved next to the map reference");
        PlusCode.setReference(33.3152, 44.3661);
        CoordFmt.Parsed ps = CoordFmt.parse(sh + " Mosul");
        T.near(ps.lat, 36.335, 0.001, "CoordFmt short + English city");
        T.done("IraqPlacesTest");
    }
}
