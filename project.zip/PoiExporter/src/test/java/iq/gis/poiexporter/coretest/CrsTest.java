package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.Utm;
import iq.gis.poiexporter.core.crs.Crs;

import java.util.List;

public class CrsTest {
    public static void main(String[] a) {
        T.ok(Crs.available(), "crs available");
        Crs w = Crs.wgs84(), u38 = Crs.of("EPSG:32638");
        // Baghdad: compare with the independent Kruger implementation of Utm
        double[][] pts = {{33.3152, 44.3661}, {30.5, 47.8}, {36.34, 43.13}, {32.0, 36.2}, {37.0, 42.0}, {29.1, 48.6}};
        for (double[] p : pts) {
            Utm.Result r = Utm.fromLatLon(p[0], p[1]);
            Crs z = Crs.utm(r.zone, true);
            double[] xy = w.to(z).apply(p[1], p[0]);
            T.near(xy[0], r.easting, 0.01, "easting " + p[0] + "," + p[1]);
            T.near(xy[1], r.northing, 0.01, "northing " + p[0] + "," + p[1]);
            double[] back = z.to(w).apply(xy[0], xy[1]);
            T.near(back[0], p[1], 1e-8, "lon roundtrip");
            T.near(back[1], p[0], 1e-8, "lat roundtrip");
        }
        // Baghdad UTM38N known value (checked against EPSG:32638 formulas): E ~ 444 km, N ~ 3 686 km
        double[] b = w.to(u38).apply(44.3661, 33.3152);
        T.ok(b[0] > 440000 && b[0] < 450000 && b[1] > 3680000 && b[1] < 3690000, "baghdad range " + b[0] + "," + b[1]);
        // geographic datums: ED50 (4230) -> WGS84 shift is 100-250 m in the region
        Crs ed = Crs.of(4230);
        double[] s = ed.to(w).apply(44.3661, 33.3152);
        double dm = Math.hypot((s[0] - 44.3661) * 93000, (s[1] - 33.3152) * 111000);
        T.ok(dm > 50 && dm < 300, "ED50 shift metres " + dm);
        T.ok(Crs.approximateShift(ed, w), "ED50 approx flag");
        T.ok(!Crs.approximateShift(u38, w), "UTM WGS84 no approx");
        // Iraq projected systems exist
        for (int c : new int[]{3893, 23038, 20438, 4270, 4204, 3857, 3891})
            T.ok(Crs.of(c) != null, "epsg " + c);
        // round trip through a datum system
        Crs ain = Crs.of(20438);
        double[] ab = w.to(ain).apply(44.3661, 33.3152);
        double[] ba = ain.to(w).apply(ab[0], ab[1]);
        T.near(ba[0], 44.3661, 1e-7, "ain roundtrip lon");
        T.near(ba[1], 33.3152, 1e-7, "ain roundtrip lat");
        // web mercator
        double[] m = w.to(Crs.of(3857)).apply(44.3661, 33.3152);
        T.near(m[0], 44.3661 * 20037508.342789244 / 180, 1.0, "mercator x");
        // invalid input rejected
        try {
            w.to(u38).apply(Double.NaN, 1);
            T.ok(false, "NaN must throw");
        } catch (IllegalArgumentException e) {
            T.ok(true, "nan");
        }
        List<Crs.Entry> hits = Crs.search("nahrwan", 50);
        T.ok(hits.size() >= 3, "search nahrwan " + hits.size());
        T.ok(Crs.search("32638", 5).get(0).code == 32638, "search by code");
        T.ok(Crs.catalog().size() > 3000, "catalog size " + Crs.catalog().size());
        T.eq(u38.utmZoneOf()[0], 38, "zone of 32638");
        T.eq(Crs.utmZone(44.3661), 38, "zone for baghdad");
        // speed: 1M transforms
        long t0 = System.nanoTime();
        Crs.Tx tx = w.to(u38);
        double[] out = new double[2];
        for (int i = 0; i < 1000000; i++) tx.apply(44 + (i % 1000) * 1e-4, 33 + (i / 1000) * 1e-4, out);
        double sec = (System.nanoTime() - t0) / 1e9;
        System.out.println("1M transforms: " + sec + " s");
        T.ok(sec < 20, "speed");
        T.done("CrsTest");
    }
}
