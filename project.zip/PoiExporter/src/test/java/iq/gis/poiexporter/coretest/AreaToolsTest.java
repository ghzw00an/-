package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.AreaSpec;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.geo.AreaTools;
import iq.gis.poiexporter.core.geo.GeoOps;
import iq.gis.poiexporter.core.geo.Geodesy;

import java.util.Random;

public class AreaToolsTest {
    public static void main(String[] a) {
        double lat = 33.3, lon = 44.4;
        // grid of points every ~100 m over 4 km x 4 km
        LayerData l = new LayerData("p", "pts", Feature.POINT);
        double dLat = 100 / 111320.0, dLon = 100 / (111320.0 * Math.cos(Math.toRadians(lat)));
        for (int i = -20; i <= 20; i++) for (int j = -20; j <= 20; j++) {
            Feature f = Feature.point(lat + i * dLat + 1e-7, lon + j * dLon + 1e-7);
            f.id = Feature.newId();
            l.features.add(f);
        }
        // 1000 x 1000 m square: expect about 10 x 10 points
        AreaSpec sq = AreaSpec.centered(lat, lon, 1000, 1000);
        LayerData in = AreaTools.extract(l, sq, GeoOps.Mode.INSIDE, "x");
        T.ok(in.features.size() >= 99 && in.features.size() <= 121, "square extract count " + in.features.size());
        T.ok(in.features.get(0).id != l.features.get(0).id && !in.features.get(0).id.isEmpty(), "new ids");
        // circle radius 500 m: area pi*0.25 km2 = 0.785 -> about 78 points (100 m grid -> 100 m2 each)
        AreaSpec ci = AreaSpec.circle(lat, lon, 500);
        int n = AreaTools.extract(l, ci, GeoOps.Mode.INSIDE, "c").features.size();
        T.ok(n >= 70 && n <= 90, "circle extract count " + n);
        // rotated square 45 deg: same area as the unrotated one, count similar
        AreaSpec rot = AreaSpec.rotated(lat, lon, 1000, 1000, 45);
        int nr = AreaTools.extract(l, rot, GeoOps.Mode.INSIDE, "r").features.size();
        T.ok(nr >= 85 && nr <= 120, "rotated extract count " + nr);
        T.near(Geodesy.area(AreaTools.polygon(rot)), 1_000_000, 3000, "rotated polygon area");
        T.near(Geodesy.area(AreaTools.polygon(sq)), 1_000_000, 3000, "square polygon area");
        T.near(Geodesy.area(AreaTools.polygon(ci)), Math.PI * 500 * 500, 3000, "circle polygon area");
        // clip of a line layer
        LayerData lines = new LayerData("l", "road", Feature.LINE);
        Feature r = new Feature();
        r.geom = Feature.LINE;
        r.id = Feature.newId();
        r.addPart(new double[]{lon - 0.05, lat, lon + 0.05, lat}, false);
        lines.features.add(r);
        LayerData cl = GeoOps.clip(lines, AreaTools.polygon(sq), true);
        T.eq(cl.features.size(), 1, "clipped line");
        T.near(Geodesy.length(cl.features.get(0)), 1000 * 1.0, 6, "clipped length 1 km");
        // intersects mode keeps a line crossing the area
        LayerData touch = AreaTools.extract(lines, sq, GeoOps.Mode.INTERSECTS, "t");
        T.eq(touch.features.size(), 1, "line intersects area");
        LayerData inside = AreaTools.extract(lines, sq, GeoOps.Mode.INSIDE, "t");
        T.eq(inside.features.size(), 0, "long line not fully inside");
        T.done("AreaToolsTest");
    }
}
