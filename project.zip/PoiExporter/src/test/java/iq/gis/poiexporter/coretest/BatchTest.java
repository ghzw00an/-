package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.S;
import iq.gis.poiexporter.core.CoordFmt;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.coord.*;
import iq.gis.poiexporter.core.crs.Crs;
import iq.gis.poiexporter.core.table.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

public class BatchTest {
    static File tmp(String n) throws IOException {
        File d = new File(System.getProperty("java.io.tmpdir"), "bt_" + System.nanoTime());
        d.mkdirs();
        return new File(d, n);
    }

    public static void main(String[] a) throws Exception {
        S.ar = true;
        // ---- CoordService
        CoordService.Result r = CoordService.convert("33.3152 44.3661", null, true, Crs.of(32638));
        T.near(r.lat, 33.3152, 1e-9, "lat");
        T.near(r.lon, 44.3661, 1e-9, "lon");
        T.ok(r.utm.startsWith("38S"), "utm label " + r.utm);
        T.ok(r.ddm != null && r.ddm.contains("°"), "ddm " + r.ddm);
        T.ok(r.targetText != null && !r.targetText.isEmpty(), "target text");
        System.out.println(r.copyText(true));
        // lon first
        r = CoordService.convert("44.3661 33.3152", null, false, null);
        T.near(r.lat, 33.3152, 1e-9, "lonfirst lat");
        // DMS / DDM / UTM / MGRS round trips
        CoordService.Result d = CoordService.convert(r.dms, null, true, null);
        T.near(d.lat, 33.3152, 2e-4, "dms back (rounded to input precision)");
        d = CoordService.convert(r.ddm, null, true, null);
        T.near(d.lon, 44.3661, 2e-4, "ddm back");
        d = CoordService.convert(r.utm, null, true, null);
        T.near(d.lat, 33.3152, 2e-4, "utm back " + r.utm);
        d = CoordService.convert(r.mgrs, null, true, null);
        T.near(d.lat, 33.3152, 2e-3, "mgrs back " + r.mgrs);
        // arabic digits
        d = CoordService.convert("٣٣٫٣١٥٢ ٤٤٫٣٦٦١", null, true, null);
        T.near(d.lat, 33.3152, 1e-9, "arabic digits");
        // precision: input 4 decimals ~ 11 m -> UTM not shown to mm
        r = CoordService.convert("33.3152 44.3661", null, true, Crs.of(32638));
        T.ok(r.targetX.indexOf('.') < 0 || r.targetX.length() - r.targetX.indexOf('.') <= 2, "no false precision: " + r.targetX);
        // projected source
        d = CoordService.convert("444000 3686000", Crs.of(32638), true, null);
        T.ok(d.lat > 33 && d.lat < 34, "projected src " + d.lat);
        // datum warning
        d = CoordService.convert("33.3152 44.3661", Crs.of(4230), true, null);
        T.ok(!d.warnings.isEmpty(), "datum warning");
        // out of range
        try {
            CoordService.convert("95 44", null, true, null);
            T.ok(false, "range");
        } catch (IllegalArgumentException e) {
            T.ok(true, "range rejected: " + e.getMessage());
        }
        // ---- CSV batch with bad rows
        File csv = tmp("pts.csv");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(csv), StandardCharsets.UTF_8)) {
            w.write("﻿الاسم,lat,lon,note\n");
            w.write("بغداد,33.3152,44.3661,ok\n");
            w.write("خطأ,abc,44.0,bad\n");
            w.write("بعيد,95.0,44.0,range\n");
            w.write("البصرة,30.5,47.8,ok\n");
            w.write("ar,٣٠٫٥,٤٧٫٨,digits\n");
        }
        TableReader tr = TableReader.open(csv, "pts.csv");
        T.eq(tr.header().get(0), "الاسم", "bom header");
        PointTable.Guess g = PointTable.guess(tr.header());
        T.eq(g.name, 0, "name col");
        T.eq(g.y, 1, "lat col");
        T.eq(g.x, 2, "lon col");
        tr.close();
        BatchConverter.Options o = new BatchConverter.Options();
        o.mapping = new PointTable.Mapping(g);
        o.target = Crs.of(32638);
        o.outUTM = true;
        o.outMGRS = true;
        o.errorsFile = tmp("errors.csv");
        File out = tmp("out.csv");
        BatchConverter.Summary s = BatchConverter.run(csv, "pts.csv", o, new CsvSink(new FileOutputStream(out)), null);
        T.eq(s.read, 5L, "read");
        T.eq(s.converted, 3L, "converted");
        T.eq(s.bad, 2L, "bad");
        System.out.println(s.toText(true));
        String outTxt = new String(Files.readAllBytes(out.toPath()), StandardCharsets.UTF_8);
        T.ok(outTxt.contains("بغداد"), "arabic out");
        T.ok(o.errorsFile.length() > 0, "errors file");
        // ---- LayerData from points
        RowReport rep = new RowReport();
        LayerData ld = PointTable.toLayer(csv, "pts.csv", o.mapping, null, rep);
        T.eq(ld.features.size(), 3, "layer features");
        T.eq(ld.features.get(0).name, "بغداد", "feature name");
        T.eq(ld.features.get(0).attrs.get("note"), "ok", "attrs kept");
        // ---- projected CSV (lon/lat swapped detection by CRS): easting northing in UTM 38
        File ut = tmp("utm.csv");
        Files.write(ut.toPath(), "name,E,N\nA,444000,3686000\nB,0,0\nC,445000.5,3687000.25\n".getBytes(StandardCharsets.UTF_8));
        PointTable.Guess gu = PointTable.guess(TableReader.open(ut, "utm.csv").header());
        BatchConverter.Options o2 = new BatchConverter.Options();
        o2.mapping = new PointTable.Mapping(gu);
        o2.src = Crs.of(32638);
        File out2 = tmp("o2.csv");
        BatchConverter.Summary s2 = BatchConverter.run(ut, "utm.csv", o2, new CsvSink(new FileOutputStream(out2)), null);
        T.eq(s2.converted + s2.bad, 3L, "utm rows");
        T.ok(s2.converted >= 2, "utm converted " + s2.toText(false));
        // ---- XLSX round trip: Java writes -> openpyxl reads (done in python below), and Java reads openpyxl file
        File x = tmp("w.xlsx");
        BatchConverter.Summary s3 = BatchConverter.run(csv, "pts.csv", o, new XlsxSink(new FileOutputStream(x), true), null);
        T.eq(s3.converted, 3L, "xlsx converted");
        System.out.println("XLSX_WRITTEN " + x.getAbsolutePath());
        File pyx = tmp("py.xlsx");
        int rc = new ProcessBuilder("python3", "-I", "-c",
                "import openpyxl,sys\nwb=openpyxl.Workbook();ws=wb.active\nws.append(['\\u0627\\u0633\\u0645','lat','lon'])\nws.append(['\\u0628\\u063a\\u062f\\u0627\\u062f',33.3152,44.3661])\nws.append(['\\u0628\\u0635\\u0631\\u0629',30.5,47.8])\nws.append(['x','z',1])\nwb.save(sys.argv[1])",
                pyx.getAbsolutePath()).inheritIO().start().waitFor();
        T.eq(rc, 0, "python wrote xlsx");
        TableReader tx = TableReader.open(pyx, "py.xlsx");
        T.eq(tx.header().get(0), "\u0627\u0633\u0645", "xlsx header");
        String[] row = tx.next();
        T.eq(row[0], "\u0628\u063a\u062f\u0627\u062f", "xlsx arabic");
        T.near(Double.parseDouble(row[1]), 33.3152, 1e-9, "xlsx number");
        tx.close();
        BatchConverter.Options o3 = new BatchConverter.Options();
        o3.mapping = new PointTable.Mapping(PointTable.guess(Arrays.asList("\u0627\u0633\u0645", "lat", "lon")));
        RowReport rp3 = new RowReport();
        LayerData l3 = PointTable.toLayer(pyx, "py.xlsx", o3.mapping, null, rp3);
        T.eq(l3.features.size(), 2, "xlsx layer " + rp3.toText(false));
        // ---- delimiters and windows-1256
        File sc = tmp("semi.txt");
        Files.write(sc.toPath(), "name;lat;lon\nأ;33,5;44,5\n".getBytes(StandardCharsets.UTF_8));
        TableReader ts = TableReader.open(sc, "semi.txt");
        T.eq(ts.delimiter(), ';', "semicolon");
        ts.close();
        File w1256 = tmp("w1256.csv");
        Files.write(w1256.toPath(), "الاسم,lat,lon\nبغداد,33.3,44.4\n".getBytes("windows-1256"));
        TableReader t12 = TableReader.open(w1256, "w1256.csv");
        T.eq(t12.header().get(0), "الاسم", "windows-1256 fallback");
        t12.close();
        // ---- GeoJSON sink
        File gj = tmp("o.geojson");
        BatchConverter.run(csv, "pts.csv", o, new GeoJsonSink(new FileOutputStream(gj)), null);
        String gt = new String(Files.readAllBytes(gj.toPath()), StandardCharsets.UTF_8);
        T.ok(gt.contains("FeatureCollection") && gt.contains("Point"), "geojson");
        int rc2 = new ProcessBuilder("python3", "-I", "-c", "import json,sys;d=json.load(open(sys.argv[1],encoding='utf8'));assert len(d['features'])==3;print('geojson ok')", gj.getAbsolutePath()).inheritIO().start().waitFor();
        T.eq(rc2, 0, "python geojson");
        int rc3 = new ProcessBuilder("python3", "-I", "-c",
                "import openpyxl,sys;wb=openpyxl.load_workbook(sys.argv[1]);ws=wb.active;rows=list(ws.iter_rows(values_only=True));print(rows[0]);print(rows[1]);assert len(rows)==4;assert isinstance(rows[1][4],float);assert rows[1][0]=='\\u0628\\u063a\\u062f\\u0627\\u062f'", x.getAbsolutePath()).inheritIO().start().waitFor();
        T.eq(rc3, 0, "openpyxl reads java xlsx");
        // ---- big run: 1M rows constant memory
        File big = tmp("big.csv");
        try (BufferedWriter w = new BufferedWriter(new FileWriter(big), 1 << 16)) {
            w.write("name,lat,lon\n");
            Random rnd = new Random(1);
            for (int i = 0; i < 1_000_000; i++)
                w.write("p" + i + "," + (29 + rnd.nextDouble() * 8) + "," + (39 + rnd.nextDouble() * 9) + "\n");
        }
        BatchConverter.Options ob = new BatchConverter.Options();
        ob.mapping = new PointTable.Mapping(PointTable.guess(Arrays.asList("name", "lat", "lon")));
        ob.outUTM = true;
        ob.outMGRS = true;
        ob.target = Crs.of(3857);
        File bo = tmp("bigout.csv");
        long t0 = System.nanoTime();
        BatchConverter.Summary sb = BatchConverter.run(big, "big.csv", ob, new CsvSink(new FileOutputStream(bo)), null);
        double sec = (System.nanoTime() - t0) / 1e9;
        System.out.println("1M rows: " + sec + " s, converted " + sb.converted + " bad " + sb.bad);
        T.eq(sb.converted, 1_000_000L, "big converted");
        T.done("BatchTest");
    }
}
