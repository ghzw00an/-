package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.*;
import iq.gis.poiexporter.core.report.*;

import java.util.*;

public class ReportTest {
    public static void main(String[] a) {
        double[] bbox = {44.30, 33.25, 44.45, 33.38}; // part of Baghdad
        for (boolean land : new boolean[]{true, false}) {
            for (Paper p : Paper.ALL) {
                ReportLayout L = ReportLayout.compute(p, land, bbox, 3, 0);
                T.ok(L.frameX >= 0 && L.frameY >= 0 && L.frameX + L.frameW <= L.pageW + 1e-6 && L.frameY + L.frameH + L.legendH <= L.pageH, "frame inside page " + p.name + land);
                T.ok(L.legendY + L.legendH <= L.pageH - ReportLayout.MARGIN_PT, "legend inside page");
                // bbox fully visible
                T.ok(L.shown[0] <= bbox[0] && L.shown[2] >= bbox[2] && L.shown[1] <= bbox[1] && L.shown[3] >= bbox[3], "bbox visible " + p.name);
                T.near(L.px(L.shown[0]), L.frameX, 1e-6, "west at left");
                T.near(L.px(L.shown[2]), L.frameX + L.frameW, 1e-6, "east at right");
                T.near(L.py(L.shown[3]), L.frameY, 1e-6, "north at top");
                T.near(L.py(L.shown[1]), L.frameY + L.frameH, 1e-6, "south at bottom");
                // scale check: 1 km of ground must measure 1000/scale m on paper
                double lat0 = (L.shown[1] + L.shown[3]) / 2;
                double dLon = 1000 / MapMath.metresPerDegLon(lat0);
                double ptPerKm = L.px(L.shown[0] + dLon) - L.px(L.shown[0]);
                double expectPt = 1000.0 / L.fit.niceScale * 1000 / 25.4 * 72 / 1000 * 1000 / 1000; // metres on paper -> mm -> pt
                double paperMm = 1000.0 / L.fit.niceScale * 1000;
                T.near(ptPerKm, paperMm / 25.4 * 72, 0.01, "1 km on paper at 1:" + L.fit.niceScale);
                double bar = L.scaleBarMetres();
                T.ok(L.barPoints(bar) <= L.frameW * 0.36 + 1e-6 && L.barPoints(bar) > 10, "bar length " + bar);
            }
        }
        // fixed scale
        ReportLayout F = ReportLayout.compute(Paper.A4, true, bbox, 0, 25000);
        T.near(F.fit.niceScale, 25000, 0, "fixed scale kept");
        double lat0 = (F.shown[1] + F.shown[3]) / 2;
        double wM = (F.shown[2] - F.shown[0]) * MapMath.metresPerDegLon(lat0);
        T.near(wM, F.frameW / 72 * 0.0254 * 25000, 0.5, "ground width at 1:25000");
        // a single point gets a sane extent
        ReportLayout P = ReportLayout.compute(Paper.A4, false, new double[]{44.4, 33.3, 44.4, 33.3}, 0, 0);
        T.ok(P.fit.niceScale <= 5000, "single point is shown at a large scale: " + P.fit.niceScale);
        // extent + table
        LayerData l = new LayerData("x", "x", Feature.POINT);
        for (int i = 0; i < 10; i++) {
            Feature f = Feature.point(33 + i * 0.01, 44 + i * 0.01);
            f.name = "n" + i;
            f.governorate = "بغداد";
            l.features.add(f);
        }
        double[] ex = ReportLayout.extent(Collections.singletonList(l));
        T.near(ex[0], 44, 1e-9, "extent west");
        T.near(ex[3], 33.09, 1e-9, "extent north");
        List<String[]> rows = ReportLayout.tableRows(Collections.singletonList(l), 5);
        T.eq(rows.size(), 6, "table capped (header + 5)");
        T.eq(Arrays.asList(rows.get(0)), Arrays.asList(LandmarkFields.NAMES), "table header exact");
        T.eq(rows.get(1)[5], "بغداد", "table mohafadha");
        T.done("ReportTest");
    }
}
