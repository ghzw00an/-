package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.CodeGen;
import iq.gis.poiexporter.core.Feature;
import iq.gis.poiexporter.core.LayerData;
import iq.gis.poiexporter.core.MiniJson;

import java.util.ArrayList;
import java.util.List;

public class CodeGenTest {
    public static void main(String[] a) {
        LayerData pts = new LayerData("p", "نقاط \"1\"", Feature.POINT);
        Feature p = Feature.point(33.3, 44.4);
        p.name = "مدرسة 'النور'";
        p.type = "مدرسة";
        p.category = "القطاع التعليمي";
        pts.features.add(p);
        LayerData pg = new LayerData("g", "مضلعات", Feature.POLYGON);
        Feature f = new Feature();
        f.geom = Feature.POLYGON;
        f.addPart(new double[]{0, 0, 4, 0, 4, 4, 0, 4}, false);
        f.addPart(new double[]{1, 1, 2, 1, 2, 2, 1, 2}, true);
        f.lat = 2;
        f.lon = 2;
        pg.features.add(f);
        List<LayerData> all = new ArrayList<>();
        all.add(pts);
        all.add(pg);

        String gj = CodeGen.geoJson(all);
        Object o = MiniJson.parse(gj);
        T.eq(o != null, true, "geojson parses");
        T.eq(gj.contains("\"coordinates\":[44.4,33.3]"), true, "lon,lat order");
        T.eq(gj.contains("[0,0],[4,0],[4,4],[0,4],[0,0]"), true, "ring closed");
        T.eq(gj.contains("\"name\":\"مدرسة 'النور'\""), true, "arabic name kept");
        T.eq(gj.contains("\"layer\":\"نقاط \\\"1\\\"\""), true, "quotes escaped");
        T.eq(CodeGen.wktOf(p), "POINT (44.4 33.3)", "point wkt");
        T.eq(CodeGen.wktOf(f), "POLYGON ((0 0, 4 0, 4 4, 0 4, 0 0), (1 1, 2 1, 2 2, 1 2, 1 1))", "polygon with hole");
        String sql = CodeGen.postgis(all);
        T.eq(sql.contains("'مدرسة ''النور'''"), true, "sql quote doubled");
        T.eq(sql.contains("ST_GeomFromText('POINT (44.4 33.3)', 4326)"), true, "sql geom");
        String csv = CodeGen.csv(all);
        T.eq(csv.startsWith("wkt,name,type"), true, "csv header");
        T.eq(csv.contains("\"POLYGON ((0 0"), true, "csv wkt quoted");
        T.eq(CodeGen.leaflet(all).contains("L.geoJSON("), true, "leaflet");
        T.eq(CodeGen.leaflet(all).contains("L.control.layers"), true, "leaflet layer control");
        T.eq(CodeGen.generate(7, all).contains("st_as_sf"), true, "r code");
        T.eq(CodeGen.generate(4, all).contains("GeoDataFrame"), true, "geopandas");
        T.eq(CodeGen.generate(5, all).contains("folium.GeoJson"), true, "folium");
        T.eq(CodeGen.LANGS.length, CodeGen.EXT.length, "langs/ext");
        T.done("CodeGenTest");
    }
}
