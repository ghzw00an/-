package iq.gis.poiexporter.coretest;

import iq.gis.poiexporter.core.PlusCode;

public class PlusCodeTest {
    public static void main(String[] a) {
        // encoding vectors from the public specification
        T.eq(PlusCode.encode(20.375, 2.775, 6), "7FG49Q00+", "6 digits padded");
        T.eq(PlusCode.encode(20.3700625, 2.7821875), "7FG49QCJ+2V", "10 digits");
        T.eq(PlusCode.encode(20.3701125, 2.782234375, 11), "7FG49QCJ+2VX", "11 digits");
        T.eq(PlusCode.encode(47.0000625, 8.0000625), "8FVC2222+22", "Switzerland");
        T.eq(PlusCode.encode(-41.2730625, 174.7859375), "4VCPPQGP+Q9", "NZ");
        T.eq(PlusCode.encode(37.4220, -122.0841), "849VCWC8+R9", "Googleplex");
        T.eq(PlusCode.encode(90, 1, 4), "CFX30000+", "north pole clipped");
        T.eq(PlusCode.encode(1, 180, 4), PlusCode.encode(1, -180, 4), "lon 180 wraps");
        // decode
        PlusCode.Area d = PlusCode.decode("7FG49QCJ+2VX");
        T.near(d.latLo, 20.3701, 1e-9, "lat lo");
        T.near(d.latHi, 20.370125, 1e-9, "lat hi");
        T.near(d.lonLo, 2.78221875, 1e-9, "lon lo");
        T.near(d.lonHi, 2.78225, 1e-9, "lon hi");
        T.eq(d.length, 11, "len 11");
        PlusCode.Area p = PlusCode.decode("7FG49Q00+");
        T.near(p.latLo, 20.35, 1e-9, "padded lat lo");
        T.near(p.latHi, 20.4, 1e-9, "padded lat hi");
        // Iraq round trips at several lengths
        double[][] pts = {{33.3152, 44.3661}, {36.19, 44.01}, {30.5, 47.8}, {-33.9, 18.4}, {0.0001, -0.0001}};
        for (double[] q : pts) {
            for (int len : new int[]{8, 10, 11, 12, 14}) {
                String c = PlusCode.encode(q[0], q[1], len);
                PlusCode.Area ar = PlusCode.decode(c);
                T.ok(q[0] >= ar.latLo - 1e-9 && q[0] <= ar.latHi + 1e-9 && q[1] >= ar.lonLo - 1e-9 && q[1] <= ar.lonHi + 1e-9,
                        "inside area " + c);
            }
        }
        // metres: 10 digits is about 14 m
        double[] sz = PlusCode.decode(PlusCode.encode(33.3, 44.4)).sizeMetres();
        T.near(sz[0], 13.9, 0.5, "height of a 10-digit cell");
        // validation
        T.eq(PlusCode.isValid("8FVC2222+22"), true, "valid full");
        T.eq(PlusCode.isValid("2222+22"), true, "valid short");
        T.eq(PlusCode.isShort("2222+22"), true, "short");
        T.eq(PlusCode.isFull("8FVC2222+22"), true, "full");
        T.eq(PlusCode.isValid("8FVC2222+2"), false, "single digit after +");
        T.eq(PlusCode.isValid("8FVC2222"), false, "no separator");
        T.eq(PlusCode.isValid("8FVC+2222+22"), false, "two separators");
        T.eq(PlusCode.isValid("AAAA+AA"), false, "bad letters");
        T.eq(PlusCode.isValid("G0VC2222+22"), false, "lat digit beyond globe");
        T.eq(PlusCode.isValid("7FG49Q00+"), true, "padded full");
        T.eq(PlusCode.isValid("8FVC2200+22"), false, "digits after padding");
        T.eq(PlusCode.isValid("8fvc2222+22"), true, "lowercase accepted");
        // short codes
        T.eq(PlusCode.recoverNearest("9QCJ+2VX", 51.3708675, -1.217765625), "9C3W9QCJ+2VX", "recover");
        T.eq(PlusCode.recoverNearest("CJ+2VX", 51.3708675, -1.217765625), "9C3W9QCJ+2VX", "recover 6");
        T.eq(PlusCode.shorten("9C3W9QCJ+2VX", 51.3701125, -1.217765625), "+2VX", "shorten 8");
        T.eq(PlusCode.shorten("9C3W9QCJ+2VX", 51.3708675, -1.217765625), "CJ+2VX", "shorten 6");
        T.eq(PlusCode.shorten("9C3W9QCJ+2VX", 51.3, -1.2), "9QCJ+2VX", "shorten 4");
        T.eq(PlusCode.shorten("9C3W9QCJ+2VX", 40, 20), "9C3W9QCJ+2VX", "far reference: unchanged");
        // Baghdad: a short code recovers next to a reference
        String full = PlusCode.encode(33.3152, 44.3661);
        String sh = PlusCode.shorten(full, 33.32, 44.37);
        T.ok(sh.length() < full.length(), "shortened " + sh);
        T.eq(PlusCode.recoverNearest(sh, 33.32, 44.37), full, "round trip short");
        // find in text
        T.eq(PlusCode.find("8HJ7+2F بغداد"), "8HJ7+2F", "find short with city");
        T.eq(PlusCode.find("افتح 8FVC2222+22 الآن"), "8FVC2222+22", "find full");
        T.eq(PlusCode.find("no code here") == null, true, "none");
        T.eq(PlusCode.find("C++ code"), null, "C++ is not a code");
        T.eq(PlusCode.localityAfter("8HJ7+2F Baghdad, Iraq", "8HJ7+2F"), "Baghdad, Iraq", "locality");
        // reference
        try {
            PlusCode.toLatLon("2222+22");
            T.ok(false, "short without reference must fail");
        } catch (IllegalArgumentException e) {
            T.ok(true, "short without reference fails");
        }
        PlusCode.setReference(47.0, 8.0);
        double[] ll = PlusCode.toLatLon("C2222+22".substring(1));
        T.near(ll[0], 47.0000625, 1e-3, "short with reference lat");
        double[] ll2 = PlusCode.toLatLon("8FVC2222+22");
        T.near(ll2[0], 47.0000625, 1e-5, "full lat");
        T.near(ll2[1], 8.0000625, 1e-5, "full lon");
        T.done("PlusCodeTest");
    }
}
