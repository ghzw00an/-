"""Independent shapefile / geopackage helpers used by the Java tests (no third-party libs)."""
import struct, sys, zipfile, json, sqlite3, io

def write_shapefile(zpath, base, shape_type, records, fields, encoding, prj=None, cpg=None):
    """records: list of (geometry, [values]); geometry: point (x,y) or list of rings/lines [[(x,y),...],...]"""
    shp = io.BytesIO(); shx = io.BytesIO()
    allx = []; ally = []
    bodies = []
    for geom, _ in records:
        if shape_type == 1:
            x, y = geom; allx.append(x); ally.append(y)
            body = struct.pack('<idd', 1, x, y)
        else:
            parts = geom
            pts = [p for part in parts for p in part]
            xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
            allx += xs; ally += ys
            body = struct.pack('<i4di i', shape_type, min(xs), min(ys), max(xs), max(ys), len(parts)) if False else struct.pack('<i4dii', shape_type, min(xs), min(ys), max(xs), max(ys), len(parts), len(pts))
            idx = 0
            for part in parts:
                body += struct.pack('<i', idx); idx += len(part)
            for x, y in pts: body += struct.pack('<dd', x, y)
        bodies.append(body)
    total = 100 + sum(8 + len(b) for b in bodies)
    def header(length):
        h = struct.pack('>i5ii', 9994, 0, 0, 0, 0, 0, length // 2)
        h += struct.pack('<ii4d4d', 1000, shape_type, min(allx), min(ally), max(allx), max(ally), 0, 0, 0, 0)
        return h
    shp.write(header(total)); shx.write(header(100 + 8 * len(bodies)))
    off = 100
    for i, b in enumerate(bodies):
        shp.write(struct.pack('>ii', i + 1, len(b) // 2)); shp.write(b)
        shx.write(struct.pack('>ii', off // 2, len(b) // 2)); off += 8 + len(b)
    # dbf
    recLen = 1 + sum(f[2] for f in fields)
    dbf = io.BytesIO()
    dbf.write(struct.pack('<BBBBIHH20x', 3, 126, 1, 1, len(records), 32 + 32 * len(fields) + 1, recLen))
    for name, typ, ln in fields:
        dbf.write(name.encode('ascii').ljust(11, b'\0') + typ.encode() + b'\0' * 4 + bytes([ln, 0]) + b'\0' * 14)
    dbf.write(b'\r')
    for _, vals in records:
        dbf.write(b' ')
        for (name, typ, ln), v in zip(fields, vals):
            b = str(v).encode(encoding)[:ln]
            dbf.write(b.rjust(ln) if typ == 'N' else b.ljust(ln))
    dbf.write(b'\x1a')
    with zipfile.ZipFile(zpath, 'w') as z:
        z.writestr(base + '.shp', shp.getvalue()); z.writestr(base + '.shx', shx.getvalue()); z.writestr(base + '.dbf', dbf.getvalue())
        if prj: z.writestr(base + '.prj', prj)
        if cpg: z.writestr(base + '.cpg', cpg)

def read_shapefile(zpath):
    """Returns {base: {'type': int, 'records': [(geom, {field: value})], 'prj': str, 'cpg': str}}"""
    out = {}
    z = zipfile.ZipFile(zpath)
    for n in z.namelist():
        if not n.lower().endswith('.shp'): continue
        base = n[:-4]
        shp = z.read(n)
        t = struct.unpack('<i', shp[32:36])[0]
        assert struct.unpack('>i', shp[0:4])[0] == 9994
        flen = struct.unpack('>i', shp[24:28])[0] * 2
        assert flen == len(shp), (flen, len(shp))
        shx = z.read(base + '.shx')
        assert len(shx) == 100 + 8 * ((len(shx) - 100) // 8)
        dbf = z.read(base + '.dbf')
        nrec, hlen, rlen = struct.unpack('<IHH', dbf[4:12])
        fields = []
        p = 32
        while dbf[p] != 0x0D:
            name = dbf[p:p + 11].split(b'\0')[0].decode('ascii'); typ = chr(dbf[p + 11]); ln = dbf[p + 16]; dec = dbf[p + 17]
            fields.append((name, typ, ln, dec)); p += 32
        cpg = z.read(base + '.cpg').decode() if base + '.cpg' in z.namelist() else ''
        enc = 'utf-8' if cpg.upper() in ('UTF-8', 'UTF8', '') else cpg
        recs = []
        pos = 100
        for i in range(nrec):
            num, clen = struct.unpack('>ii', shp[pos:pos + 8]); pos += 8
            body = shp[pos:pos + clen * 2]; pos += clen * 2
            st = struct.unpack('<i', body[:4])[0]
            if st == 1:
                geom = struct.unpack('<dd', body[4:20])
            else:
                nparts, npts = struct.unpack('<ii', body[36:44])
                parts = struct.unpack('<%di' % nparts, body[44:44 + 4 * nparts])
                pts = [struct.unpack('<dd', body[44 + 4 * nparts + 16 * k: 44 + 4 * nparts + 16 * k + 16]) for k in range(npts)]
                geom = [pts[parts[k]:(parts[k + 1] if k + 1 < nparts else npts)] for k in range(nparts)]
            rec = dbf[hlen + i * rlen: hlen + (i + 1) * rlen]
            vals = {}; q = 1
            for name, typ, ln, dec in fields:
                vals[name] = rec[q:q + ln].decode(enc).strip(); q += ln
            recs.append((geom, vals))
        prj = z.read(base + '.prj').decode() if base + '.prj' in z.namelist() else ''
        out[base] = {'type': t, 'records': recs, 'prj': prj, 'cpg': cpg, 'fields': [f[0] for f in fields]}
    return out

def run_sql_script(db, script):
    con = sqlite3.connect(db)
    con.executescript(open(script, encoding='utf8').read())
    con.commit(); con.close()

def gpkg_check(db):
    con = sqlite3.connect(db)
    assert con.execute('pragma application_id').fetchone()[0] == 0x47504B47
    assert con.execute('pragma user_version').fetchone()[0] == 10300
    srs = {r[0] for r in con.execute('select srs_id from gpkg_spatial_ref_sys')}
    assert {4326, -1, 0} <= srs
    res = {}
    for t, gtn in con.execute('select table_name, geometry_type_name from gpkg_geometry_columns'):
        assert con.execute("select count(*) from gpkg_contents where table_name=? and data_type='features'", (t,)).fetchone()[0] == 1
        rows = con.execute('select * from "%s"' % t).fetchall()
        cols = [d[0] for d in con.execute('select * from "%s"' % t).description]
        for r in rows:
            blob = r[cols.index('geom')]
            assert blob[:2] == b'GP' and blob[2] == 0
        res[t] = {'type': gtn, 'cols': cols, 'n': len(rows)}
    return res

def gpkg_dump(db, out):
    """Dumps all feature tables as JSON with blobs as hex (input for the Java reader test)."""
    con = sqlite3.connect(db)
    d = {'contents': [], 'geomcol': {}, 'srs': {}, 'tables': {}}
    for r in con.execute("select table_name, identifier, srs_id from gpkg_contents where data_type='features'"):
        d['contents'].append(list(r))
    for t, c in con.execute('select table_name, column_name from gpkg_geometry_columns'): d['geomcol'][t] = c
    for sid, org, oid in con.execute('select srs_id, organization, organization_coordsys_id from gpkg_spatial_ref_sys'): d['srs'][str(sid)] = [org, oid]
    for t, in con.execute("select table_name from gpkg_contents where data_type='features'"):
        cur = con.execute('select * from "%s"' % t)
        cols = [x[0] for x in cur.description]
        rows = []
        for r in cur.fetchall():
            rows.append([('hex:' + v.hex()) if isinstance(v, bytes) else v for v in r])
        d['tables'][t] = {'cols': cols, 'rows': rows}
    json.dump(d, open(out, 'w', encoding='utf8'), ensure_ascii=False)

if __name__ == '__main__':
    cmd = sys.argv[1]
    if cmd == 'read_shp':
        r = read_shapefile(sys.argv[2])
        json.dump(r, open(sys.argv[3], 'w', encoding='utf8'), ensure_ascii=False)
    elif cmd == 'sql': run_sql_script(sys.argv[2], sys.argv[3])
    elif cmd == 'gpkg_check': print(json.dumps(gpkg_check(sys.argv[2]), ensure_ascii=False))
    elif cmd == 'gpkg_dump': gpkg_dump(sys.argv[2], sys.argv[3])
