# مصدّر المعالم v2
تطبيق أندرويد: تحميل المعالم/الطرق/الأنهار/البحيرات/السدود/الحدود الإدارية من OpenStreetMap وتصديرها Shapefile / KML / KMZ، مع محول إحداثيات (DD, DMS, UTM, MGRS).
البناء: GitHub Actions (build.yml) ← Artifacts ← apk.
